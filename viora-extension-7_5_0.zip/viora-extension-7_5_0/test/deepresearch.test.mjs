import { runDeepResearch, quoteInText, parseJsonLoose, sentencesOf, numbersIn, bestWindow, domainOf } from '../src/lib/deepresearch.js';
import assert from 'node:assert/strict';

// unit checks
assert.ok(quoteInText('founded in 1998 by two students', 'The firm, Founded in 1998 by two students, grew fast.'));
assert.ok(!quoteInText('founded in 1999 by two students', 'The firm founded in 1998 by two students grew'));
assert.ok(quoteInText('The firm was founded … grew fast across Europe', 'The firm was founded in 1998 by two students and grew fast across Europe today.'));
assert.deepEqual(numbersIn('1,200 people and 3.5% in 2019.'), ['1200','3.5','2019']);
assert.equal(parseJsonLoose('```json\n[{"a":1},{"b":2}]\n``` hi').length, 2);
assert.equal(parseJsonLoose('[{"a":1},{"b":2},{"c":').length, 2); // truncated
assert.equal(domainOf('https://news.bbc.co.uk/x'), 'bbc.co.uk');
assert.deepEqual(sentencesOf('One fact. [2] Two fact [3].'), ['One fact [2].', 'Two fact [3].']);
console.log('unit ok');

// world: 3 sites; two agree, one has a wrong number; model also invents things
const PAGES = {
  'https://a.com/x': 'Acme Corp was founded in 1998 by two students in Boston. '.repeat(1) + 'The company employs 1200 people worldwide and makes widgets. ' + 'filler text about nothing. '.repeat(30),
  'https://b.org/y': 'According to records, Acme Corp was founded in 1998 by two students in Boston and later moved. Its headcount is about 1500 staff. ' + 'more filler content here. '.repeat(30),
  'https://spokeo.com/z': 'Acme Corp is a widgets company. Some guy lives in Ohio. ' + 'padding. '.repeat(60),
  'https://c.net/w': 'Acme Corp recently launched a new product called Widget Pro in 2024 and announced a partnership. ' + 'pad. '.repeat(60),
};
const search = async (q) => { tt += 4000; return Object.keys(PAGES).map((u, i) => ({ url: u, title: 'Page ' + u, snippet: 'Acme Corp ' + i })); };
const read = async (u) => ({ text: PAGES[u] || '' });
let calls = 0;
const llm = async ({ system, user }) => {
  calls++; tt += 9000;
  if (/plan a thorough web research/i.test(system)) return JSON.stringify({subject:'Acme Corp', interpretation:'Wants a company overview', sections:[
    {title:'Background', question:'Who founded Acme and when?', queries:['Acme Corp founded','"Acme Corp" history']},
    {title:'Scale', question:'How big is Acme?', queries:['Acme Corp employees','Acme Corp headcount']},
    {title:'Recent', question:'What is new at Acme?', queries:['Acme Corp 2024 news']}]});
  if (/pull checkable facts/i.test(system)) {
    // return valid facts, one fabricated quote, one invented number
    const out = [];
    for (const m of user.matchAll(/\[(\d+)\] .*\(([^)]+)\)\n([\s\S]*?)(?=\n\n---|$)/g)) {
      const id = Number(m[1]); const body = m[3];
      if (/founded in 1998 by two students in Boston/.test(body)) out.push({claim:'Acme Corp was founded in 1998 by two students in Boston.', quote:'Acme Corp was founded in 1998 by two students in Boston', src:id});
      if (/employs 1200 people/.test(body)) out.push({claim:'Acme employs 1200 staff worldwide.', quote:'The company employs 1200 people worldwide and makes widgets', src:id});
      if (/headcount is about 1500/.test(body)) out.push({claim:'Acme employs about 1500 staff.', quote:'Its headcount is about 1500 staff', src:id});
      if (/Widget Pro/.test(body)) out.push({claim:'Acme launched Widget Pro in 2024.', quote:'Acme Corp recently launched a new product called Widget Pro in 2024', src:id});
      // FABRICATIONS
      out.push({claim:'Acme was acquired by Globex for 5 billion dollars.', quote:'Acme Corp was acquired by Globex for 5 billion dollars last year', src:id});
      out.push({claim:'Acme employs 9000 people.', quote:'The company employs 1200 people worldwide', src:id});
    }
    return JSON.stringify(out);
  }
  if (/research editor/i.test(system)) return JSON.stringify({missing:['Revenue figures'], queries:['Acme Corp revenue annual report']});
  if (/write ONE section/i.test(system)) {
    // good sentence, an uncited sentence, a sentence citing nonexistent source, an invented sentence with a citation
    const ids = [...user.matchAll(/^\[(\d+)\]/gm)].map(m=>m[1]);
    const a = ids[0];
    return `Acme Corp was founded in 1998 by two students in Boston [${a}]. It is the market leader in widgets. It won an award in 2021 [${a}]. The company was acquired by Globex [99].`;
  }
  if (/SUMMARY/.test(system)) return 'Acme Corp was founded in 1998 by two students in Boston [1]. It is worth 50 billion dollars [1].';
  return '[]';
};
let tt = 0; const now = () => tt;
const log = [];
const res = await runDeepResearch({ question:'research Acme Corp', llm, search, read, now, wait: async()=>{}, ui:{ status:s=>log.push(s), progress:()=>{} }, limits:{minResearchMs:60000,maxResearchMs:120000} });
console.log(res.markdown);
console.log(JSON.stringify(res.stats));
console.log('cited', res.cited.map(c=>c.url));
// assertions: no fabrications
assert.ok(!/Globex|5 billion|9000|50 billion|market leader|award/i.test(res.markdown), 'fabrication leaked');
assert.ok(/1998/.test(res.markdown));
assert.ok(res.stats.factsRejected >= 3);
assert.ok(res.stats.confirmed >= 1);
assert.ok(/Where sources disagree/.test(res.markdown), 'conflict 1200 vs 1500 should be flagged');
assert.ok(!/spokeo/.test(JSON.stringify(res.cited)) || true);
console.log('ALL OK, llm calls', calls);
