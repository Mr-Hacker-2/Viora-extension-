import * as ap from '../../src/lib/autopilot.js';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? 'ok  ' : 'FAIL', m); };
const nosleep = () => Promise.resolve();

// ---- a fake browser: tabs + a scriptable page behind the content-script messages
const page = { url: 'https://shop.test/', title: 'Shop', fp: 'a', value: '', acceptFill: 0, clicks: [], onClick: () => {} };
let tabs = { 1: { id: 1, status: 'complete', url: page.url, title: 'Shop' } };
globalThis.chrome = {
  tabs: {
    get: async (id) => { if (!tabs[id]) throw new Error('no tab'); return tabs[id]; },
    update: async (id, p) => { Object.assign(tabs[id], p, p.url ? { status: 'complete' } : {}); if (p.url) page.url = p.url; return tabs[id]; },
    create: async ({ url }) => { tabs[2] = { id: 2, status: 'complete', url, title: 'New' }; return tabs[2]; },
    reload: async () => {},
    sendMessage: async (id, msg) => {
      if (msg.type === 'viora:probe') return { url: page.url, title: page.title, fp: page.fp, ready: true, busy: false };
      if (msg.type === 'viora:act') {
        const a = msg.action;
        if (a.type === 'fill') {
          if (page.acceptFill-- > 0) page.value = a.value; else if (page.acceptFill < -1) page.value = '';
          return { ok: true, detail: 'Filled', readback: page.value };
        }
        if (a.type === 'click') { page.clicks.push(a.ref); page.onClick(); return { ok: true, detail: 'Clicked' }; }
        return { ok: true, detail: 'ok' };
      }
      return {};
    },
    onUpdated: { addListener() {}, removeListener() {} }
  },
  scripting: { executeScript: async () => {} }
};
const { runPlan, parsePlan, describeAction } = await import('../../src/lib/automation.js');

// ---- run record + checkpoint storage
const mem = {};
const area = { get: async (k) => ({ [k]: mem[k] }), set: async (o) => Object.assign(mem, o), remove: async (k) => { delete mem[k]; } };
const run = ap.newRun({ prompt: 'Compare three laptops', linux: false, tabId: 1 });
run.history.push('- Click element 3: Clicked "Search"');
run.pending = { actions: [{ type: 'click', ref: 3 }, { type: 'fill', ref: 4, value: 'x' }], done: 1 };
await ap.saveRun(run, area);
const back = await ap.loadRun(area);
ok(back && back.prompt === 'Compare three laptops' && back.history.length === 1 && back.pending.done === 1, 'checkpoint round-trips plan progress and the in-flight batch');
ok(ap.recoverOnStartup(back).status === 'interrupted', 'a run still "running" at startup is marked interrupted');
ok(ap.recoverOnStartup({ ...back, status: 'paused' }).status === 'paused', 'paused runs stay paused');
ok(ap.isResumable(ap.recoverOnStartup(back)), 'interrupted runs can be resumed');
ok(!ap.isResumable({ ...back, status: 'done' }) && !ap.isResumable({ ...back, status: 'cancelled' }), 'finished and cancelled runs are not resumable');
const ctx = ap.resumeContext({ ...back, note: 'The panel closed.' });
ok(/1 of 2 steps had run/.test(ctx) && /Do NOT assume/.test(ctx), 'resume tells the planner what was in flight and not to assume it finished');
await ap.clearRun(area);
ok((await ap.loadRun(area)) === null, 'clearRun removes the checkpoint');
const failing = { get: async () => { throw new Error('x'); }, set: async () => { throw new Error('quota'); }, remove: async () => { throw new Error('x'); } };
ok((await ap.saveRun(run, failing)) === false && (await ap.loadRun(failing)) === null, 'storage errors never throw into the task');
const big = ap.newRun({ prompt: 'x' });
for (let i = 0; i < 500; i++) { ap.addTimeline(big, { text: 's' + i }); big.history.push('h'.repeat(3000)); }
const cp = ap.checkpointOf(big);
ok(big.timeline.length <= ap.MAX_TIMELINE && cp.history.length <= ap.MAX_HISTORY && cp.history.every((h) => h.length <= 1510), 'checkpoint is bounded');

ok(['continue', 'Resume', 'retry', 'try again', 'keep going.', 'ok, continue'].every(ap.isResumeCommand), 'resume phrases recognised');
ok(!ap.isResumeCommand('continue to checkout and buy the laptop') && !ap.isResumeCommand('open the first result'), 'real tasks are not mistaken for "continue"');

// ---- pause / resume / cancel
const c = ap.makeControl();
let passed = false;
c.pause();
const gated = c.gate().then(() => { passed = true; });
await new Promise((r) => setTimeout(r, 20));
ok(!passed, 'gate holds while paused');
c.resume(); await gated;
ok(passed && c.state === 'running', 'gate releases on resume');
c.pause();
const p2 = c.gate().then(() => 'passed', (e) => e);
c.cancel();
const e2 = await p2;
ok(e2 instanceof ap.RunCancelled && e2.name === 'AbortError' && e2.cancelled, 'cancel while paused releases the gate with a cancel error');
ok(c.state === 'cancelled' && (c.resume(), c.state === 'cancelled'), 'a cancelled run cannot be resumed');
const c3 = ap.makeControl(); c3.stop();
ok(await c3.gate().then(() => false, (e) => e.kind === 'stopped' && !e.cancelled), 'stop is distinct from cancel (stays resumable)');

// ---- verification
const V = ap.verifyStep;
ok(V({ type: 'fill', value: 'hello' }, null, null, { readback: 'hello' }).verified === true, 'fill verified when the field shows the text');
ok(V({ type: 'fill', value: 'hello' }, null, null, { readback: '' }).verified === false, 'fill fails when the field stayed empty');
ok(V({ type: 'fill', value: '4111 1111' }, null, null, { readback: '41111111' }).verified === true, 'fill accepts a reformatted number');
ok(V({ type: 'fill', value: 'x' }, null, null, {}).verified === null, 'fill with no readback is unknown, not failed');
ok(V({ type: 'click' }, { url: 'https://a.com/', fp: '1' }, { url: 'https://a.com/next', fp: '1' }).verified === true, 'click verified by a new address');
ok(V({ type: 'click' }, { url: 'https://a.com/', fp: '1' }, { url: 'https://a.com/', fp: '2' }).verified === true, 'click verified by the page changing');
ok(V({ type: 'click' }, { url: 'https://a.com/', fp: '1' }, { url: 'https://a.com/', fp: '1' }).verified === null, 'a click that changes nothing is "not verified"');
ok(V({ type: 'click' }, { url: 'https://a.com/', fp: '1' }, { url: 'https://a.com/#/cart', fp: '1' }).verified === true, 'a hash-route change (single-page app) counts as a change');
ok(V({ type: 'navigate', url: 'https://www.a.com/x' }, null, { url: 'https://a.com/x' }).verified === true, 'navigate ignores www');
ok(V({ type: 'navigate', url: 'https://a.com/x' }, null, { url: 'https://login.b.com/' }).verified === null, 'navigate that lands elsewhere is flagged, not failed');
ok(V({ type: 'navigate', url: 'https://a.com/x' }, null, { url: 'chrome://x', restricted: true }).verified === false, 'navigate into a restricted page fails');

// ---- permission-aware + retry policy
ok(['Buy now', 'Place order', 'Delete account', 'Send message', 'Submit', 'Pay $20', 'Confirm purchase', 'Log out'].every(ap.isConsequentialLabel), 'consequential labels need confirmation');
ok(['Search', 'Next', 'Add to cart', 'Show more', 'Sign in', 'Read the terms'].every((l) => !ap.isConsequentialLabel(l)), 'ordinary labels do not');
ok(ap.isSafeToRetry({ type: 'fill' }) && ap.isSafeToRetry({ type: 'click' }, 'Next') && !ap.isSafeToRetry({ type: 'click' }, 'Place order') && !ap.isSafeToRetry({ type: 'shell' }) && !ap.isSafeToRetry({ type: 'open_tab' }), 'retry-safety rules');
ok(ap.classifyFailure('No element with ref 9. Take a fresh snapshot.') === 'stale-ref', 'stale ref recognised');
ok(/RECOVERY/.test(ap.recoveryAdvice({ type: 'click', ref: 9 }, { detail: 'No element with ref 9' }, 'Next')) && /check the page state first/.test(ap.recoveryAdvice({ type: 'click', ref: 9 }, { detail: 'boom' }, 'Place order')), 'recovery advice warns against blind repeats of consequential steps');
ok(/\[verified\]/.test(ap.describeResult('Click', { ok: true, detail: 'Clicked', verified: true })) && /NOT VERIFIED/.test(ap.describeResult('Click', { ok: true, detail: 'Clicked', verified: null, check: 'Nothing changed.' })), 'log lines carry the verification tag');

// ---- waiting for a dynamic page
let n = 0; const seq = ['a', 'b', 'c', 'c', 'c'];
const r1 = await ap.waitForSettled(async () => ({ url: 'u', fp: seq[Math.min(n++, 4)] }), { sleep: nosleep, intervalMs: 1 });
ok(r1.settled && r1.probe.fp === 'c', 'waits until the page stops changing');
let t = 0;
const r2 = await ap.waitForSettled(async () => ({ url: 'u', fp: String(t) }), { sleep: async () => { t++; }, now: () => t * 100, timeoutMs: 1000 });
ok(!r2.settled, 'gives up at the timeout on a page that never settles');
const r3 = await ap.waitForSettled(async () => ({ url: 'u', fp: 'x', busy: true }), { sleep: nosleep, now: (() => { let k = 0; return () => (k += 500); })(), timeoutMs: 2000 });
ok(!r3.settled, 'a page that says it is busy is not settled');
ok((await ap.waitForSettled(async () => { throw new Error('gone'); }, { sleep: nosleep, now: (() => { let k = 0; return () => (k += 2000); })(), timeoutMs: 3000 })).settled === false, 'probe errors do not crash the wait');

// ---- tabs
const tr = ap.newRun({ prompt: 'x' });
ap.noteTab(tr, { id: 1, url: 'https://a.com', title: 'A' }); ap.noteTab(tr, { id: 2, url: 'https://b.com', title: 'B' }); ap.noteTab(tr, { id: 1, title: 'A2' });
ok(tr.tabs.length === 2 && tr.tabs[0].title === 'A2' && tr.tabs[0].url === 'https://a.com', 'tab list keeps one entry per tab and merges updates');
ok(/1\. A2\n2\. B {2}\(current\)/.test(ap.tabListText(tr, 2)), 'tab list marks the current tab');
const sw = parsePlan('{"actions":[{"type":"switch_tab","tab":2},{"type":"switch_tab","tab":"x"},{"type":"switch_tab"}]}');
ok(sw.actions.length === 1 && sw.actions[0].tab === 2 && describeAction(sw.actions[0]) === 'Switch to tab 2', 'switch_tab parsed; bad tab numbers dropped');

// ---- runPlan against the fake page
const sig = (o) => o.map((r) => `${r.action.type}:${r.ok}${r.verified === true ? ':v' : r.check ? ':?' : ''}`).join(',');
{ // fill is rejected once, then accepted: retried automatically
  Object.assign(page, { value: '', acceptFill: 1 });
  const res = await runPlan(1, { actions: [{ type: 'fill', ref: 2, value: 'laptop' }] }, () => {}, {}, {});
  ok(res.results[0].ok && res.results[0].retried === undefined || res.results[0].ok, 'fill that sticks needs no retry');
}
{
  Object.assign(page, { value: '', acceptFill: 0 }); // first write dropped, second accepted
  let calls = 0; const orig = chrome.tabs.sendMessage;
  chrome.tabs.sendMessage = async (id, msg) => {
    if (msg.type === 'viora:act' && msg.action.type === 'fill') { calls++; return { ok: true, detail: 'Filled', readback: calls === 1 ? '' : msg.action.value }; }
    return orig(id, msg);
  };
  const res = await runPlan(1, { actions: [{ type: 'fill', ref: 2, value: 'laptop' }] });
  ok(res.results[0].ok && res.results[0].retried === true && calls === 2, 'a fill the page dropped is retried once and then succeeds');
  calls = -10; chrome.tabs.sendMessage = async (id, msg) => (msg.type === 'viora:act' ? { ok: true, detail: 'Filled', readback: '' } : orig(id, msg));
  const bad = await runPlan(1, { actions: [{ type: 'fill', ref: 2, value: 'laptop' }, { type: 'click', ref: 3 }] });
  ok(bad.results.length === 1 && !bad.results[0].ok && /still empty/.test(bad.results[0].detail), 'a field that stays empty is a failure and stops the batch');
  chrome.tabs.sendMessage = orig;
}
{ // a click that changes the page is verified; one that changes nothing ends the batch with a warning
  page.fp = 'a'; page.onClick = () => { page.fp = 'b'; };
  let res = await runPlan(1, { actions: [{ type: 'click', ref: 1 }, { type: 'scroll', to: 'top' }] }, () => {}, {}, {});
  ok(sig(res.results) === 'click:true:v,scroll:true', 'click verified by page change, batch continues: ' + sig(res.results));
  page.onClick = () => {};
  res = await runPlan(1, { actions: [{ type: 'click', ref: 1 }, { type: 'scroll', to: 'top' }] }, () => {}, {}, {});
  ok(sig(res.results) === 'click:true:?' && /Nothing on the page/.test(res.results[0].check), 'click with no visible effect is flagged and ends the batch');
}
{ // consequential click: asked first, denied -> not performed
  page.clicks = [];
  const labels = new Map([[7, 'Place order'], [8, 'Next']]);
  let asked = 0;
  const res = await runPlan(1, { actions: [{ type: 'click', ref: 7 }] }, () => {}, {}, { labels, confirm: async () => { asked++; return 'deny'; } });
  ok(asked === 1 && !res.results[0].ok && !page.clicks.includes(7), 'declining "Place order" means it is never clicked');
  page.onClick = () => { page.fp += 'x'; };
  await runPlan(1, { actions: [{ type: 'click', ref: 8 }] }, () => {}, {}, { labels, confirm: async () => { asked++; return 'deny'; } });
  ok(asked === 1 && page.clicks.includes(8), 'an ordinary click does not ask');
  await runPlan(1, { actions: [{ type: 'click', ref: 7 }] }, () => {}, {}, { labels, confirm: async () => 'allow' });
  ok(page.clicks.includes(7), 'allowing it performs the click');
}
{ // cancel stops before the next step runs
  page.clicks = []; page.onClick = () => { page.fp += 'y'; };
  const ctl = ap.makeControl(); let done = 0;
  let threw = null;
  try {
    await runPlan(1, { actions: [{ type: 'click', ref: 1 }, { type: 'click', ref: 2 }, { type: 'click', ref: 3 }] }, () => { if (++done === 1) ctl.cancel(); }, {}, { gate: () => ctl.gate() });
  } catch (e) { threw = e; }
  ok(threw?.cancelled && page.clicks.length === 1, 'cancel after step 1 stops before step 2: ' + page.clicks.join(','));
}
{ // pause holds the next step until resumed
  page.clicks = []; page.onClick = () => { page.fp += 'z'; };
  const ctl = ap.makeControl(); let started = 0;
  const running = runPlan(1, { actions: [{ type: 'click', ref: 1 }, { type: 'click', ref: 2 }] }, (s) => { if (s.action.ref === 1) ctl.pause(); }, {}, { gate: () => ctl.gate(), onStart: () => started++ });
  await new Promise((r) => setTimeout(r, 400));
  ok(page.clicks.length === 1 && started === 1, 'paused between steps: second click has not run');
  ctl.resume(); await running;
  ok(page.clicks.length === 2, 'resuming lets the rest run');
}
{ // navigation is verified and tabs are reported; switch_tab works
  const seen = [];
  const res = await runPlan(1, { actions: [{ type: 'navigate', url: 'https://shop.test/cart' }] }, () => {}, {}, { onTab: (t) => seen.push(t) });
  ok(res.results[0].ok && res.results[0].verified === true && seen[0]?.url === 'https://shop.test/cart', 'navigate verified and reported to the tab list');
  const opened = await runPlan(1, { actions: [{ type: 'open_tab', url: 'https://other.test/' }, { type: 'switch_tab', tab: 1 }] }, () => {}, {}, { tabs: () => [{ id: 1 }, { id: 2 }] });
  ok(opened.results.length === 2 && opened.finalTabId === 1, 'open_tab then switch_tab back to tab 1');
  const bad = await runPlan(1, { actions: [{ type: 'switch_tab', tab: 9 }] }, () => {}, {}, { tabs: () => [{ id: 1 }] });
  ok(!bad.results[0].ok && /no tab 9/.test(bad.results[0].detail), 'switching to a tab that does not exist fails cleanly');
}

console.log(pass + ' passed, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
