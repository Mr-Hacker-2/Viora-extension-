# Viora

A browser side panel with five assistants in it. Everything runs on Groq's free
tier, so there is no API key to find, paste, or pay for — install it and talk.

## What changed in this build

- **7.20.1 — Automate is much faster.** (1) The planner chain now leads with the fast Nemotron 3.5 Lightning; the big reasoning models are fallbacks (`src/lib/models.js`, swap the order back if plan quality drops). (2) The reviewer only runs when a plan can run commands, write or upload files, leave for another site, or click something that looks like buy/send/delete; routine plans skip it, and review is capped at two rounds instead of three. (3) Verification waits are shorter (1.2–1.5 s cap, 150 ms polling) and the pause between steps is 60 ms. The Workspace tab's copy of the loop (`src/tab/tab.js`) is not changed.

- **7.20.0 — Autopilot, phase 1: Automate that survives trouble.**
  1. **Checkpoints.** The task, its finished steps, the tabs it used and the batch that was in flight are saved after every step (`src/lib/autopilot.js`, key `viora_autopilot_run`). Close the panel, reload it or lose the browser, and next time Viora shows **You have an unfinished task — Resume / Discard**. Saying "continue" or "retry" in Automate picks the saved task up (it used to start a new task called "continue"). A resumed run is told what was mid-flight and not to assume it finished; the turn and step limits count from the restart, so a task that hit its cap gets a fresh allowance.
  2. **Pause, resume, cancel, retry.** A run bar sits above each task: **Pause** holds the next step (a model call already in flight finishes first), **Cancel** ends and discards the task, the panel's Stop button ends it but keeps it resumable. A run that stops on a problem shows **Retry** and **Discard**. A provider error mid-task no longer throws the work away: it stays saved with a Retry button.
  3. **Steps are checked.** A fill reads the field back; if the page dropped or changed the text it is retried once and, if it still doesn't stick, reported as a failure. A click compares the page before and after (address, visible elements); no change is logged as `[NOT VERIFIED]`, ends the batch, and tells the planner to look before relying on it. Navigations confirm where the tab really landed (a redirect to another host is flagged, a browser-only page is a failure). The log marks `[verified]`, `[NOT VERIFIED …]` and `[retried once]`.
  4. **Recovery.** A failed step adds a `RECOVERY:` line for the planner: stale ref → find it again by label; slow page → wait or reload; declined → don't retry; and whether repeating it is safe. Safe-to-retry is decided by rule (fills, scrolls, reads, reloads yes; clicks only when the label isn't a buy/send/delete; commands, file writes and new tabs never). Pages are also waited on until they stop changing (`waitForSettled`, using a new `viora:probe` that does not renumber refs), a snapshot that fails once is retried, and a task whose tab was closed carries on in another tab it used.
  5. **Several tabs.** The task keeps a tab list, shown to the planner as "Tabs in this task", and a new `switch_tab` action moves between them without opening the site twice.
  6. **Permission-aware clicks.** A click whose label looks like buying, paying, sending, deleting, submitting, logging out and similar asks first with the same card Linux commands use. Declining means it is never clicked.
  7. **Activity timeline.** Each task has a collapsible Activity list: every step with a time, a ✓ when verified, ⚠ when not.
  8. **Tests.** `test/node/autopilot.test.mjs` (54 checks): checkpoints, startup recovery, pause/resume/cancel/stop, verification rules, retry safety, settle waiting, tabs, and the real step runner against a fake page (dropped fill retried, unverified click ends the batch, declined "Place order" never clicked, cancel between steps, pause holds the next step, switch_tab).
  Honest limits: Automate still runs inside the panel, so it is paused (and checkpointed) when the panel closes, not continued in the background. "Verified" is evidence from the page, not proof the site accepted the action; a [NOT VERIFIED] step can still have worked.

- **7.16.0 — Planner, an agent that comes built in.** Type **@planner** and it turns a goal into a step-by-step plan: a one-line summary, a numbered checklist grouped by day or phase, time estimates, risks, and one clear "Next step". It asks one short question first only if a missing detail would change the plan. It is added once on first load (delete it and it stays deleted) and is also the first one-tap idea in Create agent, so you can bring it back or tweak it. Flash can hand planning jobs to it on its own.

- **7.15.1 — Sources panel fix.** "…" → Sources now opens a numbered list (logo, title, site, each a real link) and scrolls it into view, so it can no longer open off-screen below the latest reply. Press Sources again, or ×, to hide it. The "…" menu flips below its button when there's no room above.

- **7.15.0 — Chat that doesn't get cut off, a tidy "…" menu, emoji everywhere, and Viora Flash builds your agents.**
  1. **Enter no longer stops an answer.** While an AI is looking things up or writing, pressing Enter keeps your next message and sends it the moment the reply is done (“Got it — I’ll send that as soon as this answer is done ⏳”). Only a click on the Stop button ends an answer.
  2. **Sources live in a "…" menu.** Nothing is drawn on the answer itself any more (no logo badge on top, no source strip below). Under every reply: Copy, Star and **…**. Click it for **Read aloud** and, only when the answer really used the web, **Sources**. An ordinary conversation never shows any.
  3. **Emoji from every assistant.** Flash, Math & Code, Deep Search and every agent now use emoji frequently. Settings → Emoji is now just *None* or *Frequent* (an old "light touch" setting becomes Frequent); *None* is still respected. The Humanizer is left alone on purpose — it has to return clean rewritten text.
  4. **Create agent is now a chat with Viora Flash.** Flash asks one question at a time, and when an answer is vague or it didn't understand, it says so and asks again instead of guessing. When it has enough it writes the agent, saves it, and shows it in your **@** list straight away, with *Use it now / Review / See my agents*. "Enough questions — create it now" ends the chat early; "Skip the chat" still opens the plain form.
  5. **Tests.** 14 new checks in `test/node/agents.test.mjs` (interview replies, fenced/half-written JSON, emoji rules).

- **7.14.0 — Any assistant can use Agents, memory is fully shared, and the Linux bridge is harder to hang.**
  1. **Every assistant can reach your Agents.** Typing `@handle` now works from any of the five assistants, including Automate and the Humanizer — the mention always wins over that mode's own default for the turn. Flash, Math & Code and Deep Search can also decide *on their own* to hand a task to an agent (not just Flash as before) when one clearly fits.
  2. **Memory is one shared store.** Facts and conversation notes were already read by every assistant and agent; now agent turns also *write* to that memory, the same as an ordinary chat turn, so something you tell an agent is remembered the next time any assistant needs it.
  3. **Agent creation already interviews you.** "New agent" asks you questions one at a time and has the AI write the actual instructions from your answers — this was already the default and needed no change; the plain form is still there as a shortcut via "Skip".
  4. **Linux bridge hardening (host 1.2.0).** The streamed-command loop can no longer hang forever if a kill attempt silently fails (WSL losing track of a session, a missing `pkill`): it retries the kill once, then force-closes the command's output and reports `forcedClose` rather than wedging the host process. `state.json` (the remembered working folder) is now written atomically and guarded with a real file lock, so two commands starting close together can't race and drop each other's `cd`. Failures that used to be swallowed silently now go to `~/.viora/host.log`. The extension side adds a 15-second startup timeout so a stuck or slow-to-launch host surfaces a clear error instead of hanging the chat. **Update the helper**: run the installer again (Settings → Linux shows the command), then restart the browser.

- **7.13.1 — Watch Linux commands run, and get told when they finish.**
  1. **Live card.** When the AI runs a command in Linux (chat, agents or Automate), a card appears under the reply showing a clock, the newest output as it is printed, and a **Stop** button. If the tool prints a percentage the card grows a progress bar with the time left (nmap's `About 45.20% done … (0:01:23 remaining)`, apt, curl, wget, pip, rsync, ffmpeg and similar). If nothing prints for 10 seconds it says "Still running · no new output for 0:14", so a quiet scan doesn't look frozen. The panel's status line shows the percentage too.
  2. **Told when it's done.** The card turns green (**Finished in 1:12**), red (**Failed after … · exit 1**, **Timed out**) or grey (**Stopped**) and shows the last line of output, e.g. nmap's "scanned in 31.40 seconds". For anything that ran 8 seconds or more, while the panel isn't in front, you also get a browser notification. Switch it off in Settings → Linux.
  3. **Stop really stops.** Stop (or the panel's own stop button, or closing the panel) ends the command and everything it started, not just the shell. The AI is told it was stopped by you and won't rerun it.
  4. **Long jobs.** A chat AI can ask for more than the 120-second default by starting its command block with `# timeout=900` (seconds, up to 3600); Automate already had `"timeout"`. The AIs are told to make slow tools report progress (`nmap -v --stats-every 5s`, no `-q`) and to run security tools only against machines and networks you own or have written permission to test.
  5. **Update the helper once.** Streaming needs the new `native-host/viora_host.py` (host 1.1.0). Run the installer again (Settings → Linux shows the command), then restart the browser. With the old helper everything still works, you just don't get live output, and the card says so.
  6. **Tests.** `test/node/linux-live.test.mjs` (21 checks: progress parsing, `\r` progress bars, the tail buffer, the timeout directive) and 6 new streaming checks in `native-host/test_host.py` (live output, same final result, no bookkeeping lines leaking, cancel kills the whole tree, timeout).

- **7.13.0 — Agents (summon with @), and Linux for every chat AI.**
  1. **Create agent.** "+" menu → **Create agent** (or type `@` and pick *Create agent*). Give it a name, an icon, instructions, a brain (Flash, Math & Code or Deep Search) and what it may do: **use Linux**, **search the web**. Four one-tap starting ideas (Linux Helper, Code Reviewer, Researcher, Writing Coach). The list screen has Use / Edit / Delete. Agents are stored on-device (`viora_agents` in `chrome.storage.local`), up to 24.
  2. **Summon with @.** Type `@` in the message box and a picker lists your agents (arrow keys, Enter or Tab, or click). The agent answers in its own bubble with its icon and name, in its own voice: its instructions come right after the base prompt and outrank Viora's defaults. Mention several (`@linux-helper then @code-reviewer`) and each answers in turn, seeing the earlier replies. Handles stay stable when you rename an agent. `@` does nothing inside Humanizer and Automate.
  3. **Viora Flash can talk to your agents.** Flash is shown the roster (handle, what it can do, what it is for). When an agent's job clearly fits, or you ask Flash to ask one, Flash hands it the task, the agent replies in its own bubble, and Flash answers you from that reply. One round, at most two agents, and agents don't call each other (no loops).
  4. **Linux in chat.** Any chat AI (Flash, Math & Code, and any agent you allowed) can run commands when *Settings → Linux → Let Viora use Linux* is on. It writes one ```` ```viora-shell ```` block, Viora shows the same **Run it / Run, and stop asking this task / Don't run** card as Automate (red warning for risky commands), runs it through the bridge, hands back the exit code and output, and the AI carries on: fix, retry, continue, up to 12 commands per message. Results appear as a collapsible card and survive reloading the chat. Deep Search does not use Linux (its prompt is built around citing sources). The install steps for the bridge are unchanged (`native-host/`).
  5. **Safety.** Output from commands and files is declared untrusted data in the prompt; an agent without the Linux switch is never shown the Linux note and a command it writes anyway is ignored; a failed turn undoes everything since your last message (replies, command results, agent turns) before "Try again".
  6. **Tests.** `test/node/agents.test.mjs` (42 checks: handles, mentions, the picker's caret logic, roster and Linux prompts, tool-block parsing, how the chat job builds an agent turn).

- **7.12.0 — no searching for chit-chat or writing jobs, and a stronger Humanizer.**
  1. **Smarter "do I need the web?"** `skipsWeb` (`src/lib/web.js`) now sits on top of `isCasualChat`. Besides "hi" and "what are you?", these skip the web pass, the page read and the sources: writing and rewriting jobs ("write a poem", "rewrite this email: ..."), code and maths ("how do I reverse a string", "what is 15% of 240"), and conversation about the last reply ("explain that again", "shorter", "what do you think?"). Anything time-sensitive (latest, price, news, weather, a recent year, "who is the CEO of...") or with a link in it still searches, and with a pasted text only the instruction before the colon is judged, so "rewrite this: ...price results..." doesn't search. Those turns get `NOWEB_NOTE`: answer fully from knowledge, no citations, never claim to have searched, and flag anything that might be out of date. Replies are *not* shortened the way small talk is. Deep Search always researches.
  2. **Humanizer output cleanup.** `cleanOutput` strips "Here's the rewritten version:", a code fence, quotes around the whole reply and closing offers ("Let me know if...") before scoring, so chatter is never counted as the text or shown to you.
  3. **More machine tells caught.** About 20 new patterns: participle tails (", ensuring that...", ", highlighting..."), "stands as a testament/cornerstone/beacon", "in the realm of", "it's worth noting", "first and foremost", "a profound impact", "harness/unleash/spearhead", "meticulous/unparalleled/invaluable" and more. They feed the local score and the flagged-sentence repair.
  4. **Prompt.** New rules: no participle tails, and keep within about 15% of the original length (no padding, no cutting points).
  5. **Tests.** `test/node/humanizer.test.mjs` covers the gate (11 no-web, 9 still-searches cases), `cleanOutput`, the new tells and the note wiring.

- **Unreleased — AI quality pass: a Humanizer that stops sounding like Grammarly, and a smarter Deep Search.**
  1. **Humanizer prompt rewritten.** The old prompt asked for "plain, specific" prose and the model answered with clean, balanced, professional text, which is exactly what a grammar tool produces and what detectors (and readers) recognise. The new prompt says outright that the goal is *not* better writing, describes the human texture to aim for (uneven rhythm, spoken glue like "And/But/So", asides, fragments, a person behind the words, imperfect-but-correct sentences, no tidy closers), and shows three *original / too polished (wrong) / human (right)* examples. It also bans the "editor voice" words (enhance, streamline, empower, valuable insights…) and semicolons.
  2. **A "too clean" signal in the local check.** `analyzeText` now measures human texture: fragments, And/But openers, questions, brackets, a person speaking, spoken hedges. A text with none of them is flagged and the retry tells the model to let a person back in. Formal text is judged more leniently.
  3. **Register-aware.** `registerOf` / `registerHint` classify the source as casual, neutral or formal and tell the model to keep that level; the deterministic word swaps (obtain→get, ensure→make sure, numerous→many…) are skipped for formal text so an essay stays an essay.
  4. **Better polish pass.** Swaps no longer produce odd phrases ("makes room for", "whole-picture", "a many of"); rhythm joins use ", and" / ", but" instead of semicolons; retry voices ask for untidy, spoken output instead of a "thoughtful blogger".
  5. **Deep Search report engine.** (a) *Gap-aware follow-ups:* every other search round the model sees the facts already verified and the searches already tried, and proposes searches for what is still missing, using names and terms from those facts. (b) *Conflicts are no longer swallowed:* two pages giving different numbers for the same claim used to be merged as one fact; they are now kept apart and shown under **Where sources disagree**, newest page first. (c) *Dates:* each page's publication month travels with its facts, the writer may say "as of March 2025", and the checker accepts only dates the evidence contains. (d) New computed section **To close the gaps** with searches not yet tried for thin sections. (e) More pages per round, more links followed, higher pace, wider trusted-site list. (f) The section writer is told to explain rather than list facts. (g) The report plan prompt is intent-aware (person, company, product, health/science, decision, other).
  6. **Everyday Deep Search.** Query variants now quote the names in the question and add angles for "latest", comparisons and evidence questions (5 instead of 4); results are capped at two per site, trusted sources move up, people-finders move down, and a page several queries agree on moves up. Prompt: answer the actual question first, synthesise across sources, rank by source quality.
  7. **Notebooks.** Passage retrieval now weights rare words, matches word stems and rewards adjacent query words; the chat prompt leads with the answer and draws on every relevant reference.
  8. **Tests.** New cases in `test/node/humanizer.test.mjs` and `test/tests.js` (gap-aware searches, dates, disagreements). Two stale prompt assertions were updated.

- **Unreleased — Humanizer, Automate and Deep Search hardening, plus a separate Workspace page.**
  1. **Humanizer:** after a detector (or Viora's own check) flags sentences, it now rewrites *only those sentences* first and keeps the rest, falling back to the whole-text rewrites if that doesn't help. A replacement that drops a number, link or quote is rejected. New optional *writing sample* box in Settings: Viora measures your sentence length, contractions, commas, dashes and openers and matches those habits (it never copies your sentences).
  2. **Automate:** page text that reads like instructions to an AI ("ignore previous instructions", "reveal the API key", `curl … | sh`) is marked UNTRUSTED in the element list and the planner and reviewer are told to refuse it. New rules for recovering from a failed step, checking that an action really worked, and stopping at logins, CAPTCHAs and payments.
  3. **Deep Search and everyday web answers:** each source now shows its publication date (read from the page's own metadata, or "date not found"); answers must keep source facts apart from inference, show conflicting sources with dates, and say "I couldn't verify this" instead of guessing.
  4. **Workspace page** (`src/workspace/`): the logo button now opens a task / docs / goals workspace where the AI can propose tasks and doc edits for approval.
  5. **Tests:** `npm test` runs Node tests for the above (`test/node/`), and `.github/workflows/test.yml` runs them on every push. The browser test page is unchanged.
  6. **Notebooks** (Workspace page → Notebooks, now the first tab). A notebook gathers **references** (files, PDFs, links, pasted text, a web search, or a workspace doc / your tasks), lets you **chat** with only the ones switched on (answers cite them as numbered chips that jump to the source), and has Viora **write pages** from them: briefing doc, study guide, FAQ, summary, timeline, action plan, comparison, email, article, or your own prompt. Pages stream in live, can be edited by hand or improved / shortened / expanded / continued (on the selected text if there is one, with Undo), listened to, copied, exported as .md or PDF, turned into workspace tasks, or saved to Docs. Pages that use references end with a Sources list. Everything is stored on-device with the rest of the workspace; the only thing sent out is the model request. The AI uses the built-in Deep Search key (own budget, strongest model, Groq keys as fallback); change `NB_CHOICE` at the top of `src/workspace/notebook.js` to `'flash'` for faster, lighter answers. Tests: `test/node/notebook.test.mjs` (passages, numbering, citations, prompt-injection guard) and `test/node/notebook-ui.test.mjs` (the whole flow against a fake model).
- **7.11.0 — Automate can use a real Linux shell, and the Humanizer works harder when a detector still flags it.**
  1. **Linux for Automate** (off until you switch it on in Settings → Linux). Automate gets three new actions, `shell`, `write_file` and `read_file`, backed by a bash shell on your own machine: run and test code, install packages, clone and build, process files and media, use curl, git, ffmpeg, docker, anything a terminal does. A shell step ends its batch so the AI always reads the exit code and output before the next step; a failed command is read and fixed, not skipped. A Linux-only task needs no web page, so it works from a blank tab. Sessions get room to iterate (30 turns / 150 actions instead of 8 / 40), and old command output is trimmed in the log so long sessions stay inside the model's context. Browsers can't start programs, so this uses Chrome's Native Messaging: a one-file Python host in `native-host/` that you install once (details under **Linux** below). On Windows the shell is WSL.
  2. **Asks first by default.** Every command and file write appears in the chat as a card (Run it / Run, and stop asking this task / Don't run) before anything happens, with a red warning for things like `rm -rf /`, disk writes, `sudo` or `curl … | sh`. Turn the question off in Settings once you trust the task. Page text can try to trick an AI into running commands, so the Linux prompt tells the planner to treat page, file and command output as untrusted data and the reviewer is told to reject any command that came from page text.
  3. **Humanizer, harder retries.** Before this, a retry edited the failed draft, so the model kept its skeleton, and the skeleton is what a detector recognises. Now: two first drafts are written side by side and the better one is kept; retry 1 starts again from your original text (never from the failed draft) with a sentence-length zig-zag to follow; retries 2 and 3 rewrite passage by passage, each in a different voice, so no passage has an earlier sentence to echo. The prompt now says to rewrite from meaning rather than sentence by sentence, and to pick the second-most-expected word now and then.
  4. **Sharper local check.** Two new signals, runs of same-length sentences and too many sentences opening with The / This / It, so the free check catches the flat rhythm that rewrites most often leave. A new forced pass splits run-on sentences at a conjunction and joins one pair inside a run, but only when the result is safe. The numbers are still our own estimate; only a ZeroGPT percentage is a real detector's verdict.
- **7.10.0 — everything keeps working when you close the panel, and a proper recording bar for the mic.**
  1. **Answers now keep going in the background.** Until now only pictures, research reports and Humanizer rewrites survived closing the panel; an ordinary reply (Flash, Deep Search, Math & Code) died with it. A whole chat turn — the internet pass, the prompt, the model, trimming and asking again when the prompt is too big, carrying on when a reply runs out of room — is now one background job (`src/lib/chatjob.js`, run by `src/offscreen/offscreen.js`). The conversation is saved before it starts; if you close the panel the finished answer is written into it and a notification says it is ready (click it to jump to the chat; the toolbar badge stays until you open Viora). If the panel stays open the reply streams in exactly as before, and a strip shows any job still running when you come back. Details that matter: the job record in storage keeps only a short preview (not the prompt, page text or pictures); the panel reconnects to the worker if the browser put it to sleep and pings it every 20 s so a long reply is never mistaken for a closed panel; model IDs that worked are still remembered (the worker does it now).
  2. **"Talk to Viora" is gone.** The round voice-conversation button and its code are removed.
  3. **The mic is now a recording bar.** Tap it and the message box becomes a pill: the **+** menu on the left (still works while you record), a live waveform that grows out from the middle with your voice and fades to dots at the ends, a **square** that stops and puts your words in the box to edit, and a **blue arrow** that stops and sends them straight away. **Esc** throws the recording away. While the words are transcribed the bar stays up with the buttons resting. (Chrome's built-in recognizer, used only if the mic can't be captured, shows a gentle ripple instead of your voice.)
  Honest limits: **Automate is not in the background yet** — it clicks and types on a page using the browser tabs and the panel's screen, so it still stops if the panel closes. Editing a PDF needs the file, so if the panel closes mid-edit the chat says to send it again. Closing the *browser* still ends every job (it is marked failed on next start).
  Tests: `test/tests.js` gained a `chat job` suite (plain turn, trim-and-retry, carry-on, the web pass inside the job, saved message, notification).

- **7.9.2 — layout fix.** The "still working in the background" strip was inserted as an extra row of the page grid and pushed the chat, status line and composer out of place. It now lives inside the chat area as a sticky bar.

- **7.9.1 — the Humanizer survives closing the panel.** Rewrites now run as background jobs like pictures and reports: the chat (with your pasted text) is saved *before* the rewrite starts, the finished text is written into it, and a notification says it is ready.

- **7.9.0 — background jobs, notifications, and memory that learns from whole chats.**
  1. **Pictures and research reports keep going when you close the panel.** They now run in an offscreen document (`src/offscreen/offscreen.js`) managed by the service worker (`src/background/jobs.js`) instead of inside the panel. When one finishes, the result is written into its conversation and a notification says so (click it to jump to the chat; the toolbar icon shows a badge until you open Viora). If you reopen the panel while a job is still running, a strip above the chat shows its progress. Turn notifications off in Settings. Honest limit: closing the *browser* ends a job — it is marked failed on next start and the chat says so. Ordinary streamed chat replies still live in the panel.
  2. **Memory from past chats.** After a conversation has run a while, or has gone quiet for ten minutes, one short model call (`src/background/digest.js`) reads it and keeps (a) up to three lasting facts about you (same safety rules as before, shown under a reply as "Remembered…" with Undo) and (b) a one-line **note** about what the chat was about and where it ended. When a later message is about the same thing, the matching notes are recalled into the prompt (`recallEpisodes`, `withRecall`); an unrelated message recalls nothing. Notes are listed in Settings, deletable one by one or all at once, and "what do you remember about me" shows them. Switch off with *Learn from my past chats*. Humanizer and Automate chats are never read.
  3. **Humanizer on NVIDIA.** The Humanizer now runs on its own NVIDIA key (`NVIDIA_HUMANIZER_KEY` in `src/lib/access.js`), with the old Groq models as the automatic fallback. As with every key in that file, it is plain text inside the extension — rotate it there if it leaks.
  Tests: `test/tests.js` gained `memory from past chats` and `background jobs` suites. New permissions: `offscreen`, `notifications`, `alarms`.

- **7.8.0 — small talk stays clean, and Viora can edit PDFs.**
  1. **No sources on "hi", "bruh", "what are you?".** `isCasualChat` (`src/lib/web.js`) recognises chit-chat, thanks and questions about Viora itself — only when the *whole* message is casual, so "hi, what's the weather" still searches. Those turns skip the web pass, the page read and the follow-up chips, get a "no sources, no citations" note (`CASUAL_NOTE`), and any stray `Sources:` line the model adds is dropped. No "Read N sources" badge, no `[n]` markers.
  2. **PDF editing.** Attach a PDF with **+** and say what to change: replace or fix text, redact, highlight, add text or page numbers, watermark, delete / reorder / extract / rotate pages, add blank pages. The AI replies with a short JSON plan (`PDF_EDIT_GUIDE`, `parseEditPlan`); the panel applies it to the real file (`src/lib/pdfedit.js`) and returns **name-edited.pdf** as a download chip, with a ✓/✗ line per step. Follow-ups ("now also change the date") keep editing the latest version.
     - Dependency-free engine (the CSP forbids CDN libraries): parses objects, object streams, xref streams, page trees, fonts (ToUnicode / CID), and content streams with real text positions.
     - Edits are an **incremental update** — the original bytes are never rewritten, so untouched pages, images, fonts and bookmarks stay exactly as they were.
     - **Replace** keeps the original font when it's a plain non-embedded one; otherwise it removes the old glyphs and re-typesets the line in the closest standard font (Helvetica/Times/Courier, bold/italic matched), moving the rest of the line with it.
     - **Redact** deletes the text from the page *and* draws the box, so it can't be copied back out.
     - Honest limits, reported rather than faked: encrypted PDFs, scanned/image-only PDFs (no text layer), form fields, text inside images.
  3. **Better PDF reading everywhere.** Uploads and linked PDFs now go through the same structural reader first (page markers, subset and CID fonts via ToUnicode), with the old stream scanner as the fallback.
  Tests: `test/tests.js` gained `isCasualChat` and `pdfedit` suites (read, replace, redact, add text, page numbers, rotate, plan parsing, font metrics).

- **7.7.0 — frozen screenshots, and an AI that actually reads them.**
  1. **The page freezes.** Take a screenshot now captures the tab *first* and lays that picture over the page while you select, so video, animations and tickers stop moving; the crop comes from the same frozen picture, so you get exactly what you saw. The crop scales against the real viewport size (browser zoom and display scaling can't skew it). (`content.js`, `screenshotSelect`, `readScreenshot`)
  2. **Sharper input.** Screenshots keep up to 1600px at higher JPEG quality; small selections (a line of text, an error code) are scaled up so the vision model can read them. File names now say `.jpg` because that's what they are.
  3. **A vision brief.** Any turn with a picture carries `IMAGE_GUIDE` (`src/lib/prompts.js`): read every piece of visible text, quote exactly, never invent unreadable words, say what the screen is, then answer with specifics. With no question attached, the AI works out the likely need (error → cause + fix steps; problem → solved with working; text → key points). The model is also told which page the screenshot came from (title and address, never the query string or #fragment).
  4. **One-tap actions** appear under a fresh picture: Explain, Extract text, Solve it, Fix the error, Translate.
  5. **Bug sweep.** Lint pass over every module (no undefined names), a duplicate key in the PDF character map removed, unused imports removed.

- **7.6.1 — new logo.** The Viora mark replaces the old icon everywhere: toolbar/extension icons (16–128px, transparent background), the panel header button, the welcome screen (still flips) and the settings page, which shows the full logo with the wordmark. Sources: `icons/mark.png`, `icons/logo.png`.

- **7.6.0 — glossy screenshots, source logos up top, no more cut-off answers.**
  1. **Take a screenshot is glossy and editable.** The picker now has frosted-glass UI (hint, size readout, toolbar) with a glowing frame. When you let go of the mouse the selection stays: drag the eight handles to resize, drag inside to move, arrow keys nudge (Shift = 10px, Alt+arrows resizes), drag on the dimmed area to start over, **Retake / Cancel / Attach** or Enter / Esc / double-click to finish. The overlay is fully gone (two frames) before the page is captured, and the page can't scroll underneath it. (`src/content/content.js`, `content.css`)
  2. **A source-logo badge sits at the top of any answer that used the internet** — favicons of the sites read plus "Read N sources", shimmering as "Searching the web" while the pages load, and tapping it jumps to the chips below. Also shown when a saved chat is reopened and on Deep Search reports. (`sourceBadge` in `src/lib/citations.js`)
  3. **Answers that stop mid-sentence now finish.** The stream reader ignored `finish_reason`, so a reply that ran out of tokens (usually the reasoning ate the budget) just ended at "In mid…" with "Working it out" still showing. `streamChat` now reports `finish`, and the panel picks the answer up where it stopped (up to twice), or re-asks without heavy thinking if nothing visible came out. (`src/lib/providers.js`, `sendTurn` in `sidepanel.js`)

- **7.5.0 — four things added to every AI.**
  1. **Memory that learns.** When you say something lasting about yourself ("I'm a nurse on night shifts", "I prefer short answers"), a tiny background call keeps it — shown under the reply as "Remembered: …" with **Undo**, never silently. It only runs on messages that look personal, refuses anything sensitive (passwords, keys, card/ID numbers, emails, phones, addresses, health, money, religion, politics, legal trouble) and merges duplicates. Ask "what do you remember about me?" to see the list; "forget everything" clears it after confirming. Settings → turn it off with *Learn lasting facts*. (`src/lib/memory.js`)
  2. **Built-in tools in every mode.** Maths (percentages, powers, roots, trig, logs, factorials), unit conversion (length, mass, volume, temperature, speed, area, time, data), live currency (frankfurter.app, then open.er-api.com; never a guessed rate), and time/date ("time in Tokyo", "days until Christmas", "30 days from now"). Answered instantly on the device with no AI call. Sentences that just contain a number still go to the AI. (`src/lib/tools.js`; Settings → *Answer maths, unit…*)
  3. **Read aloud, copy and star under every answer.** Read aloud uses the browser's own voice (free, private); tap again to stop.
  4. **Chats: search, pin, star, export.** The history drawer has a search box (title and message text), pins (pinned chats are never pushed out by newer ones), a **Starred** tab of saved answers that opens the chat at that answer, and per-chat export to **Markdown** or **PDF** with sources. (`src/lib/chats.js`)
  Tests: `test/tests.js` covers all of it; the tool, memory and chat helpers are pure functions with no browser needed.

- **7.4.2 — review fixes to Deep Search.** (1) A *copy* is no longer a second source: the same passage on two sites (wire stories, syndicated posts), or two pages on one domain, count as one. (2) Links pasted with the question are read first and used for every section (the new engine ignored them). (3) Plain-word topics ("who invented the margarita") no longer skip good pages for using another word form. (4) If a reasoning model spends its whole token budget thinking and returns nothing, the retry gets more room instead of repeating the failure. (5) Token caps raised for extraction, planning, writing and summary.

- **Deep Search is now a real research engine (7.4.1).** Pick Deep Search from the "+" menu and every ask becomes: an editable plan (est. 5–10 min) → **Start research** → a long, cited report. Short follow-ups after a report, or a message starting `quick:`, still take the fast path. The engine is `src/lib/research.js` (`runResearch`), and it is built so the AI *cannot* get a made-up fact into the report, whatever the model does:
  1. **Facts, not prose, come first.** For every page it opens, the model must return facts each with an *exact quote* from the page. The quote is checked in code against the page text (`quoteInPage`), and every number in the fact must be a whole number on the page (`numbersOk`). Fact fails → thrown away (the report's footer counts how many).
  2. **Wrong-person guard.** A page that never names the subject is skipped, and the extraction prompt tells the model to return nothing for a page about someone else with the same name.
  3. **Every written sentence is re-checked in code** (`verifySection`): it must cite a source that exists, use only numbers and capitalised names found in that source's evidence, and share most of its words with it. Anything else is deleted. A section with no verified facts is never sent to the model: it says "No reliable source found for this."
  4. **Two independent sites = verified.** The Confidence and gaps section is computed, not written by the model: High (≥3 facts from ≥2 sites), Medium, Low (single source), Not found. Single-source claims are worded as what that source reports; conflicting figures are shown side by side.
  5. **It teaches itself where to look** (`RESEARCH_PLAYBOOK`): primary sources first, people-finder sites only as leads, exact-phrase names, `site:` and `filetype:pdf`, name variants, years. Each section has a ladder of 12 search strategies (`angleQueries`) tried in turn, links found on pages are followed when their text matches the subject (`extractLinks` in `web.js`), pages already read are re-used for other sections, and single-source claims get a dedicated hunt for a second source.
  6. **It doesn't quit.** A dead search, an unreadable page or a failed model call costs a retry, not the run. If every angle comes back empty (a blocked search engine looks the same as "nothing exists") it waits and goes round again, up to four times, before it says "Not found".
  7. **Time.** It works at least ~5 minutes (spent on more angles and second sources, not idle waiting) and never past ~10. The honest exceptions: if the web truly has nothing more on any angle it stops early and says so, and **Write the report now** (button under the plan) stops searching and writes up what is already verified. Model calls are paced under the key's tokens-per-minute budget (`Pacer`), which is also why a thorough run takes minutes on a free key.
  Tests: `test/tests.js` has a fake-model suite where the "AI" invents a Nobel Prize, a wrong funding figure and a same-name painter — none reach the report.

- **Four more ways it understands you.** (1) *Highlighted text*: select something on a page and "explain this" / "translate that" means exactly that text (`selectedText`, `withSelection`). (2) *Memory by conversation*: "remember that I'm vegetarian", "call me Sam", "forget the vegetarian thing" update Settings → Memory directly, with a small "Saved to memory" note (`detectMemoryCommand`, `prefs.autoMemory`). (3) *Long chats keep their thread*: once a conversation passes 24 messages, everything older than the last 14 is folded into a short rolling recap (`maybeSummarize`, `withSummary`) instead of being silently dropped. (4) *Follow-up chips*: longer answers end with three specific tappable next questions, generated on the reviewer's key so chat's budget is untouched (`suggestFollowUps`, `prefs.followUps`). Both toggles are in Settings.
- **Smarter and more understanding.** Every conversational mode now carries a compact "how you think" protocol (`MIND` in `src/lib/prompts.js`): infer intent, resolve "it/that/the second one" from history, state an assumption instead of stalling, answer the next obvious question, check the result, challenge false premises, stay consistent, match the person's level and language. Every prompt also gets today's date and timezone (models have no clock). Reasoning effort is now adaptive (`pickEffort`): easy questions stay fast, hard ones get medium or high thinking with room reserved for the answer. Follow-ups are understood (`resolveFollowUp` makes "what about its price?" search the right thing; `autoRoute` keeps a short follow-up in Math/Deep Search instead of dropping to Flash), and the router recognises far more maths, code and research phrasing.
- **Source logos have three sources, not one.** `loadLogo` (`src/lib/citations.js`) tries Google's favicon lookup, then DuckDuckGo's icon service, then the site's own `/favicon.ico`, and falls back to the letter tile only if all three fail. It detects Google's generic 16px globe and treats it as a miss. Only the bare hostname is ever sent. Used by the source chips, the logo stack, the inline `[n]` markers and the "reading pages" status icons.
- **Every mode now fails over instead of failing.** `streamChat` / `completeChat` (`src/lib/providers.js`) try, in order: the mode's model chain → whatever chat models the host is serving *right now* (asked from `/models` when the built-in IDs are retired) → each fallback in the config's `fallbacks` list (other built-in Groq keys; for Automate, Groq models when NVIDIA is down or its key is dead). Server errors (5xx) and odd 400s move to the next model rather than ending the turn, and a revoked key (401/403) skips straight to the next key. A turn that has already started streaming is never silently replaced.
- **The AI always knows which page you're on.** Every chat turn carries the current tab's title and address (`withCurrentTab` in `src/lib/prompts.js`), so "this page" / "here" resolve correctly. If your message is about the page ("summarise this", "what does it say about pricing", "fix this error"), or *Always send the page* is on, the page text is read automatically — no need to attach the tab first. Browser/extension pages are reported as unreadable instead of guessed at. Automate already received the page's title and URL every turn.

- **Deep Search searches every way it can.** Instead of one query it runs four at once (your question, its keywords, a "this year" angle, and an official/study/report angle), interleaves the results so each angle's best hit makes the cut, and reads up to five pages (`gatherWeb({ deep: true })` in `src/lib/web.js`). The prompt forbids unsourced facts: every claim carries `[n]`, anything not in the sources is written as "Not found in the sources", and each answer ends with a confidence grade and a Sources list.
- **Flash doesn't have to cite.** It still checks the web quietly, but only adds `[n]` and a Sources line when a specific, checkable claim leans on a source.
- **Automate is a visible chat.** The Planner and Reviewer talk in message bubbles (with a typing indicator): the Planner proposes, the Reviewer answers, and if it objects the Planner replies with a fix, up to three rounds. Only then does the agreed plan appear and run. Toggle in Settings (`prefs.duoAutomate`).
- **Every mode has a writing format** (`FORMAT_FLASH`, `FORMAT_RESEARCH`, `FORMAT_MATH` in `src/lib/prompts.js`): Flash answers first and briefly; Deep Search uses Answer / What the sources show / Where sources disagree / Confidence; Math & Code uses Problem / Approach / Work / Check / Result / Watch out.
- **Math & Code verifies before it answers**: substitute back or test an edge case, cross-check with a second method, exact values until the last step, no invented library functions.

## The five

| | | |
|---|---|---|
| ⚡ | **Viora Flash** | Quick, chatty, good for most things |
| 🔎 | **Viora Deep Search** | Reads the live web and cites what it found |
| 🧮 | **Viora Math & Code** | Shows its working, writes proper fractions |
| 🤖 | **Viora Automate** | Clicks, types, navigates and *looks* at the page you're on |
| ✍️ | **Viora Humanizer** | Paste AI-sounding text, get it back in a human voice |

Switch with the pill next to the wordmark. Each one has its own accent colour,
its own opening line, and its own model behind it.

## Always on the web

**Viora Flash, Deep Search and Math & Code check the internet before they
answer, every time.** The pass runs in the panel itself — no API key, no server
of ours (`src/lib/web.js`):

1. Any link in your message is opened and read first. A `.pdf` link goes
   through the very same extractor file uploads use, so a paper you pasted is
   read, not guessed at.
2. The message (with its URLs removed) is searched — DuckDuckGo's HTML
   endpoint, its Lite one, and Bing's keyless RSS *race* each other, so the
   first engine that answers supplies the results. DuckDuckGo is preferred
   but bot-challenges whole networks for hours at a time; waiting out two
   dead endpoints before asking the one that works would cost twenty seconds
   and still end with no sources.
3. The top results' pages are opened and stripped to readable text — nav,
   scripts, footers and forms dropped, article text kept.
4. All of it is laid out as a numbered block in the system prompt: `[1] Title`,
   its URL, the search snippet, then the page's own words. The prompt tells the
   model to answer *from those sources*, cite them as `[1]`, `[2]`…, and never
   to claim it searched when the lookup failed.
5. Whatever survives the budget (7000 characters, shared with history so the
   free-tier token meter isn't blown by research) is exactly the list the panel
   renders under the reply: inline `[1]` markers linking out, plus a strip of
   favicon chips. One list, so a marker can never point at a chip that doesn't
   exist.

Failures are honest rather than fatal: a page that refuses to read is listed
with "could not read it: …", a page that is too slow is reported as such (a
timeout is a failure, never mistaken for you pressing Stop), and if the whole
lookup fails the model is told to say the check didn't happen instead of
pretending it did. Stop aborts the web pass mid-read like any other part of
the turn.

Humanizer and Automate are excluded on purpose — their prompts require
JSON-only and rewritten-text-only output, and a web block would break both.
**Source favicons** in Settings (`prefs.citations`, on by default) turns the
markers and chips off if you'd rather read an answer clean; the model still
sees the sources either way.

## Automate can see

Besides the numbered list of buttons and fields it always gets, Automate has a
`look` action: it screenshots the tab, a vision model (`VISION_CHAIN`) describes
the screenshot in plain text, and the planner reads that on its next turn. Use
it for canvas apps, image-heavy pages, or to confirm a click really worked. It
ends the current batch, since what it sees can change the plan. Writing into
rich editors (chat boxes, comment fields) now goes through `execCommand`
rather than assigning `textContent`, which those editors ignore.

## Linux

Switch it on in **Settings → Linux**. It needs a small helper installed once, because a browser extension cannot start programs on its own:

1. Settings → Linux shows this copy of Viora's extension ID and the exact install command. In the folder you unzipped Viora into, run it:
   - Windows: `powershell -ExecutionPolicy Bypass -File .\native-host\install.ps1 -ExtensionId <id>` (needs Python 3 and WSL; if you have no WSL, run `wsl --install` in an admin terminal and restart)
   - Linux / macOS: `bash ./native-host/install.sh <id>` (needs `python3`)
2. Restart the browser, then press **Test connection** in Settings → Linux.

No admin rights are needed (it registers under your own user profile). Remove it with `install.ps1 -Uninstall` or `install.sh --uninstall`. If you reload the unpacked extension from a different folder its ID changes, so run the installer again with the new ID (you can list several IDs separated by commas).

**What the AI can do.** Anything your shell can: it runs as you, with your files and internet. Tick *Run as root* for full control (WSL's root user on Windows, passwordless `sudo` elsewhere). Commands start in `~/viora-workspace`, `cd` carries over between commands like a terminal tab, stdin is closed (so the AI passes `-y` instead of waiting for a question), output is cut to its start and end, and a command is stopped at the timeout you set (default 120 s, up to an hour). Files are written and read through their own actions, so code with quotes and backslashes arrives byte for byte.

**How it's built.** `src/lib/linux.js` sends one JSON message per call with `chrome.runtime.sendNativeMessage` (ops: `ping`, `run`, `write`, `read`, `reset`). A command the person watches uses `chrome.runtime.connectNative` instead: one long-lived port per command, the host sends `chunk` (output), `tick` (heartbeat) and a final `result`, and `cancel` (or closing the port) stops it. `native-host/viora_host.py` reads Chrome's length-prefixed frame, puts the script into a temp file inside Linux as base64 (so no quoting can break it, and Windows' command line re-parsing never sees it) and runs it with `bash`. There is no network listener, and only the extension IDs written into the host manifest by the installer can talk to it. Check the host any time with `python3 native-host/test_host.py` (it uses a throwaway home folder).

**Honest limits.** Automate still runs in the panel, so a long Linux session stops if you close it (since 7.13.1 closing the panel also stops the command that is running; the AI will not read its result). Only Automate has Linux so far; Flash, Deep Search and Math & Code do not run commands. The Windows installer and the WSL path were written carefully but not run on a Windows machine by their author, so the first Test connection there is the real test.

## Humanizer

Paste text that reads like an AI wrote it; the reply is the same text with the
stock phrases and even rhythm removed — same meaning, facts and structure. Say
"shorter", "more casual" or "for a school essay" and it redoes the last rewrite
that way. It runs on Groq (`openai/gpt-oss-120b`, falling back to
`openai/gpt-oss-20b`, then `qwen/qwen3.8-27b`) with its own key,
`GROQ_HUMANIZER_KEY` in `src/lib/access.js`.

**How a rewrite is made** (`src/lib/humanizer.js`). Detectors mostly react to text
that is too even and too predictable, so each rewrite goes through a loop:

1. The model rewrites with a prompt built around what detectors measure: uneven
   sentence length, plain specific words, no connector openers, no lists of three,
   no em dashes, contractions.
2. `polish()` removes what models always leave behind: stock words ("delve",
   "pivotal", "plays a crucial role"), connector openers, em dashes, missing
   contractions. It never edits quotations, headings, list items or links.
3. `analyzeText()` scores the draft 0–100 on twelve measurable signals (sentence-length
   variation, stock wording, connectors, repeated openers, dashes, lists of three,
   "not only … but also", contractions, long words, summing-up endings, hedging,
   paragraph shape). This is free, so it runs on every draft.
4. If the score is above your target (default 10) the model is told *which* signals
   failed and which sentences to change, and tries again — up to three more times.
   A draft that drops a number, link or quotation is never chosen over one that keeps it.
5. If ZeroGPT can be reached (see below), the best draft is scored by it too, and
   its verdict decides.

When a draft still fails, retries get harder instead of repeating: retry 1 starts again from
your original (not the failed draft) with a sentence-length zig-zag to follow, and retries 2
and 3 rewrite passage by passage in different voices (`humanizeLoop`'s `drafts` and `escalate`
options; the background job turns both on). Two first drafts are written side by side and the
better one is kept.

**Two scores, labelled differently.** *Viora check* is our own estimate of how
machine-written the text reads. It is not a real detector and says nothing certain
about ZeroGPT, GPTZero or Turnitin. *ZeroGPT: n% AI* appears only when ZeroGPT really
scored that text. ZeroGPT's API needs a key (Settings → *Humanizer AI check*); with no
key the panel says so instead of quietly skipping the check. Detectors disagree with
each other and are unreliable in both directions, so treat any number as a guide.

**Learning your voice.** The first time you open the Humanizer it shows ten
question cards, one at a time, in place of the composer (`src/lib/style-questions.js`).
Seven are short writing tasks (introduce yourself, cancel plans, a formal email…)
and three ask you to describe your own habits and what sounds fake to you. Each
answer needs at least 25 and at most 500 characters. Progress is saved after
every keystroke, so closing the panel mid-way loses nothing, and the header
stays usable — pick another Viora and the gate lifts. The answers are stored
on-device (`settings.humanizer`) and added to every rewrite's system prompt as
data about your style. Retake or clear them from the Humanizer's welcome screen
or Settings → *Humanizer writing style*.

## Speed

- A model that hasn't produced a first token in 10 seconds is dropped and the
  next one in its chain takes the turn (the last model is never timed out).
  A model is only remembered as "working" once it has actually started answering.
- Automate's reviewer gets at most two models, 6 seconds each, low reasoning
  effort and a short answer; if it's slow it's skipped and the planner's steps run.
- `quick` mode asks `openai/gpt-oss-*` models to think briefly.
- Groq counts the prompt *plus* the reserved reply against a small per-minute
  token ceiling, so a research-heavy turn can be refused as "request too large"
  before it runs. The reserved reply is shrunk to fit when that is enough
  (`providers.js` learns each model's ceiling from the refusal and sizes later
  turns to fit first time); when the prompt itself is over the ceiling the panel
  rebuilds the same turn with less context — page, then history, then the web
  block's text — rather than surfacing the error.

## The "+" menu

Click it to upload a file, or to hand Viora one of your open tabs — pick one
and its page content is read on every turn until you remove the chip. That's
a `pageContext()` read (same one automation already used), not a screenshot:
Viora gets the page's text, not a picture of it. Listing tabs needs the
`tabs` permission, which is why Chrome will ask you to re-approve Viora after
this update.

## Voice input

The mic button records your speech and transcribes it with Groq's
`whisper-large-v3`. It uses its own key (`GROQ_STT_KEY` in `src/lib/access.js`),
so transcription never draws on the shared chat budget (a personal key from
settings still wins for both). Tap to record, tap again when you're done, and
the text lands in the input box for you to review before sending.

Chrome hides the mic-permission prompt inside a docked side panel, so the
first time you tap the mic Viora opens a small popup that asks for microphone
access once (see `src/mic/`). If permission is blocked, it opens the site
settings instead. If the mic still can't be captured it falls back to Chrome's
built-in speech recognition, and the button hides if the browser supports
neither.

## Images and video

Uploaded images and videos go to NVIDIA's multimodal models first
(`NVIDIA_VISION_CHAIN` in `src/lib/models.js`: DeepSeek V4.1 Flash, GLM 5.3
Flash, Muse Glimmer, Kimi K3), with Groq's `qwen/qwen3.8-27b` (`VISION_CHAIN`)
as the fallback. Images are downscaled client-side, up to eight pictures per
request. A video is never uploaded whole: Viora samples 4–8 evenly spaced
frames in the browser (`readVideo` in `src/lib/files.js`), labels each with its
timestamp, and sends them as images, so the model can describe what happens
over time. The soundtrack is not read, and Groq's fallback only accepts three
pictures per request. Any mode you're talking to will use them.

## Icons, not emoji

The interface itself never speaks in emoji — `src/lib/icons.js` is a small
set of stroke icons (one per assistant, plus upload/tab/mic/check/plus) that
every bit of chrome draws from instead: the model pill, the welcome screen,
the picker rows, the reply badge, thread history. Only Viora's own replies
use emoji, and only at whatever level is set in **Emoji** under settings.

## Maths

Viora renders LaTeX itself — no engine is bundled, because the extension's CSP
forbids remote scripts and KaTeX is far too heavy for a side panel. `src/lib/math.js`
covers what an assistant actually writes:

- `\frac{3}{4}` draws as a stacked fraction with a rule, not `3/4`
- `\sqrt{x}`, `\sqrt[3]{x}`, `x^{2}`, `a_{n}`
- `\le \ge \ne \approx \pm \times \cdot \infty \sum \int` and the Greek alphabet
- ASCII stand-ins typed by habit (`>=`, `<=`, `!=`, `->`, `+-`) are converted
- a bare `3/4` between `$…$` is promoted to a real fraction

The system prompt tells every model to write maths this way, so it usually
arrives already correct.

## Voice

Viora is warm by default: it reacts, has opinions, and uses the occasional
emoji. That's a character, not a claim about inner life — and it never buys
agreeableness with accuracy. It still says "I'm not sure", still disagrees when
you're about to do something that won't work. Both can be turned down in
settings: **Voice → Plain** and **Emoji → None**.

## 100+ ways to write

`src/lib/styles.js` is a catalogue of over 100 writing techniques — structures
(numbered lists, tables, timelines, decision trees), tones (blunt, deadpan,
tactful…), sentence craft (rule of three, antithesis, fragments), reasoning
rhetoric (steelman, pre-mortem, inversion) and ready-made formats (emails,
cover letters, poems, release notes, post-mortems). Ask for one by name —
"write this as a bulleted list, formal tone", "draft a cover letter", "as a
haiku" — and the matching techniques are folded into that turn's system
prompt, each with a one-line instruction.

They load **on demand only**: `matchStyles()` requires the message to both
name a technique and read as a writing request (a stray "did you get my
email?" pulls in nothing), caps what's injected at four techniques and 900
characters, and an ordinary turn pays zero tokens — which matters, because
the shared key meters 8,000 tokens a minute. The Humanizer, Automate and
quiz cards never receive them: those must emit only rewritten text or only
their JSON object.

## Account and cloud backup (7.17.0)

Settings has an **Account** card: create an account or sign in with an email and password, then **Back up now** / **Restore from cloud**. Nothing is saved to the cloud until you are signed in. Storage is a private Backblaze B2 bucket reached through its S3-compatible API (`src/lib/cloud.js`, keys in `src/lib/access.js`). Only a salted PBKDF2 hash of the password is stored. Your personal Groq and ZeroGPT keys are left out of backups. This is a test setup: the bucket key ships inside the extension, so rotate it and move it behind a server before sharing Viora.

## Settings

There are no credential fields, because there are no credentials to enter. What
is there:

- which Viora opens by default
- voice and emoji level
- reply length, working-shown, source favicons
- model IDs, if you want to pin a specific Groq model to one of the four
- an optional personal Groq key, for when the shared one hits a rate limit

## Tests

The Linux bridge has its own check: `python3 native-host/test_host.py`.

There is no bundler and no test framework here, so the suite is a web page:
`test/server.ps1` serves the workspace (and proxies `/proxy?url=…`, which
reproduces the `<all_urls>` host permission an extension page has and a web
page doesn't), and `test/run.ps1` opens `test/index.html` in headless Chrome,
lets it run in real time, and prints the verdict. The live checks hit the real
DuckDuckGo/Bing and real pages through that proxy.

```
powershell -NoProfile -ExecutionPolicy Bypass -File .\test\server.ps1   # keep running
powershell -NoProfile -ExecutionPolicy Bypass -File .\test\run.ps1
```

## About the shipped key

`src/lib/access.js` contains a Groq key in plain text. Two consequences worth
knowing about:

1. Anyone who installs Viora can read it out of the source. It is not secret.
2. Groq counts free-tier limits **per key, not per user**. Every install shares
   one budget, so rate limits arrive quickly once more than a handful of people
   are using it.

Viora softens this in the client (`src/lib/providers.js`): a request that only
just misses the minute's token budget is shrunk to fit and re-sent at once, short
resets are waited out, and only then does it fall back to the next model. Page
context, chat history and Flash's reply reservation are kept lean for the same
reason. It can't create budget that isn't there, though — with many installs on
one key, the fix is per-user keys or a proxy.

The optional key field in settings is the escape hatch: a free key from
console.groq.com, stored on-device, takes over for that install. If the shared
key gets abused, rotate it in `access.js` and ship a new version.

## Model IDs

Groq retires model IDs on its own schedule. Each assistant carries a fallback
chain (`src/lib/models.js`); a dead ID is skipped automatically and the one that
answered is remembered. If a whole chain dies, the error offers a live list of
what Groq is serving so you can pin a replacement without editing code.

## Install

1. `chrome://extensions` → enable Developer mode
2. Load unpacked → choose this folder
3. Ctrl+Shift+Y (Cmd+Shift+Y) opens the panel

## Build

```
./scripts/build.sh
```

Validates the manifest, checks every referenced file exists, checks no key has
leaked outside `access.js`, and writes `dist/viora-extension-<version>.zip`.

## Layout

```
src/
  lib/
    access.js      the shipped keys + base URLs
    models.js      the five assistants and their model chains
    providers.js   Groq streaming client with chain fallback
    prompts.js     system prompts: voice, emoji, maths rules
    styles.js      100+ writing techniques, injected on demand
    math.js        LaTeX subset → HTML
    markdown.js    markdown + maths + tables, escaped throughout
    storage.js     settings and saved threads
    style-questions.js  the Humanizer's ten onboarding cards
    humanizer.js   the Humanizer's scoring, polish and retry loop
    linux.js       the Linux bridge client (Native Messaging) and output shaping
  native-host/     the one-file Python helper and its installers (Linux bridge)
    detector.js    optional ZeroGPT check
    citations.js   source chips and inline markers
    web.js         the always-on web pass: search, page/PDF reading, budget
    automation.js  page snapshots and action running
    files.js       attachments (and the shared PDF text extractor)
  mic/             microphone permission bridge (popup that asks Chrome once)
  sidepanel/       the panel
  options/         settings
  background/      service worker
  content/         page-side helpers
```

### Sign in with Google

Settings > Account has **Continue with Google** (`signInWithGoogle` in `src/lib/cloud.js`). It opens the sign-in site on Render (`AUTH_SITE` in `src/lib/access.js`, currently `https://viora-auth.onrender.com`) with `chrome.identity.launchWebAuthFlow`. The site does the Google OAuth code exchange with the client secret (kept on Render, never in the extension) and redirects back to `https://<extension-id>.chromiumapp.org/` with a signed token; the extension confirms it with the site's `/api/verify` and uses the verified email. Signing in with Google gives the same backup as email sign-in for that address. The manifest has a fixed `key`, so the extension ID is always `kkcljeingbbpgbilahlaganmmgggbkik`, and that ID must be in the site's `ALLOWED_EXTENSION_IDS`. The Google OAuth client's redirect URI is `https://viora-auth.onrender.com/auth/google/callback`. While the Google app is in Testing, add each person as a *Test user*. The free Render plan sleeps when idle, so the first sign-in can take about 30 seconds.


### Light and dark mode

Viora is **light by default** on every page. The sun/moon button in the header switches to dark and remembers the choice (`prefs.theme`, applied by `src/theme.js` before the page paints). It no longer follows the computer's dark-mode setting.

### Feeling and teaching

The chat system prompt includes a short "Heart and teaching" block (`HEART` in `src/lib/prompts.js`): it notices the person's mood, explains like a patient tutor, checks understanding, and stays honest that it is an AI. Setting the voice to "plain" turns it off.

## 7.19.0 release notes

- **Permissions:** `nativeMessaging` is now an optional permission. Chrome asks for it only when someone turns Linux on or presses Test connection; until then the Linux helper refuses to run with a clear message. Every other permission is used by a feature (checked in `test/node/release.test.mjs`).
- **Settings > Help > Privacy and permissions** explains what each permission is for and what leaves the computer.
- **AI honesty:** the thinking rules now say never to claim an action worked unless the result shows it, and to keep checked facts apart from guesses.
- **Release checks:** `npm test` now validates the manifest (files exist, fixed extension ID, no unexpected permissions), every page's scripts and stylesheets, the light-by-default theme, and the AI prompt rules.

### Release checklist

1. `npm test` passes.
2. Bump `version` in `manifest.json`.
3. In a fresh Chrome profile: Load unpacked, open the side panel, send a message, open Settings, switch light/dark, test Continue with Google.
4. Zip the folder and keep the `key` in the manifest so the extension ID stays the same.
