# Viora

A browser side panel with five assistants in it. Everything runs on Groq's free
tier, so there is no API key to find, paste, or pay for — install it and talk.

## What changed in this build

- **7.6.1 — new logo.** The Viora mark replaces the old icon everywhere: toolbar/extension icons (16–128px, transparent background), the panel header button, the welcome screen (still flips) and the settings page, which shows the full logo with the wordmark. Sources: `icons/mark.png`, `icons/logo.png`.

- **7.6.0 — glossy screenshots, source logos up top, no more cut-off answers.**
  1. **Take a screenshot is glossy and editable.** The picker now has frosted-glass UI (hint, size readout, toolbar) with a glowing frame. When you let go of the mouse the selection stays: drag the eight handles to resize, drag inside to move, arrow keys nudge (Shift = 10px, Alt+arrows resizes), drag on the dimmed area to start over, **Retake / Cancel / Attach** or Enter / Esc / double-click to finish. The overlay is fully gone (two frames) before the page is captured, and the page can't scroll underneath it. (`src/content/content.js`, `content.css`)
  2. **A source-logo badge sits at the top of any answer that used the internet** — favicons of the sites read plus "Read N sources", shimmering as "Searching the web" while the pages load, and tapping it jumps to the chips below. Also shown when a saved chat is reopened and on Deep Search reports. (`sourceBadge` in `src/lib/citations.js`)
  3. **Answers that stop mid-sentence now finish.** The stream reader ignored `finish_reason`, so a reply that ran out of tokens (usually the reasoning ate the budget) just ended at "In mid…" with "Working it out" still showing. `streamChat` now reports `finish`, and the panel picks the answer up where it stopped (up to twice), or re-asks without heavy thinking if nothing visible came out. (`src/lib/providers.js`, `sendTurn` in `sidepanel.js`)

- **7.5.0 — four things added to every AI.**
  1. **Memory that learns.** When you say something lasting about yourself ("I'm a nurse on night shifts", "I prefer short answers"), a tiny background call keeps it — shown under the reply as "Remembered: …" with **Undo**, never silently. It only runs on messages that look personal, refuses anything sensitive (passwords, keys, card/ID numbers, emails, phones, addresses, health, money, religion, politics, legal trouble) and merges duplicates. Ask "what do you remember about me?" to see the list; "forget everything" clears it after confirming. Settings → turn it off with *Learn lasting facts*. (`src/lib/memory.js`)
  2. **Built-in tools in every mode.** Maths (percentages, powers, roots, trig, logs, factorials), unit conversion (length, mass, volume, temperature, speed, area, time, data), live currency (frankfurter.app, then open.er-api.com; never a guessed rate), and time/date ("time in Tokyo", "days until Christmas", "30 days from now"). Answered instantly on the device with no AI call. Sentences that just contain a number still go to the AI. (`src/lib/tools.js`; Settings → *Answer maths, unit…*)
  3. **Read aloud, copy and star under every answer.** Read aloud uses the browser's own voice (free, private); tap again to stop.
  4. **Chats: search, pin, star, export.** The history drawer has a search box (title and message text), pins (pinned chats are never pushed out by newer ones), a **Starred** tab of saved answers that opens the chat at that answer, and per-chat export to **Markdown** or **PDF** with sources. (`src/lib/chats.js`)
  Tests: `test/tests.js` covers all of it; the tool, memory and chat helpers are pure functions with no browser needed.

- **7.4.2 — review fixes to Deep Search.** (1) A *copy* is no longer a second source: the same passage on two sites (wire stories, syndicated posts), or two pages on one domain, count as one. (2) Links pasted with the question are read first and used for every section (the new engine ignored them). (3) Plain-word topics ("who invented the margarita") no longer skip good pages for using another word form. (4) If a reasoning model spends its whole token budget thinking and returns nothing, the retry gets more room instead of repeating the failure. (5) Token caps raised for extraction, planning, writing and summary.

- **Deep Search is now a real research engine (7.4.1).** Pick Deep Search from the "+" menu and every ask becomes: an editable plan (est. 5–10 min) → **Start research** → a long, cited report. Short follow-ups after a report, or a message starting `quick:`, still take the fast path. The engine is `src/lib/research.js` (`runResearch`), and it is built so the AI *cannot* get a made-up fact into the report, whatever the model does:
  1. **Facts, not prose, come first.** For every page it opens, the model must return facts each with an *exact quote* from the page. The quote is checked in code against the page text (`quoteInPage`), and every number in the fact must be a whole number on the page (`numbersOk`). Fact fails → thrown away (the report's footer counts how many).
  2. **Wrong-person guard.** A page that never names the subject is skipped, and the extraction prompt tells the model to return nothing for a page about someone else with the same name.
  3. **Every written sentence is re-checked in code** (`verifySection`): it must cite a source that exists, use only numbers and capitalised names found in that source's evidence, and share most of its words with it. Anything else is deleted. A section with no verified facts is never sent to the model: it says "No reliable source found for this."
  4. **Two independent sites = verified.** The Confidence and gaps section is computed, not written by the model: High (≥3 facts from ≥2 sites), Medium, Low (single source), Not found. Single-source claims are worded as what that source reports; conflicting figures are shown side by side.
  5. **It teaches itself where to look** (`RESEARCH_PLAYBOOK`): primary sources first, people-finder sites only as leads, exact-phrase names, `site:` and `filetype:pdf`, name variants, years. Each section has a ladder of 12 search strategies (`angleQueries`) tried in turn, links found on pages are followed when their text matches the subject (`extractLinks` in `web.js`), pages already read are re-used for other sections, and single-source claims get a dedicated hunt for a second source.
  6. **It doesn't quit.** A dead search, an unreadable page or a failed model call costs a retry, not the run. If every angle comes back empty (a blocked search engine looks the same as "nothing exists") it waits and goes round again, up to four times, before it says "Not found".
  7. **Time.** It works at least ~5 minutes (spent on more angles and second sources, not idle waiting) and never past ~10. The honest exceptions: if the web truly has nothing more on any angle it stops early and says so, and **Write the report now** (button under the plan) stops searching and writes up what is already verified. Model calls are paced under the key's tokens-per-minute budget (`Pacer`), which is also why a thorough run takes minutes on a free key.
  Tests: `test/tests.js` has a fake-model suite where the "AI" invents a Nobel Prize, a wrong funding figure and a same-name painter — none reach the report.

- **Four more ways it understands you.** (1) *Highlighted text*: select something on a page and "explain this" / "translate that" means exactly that text (`selectedText`, `withSelection`). (2) *Memory by conversation*: "remember that I'm vegetarian", "call me Sam", "forget the vegetarian thing" update Settings → Memory directly, with a small "Saved to memory" note (`detectMemoryCommand`, `prefs.autoMemory`). (3) *Long chats keep their thread*: once a conversation passes 24 messages, everything older than the last 14 is folded into a short rolling recap (`maybeSummarize`, `withSummary`) instead of being silently dropped. (4) *Follow-up chips*: longer answers end with three specific tappable next questions, generated on the reviewer's key so chat's budget is untouched (`suggestFollowUps`, `prefs.followUps`). Both toggles are in Settings.
- **Smarter and more understanding.** Every conversational mode now carries a compact "how you think" protocol (`MIND` in `src/lib/prompts.js`): infer intent, resolve "it/that/the second one" from history, state an assumption instead of stalling, answer the next obvious question, check the result, challenge false premises, stay consistent, match the person's level and language. Every prompt also gets today's date and timezone (models have no clock). Reasoning effort is now adaptive (`pickEffort`): easy questions stay fast, hard ones get medium or high thinking with room reserved for the answer. Follow-ups are understood (`resolveFollowUp` makes "what about its price?" search the right thing; `autoRoute` keeps a short follow-up in Math/Deep Search instead of dropping to Flash), and the router recognises far more maths, code and research phrasing.
- **Source logos have three sources, not one.** `loadLogo` (`src/lib/citations.js`) tries Google's favicon lookup, then DuckDuckGo's icon service, then the site's own `/favicon.ico`, and falls back to the letter tile only if all three fail. It detects Google's generic 16px globe and treats it as a miss. Only the bare hostname is ever sent. Used by the source chips, the logo stack, the inline `[n]` markers and the "reading pages" status icons.
- **Every mode now fails over instead of failing.** `streamChat` / `completeChat` (`src/lib/providers.js`) try, in order: the mode's model chain → whatever chat models the host is serving *right now* (asked from `/models` when the built-in IDs are retired) → each fallback in the config's `fallbacks` list (other built-in Groq keys; for Automate, Groq models when NVIDIA is down or its key is dead). Server errors (5xx) and odd 400s move to the next model rather than ending the turn, and a revoked key (401/403) skips straight to the next key. A turn that has already started streaming is never silently replaced.
- **The AI always knows which page you're on.** Every chat turn carries the current tab's title and address (`withCurrentTab` in `src/lib/prompts.js`), so "this page" / "here" resolve correctly. If your message is about the page ("summarise this", "what does it say about pricing", "fix this error"), or *Always send the page* is on, the page text is read automatically — no need to attach the tab first. Browser/extension pages are reported as unreadable instead of guessed at. Automate already received the page's title and URL every turn.

- **Deep Search searches every way it can.** Instead of one query it runs four at once (your question, its keywords, a "this year" angle, and an official/study/report angle), interleaves the results so each angle's best hit makes the cut, and reads up to five pages (`gatherWeb({ deep: true })` in `src/lib/web.js`). The prompt forbids unsourced facts: every claim carries `[n]`, anything not in the sources is written as "Not found in the sources", and each answer ends with a confidence grade and a Sources list.
- **Flash doesn't have to cite.** It still checks the web quietly, but only adds `[n]` and a Sources line when a specific, checkable claim leans on a source.
- **Automate is a visible chat.** The Planner and Reviewer talk in message bubbles (with a typing indicator): the Planner proposes, the Reviewer answers, and if it objects the Planner replies with a fix, up to three rounds. Only then does the agreed plan appear and run. Toggle in Settings (`prefs.duoAutomate`).
- **Every mode has a writing format** (`FORMAT_FLASH`, `FORMAT_RESEARCH`, `FORMAT_MATH` in `src/lib/prompts.js`): Flash answers first and briefly; Deep Search uses Answer / What the sources show / Where sources disagree / Confidence; Math & Code uses Problem / Approach / Work / Check / Result / Watch out.
- **Math & Code verifies before it answers**: substitute back or test an edge case, cross-check with a second method, exact values until the last step, no invented library functions.

## The five

| | | |
|---|---|---|
| ⚡ | **Viora Flash** | Quick, chatty, good for most things |
| 🔎 | **Viora Deep Search** | Reads the live web and cites what it found |
| 🧮 | **Viora Math & Code** | Shows its working, writes proper fractions |
| 🤖 | **Viora Automate** | Clicks, types, navigates and *looks* at the page you're on |
| ✍️ | **Viora Humanizer** | Paste AI-sounding text, get it back in a human voice |

Switch with the pill next to the wordmark. Each one has its own accent colour,
its own opening line, and its own model behind it.

## Always on the web

**Viora Flash, Deep Search and Math & Code check the internet before they
answer, every time.** The pass runs in the panel itself — no API key, no server
of ours (`src/lib/web.js`):

1. Any link in your message is opened and read first. A `.pdf` link goes
   through the very same extractor file uploads use, so a paper you pasted is
   read, not guessed at.
2. The message (with its URLs removed) is searched — DuckDuckGo's HTML
   endpoint, its Lite one, and Bing's keyless RSS *race* each other, so the
   first engine that answers supplies the results. DuckDuckGo is preferred
   but bot-challenges whole networks for hours at a time; waiting out two
   dead endpoints before asking the one that works would cost twenty seconds
   and still end with no sources.
3. The top results' pages are opened and stripped to readable text — nav,
   scripts, footers and forms dropped, article text kept.
4. All of it is laid out as a numbered block in the system prompt: `[1] Title`,
   its URL, the search snippet, then the page's own words. The prompt tells the
   model to answer *from those sources*, cite them as `[1]`, `[2]`…, and never
   to claim it searched when the lookup failed.
5. Whatever survives the budget (7000 characters, shared with history so the
   free-tier token meter isn't blown by research) is exactly the list the panel
   renders under the reply: inline `[1]` markers linking out, plus a strip of
   favicon chips. One list, so a marker can never point at a chip that doesn't
   exist.

Failures are honest rather than fatal: a page that refuses to read is listed
with "could not read it: …", a page that is too slow is reported as such (a
timeout is a failure, never mistaken for you pressing Stop), and if the whole
lookup fails the model is told to say the check didn't happen instead of
pretending it did. Stop aborts the web pass mid-read like any other part of
the turn.

Humanizer and Automate are excluded on purpose — their prompts require
JSON-only and rewritten-text-only output, and a web block would break both.
**Source favicons** in Settings (`prefs.citations`, on by default) turns the
markers and chips off if you'd rather read an answer clean; the model still
sees the sources either way.

## Automate can see

Besides the numbered list of buttons and fields it always gets, Automate has a
`look` action: it screenshots the tab, a vision model (`VISION_CHAIN`) describes
the screenshot in plain text, and the planner reads that on its next turn. Use
it for canvas apps, image-heavy pages, or to confirm a click really worked. It
ends the current batch, since what it sees can change the plan. Writing into
rich editors (chat boxes, comment fields) now goes through `execCommand`
rather than assigning `textContent`, which those editors ignore.

## Humanizer

Paste text that reads like an AI wrote it; the reply is the same text with the
stock phrases and even rhythm removed — same meaning, facts and structure. Say
"shorter", "more casual" or "for a school essay" and it redoes the last rewrite
that way. It runs on Groq (`openai/gpt-oss-120b`, falling back to
`openai/gpt-oss-20b`, then `qwen/qwen3.8-27b`) with its own key,
`GROQ_HUMANIZER_KEY` in `src/lib/access.js`. It's a rewriting aid, not a
guarantee against AI detectors — those are unreliable in both directions.

**Learning your voice.** The first time you open the Humanizer it shows ten
question cards, one at a time, in place of the composer (`src/lib/style-questions.js`).
Seven are short writing tasks (introduce yourself, cancel plans, a formal email…)
and three ask you to describe your own habits and what sounds fake to you. Each
answer needs at least 25 and at most 500 characters. Progress is saved after
every keystroke, so closing the panel mid-way loses nothing, and the header
stays usable — pick another Viora and the gate lifts. The answers are stored
on-device (`settings.humanizer`) and added to every rewrite's system prompt as
data about your style. Retake or clear them from the Humanizer's welcome screen
or Settings → *Humanizer writing style*.

## Speed

- A model that hasn't produced a first token in 10 seconds is dropped and the
  next one in its chain takes the turn (the last model is never timed out).
  A model is only remembered as "working" once it has actually started answering.
- Automate's reviewer gets at most two models, 6 seconds each, low reasoning
  effort and a short answer; if it's slow it's skipped and the planner's steps run.
- `quick` mode asks `openai/gpt-oss-*` models to think briefly.
- Groq counts the prompt *plus* the reserved reply against a small per-minute
  token ceiling, so a research-heavy turn can be refused as "request too large"
  before it runs. The reserved reply is shrunk to fit when that is enough
  (`providers.js` learns each model's ceiling from the refusal and sizes later
  turns to fit first time); when the prompt itself is over the ceiling the panel
  rebuilds the same turn with less context — page, then history, then the web
  block's text — rather than surfacing the error.

## The "+" menu

Click it to upload a file, or to hand Viora one of your open tabs — pick one
and its page content is read on every turn until you remove the chip. That's
a `pageContext()` read (same one automation already used), not a screenshot:
Viora gets the page's text, not a picture of it. Listing tabs needs the
`tabs` permission, which is why Chrome will ask you to re-approve Viora after
this update.

## Voice input

The mic button records your speech and transcribes it with Groq's
`whisper-large-v3`. It uses its own key (`GROQ_STT_KEY` in `src/lib/access.js`),
so transcription never draws on the shared chat budget (a personal key from
settings still wins for both). Tap to record, tap again when you're done, and
the text lands in the input box for you to review before sending.

Chrome hides the mic-permission prompt inside a docked side panel, so the
first time you tap the mic Viora opens a small popup that asks for microphone
access once (see `src/mic/`). If permission is blocked, it opens the site
settings instead. If the mic still can't be captured it falls back to Chrome's
built-in speech recognition, and the button hides if the browser supports
neither.

## Images and video

Uploaded images and videos go to NVIDIA's multimodal models first
(`NVIDIA_VISION_CHAIN` in `src/lib/models.js`: DeepSeek V4.1 Flash, GLM 5.3
Flash, Muse Glimmer, Kimi K3), with Groq's `qwen/qwen3.8-27b` (`VISION_CHAIN`)
as the fallback. Images are downscaled client-side, up to eight pictures per
request. A video is never uploaded whole: Viora samples 4–8 evenly spaced
frames in the browser (`readVideo` in `src/lib/files.js`), labels each with its
timestamp, and sends them as images, so the model can describe what happens
over time. The soundtrack is not read, and Groq's fallback only accepts three
pictures per request. Any mode you're talking to will use them.

## Icons, not emoji

The interface itself never speaks in emoji — `src/lib/icons.js` is a small
set of stroke icons (one per assistant, plus upload/tab/mic/check/plus) that
every bit of chrome draws from instead: the model pill, the welcome screen,
the picker rows, the reply badge, thread history. Only Viora's own replies
use emoji, and only at whatever level is set in **Emoji** under settings.

## Maths

Viora renders LaTeX itself — no engine is bundled, because the extension's CSP
forbids remote scripts and KaTeX is far too heavy for a side panel. `src/lib/math.js`
covers what an assistant actually writes:

- `\frac{3}{4}` draws as a stacked fraction with a rule, not `3/4`
- `\sqrt{x}`, `\sqrt[3]{x}`, `x^{2}`, `a_{n}`
- `\le \ge \ne \approx \pm \times \cdot \infty \sum \int` and the Greek alphabet
- ASCII stand-ins typed by habit (`>=`, `<=`, `!=`, `->`, `+-`) are converted
- a bare `3/4` between `$…$` is promoted to a real fraction

The system prompt tells every model to write maths this way, so it usually
arrives already correct.

## Voice

Viora is warm by default: it reacts, has opinions, and uses the occasional
emoji. That's a character, not a claim about inner life — and it never buys
agreeableness with accuracy. It still says "I'm not sure", still disagrees when
you're about to do something that won't work. Both can be turned down in
settings: **Voice → Plain** and **Emoji → None**.

## 100+ ways to write

`src/lib/styles.js` is a catalogue of over 100 writing techniques — structures
(numbered lists, tables, timelines, decision trees), tones (blunt, deadpan,
tactful…), sentence craft (rule of three, antithesis, fragments), reasoning
rhetoric (steelman, pre-mortem, inversion) and ready-made formats (emails,
cover letters, poems, release notes, post-mortems). Ask for one by name —
"write this as a bulleted list, formal tone", "draft a cover letter", "as a
haiku" — and the matching techniques are folded into that turn's system
prompt, each with a one-line instruction.

They load **on demand only**: `matchStyles()` requires the message to both
name a technique and read as a writing request (a stray "did you get my
email?" pulls in nothing), caps what's injected at four techniques and 900
characters, and an ordinary turn pays zero tokens — which matters, because
the shared key meters 8,000 tokens a minute. The Humanizer, Automate and
quiz cards never receive them: those must emit only rewritten text or only
their JSON object.

## Settings

There are no credential fields, because there are no credentials to enter. What
is there:

- which Viora opens by default
- voice and emoji level
- reply length, working-shown, source favicons
- model IDs, if you want to pin a specific Groq model to one of the four
- an optional personal Groq key, for when the shared one hits a rate limit

## Tests

There is no bundler and no test framework here, so the suite is a web page:
`test/server.ps1` serves the workspace (and proxies `/proxy?url=…`, which
reproduces the `<all_urls>` host permission an extension page has and a web
page doesn't), and `test/run.ps1` opens `test/index.html` in headless Chrome,
lets it run in real time, and prints the verdict. The live checks hit the real
DuckDuckGo/Bing and real pages through that proxy.

```
powershell -NoProfile -ExecutionPolicy Bypass -File .\test\server.ps1   # keep running
powershell -NoProfile -ExecutionPolicy Bypass -File .\test\run.ps1
```

## About the shipped key

`src/lib/access.js` contains a Groq key in plain text. Two consequences worth
knowing about:

1. Anyone who installs Viora can read it out of the source. It is not secret.
2. Groq counts free-tier limits **per key, not per user**. Every install shares
   one budget, so rate limits arrive quickly once more than a handful of people
   are using it.

Viora softens this in the client (`src/lib/providers.js`): a request that only
just misses the minute's token budget is shrunk to fit and re-sent at once, short
resets are waited out, and only then does it fall back to the next model. Page
context, chat history and Flash's reply reservation are kept lean for the same
reason. It can't create budget that isn't there, though — with many installs on
one key, the fix is per-user keys or a proxy.

The optional key field in settings is the escape hatch: a free key from
console.groq.com, stored on-device, takes over for that install. If the shared
key gets abused, rotate it in `access.js` and ship a new version.

## Model IDs

Groq retires model IDs on its own schedule. Each assistant carries a fallback
chain (`src/lib/models.js`); a dead ID is skipped automatically and the one that
answered is remembered. If a whole chain dies, the error offers a live list of
what Groq is serving so you can pin a replacement without editing code.

## Install

1. `chrome://extensions` → enable Developer mode
2. Load unpacked → choose this folder
3. Ctrl+Shift+Y (Cmd+Shift+Y) opens the panel

## Build

```
./scripts/build.sh
```

Validates the manifest, checks every referenced file exists, checks no key has
leaked outside `access.js`, and writes `dist/viora-extension-<version>.zip`.

## Layout

```
src/
  lib/
    access.js      the shipped keys + base URLs
    models.js      the five assistants and their model chains
    providers.js   Groq streaming client with chain fallback
    prompts.js     system prompts: voice, emoji, maths rules
    styles.js      100+ writing techniques, injected on demand
    math.js        LaTeX subset → HTML
    markdown.js    markdown + maths + tables, escaped throughout
    storage.js     settings and saved threads
    style-questions.js  the Humanizer's ten onboarding cards
    citations.js   source chips and inline markers
    web.js         the always-on web pass: search, page/PDF reading, budget
    automation.js  page snapshots and action running
    files.js       attachments (and the shared PDF text extractor)
  mic/             microphone permission bridge (popup that asks Chrome once)
  sidepanel/       the panel
  options/         settings
  background/      service worker
  content/         page-side helpers
```
