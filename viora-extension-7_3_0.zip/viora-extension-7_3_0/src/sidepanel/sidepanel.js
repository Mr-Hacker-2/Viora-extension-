/**
 * Viora — side panel controller.
 * One backend, four personalities. Owns the thread, runs the turn, renders it.
 */

import {
  getSettings, saveSettings, getThreads, saveThread, deleteThread, newThread,
  groqConfig, configForChoice, partnerConfig, rememberModel
} from '../lib/storage.js';
import { MODELS, MODEL_ORDER, VISION_CHAIN, getModel, chainFor, partnerChain } from '../lib/models.js';
import { streamChat, completeChat, listModels, ProviderError, transcribeAudio, synthesizeSpeech } from '../lib/providers.js';
import { renderMarkdown, renderInline, bindCodeCopy, escapeHtml } from '../lib/markdown.js';
import { sourceStrip, linkInlineMarkers, extractTrailingSources } from '../lib/citations.js';
import { systemFor, withPageContext, REVIEWER_SYSTEM } from '../lib/prompts.js';
import { readFile, readScreenshot, attachmentsToText, attachmentsToContent, LIMITS } from '../lib/files.js';
import { icon, MODEL_ICON } from '../lib/icons.js';
import {
  activeTab, openTabs, snapshot, pageContext, parsePlan, parseReview, runPlan, describeAction,
  isRestrictedUrl, PageAccessError, MAX_TURNS, MAX_TOTAL_ACTIONS, screenshotSelect
} from '../lib/automation.js';

const $ = (sel) => document.querySelector(sel);

/** How many times the reviewer may check a plan (and the planner revise between) before it just runs. */
const MAX_REVIEW_ROUNDS = 2;

// Safety net: an uncaught error anywhere (a click handler, a render pass,
// a rejected promise) used to fail silently — a button would just look
// dead, with nothing in the UI to say why. Surface it in the status line
// instead, and always to the console, so a real bug is diagnosable from
// screenshots/reports instead of "nothing happens".
window.addEventListener('error', (e) => {
  console.error('[Viora]', e.error || e.message);
  try { setStatus('Something went wrong — check the console (right-click → Inspect).'); } catch {}
});
window.addEventListener('unhandledrejection', (e) => {
  console.error('[Viora]', e.reason);
  try { setStatus('Something went wrong — check the console (right-click → Inspect).'); } catch {}
});

const el = {
  root: document.documentElement,
  thread: $('#thread'),
  welcome: $('#welcome'),
  welcomeIcon: $('#welcome-icon'),
  welcomeLine: $('#welcome-line'),
  suggestions: $('#suggestions'),
  form: $('#composer'),
  input: $('#input'),
  send: $('#send'),
  hint: $('#hint'),
  status: $('#status'),
  attach: $('#attach'),
  attachSheet: $('#attach-sheet'),
  attachUpload: $('#attach-upload'),
  attachUploadIcon: $('#attach-upload-icon'),
  attachScreenshot: $('#attach-screenshot'),
  attachScreenshotIcon: $('#attach-screenshot-icon'),
  tabsDivider: $('#tabs-divider'),
  tabList: $('#tab-list'),
  fileInput: $('#file-input'),
  attachTray: $('#attach-tray'),
  pageChip: $('#page-chip'),
  pageChipIcon: $('#page-chip-icon'),
  pageChipTitle: $('#page-chip-title'),
  pageChipRemove: $('#page-chip-remove'),
  mic: $('#mic'),
  micIcon: $('#mic-icon'),
  voice: $('#voice'),
  voiceIcon: $('#voice-icon'),
  modelBtn: $('#model-btn'),
  modelSheet: $('#model-sheet'),
  modelList: $('#model-list'),
  pillIcon: $('#pill-icon'),
  pillName: $('#pill-name'),
  drawer: $('#drawer'),
  threadList: $('#thread-list'),
  threadEmpty: $('#thread-empty')
};

const OPENERS = {
  flash: 'What are we working on?',
  search: 'What should I go and find out?',
  math: 'Give me something to chew on.',
  automate: 'What should I do on this page?',
  humanize: 'Paste the text and I’ll make it sound like you wrote it.'
};

const SUGGESTIONS = {
  flash: ['Summarise what I am reading', 'Draft a reply to this email', 'Talk me through two options'],
  search: ['What changed in EU AI rules this year?', 'Compare this year’s flagship phone cameras', 'Is this library still maintained?'],
  math: ['Solve 3x² − 7x + 2 = 0 step by step', 'Why does this throw a null reference?', 'Write a debounce hook in TypeScript'],
  automate: ['Fill this form with my details', 'Read me the pricing table', 'Open the first search result'],
  humanize: ['Make this sound more casual: ', 'Humanize this, keep it under 150 words: ', 'Humanize this for a school essay: ']
};

let settings = await getSettings();
let config = groqConfig(settings);
let thread = newThread(settings.prefs.model);
let controller = null;
let busy = false;
let pendingAttachments = [];
/** The tab picked from the "+" menu, if any — its page is read on every turn until removed. */
let selectedPage = null;

/* ---------------- shell ---------------- */

function current() {
  return getModel(thread.model);
}

function chain(choice = thread.model) {
  return chainFor(choice, {
    overrides: settings.modelOverrides,
    resolved: settings.resolvedModels
  });
}

/** Remember which ID answered, so the dead ones aren't retried next turn. */
function noteModel(choice) {
  return async (modelId) => {
    if (settings.resolvedModels[choice] !== modelId) {
      settings = await rememberModel(choice, modelId);
    }
  };
}

function setModel(choice) {
  thread.model = choice;
  const model = current();
  el.root.dataset.model = choice;
  el.pillIcon.innerHTML = icon(MODEL_ICON[choice]);
  el.pillName.textContent = model.name;
  el.modelBtn.title = model.blurb;
  el.input.placeholder = model.placeholder;
  el.welcomeIcon.innerHTML = icon(MODEL_ICON[choice]);
  el.welcomeLine.textContent = OPENERS[choice] || OPENERS.flash;

  el.attach.hidden = !model.canAttach;
  if (!model.canAttach) {
    if (pendingAttachments.length) {
      pendingAttachments = [];
      renderTray();
    }
    if (selectedPage) {
      selectedPage = null;
      renderPageChip();
    }
  }

  renderSuggestions();
  renderModelList();
  saveSettings({ prefs: { model: choice } });
}

function renderModelList() {
  el.modelList.replaceChildren();
  for (const id of MODEL_ORDER) {
    const model = MODELS[id];
    const li = document.createElement('li');

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'model-row';
    btn.dataset.model = id;
    btn.setAttribute('role', 'option');
    btn.setAttribute('aria-selected', String(id === thread.model));

    const rowIcon = document.createElement('span');
    rowIcon.className = 'row-icon';
    rowIcon.innerHTML = icon(MODEL_ICON[id]);

    const copy = document.createElement('span');
    copy.className = 'row-copy';
    const name = document.createElement('span');
    name.className = 'row-name';
    name.textContent = model.name;
    const blurb = document.createElement('span');
    blurb.className = 'row-blurb';
    blurb.textContent = model.blurb;
    copy.append(name, blurb);

    const tick = document.createElement('span');
    tick.className = 'row-tick';
    if (id === thread.model) tick.innerHTML = icon('check');

    btn.append(rowIcon, copy, tick);
    btn.addEventListener('click', () => {
      setModel(id);
      closeSheets();
      el.input.focus();
    });

    li.append(btn);
    el.modelList.append(li);
  }
}

function renderSuggestions() {
  el.suggestions.replaceChildren();
  for (const text of SUGGESTIONS[thread.model] || []) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'suggestion';
    b.textContent = text;
    b.addEventListener('click', () => {
      el.input.value = text;
      el.input.focus();
      autosize();
    });
    el.suggestions.append(b);
  }
}

function closeSheets() {
  el.modelSheet.hidden = true;
  el.drawer.hidden = true;
  el.attachSheet.hidden = true;
  el.modelBtn.setAttribute('aria-expanded', 'false');
  $('#history').setAttribute('aria-expanded', 'false');
  el.attach.setAttribute('aria-expanded', 'false');
}

/* ---------------- the "+" menu: upload a file, or read an open tab ---------------- */

/** Set an icon element's content to a tab's favicon, falling back to the generic tab glyph. */
function setFavicon(target, favIconUrl) {
  target.replaceChildren();
  if (!favIconUrl) {
    target.innerHTML = icon('tab');
    return;
  }
  const img = document.createElement('img');
  img.src = favIconUrl;
  img.alt = '';
  img.addEventListener('error', () => { target.innerHTML = icon('tab'); }, { once: true });
  target.append(img);
}

function renderPageChip() {
  if (!selectedPage) {
    el.pageChip.hidden = true;
    return;
  }
  el.pageChip.hidden = false;
  el.pageChipTitle.textContent = selectedPage.title;
  el.pageChipTitle.title = selectedPage.url;
  setFavicon(el.pageChipIcon, selectedPage.favIconUrl);
}

function pickPage(tab) {
  selectedPage = { id: tab.id, title: tab.title, url: tab.url, favIconUrl: tab.favIconUrl };
  renderPageChip();
  closeSheets();
  el.input.focus();
}

const tabsById = new Map();

async function renderTabList() {
  el.tabList.replaceChildren();
  el.tabsDivider.hidden = true;
  tabsById.clear();

  let tabs;
  try {
    tabs = await openTabs();
  } catch {
    return;
  }
  // The panel's own window still counts, but there's nothing useful to
  // hand back for a tab Viora structurally can't read — show it, but disabled.
  if (!tabs.length) return;

  el.tabsDivider.hidden = false;
  for (const tab of tabs) {
    const li = document.createElement('li');
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'sheet-action tab-row';
    row.disabled = tab.restricted;
    if (tab.restricted) row.title = "Viora can't read this page.";

    const favicon = document.createElement('span');
    favicon.className = 'sheet-action-icon';
    setFavicon(favicon, tab.favIconUrl);

    const copy = document.createElement('span');
    copy.className = 'tab-copy';
    const title = document.createElement('span');
    title.className = 'tab-title';
    title.textContent = tab.title;
    const host = document.createElement('span');
    host.className = 'tab-host';
    try {
      host.textContent = new URL(tab.url).hostname;
    } catch {
      host.textContent = tab.url;
    }
    copy.append(title, host);

    row.append(favicon, copy);
    if (!tab.restricted) row.dataset.tabId = String(tab.id);
    li.append(row);
    el.tabList.append(li);
    if (!tab.restricted) tabsById.set(tab.id, tab);
  }
}

// Delegated: the list is torn down and rebuilt every time the "+" sheet
// opens (renderTabList), so binding to the container instead of each row
// means a click always hits a live listener, however many times it's redrawn.
el.tabList.addEventListener('click', (e) => {
  const row = e.target.closest('.tab-row');
  if (!row || row.disabled) return;
  const tab = tabsById.get(Number(row.dataset.tabId));
  if (tab) pickPage(tab);
});

function setStatus(text) {
  el.status.textContent = text;
  el.status.hidden = !text;
}

function setBusy(state) {
  busy = state;
  el.send.classList.toggle('stop', state);
  el.send.setAttribute('aria-label', state ? 'Stop' : 'Send');
  el.hint.textContent = state ? 'Thinking' : '';
}

let scrollFrame = 0;
function scrollDown() {
  // Streaming calls this per token; one scroll per frame is plenty.
  if (scrollFrame) return;
  scrollFrame = requestAnimationFrame(() => {
    scrollFrame = 0;
    el.thread.scrollTop = el.thread.scrollHeight;
  });
}

function autosize() {
  el.input.style.height = 'auto';
  el.input.style.height = `${Math.min(el.input.scrollHeight, 168)}px`;
}

/* ---------------- rendering ---------------- */

function clearWelcome() {
  if (el.welcome.isConnected) el.welcome.remove();
}

function attachmentChip(a, onRemove) {
  const chip = document.createElement('span');
  chip.className = 'attach-chip' + (a.warning ? ' has-warning' : '');
  if (a.warning) chip.title = a.warning;

  if (a.kind === 'image' && a.dataUrl) {
    const img = document.createElement('img');
    img.src = a.dataUrl;
    img.alt = '';
    chip.append(img);
  } else {
    const icon = document.createElement('span');
    icon.className = 'attach-icon';
    icon.textContent = a.kind === 'pdf' ? 'PDF' : 'TXT';
    chip.append(icon);
  }

  const name = document.createElement('span');
  name.className = 'attach-name';
  name.textContent = a.name;
  chip.append(name);

  if (onRemove) {
    const x = document.createElement('button');
    x.type = 'button';
    x.className = 'attach-remove';
    x.textContent = '×';
    x.setAttribute('aria-label', `Remove ${a.name}`);
    chip.append(x);
  }
  return chip;
}

function addUser(text, attachments = []) {
  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg user';

  if (attachments.length) {
    const tray = document.createElement('div');
    tray.className = 'attach-chips';
    attachments.forEach((a) => tray.append(attachmentChip(a)));
    node.append(tray);
  }
  if (text) {
    const p = document.createElement('div');
    p.className = 'user-text';
    p.textContent = text;
    node.append(p);
  }

  el.thread.append(node);
  scrollDown();
}

function addAssistant() {
  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg assistant streaming';

  const badge = document.createElement('span');
  badge.className = 'who';
  badge.innerHTML = icon(MODEL_ICON[thread.model]);

  const trace = document.createElement('details');
  trace.className = 'reasoning';
  trace.hidden = true;
  const summary = document.createElement('summary');
  summary.textContent = 'Working it out';
  const pre = document.createElement('div');
  pre.className = 'trace';
  trace.append(summary, pre);

  const body = document.createElement('div');
  body.className = 'body';

  node.append(badge, trace, body);
  el.thread.append(node);
  scrollDown();

  let pendingMd = null;
  let mdFrame = 0;

  return {
    node,
    body,
    setReasoning(text) {
      if (!settings.prefs.showReasoning || !text) return;
      trace.hidden = false;
      pre.textContent = text;
    },
    // Re-rendering the whole markdown tree for every streamed token gets
    // slower the longer the reply is. Coalesce to one render per frame —
    // always the latest text, so nothing is lost — and flush on finish.
    setMarkdown(text) {
      pendingMd = text;
      if (mdFrame) return;
      mdFrame = requestAnimationFrame(() => {
        mdFrame = 0;
        if (pendingMd !== null) {
          body.innerHTML = renderMarkdown(pendingMd);
          pendingMd = null;
        }
      });
    },
    finish() {
      if (mdFrame) {
        cancelAnimationFrame(mdFrame);
        mdFrame = 0;
      }
      if (pendingMd !== null) {
        body.innerHTML = renderMarkdown(pendingMd);
        pendingMd = null;
      }
      node.classList.remove('streaming');
      bindCodeCopy(body);
    }
  };
}

function addError(err, retry, extra) {
  clearWelcome();
  const box = document.createElement('div');
  box.className = 'msg assistant';
  const inner = document.createElement('div');
  inner.className = 'error';
  inner.textContent = err.message || 'Something went wrong.';
  if (err.hint) {
    const fix = document.createElement('span');
    fix.className = 'fix';
    fix.textContent = err.hint;
    inner.append(fix);
  }
  if (retry) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'Try again';
    btn.addEventListener('click', () => {
      box.remove();
      retry();
    });
    inner.append(btn);
  }
  box.append(inner);
  if (extra) inner.append(extra);
  el.thread.append(box);
  scrollDown();
}

/**
 * When every model in a chain is gone, ask Groq what it does serve and let the
 * user pin one, rather than sending them hunting through settings.
 */
function modelPicker(choice, retryFn) {
  const wrap = document.createElement('div');
  wrap.className = 'model-fix';
  const providerConfig = configForChoice(settings, choice);
  const providerLabel = providerConfig.label || 'Groq';

  const load = document.createElement('button');
  load.type = 'button';
  load.textContent = `Show what ${providerLabel} is serving`;

  load.addEventListener('click', async () => {
    load.disabled = true;
    load.textContent = 'Loading';
    try {
      const models = await listModels({ config: providerConfig });
      load.remove();

      const note = document.createElement('p');
      note.className = 'fix';
      note.textContent = `${providerLabel} has ${models.length} models right now. Pick the one ${getModel(choice).name} should use.`;

      const list = document.createElement('div');
      list.className = 'id-list';

      for (const id of models) {
        const b = document.createElement('button');
        b.type = 'button';
        b.textContent = id;
        b.addEventListener('click', async () => {
          settings = await saveSettings({ modelOverrides: { [choice]: id } });
          retryFn?.();
        });
        list.append(b);
      }

      wrap.append(note, list);
    } catch (err) {
      load.disabled = false;
      load.textContent = `Show what ${providerLabel} is serving`;
      const fail = document.createElement('span');
      fail.className = 'fix';
      fail.textContent = err.message;
      wrap.append(fail);
    }
  });

  wrap.append(load);
  return wrap;
}

/* ---------------- history ---------------- */

async function refreshDrawer() {
  const threads = await getThreads();
  el.threadList.replaceChildren();
  el.threadEmpty.hidden = threads.length > 0;

  for (const t of threads) {
    const li = document.createElement('li');
    const row = document.createElement('div');
    row.className = 'thread-item';

    const open = document.createElement('button');
    open.type = 'button';
    open.className = 't-title';
    open.textContent = t.title;
    open.addEventListener('click', () => loadThread(t));

    const mark = document.createElement('span');
    mark.className = 't-mode';
    mark.innerHTML = icon(MODEL_ICON[t.model] || 'flash');
    mark.title = getModel(t.model).name;

    const del = document.createElement('button');
    del.type = 'button';
    del.className = 't-del';
    del.title = 'Delete';
    del.setAttribute('aria-label', `Delete ${t.title}`);
    del.textContent = '×';
    del.dataset.threadId = t.id;

    row.append(open, mark, del);
    li.append(row);
    el.threadList.append(li);
  }
}

// Delegated: the drawer's rows are rebuilt on every refreshDrawer() call, so a
// listener bound directly to a row is gone the moment the list re-renders.
// Binding once on the stable #thread-list container survives every re-render.
el.threadList.addEventListener('click', async (e) => {
  const del = e.target.closest('.t-del');
  if (!del) return;
  try {
    await deleteThread(del.dataset.threadId);
    refreshDrawer();
  } catch (err) {
    setStatus("Couldn't delete that conversation — try again.");
  }
});

function loadThread(saved) {
  thread = structuredClone(saved);
  closeSheets();
  el.thread.replaceChildren();
  setModel(thread.model || 'flash');

  for (const m of thread.messages) {
    if (m.role === 'user') {
      addUser(m.displayText ?? m.content, m.attachments || []);
    } else {
      const view = addAssistant();
      view.setReasoning(m.reasoning);
      view.setMarkdown(m.content);
      if (m.sources?.length) {
        linkInlineMarkers(view.body, m.sources);
        view.body.append(sourceStrip(m.sources));
      }
      view.finish();
    }
  }
  scrollDown();
}

async function persist(firstPrompt) {
  if (thread.title === 'New conversation' && firstPrompt) {
    thread.title = firstPrompt.replace(/\s+/g, ' ').slice(0, 52) + (firstPrompt.length > 52 ? '…' : '');
  }
  await saveThread(thread);
  refreshDrawer();
}

/* ---------------- the turn ---------------- */

async function collectPage() {
  if (!selectedPage) return null;
  try {
    return await pageContext(selectedPage.id);
  } catch (err) {
    setStatus(err.message || "Viora can't read that page.");
    return null;
  }
}

async function runChat() {
  const model = current();
  const page = await collectPage();
  const attachments = pendingTurnAttachments;
  const hasImages = attachments.some((a) => a.kind === 'image');

  // Images need a vision model whichever personality is selected. The vision
  // model only exists on Groq, so an image turn always uses Groq regardless
  // of whether the chosen personality normally runs on NVIDIA.
  const models = hasImages ? [...VISION_CHAIN, ...chain()] : chain();
  const turnConfig = hasImages ? groqConfig(settings) : configForChoice(settings, thread.model);
  const canSearch = model.canSearch && !hasImages;

  const messages = [
    { role: 'system', content: withPageContext(systemFor(model.prompt, settings.prefs, { canSearch }), page) },
    // The last 20 messages are plenty of context, and a shorter prompt means
    // a faster first token on long threads.
    ...thread.messages.slice(-20).map(({ role, content }) => ({ role, content }))
  ];

  if (hasImages) {
    const last = messages[messages.length - 1];
    last.content = attachmentsToContent(last.content, attachments);
  }

  const view = addAssistant();
  let content = '';
  let reasoning = '';

  // Some hosted reasoning models put their chain inline in <think> tags
  // instead of a separate field, so split it back out before rendering.
  const split = (raw) => {
    const open = raw.indexOf('<think>');
    if (open < 0) return { think: '', answer: raw };
    const close = raw.indexOf('</think>');
    return close < 0
      ? { think: raw.slice(open + 7), answer: '' }
      : { think: raw.slice(open + 7, close), answer: raw.slice(0, open) + raw.slice(close + 8) };
  };

  if (canSearch) setStatus('Searching the web');

  // Free-tier Groq caps qwen3.8-27b (the vision model) at 1000 output tokens
  // per minute and rejects a request that *expects* more before it runs, so
  // keep image turns modest no matter what the default maxTokens is.
  const maxTokens = hasImages ? Math.min(settings.prefs.maxTokens, 768) : settings.prefs.maxTokens;

  const result = await streamChat({
    config: turnConfig,
    models,
    messages,
    temperature: model.temperature,
    maxTokens,
    tools: canSearch ? [{ type: 'browser_search' }] : undefined,
    toolChoice: canSearch ? 'auto' : undefined,
    signal: controller.signal,
    onModel: noteModel(hasImages ? 'vision' : thread.model),
    onDelta: (d) => {
      if (d.reasoning) {
        reasoning += d.reasoning;
        view.setReasoning(reasoning);
      }
      if (d.content) {
        setStatus('');
        content += d.content;
        const { think, answer } = split(content);
        if (think) view.setReasoning(reasoning + think);
        view.setMarkdown(answer);
      }
      scrollDown();
    }
  });

  setStatus('');
  const { think, answer } = split(result.content);
  const cleaned = answer.trim();
  const { text: displayAnswer, sources } = canSearch
    ? extractTrailingSources(cleaned)
    : { text: cleaned, sources: [] };

  view.setMarkdown(displayAnswer);
  if (sources.length && settings.prefs.citations) {
    linkInlineMarkers(view.body, sources);
    view.body.append(sourceStrip(sources));
  }
  view.finish();

  thread.messages.push({
    role: 'assistant',
    content: displayAnswer,
    reasoning: (result.reasoning || think).trim(),
    sources
  });
}

/**
 * Viora Automate's eyes. Screenshots the tab, has the vision model describe it
 * in plain text, and hands that back as the step's result (which lands in the
 * planner's "Done so far"). Chrome can only capture the tab that's in front,
 * so a background tab is brought forward first.
 */
async function lookAtTab(tabId, action) {
  const tab = await chrome.tabs.get(tabId);
  if (isRestrictedUrl(tab.url)) throw new PageAccessError(tab.url);
  if (!tab.active) {
    await chrome.tabs.update(tabId, { active: true });
    await new Promise((r) => setTimeout(r, 300)); // let it paint
  }

  const shot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 70 });
  // Whole viewport, downscaled the same way uploaded images are.
  const image = await readScreenshot(shot, { x: 0, y: 0, width: 100000, height: 100000 }, 1);

  const focus = (action.value || '').trim();
  const ask =
    'You are the eyes of a browser assistant. Describe what is on this screenshot of a web page in plain text: ' +
    'the main sections and their layout, visible text that matters, buttons, fields and their state (filled, empty, disabled, error), ' +
    'images or charts and what they show, popups or banners in the way, and anything that looks loading or broken. ' +
    (focus ? `Pay special attention to: ${focus}. ` : '') +
    'Be specific and concise, under 180 words, no preamble.';

  const { content } = await completeChat({
    config: groqConfig(settings),
    models: VISION_CHAIN,
    messages: [{ role: 'user', content: attachmentsToContent(ask, [image]) }],
    temperature: 0.2,
    // Free-tier Groq caps the vision model's output per minute; stay modest.
    maxTokens: 400,
    timeoutMs: 20000,
    signal: controller?.signal
  });
  const seen = content.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
  if (!seen) return { ok: false, detail: 'The vision model came back empty.' };
  return { ok: true, detail: `Saw: ${seen.slice(0, 900)}` };
}

/**
 * The Humanizer: paste AI-sounding text, get it back sounding human. One
 * streamed Groq call — no page, no tools — so it starts printing right away.
 */
const HUMANIZE_MAX_CHARS = 15000;

async function runHumanize() {
  const model = current();
  const lastUser = thread.messages.at(-1)?.content || '';
  if (lastUser.length > HUMANIZE_MAX_CHARS) {
    throw new ProviderError('That’s too much text for one go.', {
      hint: 'Paste about 2,500 words at a time and I’ll do it in pieces.'
    });
  }

  // Only the last few turns: enough for "shorter" or "warmer" to mean the
  // previous rewrite, short enough that the first word appears quickly.
  const recent = thread.messages.slice(-5).map(({ role, content }) => ({ role, content }));
  while (recent.length && recent[0].role !== 'user') recent.shift();

  const messages = [{ role: 'system', content: systemFor(model.prompt, settings.prefs) }, ...recent];
  const view = addAssistant();
  setStatus('Rewriting');

  // Drop any <think> block a reasoning model leaves inline.
  const stripThink = (raw) =>
    raw.replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/<think>[\s\S]*$/i, '');

  let content = '';
  const result = await streamChat({
    config: configForChoice(settings, 'humanize'),
    models: chain('humanize'),
    messages,
    temperature: model.temperature,
    // A rewrite is about as long as the original; leave headroom, not a cap
    // that clips it.
    maxTokens: Math.min(4096, Math.max(400, Math.ceil(lastUser.length / 2.2))),
    quick: true,
    signal: controller.signal,
    onModel: noteModel('humanize'),
    onDelta: (d) => {
      if (!d.content) return;
      setStatus('');
      content += d.content;
      view.setMarkdown(stripThink(content));
      scrollDown();
    }
  });

  setStatus('');
  const text = stripThink(result.content).trim();
  view.setMarkdown(text);
  view.finish();

  const words = (t) => (t.trim() ? t.trim().split(/\s+/).length : 0);
  const bar = document.createElement('div');
  bar.className = 'humanize-bar';
  const count = document.createElement('span');
  count.textContent = `${words(lastUser)} → ${words(text)} words`;
  const copy = document.createElement('button');
  copy.type = 'button';
  copy.className = 'copy-btn';
  copy.textContent = 'Copy';
  copy.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(text);
      copy.textContent = 'Copied';
    } catch {
      copy.textContent = 'Couldn’t copy';
    }
    setTimeout(() => { copy.textContent = 'Copy'; }, 1500);
  });
  bar.append(count, copy);
  view.node.append(bar);

  thread.messages.push({ role: 'assistant', content: text, reasoning: '' });
}

/**
 * Works a task across as many planning turns as it needs, re-snapshotting the
 * page after each batch so the model always plans against what's on screen now.
 */
async function runAutomation(prompt) {
  const tab = await activeTab();
  if (!tab?.id) throw new ProviderError('No active tab to work with.');
  if (isRestrictedUrl(tab.url)) {
    throw new ProviderError("I can't act on this tab — it's a browser page, not a website.", {
      hint: 'Switch to a normal website tab and ask me again.'
    });
  }

  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg assistant';
  el.thread.append(node);
  scrollDown();

  let currentTabId = tab.id;
  const history = [];
  let lastThought = '';
  let totalActions = 0;
  let turn = 0;
  let finished = false;
  let failStreak = 0;
  let stopNote = '';
  const reasoningLog = [];

  /** A collapsible "Working it out" box for one planning turn (respects the showReasoning pref). */
  function makeTrace() {
    const root = document.createElement('details');
    root.className = 'reasoning';
    root.hidden = true;
    const summary = document.createElement('summary');
    summary.textContent = turn > 1 ? `Working it out (step ${turn})` : 'Working it out';
    const pre = document.createElement('div');
    pre.className = 'trace';
    root.append(summary, pre);
    return {
      root,
      set(text) {
        if (!settings.prefs.showReasoning || !text) return;
        root.hidden = false;
        pre.textContent = text;
        pre.scrollTop = pre.scrollHeight;
      }
    };
  }

  /** The planner ⇄ reviewer conversation for one turn, shown as a short exchange. */
  function makeDuo() {
    const root = document.createElement('div');
    root.className = 'duo';
    const lines = [];
    const say = (who, text, tone) => {
      const row = document.createElement('div');
      row.className = 'duo-row';
      row.dataset.who = who;
      if (tone) row.dataset.tone = tone;
      const tag = document.createElement('span');
      tag.className = 'duo-who';
      tag.textContent = who === 'planner' ? 'Planner' : 'Reviewer';
      const txt = document.createElement('span');
      txt.className = 'duo-text';
      txt.textContent = text;
      row.append(tag, txt);
      root.append(row);
      lines.push(`${tag.textContent}: ${text}`);
      scrollDown();
    };
    const note = (text, cls = 'duo-note') => {
      const p = document.createElement('div');
      p.className = cls;
      p.textContent = text;
      root.append(p);
      lines.push(text);
      scrollDown();
    };
    return {
      root,
      say,
      note,
      agreed: () => note('Both agree — running it.', 'duo-note duo-agreed'),
      transcript: () => lines.join('\n')
    };
  }

  while (!finished && turn < MAX_TURNS && totalActions < MAX_TOTAL_ACTIONS) {
    turn++;

    setStatus('Reading the page');
    let snap;
    try {
      snap = await snapshot(currentTabId);
    } catch (err) {
      stopNote = err instanceof PageAccessError ? err.message : 'Lost track of the tab.';
      break;
    }
    const elements = snap.elements
      .map((e) => `${e.ref}. <${e.tag}${e.type ? ` ${e.type}` : ''}> ${e.label}`)
      .join('\n');

    const trace = makeTrace();
    node.append(trace.root);
    // Two AIs, one plan: the NVIDIA planner drafts, a Groq reviewer checks it
    // against the same snapshot, and they trade notes until they agree (or the
    // round cap is hit). Nothing touches the page before that.
    const duo = settings.prefs.duoAutomate ? makeDuo() : null;
    if (duo) node.append(duo.root);

    const context = `Overall task: ${prompt}\n\n${
      history.length ? `Done so far:\n${history.join('\n')}\n\n` : ''
    }Current page: ${snap.title}\n${snap.url}\n\nElements:\n${elements}`;

    const convo = [
      { role: 'system', content: systemFor('automate', settings.prefs) },
      { role: 'user', content: context }
    ];

    // Streamed, not one blocking call: the planner's own reasoning (when it
    // exposes any) shows up live in the "Working it out" box while it plans.
    const draftPlan = async (messages) => {
      let native = '';
      const res = await streamChat({
        config: configForChoice(settings, 'automate'),
        models: chain('automate'),
        messages,
        temperature: getModel('automate').temperature,
        // Headroom for a reasoning model's chain plus the JSON plan — max_tokens
        // counts both, and a plan cut off mid-JSON is a wasted turn.
        maxTokens: 1600,
        signal: controller.signal,
        onModel: noteModel('automate'),
        onDelta: (d) => {
          if (d.reasoning) {
            native += d.reasoning;
            trace.set(native);
            scrollDown();
          }
        }
      });
      return { raw: res.content, native: res.reasoning || native, plan: parsePlan(res.content) };
    };

    const reviewPlan = async (plan) => {
      const { content } = await completeChat({
        config: partnerConfig(settings),
        // The reviewer only says "agree" or "here's what's wrong", so it gets
        // two tries at most, a few seconds each, and low reasoning effort —
        // a slow reviewer is skipped rather than waited for.
        models: partnerChain({ overrides: settings.modelOverrides, resolved: settings.resolvedModels }).slice(0, 2),
        messages: [
          { role: 'system', content: REVIEWER_SYSTEM },
          {
            role: 'user',
            content: `${context}\n\nProposed plan:\n${JSON.stringify({
              thought: plan.thought,
              reasoning: plan.reasoning,
              actions: plan.actions
            })}`
          }
        ],
        temperature: 0.1,
        maxTokens: 300,
        quick: true,
        timeoutMs: 6000,
        timeoutAll: true,
        signal: controller.signal,
        onModel: noteModel('automatePartner')
      });
      return parseReview(content);
    };

    setStatus(duo ? 'Planner is drafting' : 'Planning');
    let drafted = await draftPlan(convo);
    let plan = drafted.plan;
    let nativeReasoning = drafted.native;

    if (duo) {
      duo.say('planner', plan.thought || `${plan.actions.length} step${plan.actions.length === 1 ? '' : 's'}`);
      let agreed = false;
      for (let round = 0; round < MAX_REVIEW_ROUNDS; round++) {
        setStatus('Reviewer is checking');
        let review;
        try {
          review = await reviewPlan(plan);
        } catch (err) {
          if (err.name === 'AbortError') throw err;
          duo.note("Reviewer couldn't be reached — going ahead with the planner's steps.");
          break;
        }

        if (review.verdict === 'agree') {
          duo.say('reviewer', review.comment || 'Looks right.', 'agree');
          agreed = true;
          break;
        }

        duo.say('reviewer', review.comment || 'Something looks off.', 'revise');
        if (round === MAX_REVIEW_ROUNDS - 1) {
          duo.note("Still not fully agreed — running the planner's latest steps.");
          break;
        }

        setStatus('Planner is revising');
        try {
          const revised = await draftPlan([
            ...convo,
            { role: 'assistant', content: drafted.raw },
            {
              role: 'user',
              content:
                `A second AI (the reviewer) checked your plan against the same page and says: "${review.comment}"\n` +
                'If they are right, reply with the corrected full JSON plan. If they are wrong, keep your plan and explain why in "reasoning". JSON only, same format as before.'
            }
          ]);
          drafted = revised;
          plan = revised.plan;
          nativeReasoning = [nativeReasoning, revised.native].filter(Boolean).join('\n\n');
          duo.say('planner', plan.thought || 'Revised the steps.');
        } catch (err) {
          if (err.name === 'AbortError') throw err;
          duo.note("Planner couldn't revise — keeping its first plan.");
          break;
        }
      }
      if (agreed) duo.agreed();
    }

    lastThought = plan.thought || lastThought;

    // Final trace = the planner's native chain (if it has one) + the short
    // "why these steps" it wrote into the plan itself.
    const traceText = [nativeReasoning.trim(), plan.reasoning].filter(Boolean).join('\n\n');
    trace.set(traceText);
    const logged = [traceText, duo?.transcript()].filter(Boolean).join('\n\n');
    if (logged) reasoningLog.push(`Turn ${turn}:\n${logged}`);

    if (plan.thought && !duo) {
      const body = document.createElement('div');
      body.className = 'body';
      body.innerHTML = `<p>${escapeHtml(plan.thought)}</p>`;
      node.append(body);
    }

    const list = document.createElement('div');
    list.className = 'plan';
    node.append(list);

    const rows = plan.actions.map((action) => {
      const row = document.createElement('div');
      row.className = 'step';
      row.dataset.state = 'idle';
      const dot = document.createElement('span');
      dot.className = 'dot';
      const label = document.createElement('span');
      label.textContent = describeAction(action);
      const detail = document.createElement('span');
      detail.className = 'detail';
      row.append(dot, label, detail);
      list.append(row);
      return { row, detail };
    });
    scrollDown();

    setStatus('Running');
    let i = 0;
    const { results, finalTabId } = await runPlan(currentTabId, plan, (step) => {
      const ui = rows[i++];
      if (!ui) return;
      ui.row.dataset.state = step.ok ? 'ok' : 'fail';
      ui.detail.textContent = (step.detail || '').slice(0, 120);
      scrollDown();
    }, { look: lookAtTab });
    setStatus('');

    currentTabId = finalTabId;
    totalActions += plan.actions.length;
    for (const r of results) {
      history.push(`- ${describeAction(r.action)}: ${r.ok ? r.detail || 'ok' : `failed — ${r.detail}`}`);
    }

    // A look ends its batch early, so a "done" queued behind it never ran.
    finished = results.some((r) => r.action.type === 'done');
    failStreak = results.some((r) => r.ok) ? 0 : failStreak + 1;
    if (failStreak >= 2) {
      stopNote = "Stopping — the last two batches didn't get anywhere. Try rephrasing, or check the page is what you expect.";
      break;
    }
  }

  if (!finished) {
    if (!stopNote) {
      stopNote = `Paused after ${totalActions} steps across ${turn} turn${turn === 1 ? '' : 's'} — say "continue" and I'll pick it up.`;
    }
    const note = document.createElement('div');
    note.className = 'body';
    note.innerHTML = `<p>${escapeHtml(stopNote)}</p>`;
    node.append(note);
  }

  thread.messages.push({
    role: 'assistant',
    content: `${lastThought}\n\n${history.join('\n')}${finished ? '' : `\n\n${stopNote}`}`,
    reasoning: reasoningLog.join('\n\n')
  });
}

/* ---------------- quiz ("test me on ...") ---------------- */

/** "test me on X", "quiz me on X", "test me about X" — X becomes the topic, verbatim. */
const QUIZ_RE = /^(?:test|quiz)\s+me\s+(?:on|about|in)\s+(.+?)[\s.!?]*$/i;

function detectQuizTopic(text) {
  const m = QUIZ_RE.exec(text.trim());
  return m ? m[1].trim() : null;
}

/** Ask the math model for one multiple-choice question, strictly as JSON. */
async function fetchQuizQuestion(topic, avoid = []) {
  const avoidLine = avoid.length
    ? `\n\nAlready asked on this topic — write a different question, don't repeat or reword these:\n- ${avoid.join('\n- ')}`
    : '';
  const { content: raw } = await completeChat({
    config: configForChoice(settings, 'math'),
    models: chain('math'),
    messages: [
      { role: 'system', content: systemFor('quiz', settings.prefs) },
      { role: 'user', content: `Test me on: ${topic}${avoidLine}` }
    ],
    temperature: 0.6,
    maxTokens: 500,
    signal: controller.signal,
    onModel: noteModel('math')
  });
  return parseQuiz(raw);
}

/** Pull the JSON object out of the reply and check its shape before trusting it. */
function parseQuiz(raw) {
  const match = String(raw).match(/\{[\s\S]*\}/);
  let data;
  try {
    data = match && JSON.parse(match[0]);
  } catch {
    data = null;
  }
  const { question, choices, correctIndex, explanation } = data || {};
  if (
    typeof question !== 'string' || !question.trim() ||
    !Array.isArray(choices) || choices.length < 2 ||
    !choices.every((c) => typeof c === 'string' && c.trim()) ||
    !Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex >= choices.length
  ) {
    throw new ProviderError("That question came back malformed — try again, or rephrase the topic.");
  }
  return { question, choices, correctIndex, explanation: typeof explanation === 'string' ? explanation : '' };
}

function addQuizCard() {
  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg assistant';

  const badge = document.createElement('span');
  badge.className = 'who';
  badge.innerHTML = icon(MODEL_ICON.math);

  const card = document.createElement('div');
  card.className = 'quiz-card';
  card.textContent = 'Putting a question together…';

  node.append(badge, card);
  el.thread.append(node);
  scrollDown();
  return card;
}

/** Render one question into the card as tappable choices, flashcard style. */
function renderQuizQuestion(card, topic, q, asked, score) {
  card.dataset.state = 'unanswered';
  card.replaceChildren();

  const head = document.createElement('div');
  head.className = 'quiz-head';
  const topicEl = document.createElement('span');
  topicEl.className = 'quiz-topic';
  topicEl.textContent = topic;
  const scoreEl = document.createElement('span');
  scoreEl.className = 'quiz-score';
  scoreEl.textContent = `${score.right}/${score.total}`;
  head.append(topicEl, scoreEl);

  const qEl = document.createElement('div');
  qEl.className = 'quiz-question';
  qEl.innerHTML = renderInline(q.question);

  const choicesEl = document.createElement('div');
  choicesEl.className = 'quiz-choices';
  const buttons = q.choices.map((choiceText, i) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'quiz-choice';
    btn.innerHTML = renderInline(choiceText);
    btn.addEventListener('click', () => answer(i));
    choicesEl.append(btn);
    return btn;
  });

  card.append(head, qEl, choicesEl);
  scrollDown();

  function answer(i) {
    if (card.dataset.state !== 'unanswered') return;
    card.dataset.state = 'answered';
    const correct = i === q.correctIndex;
    score.total++;
    if (correct) score.right++;
    scoreEl.textContent = `${score.right}/${score.total}`;

    buttons.forEach((btn, idx) => {
      btn.disabled = true;
      if (idx === q.correctIndex) btn.classList.add('correct');
      else if (idx === i) btn.classList.add('wrong');
    });

    if (q.explanation) {
      const exp = document.createElement('div');
      exp.className = 'quiz-explain';
      exp.innerHTML = renderMarkdown(q.explanation);
      card.append(exp);
    }

    const next = document.createElement('button');
    next.type = 'button';
    next.className = 'quiz-next';
    next.textContent = correct ? 'Nice — next question' : 'Next question';
    next.addEventListener('click', async () => {
      next.disabled = true;
      next.textContent = 'Loading…';
      try {
        const nextQ = await fetchQuizQuestion(topic, asked);
        asked.push(nextQ.question);
        if (asked.length > 12) asked.shift();
        renderQuizQuestion(card, topic, nextQ, asked, score);
      } catch (err) {
        next.disabled = false;
        next.textContent = 'Try again';
        setStatus(err.message || "Couldn't get the next question.");
      }
    });
    card.append(next);
    scrollDown();
  }
}

async function runQuiz(topic) {
  const card = addQuizCard();
  const score = { right: 0, total: 0 };
  const asked = [];
  let q;
  try {
    q = await fetchQuizQuestion(topic, asked);
  } catch (err) {
    card.closest('.msg')?.remove();
    throw err;
  }
  asked.push(q.question);
  renderQuizQuestion(card, topic, q, asked, score);

  thread.messages.push({
    role: 'assistant',
    content: `Quiz on **${topic}** — tap an answer above to keep going.`
  });
}

/* ---------------- send ---------------- */

function renderTray() {
  el.attachTray.replaceChildren();
  el.attachTray.hidden = pendingAttachments.length === 0;
  pendingAttachments.forEach((a) => {
    el.attachTray.append(attachmentChip(a, true));
  });
}

// Delegated for the same reason as the drawer's delete button: renderTray()
// rebuilds every chip from scratch, so the container is the only listener
// target guaranteed to stick around.
el.attachTray.addEventListener('click', (e) => {
  const x = e.target.closest('.attach-remove');
  if (!x) return;
  const chip = x.closest('.attach-chip');
  const i = [...el.attachTray.children].indexOf(chip);
  if (i < 0) return;
  pendingAttachments.splice(i, 1);
  renderTray();
});

/** Trim what a saved attachment carries — images keep their data URL, the rest just a name. */
function attachmentMeta(a) {
  return a.kind === 'image'
    ? { kind: 'image', name: a.name, dataUrl: a.dataUrl }
    : { kind: a.kind, name: a.name };
}

let pendingTurnAttachments = [];

async function send(prompt, attachments = []) {
  const text = prompt.trim();
  if (busy || (!text && !attachments.length)) return;

  const quizTopic = !attachments.length ? detectQuizTopic(text) : null;

  pendingTurnAttachments = attachments;
  const folded = attachmentsToText(attachments);
  const fullText = [text, folded].filter(Boolean).join('\n\n') || 'Tell me about the attached file.';

  addUser(text, attachments);
  thread.messages.push({
    role: 'user',
    content: fullText,
    displayText: text,
    attachments: attachments.map(attachmentMeta)
  });
  el.input.value = '';
  autosize();

  controller = new AbortController();
  setBusy(true);

  try {
    if (quizTopic) await runQuiz(quizTopic);
    else if (thread.model === 'automate') await runAutomation(prompt);
    else if (thread.model === 'humanize') await runHumanize();
    else await runChat();
    await persist(text || attachments[0]?.name || 'Shared a file');
  } catch (err) {
    document.querySelector('.msg.assistant.streaming')?.classList.remove('streaming');
    setStatus('');
    if (err.name === 'AbortError') {
      setStatus('Stopped');
    } else if (err.code === 'model_retired') {
      const retry = () => {
        document.querySelectorAll('.msg.assistant .error').forEach((n) => n.closest('.msg')?.remove());
        if (thread.messages.at(-1)?.role === 'user') thread.messages.pop();
        el.thread.querySelector('.msg.user:last-of-type')?.remove();
        send(prompt, attachments);
      };
      addError(err, null, modelPicker(thread.model, retry));
    } else {
      addError(err, () => send(prompt, attachments));
    }
  } finally {
    setBusy(false);
    controller = null;
  }
}

/* ---------------- events ---------------- */

el.form.addEventListener('submit', (e) => {
  e.preventDefault();
  if (busy) {
    controller?.abort();
    return;
  }
  const attachments = pendingAttachments;
  pendingAttachments = [];
  renderTray();
  send(el.input.value, attachments);
});

el.attach.addEventListener('click', () => {
  const open = el.attachSheet.hidden;
  closeSheets();
  el.attachSheet.hidden = !open;
  el.attach.setAttribute('aria-expanded', String(open));
  if (open) renderTabList();
});

el.attachUpload.addEventListener('click', () => {
  closeSheets();
  el.fileInput.click();
});

el.attachScreenshot.addEventListener('click', async () => {
  closeSheets();

  const tab = await activeTab();
  if (!tab?.id) {
    setStatus("Can't find the tab to screenshot.");
    return;
  }
  if (isRestrictedUrl(tab.url)) {
    setStatus("Viora can't screenshot a browser or extension page — switch to a regular website tab.");
    return;
  }
  if (pendingAttachments.length >= LIMITS.maxFiles) {
    setStatus(`I can take up to ${LIMITS.maxFiles} files at a time.`);
    return;
  }

  setStatus('Drag to select an area on the page…');
  let selection;
  try {
    selection = await screenshotSelect(tab.id);
  } catch (err) {
    setStatus(err.message || "Couldn't start the screenshot tool on this page.");
    return;
  }
  if (!selection?.ok) {
    setStatus('');
    return; // cancelled — Esc, or too small a drag
  }

  try {
    const captureDataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
    const result = await readScreenshot(captureDataUrl, selection.rect, selection.dpr);
    pendingAttachments.push(result);
    renderTray();
    setStatus('');
  } catch (err) {
    setStatus("Couldn't capture that screenshot — try again.");
  }
});

el.pageChipRemove.addEventListener('click', () => {
  selectedPage = null;
  renderPageChip();
});

el.fileInput.addEventListener('change', async () => {
  const files = [...el.fileInput.files];
  el.fileInput.value = '';

  for (const file of files) {
    if (pendingAttachments.length >= LIMITS.maxFiles) {
      setStatus(`I can take up to ${LIMITS.maxFiles} files at a time.`);
      break;
    }
    try {
      const result = await readFile(file);
      pendingAttachments.push(result);
      if (result.warning) setStatus(result.warning);
    } catch (err) {
      setStatus(err.message);
    }
  }
  renderTray();
});

el.input.addEventListener('input', autosize);

el.input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    el.form.requestSubmit();
  }
});

el.modelBtn.addEventListener('click', () => {
  const open = el.modelSheet.hidden;
  closeSheets();
  el.modelSheet.hidden = !open;
  el.modelBtn.setAttribute('aria-expanded', String(open));
});

$('#new-thread').addEventListener('click', () => {
  controller?.abort();
  const keep = thread.model;
  thread = newThread(keep);
  el.thread.replaceChildren(el.welcome);
  setModel(keep);
  closeSheets();
  el.input.focus();
});

$('#history').addEventListener('click', (e) => {
  const open = el.drawer.hidden;
  closeSheets();
  el.drawer.hidden = !open;
  e.currentTarget.setAttribute('aria-expanded', String(open));
  if (open) refreshDrawer();
});

$('#open-settings').addEventListener('click', () => chrome.runtime.openOptionsPage());

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeSheets();
});

document.addEventListener('click', (e) => {
  if (el.modelSheet.hidden && el.drawer.hidden && el.attachSheet.hidden) return;
  if (e.target.closest('#model-sheet, #drawer, #attach-sheet, #model-btn, #history, #attach')) return;
  closeSheets();
});

chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area === 'local' && changes.settings) {
    settings = await getSettings();
    config = groqConfig(settings);
  }
});

/* ---------------- voice input ---------------- */

// Viora transcribes speech with Groq's whisper-large-v3. It uses its own key
// (GROQ_STT_KEY), so the shared chat key's budget stays untouched; a personal
// key from settings still wins for both. The mic records locally
// (MediaRecorder) and the audio is transcribed once you tap stop. If the
// microphone can't be captured it falls back to Chrome's built-in recognizer,
// and if neither exists the mic button stays hidden.
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

const canCapture =
  typeof MediaRecorder !== 'undefined' &&
  Boolean(navigator.mediaDevices?.getUserMedia);

if (!canCapture && !SpeechRecognition) {
  el.mic.hidden = true;
} else {
  /** 'idle' | 'requesting' | 'capturing' | 'transcribing' */
  let state = 'idle';
  let audioStream = null; // live mic, released as soon as recording stops
  let recorder = null;    // active MediaRecorder, if any
  let recognizer = null;  // active Chrome recognizer, if any

  const setMicState = (next) => {
    state = next;
    el.mic.classList.toggle('recording', next === 'capturing');
    el.mic.disabled = next === 'requesting' || next === 'transcribing';
    el.mic.setAttribute(
      'aria-label',
      next === 'capturing' ? 'Stop listening'
        : next === 'requesting' ? 'Starting mic'
        : next === 'transcribing' ? 'Transcribing'
        : 'Voice input'
    );
  };

  const releaseMic = () => {
    audioStream?.getTracks().forEach((t) => t.stop());
    audioStream = null;
  };

  const withTimeout = (promise, ms) =>
    Promise.race([
      promise,
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), ms))
    ]);

  /**
   * Make sure the extension may use the mic. Chrome won't show the permission
   * prompt inside a docked side panel (a known limitation), so when permission
   * isn't already granted this opens the mic-permission page in a small popup
   * window where the prompt CAN be shown. A "blocked" state opens the site
   * settings so the user can flip it to Allow. Returns false when the user
   * shouldn't proceed (and has been told why in the status line).
   */
  async function ensureMicPermission() {
    try {
      const status = await navigator.permissions.query({ name: 'microphone' });
      if (status.state === 'granted') return true;
      if (status.state === 'denied') {
        chrome.tabs.create({
          url: `chrome://settings/content/siteDetails?site=chrome-extension%3A%2F%2F${chrome.runtime.id}%2F`
        });
        setStatus('Microphone is blocked — set it to Allow in the settings tab that opened, then tap the mic again.');
        return false;
      }
    } catch {
      // Permission query unsupported — fall through to a direct request.
    }

    // Try a direct request first; Chrome may show the prompt here normally.
    let direct = null;
    try {
      direct = navigator.mediaDevices.getUserMedia({ audio: true });
      const stream = await withTimeout(direct, 4000);
      direct = null;
      stream.getTracks().forEach((t) => t.stop());
      return true;
    } catch {
      direct?.then((s) => s.getTracks().forEach((t) => t.stop())).catch(() => {});
      /* expected — side panels suppress the prompt */
    }

    // Open the permission bridge in a popup window and wait for it to close.
    setStatus('Allow the microphone in the popup that just opened.');
    try {
      const win = await chrome.windows.create({
        url: chrome.runtime.getURL('src/mic/mic-permission.html'),
        type: 'popup',
        width: 440,
        height: 340,
        focused: true
      });
      if (!win?.id) return false;
      await new Promise((resolve) => {
        const onClose = (windowId) => {
          if (windowId !== win.id) return;
          chrome.windows.onRemoved.removeListener(onClose);
          setTimeout(resolve, 350);
        };
        chrome.windows.onRemoved.addListener(onClose);
      });
      return true;
    } catch {
      return false;
    }
  }

  /** Record until stopped, then POST the audio to Groq's whisper model. */
  async function transcribeWithWhisper() {
    setMicState('requesting');
    setStatus('Requesting microphone…');

    if (!(await ensureMicPermission())) {
      if (!el.status.textContent) setStatus("Couldn't get microphone access — try again.");
      setMicState('idle');
      return;
    }

    let stream;
    let pending = null;
    try {
      pending = navigator.mediaDevices.getUserMedia({ audio: true });
      stream = await withTimeout(pending, 6000);
      pending = null;
    } catch {
      // The prompt was denied or never answered. If a stream now shows up
      // late, drop it so the mic light doesn't stay on. Fall back to Chrome's
      // recognizer when there is one, else say what happened.
      pending?.then((s) => s.getTracks().forEach((t) => t.stop())).catch(() => {});
      if (SpeechRecognition) { captureLocally(); return; }
      setMicState('idle');
      setStatus('Microphone access was blocked.');
      return;
    }
    audioStream = stream;

    let rec;
    try {
      rec = new MediaRecorder(stream);
    } catch {
      releaseMic();
      if (SpeechRecognition) { captureLocally(); return; }
      setMicState('idle');
      setStatus('Audio recording is not supported here.');
      return;
    }
    recorder = rec;

    const chunks = [];
    rec.addEventListener('dataavailable', (e) => {
      if (e.data.size) chunks.push(e.data);
    });

    setMicState('capturing');
    setStatus('Recording — tap again when done');
    rec.start();

    await new Promise((resolve) => {
      rec.addEventListener('stop', resolve, { once: true });
      rec.addEventListener('error', resolve, { once: true });
    });
    releaseMic();
    recorder = null;

    if (!chunks.length) {
      setMicState('idle');
      return;
    }

    setMicState('transcribing');
    setStatus('Transcribing');
    let text = '';
    try {
      const blob = new Blob(chunks, { type: rec.mimeType || 'audio/webm' });
      text = await transcribeAudio({ config, blob });
    } catch (err) {
      setMicState('idle');
      setStatus(err.hint || 'Transcription failed — try again.');
      el.input.focus();
      return;
    }

    setMicState('idle');
    if (text) {
      el.input.value = el.input.value.trim() ? `${el.input.value.trim()} ${text}` : text;
      autosize();
      setStatus('');
    } else {
      setStatus("Didn't catch that — try again.");
    }
    el.input.focus();
  }

  /** Chrome's built-in recognizer — the fallback when the mic can't be captured. */
  function captureLocally() {
    recognizer = new SpeechRecognition();
    recognizer.lang = navigator.language || 'en-US';
    recognizer.interimResults = true;
    recognizer.continuous = false;

    recognizer.addEventListener('start', () => {
      setMicState('capturing');
      setStatus('Listening');
    });

    recognizer.addEventListener('result', (e) => {
      let transcript = '';
      for (const r of e.results) transcript += r[0].transcript;
      el.input.value = transcript;
      autosize();
    });

    recognizer.addEventListener('error', (e) => {
      setStatus(
        e.error === 'not-allowed' || e.error === 'service-not-allowed'
          ? 'Microphone access was blocked.'
          : e.error === 'no-speech'
            ? ''
            : "Didn't catch that — try again."
      );
    });

    recognizer.addEventListener('end', () => {
      recognizer = null;
      setMicState('idle');
      setStatus('');
      el.input.focus();
    });

    try {
      recognizer.start();
    } catch {
      recognizer = null;
      setMicState('idle');
    }
  }

  el.mic.addEventListener('click', () => {
    if (state === 'requesting' || state === 'transcribing') return;
    if (state === 'capturing') {
      recorder?.stop();
      recognizer?.stop();
      return;
    }
    if (canCapture) transcribeWithWhisper();
    else captureLocally();
  });

  /* -------- voice mode: "talk to Viora" -------- */
  // Tap the voice button once: Viora listens, transcribes with whisper,
  // sends the message, speaks the reply back with Groq's Orpheus TTS, then
  // starts listening again automatically — a hands-free back-and-forth,
  // like tapping a voice button in a chat app. Tap again at any point to
  // stop and hand control back to typing.
  if (el.voice) {
    if (!canCapture) {
      el.voice.hidden = true;
    } else {
      let voiceActive = false;
      let voiceRecorder = null;
      let voiceStream = null;
      let currentAudio = null;

      const setVoiceState = (next) => {
        el.voice.classList.remove('listening', 'thinking', 'speaking');
        if (next !== 'off') el.voice.classList.add(next);
        el.voice.setAttribute(
          'aria-label',
          next === 'listening' ? 'Listening — tap to send'
            : next === 'thinking' ? 'Thinking'
            : next === 'speaking' ? 'Speaking — tap to stop'
            : 'Talk to Viora'
        );
      };

      const stripForSpeech = (text) =>
        text
          .replace(/```[\s\S]*?```/g, ' ')
          .replace(/`([^`]+)`/g, '$1')
          .replace(/!\[[^\]]*]\([^)]*\)/g, ' ')
          .replace(/\[([^\]]+)]\([^)]*\)/g, '$1')
          .replace(/[*_#>~]/g, '')
          .trim()
          .slice(0, 4000);

      async function speakReply(text) {
        const clean = stripForSpeech(text);
        if (!clean) return;
        setVoiceState('speaking');
        setStatus('Speaking — tap to stop');
        try {
          const blob = await synthesizeSpeech({ config, text: clean });
          if (!voiceActive) return;
          const url = URL.createObjectURL(blob);
          currentAudio = new Audio(url);
          await new Promise((resolve) => {
            currentAudio.addEventListener('ended', resolve, { once: true });
            currentAudio.addEventListener('error', resolve, { once: true });
            currentAudio.play().catch(resolve);
          });
          URL.revokeObjectURL(url);
        } catch (err) {
          setStatus(err.hint || 'Could not read that reply out loud.');
        }
        currentAudio = null;
      }

      async function voiceListenTurn() {
        setVoiceState('listening');
        setStatus('Listening — tap to send');

        if (!(await ensureMicPermission())) {
          if (!el.status.textContent) setStatus("Couldn't get microphone access.");
          voiceActive = false;
          setVoiceState('off');
          return;
        }
        if (!voiceActive) return;

        let stream;
        try {
          stream = await withTimeout(navigator.mediaDevices.getUserMedia({ audio: true }), 6000);
        } catch {
          setStatus('Microphone access was blocked.');
          voiceActive = false;
          setVoiceState('off');
          return;
        }
        if (!voiceActive) { stream.getTracks().forEach((t) => t.stop()); return; }
        voiceStream = stream;

        let rec;
        try {
          rec = new MediaRecorder(stream);
        } catch {
          stream.getTracks().forEach((t) => t.stop());
          voiceStream = null;
          setStatus('Audio recording is not supported here.');
          voiceActive = false;
          setVoiceState('off');
          return;
        }
        voiceRecorder = rec;

        const chunks = [];
        rec.addEventListener('dataavailable', (e) => { if (e.data.size) chunks.push(e.data); });
        rec.start();

        await new Promise((resolve) => {
          rec.addEventListener('stop', resolve, { once: true });
          rec.addEventListener('error', resolve, { once: true });
        });
        voiceStream?.getTracks().forEach((t) => t.stop());
        voiceStream = null;
        voiceRecorder = null;

        if (!voiceActive) return; // stopped mid-turn

        if (!chunks.length) { setVoiceState('off'); voiceActive = false; setStatus(''); return; }

        setVoiceState('thinking');
        setStatus('Transcribing');
        let text = '';
        try {
          const blob = new Blob(chunks, { type: rec.mimeType || 'audio/webm' });
          text = await transcribeAudio({ config, blob });
        } catch (err) {
          if (!voiceActive) return;
          setStatus(err.hint || 'Transcription failed — listening again.');
          voiceListenTurn();
          return;
        }
        if (!voiceActive) return;

        if (!text) {
          setStatus("Didn't catch that — listening again.");
          voiceListenTurn();
          return;
        }

        setStatus('');
        await send(text);
        if (!voiceActive) return;

        const reply = thread.messages.filter((m) => m.role === 'assistant').at(-1);
        if (reply?.content) await speakReply(reply.content);
        if (voiceActive) voiceListenTurn();
        else setStatus('');
      }

      function stopVoiceMode() {
        voiceActive = false;
        try { voiceRecorder?.stop(); } catch {}
        voiceStream?.getTracks().forEach((t) => t.stop());
        voiceStream = null;
        currentAudio?.pause();
        currentAudio = null;
        setVoiceState('off');
        setStatus('');
      }

      el.voice.addEventListener('click', () => {
        if (!voiceActive) {
          voiceActive = true;
          voiceListenTurn();
        } else if (voiceRecorder && voiceRecorder.state === 'recording') {
          voiceRecorder.stop(); // done talking — transcribe and send
        } else {
          stopVoiceMode(); // mid-thinking or mid-speaking — cancel entirely
        }
      });
    }
  }
}

/* ---------------- boot ---------------- */

el.attachUploadIcon.innerHTML = icon('upload');
el.attachScreenshotIcon.innerHTML = icon('camera');
el.micIcon.innerHTML = icon('mic');
el.voiceIcon.innerHTML = icon('voice');

setModel(settings.prefs.model || 'flash');
refreshDrawer();
el.input.focus();

// Pick up anything queued from a context-menu click.
const task = await chrome.runtime.sendMessage({ type: 'viora:get-task' }).catch(() => null);
if (task?.prompt) {
  setModel(task.model || 'flash');
  if (task.usePage && task.tabId != null) {
    try {
      pickPage(await chrome.tabs.get(task.tabId));
    } catch {
      // The tab closed before the panel opened — nothing to attach.
    }
  }
  send(task.prompt);
}
