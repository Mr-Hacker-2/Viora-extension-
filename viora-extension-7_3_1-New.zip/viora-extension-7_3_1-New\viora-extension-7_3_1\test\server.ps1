# Viora — test server.
#
# Serves the workspace over http://127.0.0.1:8764 so the test page can load
# the real ES modules (file:// blocks module imports), and answers
# /proxy?url=... by fetching that URL server-side and handing back the body.
#
# The proxy exists because a plain web page is subject to CORS, while an
# extension page with <all_urls> in host_permissions is not — routing the
# test page's fetches through it reproduces exactly the network conditions
# web.js will run under inside Chrome, against the real DuckDuckGo and the
# real pages.

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$root = Split-Path -Parent $PSScriptRoot
$types = @{
  '.html' = 'text/html; charset=utf-8'
  '.js'   = 'text/javascript; charset=utf-8'
  '.css'  = 'text/css; charset=utf-8'
  '.json' = 'application/json; charset=utf-8'
  '.pdf'  = 'application/pdf'
  '.txt'  = 'text/plain; charset=utf-8'
  '.png'  = 'image/png'
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add('http://127.0.0.1:8764/')
$listener.Start()

function Send-Bytes($ctx, [byte[]]$bytes, $ctype, $status = 200) {
  $ctx.Response.StatusCode = $status
  $ctx.Response.ContentType = $ctype
  $ctx.Response.Headers['Access-Control-Allow-Origin'] = '*'
  $ctx.Response.ContentLength64 = $bytes.Length
  $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
  $ctx.Response.OutputStream.Close()
}

while ($true) {
  $ctx = $listener.GetContext()
  try {
    $url = $ctx.Request.Url
    $path = $url.AbsolutePath

    if ($ctx.Request.HttpMethod -eq 'OPTIONS') {
      $ctx.Response.StatusCode = 204
      $ctx.Response.Headers['Access-Control-Allow-Origin'] = '*'
      $ctx.Response.Headers['Access-Control-Allow-Methods'] = 'GET, OPTIONS'
      $ctx.Response.Headers['Access-Control-Allow-Headers'] = 'Content-Type'
      $ctx.Response.Close()
      continue
    }

    # A deliberately slow page, for the timeout test: the client gives up
    # long before this answers, and writing to the already-closed connection
    # just lands in the handler's own catch.
    if ($path -eq '/hang') {
      $ms = 3000
      if ($url.Query -match 'ms=(\d+)') { $ms = [Math]::Min([int]$Matches[1], 8000) }
      Start-Sleep -Milliseconds $ms
      Send-Bytes $ctx ([Text.Encoding]::UTF8.GetBytes('too late')) 'text/plain; charset=utf-8'
      continue
    }

    if ($path -eq '/test/result' -and $ctx.Request.HttpMethod -eq 'POST') {
      $reader = New-Object IO.StreamReader($ctx.Request.InputStream, [Text.Encoding]::UTF8)
      $body = $reader.ReadToEnd()
      $reader.Close()
      [IO.File]::WriteAllText((Join-Path $PSScriptRoot '_result.json'), $body, [Text.Encoding]::UTF8)
      Send-Bytes $ctx ([Text.Encoding]::UTF8.GetBytes('ok')) 'text/plain; charset=utf-8'
      continue
    }

    if ($path -eq '/proxy') {
      $target = $url.Query -replace '^\?url=', ''
      $target = [Uri]::UnescapeDataString($target)
      try {
        $req = [Net.HttpWebRequest]::Create($target)
        $req.Method = 'GET'
        $req.Timeout = 15000
        $req.UserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36'
        $req.Accept = 'text/html,application/xhtml+xml,application/pdf,text/plain,*/*'
        $up = $req.GetResponse()
        $ctype = $up.ContentType
        if (-not $ctype) { $ctype = 'application/octet-stream' }
        $ms = New-Object IO.MemoryStream
        $up.GetResponseStream().CopyTo($ms)
        $up.Close()
        Send-Bytes $ctx $ms.ToArray() $ctype
      } catch [Net.WebException] {
        $code = 502
        if ($_.Exception.Response) { $code = [int]$_.Exception.Response.StatusCode }
        $msg = [Text.Encoding]::UTF8.GetBytes("proxy error: $($_.Exception.Message)")
        Send-Bytes $ctx $msg 'text/plain; charset=utf-8' $code
      } catch {
        $msg = [Text.Encoding]::UTF8.GetBytes("proxy error: $($_.Exception.Message)")
        Send-Bytes $ctx $msg 'text/plain; charset=utf-8' 502
      }
      continue
    }

    if ($path -eq '/') { $path = '/test/index.html' }
    $file = Join-Path $root ($path -replace '/', [IO.Path]::DirectorySeparatorChar)
    $full = [IO.Path]::GetFullPath($file)
    if (-not $full.StartsWith([IO.Path]::GetFullPath($root))) {
      Send-Bytes $ctx ([Text.Encoding]::UTF8.GetBytes('nope')) 'text/plain' 403
      continue
    }
    if (Test-Path $full -PathType Leaf) {
      $ext = [IO.Path]::GetExtension($full).ToLower()
      $ctype = $types[$ext]
      if (-not $ctype) { $ctype = 'application/octet-stream' }
      Send-Bytes $ctx ([IO.File]::ReadAllBytes($full)) $ctype
    } else {
      Send-Bytes $ctx ([Text.Encoding]::UTF8.GetBytes('not found')) 'text/plain' 404
    }
  } catch {
    try { $ctx.Response.Abort() } catch { }
  }
}
