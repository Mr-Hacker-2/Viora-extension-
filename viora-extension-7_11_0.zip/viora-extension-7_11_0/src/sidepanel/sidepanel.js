/**
 * Viora — side panel controller.
 * One backend, four personalities. Owns the thread, runs the turn, renders it.
 */

import {
  getSettings, saveSettings, getThreads, saveThread, deleteThread, newThread, getStarred, setStarred, getEpisodes, setEpisodes,
  groqConfig, configForChoice, visionConfig, partnerConfig, rememberModel
} from '../lib/storage.js';
import { MODELS, MODEL_ORDER, VISION_CHAIN, NVIDIA_VISION_CHAIN, looksLikeVision, getModel, chainFor, partnerChain } from '../lib/models.js';
import { streamChat, completeChat, listModels, ProviderError, transcribeAudio } from '../lib/providers.js';
import { renderMarkdown, renderInline, bindCodeCopy, escapeHtml } from '../lib/markdown.js';
import { loadLogo, hostOf, sourceStrip, sourceBadge, linkInlineMarkers, withSourceList } from '../lib/citations.js';
import { systemFor, REVIEWER_SYSTEM, LINUX_NOTE, LINUX_REVIEW_NOTE } from '../lib/prompts.js';
import { linuxConfig, linuxRun, linuxWrite, linuxRead, formatRun, summarizeRun, riskOf } from '../lib/linux.js';
import { riskLabel } from '../lib/humanizer.js';
import { extractUrls, isCasualChat } from '../lib/web.js';
import { editPdf, inspectPdf, parseEditPlan } from '../lib/pdfedit.js';
import { RESEARCH } from '../lib/research.js';
import { messageForJob, missingJobMessages, JOB_NOUN_A } from '../lib/jobs.js';
import { splitThink, finalizeChat } from '../lib/chatfinal.js';
import { runTools } from '../lib/tools.js';
import { looksPersonal, parseFacts, mergeMemory, detectMemoryQuery, describeMemory, recallEpisodes, formatRecall, LEARN_PROMPT } from '../lib/memory.js';
import { searchThreads, searchStarred, starKey, threadToMarkdown, exportStem, speakable, speechChunks } from '../lib/chats.js';
import { readFile, kindOf, readScreenshot, attachmentsToText, attachmentsToContent, LIMITS } from '../lib/files.js';
import { downloadPdfBlob, markdownToPdf, pdfFilename, pdfTitle } from '../lib/pdf.js';
import { icon, MODEL_ICON } from '../lib/icons.js';
import { detectImageRequest } from '../lib/imagegen.js';
import { STYLE_QUESTIONS, STYLE_ANSWER_MAX, STYLE_ANSWER_MIN, buildStyleProfile } from '../lib/style-questions.js';
import {
  activeTab, openTabs, snapshot, pageContext, parsePlan, parseReview, runPlan, describeAction,
  isRestrictedUrl, PageAccessError, MAX_TURNS, MAX_TOTAL_ACTIONS, LINUX_MAX_TURNS, LINUX_MAX_TOTAL_ACTIONS, screenshotSelect, extractJson, selectedText
} from '../lib/automation.js';

const $ = (sel) => document.querySelector(sel);

// Safety net: an uncaught error anywhere (a click handler, a render pass,
// a rejected promise) used to fail silently — a button would just look
// dead, with nothing in the UI to say why. Surface it in the status line
// instead, and always to the console, so a real bug is diagnosable from
// screenshots/reports instead of "nothing happens".
window.addEventListener('error', (e) => {
  console.error('[Viora]', e.error || e.message);
  try { setStatus('Something went wrong — check the console (right-click → Inspect).'); } catch {}
});
window.addEventListener('unhandledrejection', (e) => {
  console.error('[Viora]', e.reason);
  try { setStatus('Something went wrong — check the console (right-click → Inspect).'); } catch {}
});

const el = {
  root: document.documentElement,
  thread: $('#thread'),
  welcome: $('#welcome'),
  welcomeLogo: $('#welcome-logo'),
  welcomeLine: $('#welcome-line'),
  suggestions: $('#suggestions'),
  form: $('#composer'),
  input: $('#input'),
  send: $('#send'),
  hint: $('#hint'),
  status: $('#status'),
  attach: $('#attach'),
  attachSheet: $('#attach-sheet'),
  attachUpload: $('#attach-upload'),
  attachUploadIcon: $('#attach-upload-icon'),
  attachScreen: $('#attach-screen'),
  attachScreenIcon: $('#attach-screen-icon'),
  attachImage: $('#attach-image'),
  attachImageIcon: $('#attach-image-icon'),
  modeChip: $('#mode-chip'),
  modeChipIcon: $('#mode-chip-icon'),
  modeChipTitle: $('#mode-chip-title'),
  modeChipRemove: $('#mode-chip-remove'),
  imageChip: $('#image-chip'),
  imageChipIcon: $('#image-chip-icon'),
  imageChipRemove: $('#image-chip-remove'),
  attachScreenshot: $('#attach-screenshot'),
  attachScreenshotIcon: $('#attach-screenshot-icon'),
  tabsDivider: $('#tabs-divider'),
  tabList: $('#tab-list'),
  fileInput: $('#file-input'),
  attachTray: $('#attach-tray'),
  pageChip: $('#page-chip'),
  pageChipIcon: $('#page-chip-icon'),
  pageChipTitle: $('#page-chip-title'),
  pageChipRemove: $('#page-chip-remove'),
  mic: $('#mic'),
  micIcon: $('#mic-icon'),
  modelBtn: $('#model-btn'),
  modelSheet: $('#model-sheet'),
  modelList: $('#model-list'),
  pillIcon: $('#pill-icon'),
  pillName: $('#pill-name'),
  drawer: $('#drawer'),
  threadList: $('#thread-list'),
  threadEmpty: $('#thread-empty'),
  threadSearch: $('#thread-search'),
  tabChats: $('#tab-chats'),
  tabStarred: $('#tab-starred'),
  restyle: $('#restyle'),
  onboard: $('#onboard'),
  obDots: $('#ob-dots'),
  obCount: $('#ob-count'),
  obTitle: $('#ob-q-title'),
  obPrompt: $('#ob-q-prompt'),
  obAnswer: $('#ob-answer'),
  obNeed: $('#ob-need'),
  obChars: $('#ob-chars'),
  obBack: $('#ob-back'),
  obNext: $('#ob-next'),
  obSkip: $('#ob-skip')
};

// The line under the logo changes every few seconds, so the first screen
// never feels like a form. The first entry of each list is what shows up
// first; the rest are picked at random, never the same one twice in a row.
const GREETINGS = {
  flash: [
    'Welcome back, what do you want me to do?',
    'What’s the move?',
    'Ready when you are. What should I tackle?',
    'What are we getting done today?',
    'Got something for me? Let’s go.',
    'What can I take off your plate?',
    'Point me at something.',
    'What do you want me to look into?',
    'Welcome back. What’s on your mind?'
  ],
  search: [
    'What should I go and find out?',
    'What do you want me to dig into?',
    'Ask me anything, I’ll bring sources.',
    'What are we researching?'
  ],
  math: [
    'Give me something to chew on.',
    'Got a problem or some code for me?',
    'Show me the problem, I’ll show my work.',
    'What are we solving or building?'
  ],
  automate: [
    'What should I do on this page?',
    'Tell me what to click, type or open.',
    'Which part of this page needs doing?'
  ],
  humanize: [
    'Paste the text and I’ll make it sound like you wrote it.',
    'Drop in something that sounds like an AI.',
    'What should I rewrite in your voice?'
  ]
};
const NAMED_GREETINGS = [
  (n) => `Welcome back, ${n}. What do you want me to do?`,
  (n) => `Hi ${n}, what’s the move?`,
  (n) => `Good to see you, ${n}. What are we doing?`
];
let lastGreeting = '';

function pickGreeting(choice, first = false) {
  const pool = [...(GREETINGS[choice] || GREETINGS.flash)];
  const name = String(settings.prefs.name || '').trim();
  if (name && choice === 'flash') {
    if (first) pool[0] = NAMED_GREETINGS[0](name);
    else NAMED_GREETINGS.forEach((f) => pool.push(f(name)));
  }
  if (first) return (lastGreeting = pool[0]);
  const options = pool.filter((g) => g !== lastGreeting);
  return (lastGreeting = options[Math.floor(Math.random() * options.length)] || pool[0]);
}

/** One full 360° turn of the logo. Skipped for people who asked for reduced motion. */
function flipLogo() {
  const logo = el.welcomeLogo;
  if (!logo || settings.prefs.reducedMotion || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  logo.classList.remove('flip');
  void logo.offsetWidth; // restart the animation if it is already running
  logo.classList.add('flip');
}

/** Fade the greeting out, swap the words, fade back in. */
function rotateGreeting() {
  const line = el.welcomeLine;
  const next = pickGreeting(thread.model);
  line.classList.add('out');
  setTimeout(() => {
    line.textContent = next;
    line.classList.remove('out');
  }, 260);
}

const SUGGESTIONS = {
  flash: ['Summarise what I am reading', 'Draft a reply to this email', 'Talk me through two options', 'What is 18% of 64.50?'],
  search: ['What changed in EU AI rules this year?', 'Compare this year’s flagship phone cameras', 'Is this library still maintained?'],
  math: ['Solve 3x² − 7x + 2 = 0 step by step', 'Why does this throw a null reference?', 'Write a debounce hook in TypeScript'],
  automate: ['Fill this form with my details', 'Read me the pricing table', 'Open the first search result'],
  humanize: ['Make this sound more casual: ', 'Humanize this, keep it under 150 words: ', 'Humanize this for a school essay: ']
};

let settings = await getSettings();
let starredKeys = new Set((await getStarred()).map((x) => x.key));
let localBusy = false;
let config = groqConfig(settings);
let thread = newThread(settings.prefs.model);
let controller = null;
let busy = false;
let pendingAttachments = [];
/** The tab picked from the "+" menu, if any — its page is read on every turn until removed. */
let selectedPage = null;

/* ---------------- shell ---------------- */

function current() {
  return getModel(thread.model);
}

/**
 * Models to try for a turn with a picture in it. Text-only models are never
 * in this list — they would either error on the image or quietly ignore it,
 * which is exactly how "Flash can't see images" happens. Groq's live catalogue
 * is asked (and remembered for ten minutes) so a retired vision model is
 * replaced by whichever one is actually being served.
 */
let liveCatalogue = null;

async function visionModels() {
  const known = [settings.modelOverrides?.vision, settings.resolvedModels?.vision, ...VISION_CHAIN].filter(Boolean);
  if (!liveCatalogue || Date.now() - liveCatalogue.at > 10 * 60 * 1000) {
    try {
      const ids = await listModels({ config: groqConfig(settings), signal: controller?.signal });
      liveCatalogue = { ids, at: Date.now() };
    } catch (err) {
      if (err.name === 'AbortError') throw err;
      return [...new Set(known)];
    }
  }
  const ids = liveCatalogue.ids;
  const served = known.filter((id) => ids.includes(id));
  const guessed = ids.filter((id) => looksLikeVision(id) && !served.includes(id));
  const out = [...new Set([...served, ...guessed])];
  return out.length ? out : [...new Set(known)];
}

/** NVIDIA multimodal models for a picture/video turn, a pinned or last-working one first. */
function nvidiaVisionModels() {
  const remembered = settings.resolvedModels?.vision;
  return [...new Set([
    settings.modelOverrides?.vision,
    NVIDIA_VISION_CHAIN.includes(remembered) ? remembered : null,
    ...NVIDIA_VISION_CHAIN
  ].filter(Boolean))];
}

function chain(choice = thread.model) {
  return chainFor(choice, {
    overrides: settings.modelOverrides,
    resolved: settings.resolvedModels
  });
}

/** Remember which ID answered, so the dead ones aren't retried next turn. */
function noteModel(choice) {
  return async (modelId) => {
    if (settings.resolvedModels[choice] !== modelId) {
      settings = await rememberModel(choice, modelId);
    }
  };
}

/* ---------------- one chat: modes live in the "+" menu ---------------- */

// A mode picked from "+" sticks until its chip is dismissed. Without one,
// every message is routed on its own: Deep Search for research asks, Math &
// Code for maths and code, Flash for everything else.
let forcedMode = null;

const MODE_LABEL = { humanize: 'Humanizer', search: 'Deep Search', automate: 'Automate' };

function autoRoute(text, prev = 'flash') {
  const t = String(text || '');
  const RESEARCH = /\b(deep search|research|in[- ]depth|with sources|cite (?:your )?sources|find sources|literature review|fact[- ]?check|compare (?:the )?(?:latest|best|top)|latest (?:news|research|studies)|what(?:'s| is) (?:the )?(?:latest|newest|current)|who is (?:the )?(?:current|new)|is it true (?:that)?|according to (?:sources|experts|studies))\b/i;
  const CODE = /```|\b(solve|integral|derivative|limit of|equation|simplify|factor|prove|proof|matrix|eigen|vector|probability|permutation|combination|calculate|compute|algorithm|big[- ]?o|complexity|python|javascript|typescript|java|c\+\+|c#|rust|golang|php|ruby|swift|kotlin|bash|powershell|regex|sql|query|html|css|react|node|api|json|compile|stack ?trace|traceback|exception|segfault|bug|debug|refactor|unit test|function|class|variable|loop|array|recursion|write (?:a )?(?:script|program|code|function|app)|how many|percent(?:age)?|ratio|average|mean|median|standard deviation|geometry|triangle|circle|area of|volume of|sin|cos|tan|log)\b|\d\s*[-+*/^=×÷]\s*\d|\d+\s*%|[a-z]\s*\^\s*\d|\bx\s*=|\bf\(x\)/i;
  if (RESEARCH.test(t)) return 'search';
  if (CODE.test(t)) return 'math';
  // A short follow-up ("now do it for 7", "why?", "and the second one?") belongs
  // to whichever mode was already working on the problem — dropping back to
  // Flash would lose the careful maths/research behaviour mid-conversation.
  const followUp = t.length < 70 && /\b(it|that|this|those|these|them|again|instead|also|too|why|how come|and|so|then|now|what about|how about|same|next|another|more|explain)\b/i.test(t);
  if (followUp && (prev === 'math' || prev === 'search')) return prev;
  return 'flash';
}

/** How hard should a reasoning model think about this? Easy stays fast; hard gets real effort. */
function pickEffort(choice, text) {
  const t = String(text || '');
  const hard =
    t.length > 220 ||
    /```/.test(t) ||
    /\b(why|how does|how do|explain|compare|trade-?offs?|analy[sz]e|prove|derive|optimi[sz]e|design|architecture|debug|strategy|plan|should i|pros and cons|step by step|difference between|best way|decide|evaluate|critique|root cause|edge case|complexity)\b/i.test(t) ||
    (t.match(/\?/g) || []).length > 1;
  if (choice === 'math') return hard ? 'high' : 'medium';
  if (choice === 'search') return 'medium';
  return hard ? 'medium' : 'low';
}

/**
 * Turn a short follow-up into something a search engine can use. "What about
 * its price?" searches for nothing; "<previous question> — what about its
 * price?" searches for the right thing. No extra model call: just the last
 * thing they asked, attached when the new message leans on it.
 */
function resolveFollowUp(text, messages) {
  const t = String(text || '').trim();
  if (!t || t.length > 90 || /https?:\/\//i.test(t)) return t;
  if (!/\b(it|its|it's|that|this|those|these|they|them|their|he|she|his|her|there|then|also|too|again|instead|same|what about|how about|and the|the (?:first|second|third|last|other) one)\b/i.test(t)) return t;
  const prior = [...messages].slice(0, -1).reverse().find((m) => m.role === 'user');
  const before = String(prior?.displayText ?? prior?.content ?? '').replace(/\s+/g, ' ').trim();
  return before ? `${before.slice(0, 180)} — ${t}` : t;
}

function renderModeChip() {
  const on = !!forcedMode;
  el.modeChip.hidden = !on;
  if (on) {
    el.modeChipTitle.textContent = `${MODE_LABEL[forcedMode]} mode`;
    el.modeChipIcon.innerHTML = icon(MODEL_ICON[forcedMode]);
  }
}

function enterMode(id) {
  forcedMode = id;
  setModel(id);
  renderModeChip();
  closeSheets();
  el.input.focus();
}

function leaveMode() {
  forcedMode = null;
  setModel('flash');
  renderModeChip();
  el.input.focus();
}

function setModel(choice) {
  thread.model = choice;
  const model = current();
  el.root.dataset.model = choice;
  el.pillIcon.innerHTML = icon(MODEL_ICON[choice]);
  el.pillName.textContent = choice === 'flash' ? 'Viora' : model.name;
  el.modelBtn.title = model.blurb;
  el.input.placeholder = model.placeholder;
  el.welcomeLine.textContent = pickGreeting(choice, true);
  flipLogo();

  el.attach.hidden = !model.canAttach;
  if (!model.canAttach && imageMode) setImageMode(false);
  if (!model.canAttach) {
    if (pendingAttachments.length) {
      pendingAttachments = [];
      renderTray();
    }
    if (selectedPage) {
      selectedPage = null;
      renderPageChip();
    }
  }

  renderSuggestions();
  renderModelList();
  el.restyle.hidden = choice !== 'humanize' || !humanizerReady();
  syncHumanizerGate();
  saveSettings({ prefs: { model: choice } });
}

function renderModelList() {
  el.modelList.replaceChildren();
  for (const id of MODEL_ORDER) {
    const model = MODELS[id];
    const li = document.createElement('li');

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'model-row';
    btn.dataset.model = id;
    btn.setAttribute('role', 'option');
    btn.setAttribute('aria-selected', String(id === thread.model));

    const rowIcon = document.createElement('span');
    rowIcon.className = 'row-icon';
    rowIcon.innerHTML = icon(MODEL_ICON[id]);

    const copy = document.createElement('span');
    copy.className = 'row-copy';
    const name = document.createElement('span');
    name.className = 'row-name';
    name.textContent = model.name;
    const blurb = document.createElement('span');
    blurb.className = 'row-blurb';
    blurb.textContent = model.blurb;
    copy.append(name, blurb);

    const tick = document.createElement('span');
    tick.className = 'row-tick';
    if (id === thread.model) tick.innerHTML = icon('check');

    btn.append(rowIcon, copy, tick);
    btn.addEventListener('click', () => {
      setModel(id);
      closeSheets();
      el.input.focus();
    });

    li.append(btn);
    el.modelList.append(li);
  }
}

function renderSuggestions() {
  el.suggestions.replaceChildren();
  for (const text of SUGGESTIONS[thread.model] || []) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'suggestion';
    b.textContent = text;
    b.addEventListener('click', () => {
      el.input.value = text;
      el.input.focus();
      autosize();
    });
    el.suggestions.append(b);
  }
}

function closeSheets() {
  el.modelSheet.hidden = true;
  el.drawer.hidden = true;
  el.attachSheet.hidden = true;
  el.modelBtn.setAttribute('aria-expanded', 'false');
  $('#history').setAttribute('aria-expanded', 'false');
  setAttachOpen(false);
}

/** The "+" turns into an "X" (CSS keys off aria-expanded) while its menu is open. */
function setAttachOpen(open) {
  el.attach.setAttribute('aria-expanded', String(open));
  el.attach.title = open ? 'Close' : 'Add';
  el.attach.setAttribute('aria-label', open ? 'Close the add menu' : 'Add a file, a page or a mode');
}

/* ---------------- the "+" menu: upload a file, or read an open tab ---------------- */

/** Set an icon element's content to a tab's favicon, falling back to the generic tab glyph. */
function setFavicon(target, favIconUrl) {
  target.replaceChildren();
  if (!favIconUrl) {
    target.innerHTML = icon('tab');
    return;
  }
  const img = document.createElement('img');
  img.src = favIconUrl;
  img.alt = '';
  img.addEventListener('error', () => { target.innerHTML = icon('tab'); }, { once: true });
  target.append(img);
}

function renderPageChip() {
  if (!selectedPage) {
    el.pageChip.hidden = true;
    return;
  }
  el.pageChip.hidden = false;
  el.pageChipTitle.textContent = selectedPage.title;
  el.pageChipTitle.title = selectedPage.url;
  setFavicon(el.pageChipIcon, selectedPage.favIconUrl);
}

function pickPage(tab) {
  selectedPage = { id: tab.id, title: tab.title, url: tab.url, favIconUrl: tab.favIconUrl };
  renderPageChip();
  closeSheets();
  el.input.focus();
}

const tabsById = new Map();

async function renderTabList() {
  el.tabList.replaceChildren();
  el.tabsDivider.hidden = true;
  tabsById.clear();

  let tabs;
  try {
    tabs = await openTabs();
  } catch {
    return;
  }
  // The panel's own window still counts, but there's nothing useful to
  // hand back for a tab Viora structurally can't read — show it, but disabled.
  if (!tabs.length) return;

  el.tabsDivider.hidden = false;
  for (const tab of tabs) {
    const li = document.createElement('li');
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'sheet-action tab-row';
    row.disabled = tab.restricted;
    if (tab.restricted) row.title = "Viora can't read this page.";

    const favicon = document.createElement('span');
    favicon.className = 'sheet-action-icon';
    setFavicon(favicon, tab.favIconUrl);

    const copy = document.createElement('span');
    copy.className = 'tab-copy';
    const title = document.createElement('span');
    title.className = 'tab-title';
    title.textContent = tab.title;
    const host = document.createElement('span');
    host.className = 'tab-host';
    try {
      host.textContent = new URL(tab.url).hostname;
    } catch {
      host.textContent = tab.url;
    }
    copy.append(title, host);

    row.append(favicon, copy);
    if (!tab.restricted) row.dataset.tabId = String(tab.id);
    li.append(row);
    el.tabList.append(li);
    if (!tab.restricted) tabsById.set(tab.id, tab);
  }
}

// Delegated: the list is torn down and rebuilt every time the "+" sheet
// opens (renderTabList), so binding to the container instead of each row
// means a click always hits a live listener, however many times it's redrawn.
el.tabList.addEventListener('click', (e) => {
  const row = e.target.closest('.tab-row');
  if (!row || row.disabled) return;
  const tab = tabsById.get(Number(row.dataset.tabId));
  if (tab) pickPage(tab);
});

let statusIcons = null;

function setStatus(text) {
  el.status.textContent = text;
  if (text && statusIcons) el.status.append(statusIcons);
  if (!text) statusIcons = null;
  el.status.hidden = !text;
}

/** Logos of the pages being opened right now, shown beside the status line. */
function setStatusSources(sources) {
  const wrap = document.createElement('span');
  wrap.className = 'status-icons';
  for (const src of sources.slice(0, 8)) {
    const img = document.createElement('img');
    img.alt = '';
    img.title = hostOf(src.url);
    loadLogo(img, src.url, 32, () => img.remove());
    wrap.append(img);
  }
  statusIcons = wrap;
  if (!el.status.hidden) el.status.append(wrap);
}

function setBusy(state) {
  busy = state;
  el.send.classList.toggle('stop', state);
  el.send.setAttribute('aria-label', state ? 'Stop' : 'Send');
  el.hint.textContent = state ? 'Thinking' : '';
}

let scrollFrame = 0;
function scrollDown() {
  // Streaming calls this per token; one scroll per frame is plenty.
  if (scrollFrame) return;
  scrollFrame = requestAnimationFrame(() => {
    scrollFrame = 0;
    el.thread.scrollTop = el.thread.scrollHeight;
  });
}

function autosize() {
  el.input.style.height = 'auto';
  el.input.style.height = `${Math.min(el.input.scrollHeight, 168)}px`;
}

/* ---------------- rendering ---------------- */

function clearWelcome() {
  if (el.welcome.isConnected) el.welcome.remove();
}

function attachmentChip(a, onRemove) {
  const chip = document.createElement('span');
  chip.className = 'attach-chip' + (a.warning ? ' has-warning' : '');
  if (a.warning) chip.title = a.warning;

  if ((a.kind === 'image' || a.kind === 'video') && a.dataUrl) {
    const img = document.createElement('img');
    img.src = a.dataUrl;
    img.alt = '';
    chip.append(img);
  } else {
    const icon = document.createElement('span');
    icon.className = 'attach-icon';
    icon.textContent = a.kind === 'pdf' ? 'PDF' : 'TXT';
    chip.append(icon);
  }

  const name = document.createElement('span');
  name.className = 'attach-name';
  name.textContent = a.name;
  chip.append(name);

  if (onRemove) {
    const x = document.createElement('button');
    x.type = 'button';
    x.className = 'attach-remove';
    x.textContent = '×';
    x.setAttribute('aria-label', `Remove ${a.name}`);
    chip.append(x);
  }
  return chip;
}

function addUser(text, attachments = []) {
  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg user';

  if (attachments.length) {
    const tray = document.createElement('div');
    tray.className = 'attach-chips';
    attachments.forEach((a) => tray.append(attachmentChip(a)));
    node.append(tray);
  }
  if (text) {
    const p = document.createElement('div');
    p.className = 'user-text';
    p.textContent = text;
    node.append(p);
  }

  el.thread.append(node);
  scrollDown();
}

function addAssistant() {
  clearWelcome();
  const threadId = thread.id;
  let lastMd = '';
  const node = document.createElement('div');
  node.className = 'msg assistant streaming';

  const badge = document.createElement('span');
  badge.className = 'who';
  badge.innerHTML = icon(MODEL_ICON[thread.model]);

  const trace = document.createElement('details');
  trace.className = 'reasoning';
  trace.hidden = true;
  const summary = document.createElement('summary');
  summary.textContent = 'Working it out';
  const pre = document.createElement('div');
  pre.className = 'trace';
  trace.append(summary, pre);

  const body = document.createElement('div');
  body.className = 'body';

  const dots = document.createElement('span');
  dots.className = 'typing-dots';
  dots.setAttribute('aria-hidden', 'true');
  dots.innerHTML = '<i></i><i></i><i></i>';

  node.append(badge, trace, body, dots);
  el.thread.append(node);
  scrollDown();

  let pendingMd = null;
  let mdFrame = 0;

  return {
    node,
    body,
    setImage(dataUrl, caption) {
      lastMd = '';
      body.replaceChildren(imageCard(dataUrl, caption));
    },
    // The logos of what the answer read, pinned above the text.
    setSources(list, opts) {
      node.querySelector('.src-badge')?.remove();
      if (!list?.length || !settings.prefs.citations) return;
      node.insertBefore(sourceBadge(list, opts), body);
    },
    setReasoning(text) {
      if (!settings.prefs.showReasoning || !text) return;
      trace.hidden = false;
      pre.textContent = text;
    },
    // Re-rendering the whole markdown tree for every streamed token gets
    // slower the longer the reply is. Coalesce to one render per frame —
    // always the latest text, so nothing is lost — and flush on finish.
    setMarkdown(text) {
      lastMd = String(text ?? '');
      pendingMd = text;
      if (mdFrame) return;
      mdFrame = requestAnimationFrame(() => {
        mdFrame = 0;
        if (pendingMd !== null) {
          body.innerHTML = renderMarkdown(pendingMd);
          pendingMd = null;
        }
      });
    },
    finish() {
      if (mdFrame) {
        cancelAnimationFrame(mdFrame);
        mdFrame = 0;
      }
      if (pendingMd !== null) {
        body.innerHTML = renderMarkdown(pendingMd);
        pendingMd = null;
      }
      node.classList.remove('streaming');
      bindCodeCopy(body);
      if (lastMd.trim() && !node.querySelector('.msg-actions')) node.append(buildMessageActions(node, lastMd, threadId));
    }
  };
}

/* ---------------- under every answer: copy, read aloud, star ---------------- */

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;opacity:0;pointer-events:none';
    document.body.append(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
  }
}

let speaking = null; // { btn }

function stopSpeaking() {
  try {
    if (typeof speechSynthesis !== 'undefined') speechSynthesis.cancel();
  } catch {
    /* nothing to stop */
  }
  if (speaking) {
    speaking.btn.classList.remove('on');
    speaking.btn.innerHTML = icon('speaker');
    speaking.btn.title = 'Read aloud';
    speaking = null;
  }
}

function pickVoice() {
  try {
    const voices = speechSynthesis.getVoices();
    const lang = (navigator.language || 'en-US').toLowerCase();
    const same = voices.filter((v) => v.lang.toLowerCase().startsWith(lang.slice(0, 2)));
    return same.find((v) => /natural|neural|google|online/i.test(v.name)) || same.find((v) => v.default) || same[0] || null;
  } catch {
    return null;
  }
}

/** Read one answer with the browser's own voice: free, private, no tokens. Tap again to stop. */
function readAloud(btn, markdown) {
  if (speaking?.btn === btn) {
    stopSpeaking();
    return;
  }
  stopSpeaking();
  if (typeof speechSynthesis === 'undefined' || typeof SpeechSynthesisUtterance === 'undefined') {
    setStatus("This browser can't read aloud.");
    return;
  }
  const chunks = speechChunks(speakable(markdown));
  if (!chunks.length) return;
  const mine = { btn };
  speaking = mine;
  btn.classList.add('on');
  btn.innerHTML = icon('stop');
  btn.title = 'Stop reading';
  const voice = pickVoice();
  let i = 0;
  const next = () => {
    if (speaking !== mine) return;
    if (i >= chunks.length) {
      stopSpeaking();
      return;
    }
    const u = new SpeechSynthesisUtterance(chunks[i++]);
    if (voice) u.voice = voice;
    u.lang = voice?.lang || navigator.language || 'en-US';
    u.rate = 1.03;
    u.onend = next;
    u.onerror = () => {
      if (speaking === mine) stopSpeaking();
    };
    speechSynthesis.speak(u);
  };
  next();
}

async function toggleStar(btn, key, markdown, threadId) {
  const list = await getStarred();
  const at = list.findIndex((x) => x.key === key);
  if (at >= 0) {
    list.splice(at, 1);
    starredKeys.delete(key);
  } else {
    list.unshift({ key, threadId, title: thread.id === threadId ? thread.title : '', text: markdown.slice(0, 6000), model: thread.model, at: Date.now() });
    starredKeys.add(key);
  }
  await setStarred(list);
  const on = starredKeys.has(key);
  btn.classList.toggle('on', on);
  btn.innerHTML = icon(on ? 'starFilled' : 'star');
  btn.title = on ? 'Remove star' : 'Star this answer';
  if (!el.drawer.hidden) refreshDrawer();
}

function buildMessageActions(node, markdown, threadId) {
  const row = document.createElement('div');
  row.className = 'msg-actions';
  const key = starKey(threadId, markdown);
  node.dataset.starKey = key;
  const make = (cls, name, title) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = `msg-act ${cls}`;
    b.title = title;
    b.setAttribute('aria-label', title);
    b.innerHTML = icon(name);
    return b;
  };
  const copy = make('act-copy', 'copy', 'Copy');
  const speak = make('act-speak', 'speaker', 'Read aloud');
  const starred = starredKeys.has(key);
  const star = make('act-star', starred ? 'starFilled' : 'star', starred ? 'Remove star' : 'Star this answer');
  if (starred) star.classList.add('on');
  copy.addEventListener('click', async () => {
    await copyText(markdown);
    copy.innerHTML = icon('check');
    setTimeout(() => { copy.innerHTML = icon('copy'); }, 1200);
  });
  speak.addEventListener('click', () => readAloud(speak, markdown));
  star.addEventListener('click', () => toggleStar(star, key, markdown, threadId).catch(() => setStatus("Couldn't save that star — try again.")));
  row.append(copy, speak, star);
  return row;
}

/** The text of a JSON string field so far, even if the JSON is still being written. */
function partialField(raw, key) {
  const m = new RegExp('"' + key + '"\\s*:\\s*"').exec(String(raw || ''));
  if (!m) return '';
  let out = '';
  const src = String(raw).slice(m.index + m[0].length);
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (ch === '\\') {
      const n = src[i + 1];
      if (n === undefined) break;
      out += n === 'n' ? ' ' : n === 't' ? ' ' : n;
      i++;
    } else if (ch === '"') break;
    else out += ch;
  }
  return out.trim();
}

/** Show a hand-over from the model's raw reply: the part meant for a person to read. */
const livePlannerText = (raw) =>
  [partialField(raw, 'thought'), partialField(raw, 'reasoning')].filter(Boolean).join(' ');
const liveReviewerText = (raw) => partialField(raw, 'comment');

/* ---------------- seeing the screen ---------------- */

/** Messages that are plainly about what's in front of the person. */
const SCREEN_RE =
  /\b(my screen|the screen|on screen|this page|this tab|this website|this site|this article|this video|this image|this form|this email|this error|this chart|this table|what(?:'s| is| am i)? (?:on|in) (?:my |the )?(?:screen|page|tab)|look at (?:this|my|the)|can you see|do you see|see (?:this|what)|read (?:this|my|the) (?:page|screen|tab)|what am i (?:looking at|seeing|reading))\b/i;

function wantsScreen(text) {
  return SCREEN_RE.test(String(text || ''));
}

/**
 * Messages that lean on "the page" without saying so outright — "summarise
 * this", "what does it say about pricing", "fix the typo here". Broader than
 * SCREEN_RE on purpose: this only decides whether to read the page's *text*
 * (cheap, no picture), and a wrong yes costs a few thousand characters.
 */
const PAGE_REF_RE =
  /\b(this|that|the|current|open)\s+(page|site|website|tab|article|post|thread|doc|document|paper|pdf|video|product|listing|recipe|repo|issue|ticket|email|form|table|chart|section|paragraph|code|error|answer|question|problem|quote|review|profile|link|result)s?\b|\b(summari[sz]e|tl;?dr|explain|translate|proofread|critique|review|analy[sz]e|fact[- ]?check|rewrite|simplify)\s+(this|it|that|here)\b|\b(on|in|from)\s+(this|here|the page|the site)\b|\bwhat(?:'s| is| does)\s+(this|it|here)\b|\b(where am i|what am i (?:on|looking at|reading|viewing)|what site is this|which page)\b|\bhere\b.{0,30}\b(say|says|mention|mentions|about)\b/i;

function refersToPage(text) {
  return PAGE_REF_RE.test(String(text || ''));
}

/** Title, address and readability of whatever tab the person is on right now. */
async function currentTabInfo() {
  try {
    const tab = await activeTab();
    if (!tab?.id) return null;
    return {
      id: tab.id,
      title: tab.title || '',
      url: tab.url || '',
      favIconUrl: tab.favIconUrl || '',
      restricted: isRestrictedUrl(tab.url)
    };
  } catch {
    return null;
  }
}

/**
 * A picture of the visible tab, plus the tab itself so its full text can be
 * read too: the picture covers what's on screen right now (images, charts,
 * layout), the text covers the whole page, scrolled-away parts included.
 */
/** Where a screenshot was taken, for the model — without the query string or #fragment, which can hold tokens. */
function pageSource(tab) {
  try {
    const u = new URL(tab.url);
    return { title: String(tab.title || '').slice(0, 120), url: `${u.origin}${u.pathname}` };
  } catch {
    return null;
  }
}

async function captureScreen() {
  const tab = await activeTab();
  if (!tab?.id) throw new Error("I can't find the tab to look at.");
  if (isRestrictedUrl(tab.url)) {
    throw new Error("I can't see a browser or extension page — switch to a regular website tab and try again.");
  }
  const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
  const shot = await readScreenshot(dataUrl, { x: 0, y: 0, width: 100000, height: 100000 }, 1);
  shot.screen = true;
  shot.source = pageSource(tab);
  shot.name = `Screen ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.png`;
  return { tab, shot };
}

let turnPageIsTemporary = false;

/* ---------------- research reports: plan first, then research ---------------- */

/** "Create a research report on Jane Doe 42 years old" → "Jane Doe 42 years old" */
function detectReportRequest(text) {
  const t = String(text || '').trim();
  if (t.length < 8 || t.length > 400) return null;
  const m = t.match(/\b(?:research\s+report|report|dossier|deep\s+dive|in-depth\s+(?:report|research))\s+(?:on|about|into|of|for)\s+(.{3,})$/i);
  if (!m) return null;
  if (!/\b(create|write|make|prepare|generate|build|do|give|put together|need|want)\b|^research\s+report/i.test(t)) return null;
  return m[1].replace(/https?:\/\/\S+/gi, ' ').replace(/\s+/g, ' ').replace(/[.?!]+$/, '').trim() || null;
}

const GENERIC_PLAN = [
  'Overview and background',
  'Key facts and timeline',
  'Main contributions or activities',
  'What others say: reception and coverage',
  'Recent developments'
];

async function makeReportPlan(topic) {
  try {
    const { content } = await completeChat({
      config: configForChoice(settings, 'search'),
      models: chain('search'),
      messages: [
        {
          role: 'system',
          content:
            'You plan web research. Reply with ONLY a JSON array of 5 to 7 short strings: the section titles a research report on the subject should cover, in a sensible order. ' +
            'Name angles to research only — never state a fact about the subject, never guess who or what it is. ' +
            'For a person include biography/background, career, published or notable work, public statements or interviews, reception/recognition, and recent news. ' +
            'For a company or organisation: what it is, history, products or work, people, finances or funding, reception, recent news. ' +
            'For a question or a concept: the sub-questions that must be answered, the evidence for and against, the current state, and open disagreements. No prose, no code fences.'
        },
        { role: 'user', content: topic }
      ],
      temperature: 0.2,
      maxTokens: 300,
      quick: true,
      timeoutMs: 8000,
      timeoutAll: true,
      signal: controller?.signal
    });
    const arr = extractJson(String(content || '').replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/```json|```/g, ''));
    const steps = (Array.isArray(arr) ? arr : []).map((x) => String(x).trim()).filter(Boolean).slice(0, 7);
    if (steps.length >= 3) return steps;
  } catch (err) {
    if (err.name === 'AbortError') throw err;
  }
  return GENERIC_PLAN;
}

/** Remove a reasoning model's <think> block, finished or still open. */

const estMinutes = () => `${Math.round(RESEARCH.minMs / 60000)}–${Math.round(RESEARCH.maxMs / 60000)}`;
let reportFinishRequested = false;
let reportSeeds = []; // links pasted with the question: read first
let reportFinishBtn = null;

/** What the person typed, minus the "deep search …" wording, as the subject to research. */
function researchTopicFrom(text) {
  const t = String(text || '')
    .replace(/^\s*(?:please\s+)?(?:can you\s+)?(?:deep[- ]search|research|investigate|look up|find out(?: about)?|dig into)\s*(?:about|on|into|for)?\s*[:,-]?\s*/i, '')
    .replace(/https?:\/\/\S+/gi, ' ')
    .replace(/\s+/g, ' ')
    .replace(/[?!.\s]+$/, '')
    .trim();
  return (t.length >= 3 ? t : String(text || '').trim()).slice(0, 300);
}

/** A short follow-up after a finished report is a quick question, not a new 10-minute project. */
function isQuickFollowUp(text) {
  if (/^\s*quick\b[:,]?/i.test(text)) return true;
  const words = String(text || '').trim().split(/\s+/).filter(Boolean).length;
  return words <= 8 && thread.messages.some((m) => m.role === 'assistant' && m.research);
}

async function planReport(topic) {
  const view = addAssistant();
  view.finish();
  setStatus('Putting a research plan together…');
  const steps = await makeReportPlan(topic);
  setStatus('');

  const card = document.createElement('div');
  card.className = 'report-plan';

  const lead = document.createElement('p');
  lead.textContent = `I've put together a research plan for “${topic}”.`;

  const panel = document.createElement('div');
  panel.className = 'report-plan-panel';

  const head = document.createElement('div');
  head.className = 'report-plan-head';
  const title = document.createElement('strong');
  title.textContent = 'Research plan';
  const editBtn = document.createElement('button');
  editBtn.type = 'button';
  editBtn.className = 'report-edit';
  editBtn.textContent = 'Edit research plan';
  head.append(title, editBtn);

  const hint = document.createElement('p');
  hint.className = 'report-plan-hint';
  hint.textContent = "You can edit the plan below. You'll see the report in this conversation once I'm done.";

  const list = document.createElement('ol');
  list.className = 'report-plan-list';

  const edit = document.createElement('textarea');
  edit.className = 'report-plan-edit';
  edit.rows = Math.min(10, steps.length + 1);
  edit.value = steps.join('\n');
  edit.spellcheck = false;
  edit.hidden = true;

  const lines = () => edit.value.split('\n').map((l) => l.replace(/^[-*\d.\s]+/, '').trim()).filter(Boolean).slice(0, 8);

  const meta = document.createElement('div');
  meta.className = 'report-plan-meta';

  const refresh = () => {
    const now = lines();
    list.replaceChildren(...now.map((t) => { const li = document.createElement('li'); li.textContent = t; return li; }));
    meta.textContent = `Est. time: ~${estMinutes()} min — it keeps digging until every section has two independent sources`;
  };
  edit.addEventListener('input', () => { meta.textContent = `Est. time: ~${estMinutes()} min — it keeps digging until every section has two independent sources`; });
  refresh();

  editBtn.addEventListener('click', () => {
    const editing = edit.hidden;
    edit.hidden = !editing;
    list.hidden = editing;
    editBtn.textContent = editing ? 'Done editing' : 'Edit research plan';
    if (editing) edit.focus();
    else refresh();
  });

  const row = document.createElement('div');
  row.className = 'report-plan-actions';
  const start = document.createElement('button');
  start.type = 'button';
  start.className = 'report-start';
  start.textContent = 'Start research';
  const cancel = document.createElement('button');
  cancel.type = 'button';
  cancel.className = 'report-cancel';
  cancel.textContent = 'Cancel';
  row.append(start, cancel);

  start.addEventListener('click', () => {
    if (!edit.hidden) refresh();
    const chosen = lines();
    if (!chosen.length || busy) return;
    editBtn.remove();
    edit.hidden = true;
    list.hidden = false;
    row.remove();
    hint.remove();
    meta.textContent = `Researching · ${chosen.length} sections · about ${estMinutes()} min`;
    reportFinishRequested = false;
    const finish = document.createElement('button');
    finish.type = 'button';
    finish.className = 'report-finish';
    finish.textContent = 'Write the report now';
    finish.title = 'Stop searching and write up what has been verified so far';
    finish.addEventListener('click', () => {
      reportFinishRequested = true;
      if (activeJob) chrome.runtime.sendMessage({ type: 'viora:job-finish', id: activeJob.id }).catch(() => {});
      finish.disabled = true;
      finish.textContent = 'Wrapping up…';
    });
    reportFinishBtn = finish;
    panel.append(finish);
    startReport(topic, chosen);
  });
  cancel.addEventListener('click', () => view.node.remove());

  panel.append(head, hint, list, edit, meta, row);
  card.append(lead, panel);
  view.body.append(card);
  scrollDown();
}

async function startReport(topic, steps) {
  if (busy) return;
  controller = new AbortController();
  setBusy(true);
  try {
    await runReport(topic, steps);
    await persist(`Research: ${topic}`);
  } catch (err) {
    document.querySelectorAll('.msg.assistant.streaming').forEach((n) => {
      if (!n.querySelector('.body')?.textContent.trim()) n.remove();
      else n.classList.remove('streaming');
    });
    if (err.name === 'AbortError') setStatus('Stopped');
    else {
      if (err.detail) console.warn('[Viora] provider said:', err.detail);
      addError(err, () => {
        document.querySelectorAll('.msg.assistant .error').forEach((n) => n.closest('.msg')?.remove());
        startReport(topic, steps);
      });
    }
  } finally {
    setBusy(false);
    controller = null;
    reportFinishBtn?.remove();
    reportFinishBtn = null;
    stopClock();
    setStatus('');
  }
}

let clockTimer = 0;
function startClock(since) {
  stopClock();
  clockTimer = setInterval(() => {
    const sec = Math.floor((Date.now() - since) / 1000);
    el.hint.textContent = `Researching ${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`;
  }, 1000);
}
function stopClock() {
  if (clockTimer) clearInterval(clockTimer);
  clockTimer = 0;
}

async function runReport(topic, steps) {
  const signal = controller.signal;
  const view = addAssistant();
  const began = Date.now();
  startClock(began);

  const mmss = (ms) => `${Math.floor(ms / 60000)}:${String(Math.floor((ms % 60000) / 1000)).padStart(2, '0')}`;
  const done = []; // sections already written and checked
  let progressNote = null;

  // What the person watches while it works: the checked sections as they land,
  // and under them a live tally of what has actually been verified.
  const render = () => {
    const body = done.map((x) => `## ${x.title}\n\n${x.text}`).join('\n\n');
    const tally = progressNote
      ? [
          `> **Researching · ${mmss(progressNote.elapsedMs)}** — ${progressNote.pages} pages read · ${progressNote.facts} facts verified against the page text · ${progressNote.sources} sources`,
          ...progressNote.steps.map((s) => `> ${s.grade === 'verified' ? '✓' : s.grade === 'partial' ? '◐' : '○'} ${s.title} — ${s.facts} fact${s.facts === 1 ? '' : 's'}, ${s.hosts} site${s.hosts === 1 ? '' : 's'}`)
        ].join('\n')
      : '';
    view.setMarkdown([`# Research report: ${topic}`, body, tally].filter(Boolean).join('\n\n'));
  };
  render();

  // The research itself runs in the background runner (see lib/jobs.js), so
  // closing the panel doesn't stop it: the finished report is saved into this
  // conversation and a notification says it is ready. While the panel stays
  // open it renders exactly as before, from the runner's live events.
  let result;
  let jobId = null;
  try {
    await persist(`Research: ${topic}`); // the job needs a saved conversation to write its report into
    const job = await runJob('report', { topic, steps, seedUrls: reportSeeds }, {
      label: `Research: ${topic}`,
      signal,
      onEvent: (m) => {
        if (m.event === 'section') {
          done.push(m.section);
          render();
        } else if (m.event === 'progress') {
          if (m.status !== undefined) setStatus(m.status);
          if (m.sources) setStatusSources(m.sources);
          if (m.tally !== undefined) {
            progressNote = m.tally;
            render();
          }
        }
      }
    });
    result = job.out;
    jobId = job.id;
  } catch (err) {
    // Stopped or failed: keep the sections already checked, drop the live tally.
    progressNote = null;
    render();
    throw err;
  }
  stopClock();
  setStatus('');

  const { final, cited } = result;

  view.setMarkdown(final);
  if (cited.length && settings.prefs.citations) {
    linkInlineMarkers(view.body, cited);
    view.body.append(sourceStrip(cited));
    view.setSources(cited);
  }
  view.finish();
  if (cited.length) attachPdfFile(view, withSourceList(final, cited));

  pushJobMessage(messageForJob({ id: jobId, kind: 'report', payload: { topic } }, result));
}

/** A generated picture with a Save button. */
function imageCard(dataUrl, caption) {
  const wrap = document.createElement('div');
  wrap.className = 'gen-image';
  const img = document.createElement('img');
  img.src = dataUrl;
  img.alt = caption || 'Generated image';
  const save = document.createElement('button');
  save.type = 'button';
  save.className = 'gen-image-save';
  save.textContent = 'Save';
  save.addEventListener('click', () => {
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = 'viora-image-' + Date.now() + '.jpg';
    a.click();
  });
  wrap.append(img, save);
  return wrap;
}

/* ---------------- image mode (the "+" menu → Create an image) ---------------- */

let imageMode = false;

function setImageMode(on) {
  imageMode = on && !!current().canAttach;
  el.imageChip.hidden = !imageMode;
  el.input.placeholder = imageMode ? 'Describe the picture you want' : current().placeholder;
}

async function runImage(prompt) {
  const view = addAssistant();
  const started = Date.now();
  const tick = setInterval(() => {
    setStatus(`Painting your picture… ${Math.round((Date.now() - started) / 1000)}s`);
  }, 1000);
  setStatus('Painting your picture…');
  try {
    await persist(prompt); // saved first, so the picture lands in this chat even if the panel is closed meanwhile
    const { id, out } = await runJob('image', { prompt }, { label: prompt, signal: controller?.signal });
    view.setImage(out.dataUrl, prompt);
    view.finish();
    pushJobMessage(messageForJob({ id, kind: 'image', payload: { prompt } }, out));
  } catch (err) {
    view.node.remove();
    throw err;
  } finally {
    clearInterval(tick);
    setStatus('');
  }
}

/* ---------------- background jobs (pictures, research reports) ---------------- */

let activeJob = null; // the job this panel is waiting on, { id, kind }
// While this is open the worker knows someone is watching. The worker can be
// put to sleep by the browser during a long wait; when that drops the
// connection, reconnect and say again which jobs this panel is waiting on, so
// it is never mistaken for a closed panel while it is still here.
const watchedJobs = new Set();
let jobPort = null;
function connectJobPort() {
  jobPort = chrome.runtime.connect({ name: 'viora-panel' });
  for (const id of watchedJobs) jobPort.postMessage({ watch: id });
  jobPort.onDisconnect.addListener(() => setTimeout(connectJobPort, 250));
}
connectJobPort();
// A message every so often also stops the worker nodding off in the middle of a long reply.
setInterval(() => { try { jobPort?.postMessage({ ping: Date.now() }); } catch { /* reconnecting */ } }, 20000);

/**
 * Run a long job in the background runner and wait for it. If the panel is
 * closed meanwhile the job carries on; the worker saves the result into the
 * conversation and shows a notification (see background/jobs.js).
 */
function runJob(kind, payload, { label = '', onEvent = () => {}, signal } = {}) {
  return new Promise((resolve, reject) => {
    let id = null;
    const buffered = [];
    const cleanup = () => {
      chrome.runtime.onMessage.removeListener(listener);
      signal?.removeEventListener('abort', onAbort);
      if (id) watchedJobs.delete(id);
      activeJob = null;
    };
    const handle = (msg) => {
      if (msg.event === 'result') {
        cleanup();
        resolve({ id, out: msg.out });
      } else if (msg.event === 'error') {
        cleanup();
        const e = new Error(msg.message);
        e.hint = msg.hint;
        e.detail = msg.detail;
        if (msg.code) e.code = msg.code;
        reject(e);
      } else if (msg.event === 'cancelled') {
        cleanup();
        reject(new DOMException('Aborted', 'AbortError'));
      } else {
        onEvent(msg);
      }
    };
    const listener = (msg) => {
      if (msg?.type !== 'viora:job-event') return;
      if (id === null) buffered.push(msg);
      else if (msg.id === id) handle(msg);
    };
    const onAbort = () => {
      if (id) chrome.runtime.sendMessage({ type: 'viora:job-cancel', id }).catch(() => {});
    };
    chrome.runtime.onMessage.addListener(listener);
    signal?.addEventListener('abort', onAbort, { once: true });
    chrome.runtime.sendMessage({ type: 'viora:job-start', kind, threadId: thread.id, payload, label }, (res) => {
      if (chrome.runtime.lastError || res?.error || !res?.id) {
        cleanup();
        reject(new Error(res?.error || chrome.runtime.lastError?.message || "Couldn't start the background job."));
        return;
      }
      id = res.id;
      activeJob = { id, kind };
      watchedJobs.add(id);
      jobPort?.postMessage({ watch: id });
      if (signal?.aborted) onAbort();
      for (const m of buffered.splice(0)) if (m.id === id) handle(m);
    });
  });
}

/** Add a finished job's message to this conversation once (the worker may have saved it already). */
function pushJobMessage(m) {
  if (!thread.messages.some((x) => x.jobId === m.jobId)) thread.messages.push(m);
}

/** Jobs that finished while the panel was closed are already saved in the conversation: show them. */
async function syncJobMessages() {
  if (!thread?.id) return;
  const stored = (await getThreads()).find((t) => t.id === thread.id);
  const missing = missingJobMessages(thread.messages, stored?.messages).filter((m) => m.jobId !== activeJob?.id);
  if (!missing.length) return;
  clearWelcome();
  for (const m of missing) {
    thread.messages.push(m);
    renderMessage(m);
  }
  scrollDown();
  refreshDrawer();
}

/** A strip above the chat for work that is still running in the background (e.g. from before the panel was closed). */
let jobBanner = null;
async function refreshJobBanner() {
  const res = await chrome.runtime.sendMessage({ type: 'viora:jobs' }).catch(() => null);
  const running = (res?.jobs || []).filter((j) => j.status === 'running' && j.id !== activeJob?.id);
  if (!running.length) {
    jobBanner?.remove();
    jobBanner = null;
    return;
  }
  // Switching chats clears the thread area, which removes the strip: build it again when that happens.
  if (jobBanner && !jobBanner.isConnected) jobBanner = null;
  const j = running[0];
  if (!jobBanner) {
    jobBanner = document.createElement('div');
    jobBanner.className = 'job-banner';
    jobBanner.setAttribute('role', 'status');
    el.thread.prepend(jobBanner); // inside the chat area, not a new row of the page grid
  }
  const what = JOB_NOUN_A[j.kind] || 'a task';
  const label = document.createElement('span');
  const secs = Math.round((Date.now() - j.startedAt) / 1000);
  label.textContent = `Still working on ${what} in the background · ${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, '0')}${j.progress?.status ? ` · ${j.progress.status}` : ''}`;
  const open = document.createElement('button');
  open.type = 'button';
  open.textContent = j.threadId === thread.id ? 'Hide' : 'Open chat';
  open.addEventListener('click', async () => {
    if (j.threadId === thread.id) return void jobBanner?.remove();
    const t = (await getThreads()).find((x) => x.id === j.threadId);
    if (t && !busy) loadThread(t);
  });
  jobBanner.replaceChildren(label, open);
}
setInterval(() => { if (!document.hidden) refreshJobBanner(); }, 4000);
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'viora:job-event' && (msg.event === 'result' || msg.event === 'error' || msg.event === 'cancelled')) {
    setTimeout(() => { refreshJobBanner(); syncJobMessages(); }, 400);
  }
});

/** A notification click asks the panel to open that conversation. */
async function openRequestedThread() {
  const { openThread } = await chrome.storage.local.get('openThread');
  if (!openThread) return;
  await chrome.storage.local.remove('openThread');
  if (Date.now() - openThread.at > 120000 || busy) return;
  const t = (await getThreads()).find((x) => x.id === openThread.id);
  if (t && t.id !== thread.id) loadThread(t);
}

/** Facts the worker learned from a whole chat while nobody was looking: say so, with Undo. */
async function showLearnedFromChats() {
  const { lastLearned } = await chrome.storage.local.get('lastLearned');
  if (!lastLearned?.added?.length) return;
  await chrome.storage.local.remove('lastLearned');
  if (Date.now() - lastLearned.at > 600000) return;
  showRemembered(lastLearned.added, lastLearned.before || []);
}

function addError(err, retry, extra) {
  clearWelcome();
  const box = document.createElement('div');
  box.className = 'msg assistant';
  const inner = document.createElement('div');
  inner.className = 'error';
  inner.textContent = err.message || 'Something went wrong.';
  if (err.hint) {
    const fix = document.createElement('span');
    fix.className = 'fix';
    fix.textContent = err.hint;
    inner.append(fix);
  }
  if (retry) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'Try again';
    btn.addEventListener('click', () => {
      box.remove();
      retry();
    });
    inner.append(btn);
  }
  box.append(inner);
  if (extra) inner.append(extra);
  el.thread.append(box);
  scrollDown();
}

/**
 * When every model in a chain is gone, ask Groq what it does serve and let the
 * user pin one, rather than sending them hunting through settings.
 */
function modelPicker(choice, retryFn) {
  const wrap = document.createElement('div');
  wrap.className = 'model-fix';
  const providerConfig = configForChoice(settings, choice);
  const providerLabel = providerConfig.label || 'Groq';

  const load = document.createElement('button');
  load.type = 'button';
  load.textContent = `Show what ${providerLabel} is serving`;

  load.addEventListener('click', async () => {
    load.disabled = true;
    load.textContent = 'Loading';
    try {
      const models = await listModels({ config: providerConfig });
      load.remove();

      const note = document.createElement('p');
      note.className = 'fix';
      note.textContent = `${providerLabel} has ${models.length} models right now. Pick the one ${getModel(choice).name} should use.`;

      const list = document.createElement('div');
      list.className = 'id-list';

      for (const id of models) {
        const b = document.createElement('button');
        b.type = 'button';
        b.textContent = id;
        b.addEventListener('click', async () => {
          settings = await saveSettings({ modelOverrides: { [choice]: id } });
          retryFn?.();
        });
        list.append(b);
      }

      wrap.append(note, list);
    } catch (err) {
      load.disabled = false;
      load.textContent = `Show what ${providerLabel} is serving`;
      const fail = document.createElement('span');
      fail.className = 'fix';
      fail.textContent = err.message;
      wrap.append(fail);
    }
  });

  wrap.append(load);
  return wrap;
}

/* ---------------- history ---------------- */

let drawerTab = 'chats';
let drawerQuery = '';

async function refreshDrawer() {
  const [threads, starred] = await Promise.all([getThreads(), getStarred()]);
  el.threadList.replaceChildren();
  for (const [btn, on] of [[el.tabChats, drawerTab === 'chats'], [el.tabStarred, drawerTab === 'starred']]) {
    btn.classList.toggle('on', on);
    btn.setAttribute('aria-selected', String(on));
  }
  if (drawerTab === 'starred') {
    renderStarred(threads, starred);
    return;
  }

  const results = searchThreads(threads, drawerQuery);
  el.threadEmpty.hidden = results.length > 0;
  el.threadEmpty.textContent = threads.length
    ? 'No conversations match that search.'
    : 'Nothing saved yet. Conversations show up here once you send a message.';

  for (const { thread: t, snippet } of results) {
    const li = document.createElement('li');
    const row = document.createElement('div');
    row.className = 'thread-item';

    const open = document.createElement('button');
    open.type = 'button';
    open.className = 't-title';
    const name = document.createElement('span');
    name.className = 't-name';
    name.textContent = t.title;
    open.append(name);
    if (snippet) {
      const sn = document.createElement('span');
      sn.className = 't-snippet';
      sn.textContent = snippet;
      open.append(sn);
    }
    open.addEventListener('click', () => loadThread(t));

    const mark = document.createElement('span');
    mark.className = 't-mode';
    mark.innerHTML = icon(MODEL_ICON[t.model] || 'flash');
    mark.title = getModel(t.model).name;

    const mkBtn = (cls, glyph, title) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = cls;
      b.title = title;
      b.setAttribute('aria-label', `${title}: ${t.title}`);
      b.innerHTML = glyph;
      b.dataset.threadId = t.id;
      return b;
    };
    const pin = mkBtn(`t-act t-pin${t.pinned ? ' on' : ''}`, icon(t.pinned ? 'pinFilled' : 'pin'), t.pinned ? 'Unpin' : 'Pin to the top');
    const exp = mkBtn('t-act t-export', icon('download'), 'Export');
    const del = mkBtn('t-del', '×', 'Delete');

    row.append(open, mark, pin, exp, del);
    li.append(row);
    el.threadList.append(li);
  }
}

function renderStarred(threads, starred) {
  const items = searchStarred(starred, drawerQuery);
  el.threadEmpty.hidden = items.length > 0;
  el.threadEmpty.textContent = starred.length
    ? 'No starred answers match that search.'
    : 'Tap the star under an answer to keep it here.';
  const when = (at) => new Date(at || Date.now()).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  for (const item of items) {
    const owner = threads.find((t) => t.id === item.threadId);
    const li = document.createElement('li');
    const row = document.createElement('div');
    row.className = 'thread-item starred-item';

    const open = document.createElement('button');
    open.type = 'button';
    open.className = 't-title s-open';
    open.dataset.key = item.key;
    const name = document.createElement('span');
    name.className = 't-name';
    name.textContent = item.text.replace(/[#*_`>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 110);
    const meta = document.createElement('span');
    meta.className = 't-snippet';
    meta.textContent = `${owner?.title || item.title || 'Deleted conversation'} · ${when(item.at)}`;
    open.append(name, meta);

    const mk = (cls, glyph, title) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = `t-act ${cls}`;
      b.title = title;
      b.setAttribute('aria-label', title);
      b.innerHTML = glyph;
      b.dataset.key = item.key;
      return b;
    };
    row.append(open, mk('s-copy', icon('copy'), 'Copy'), mk('s-unstar on', icon('starFilled'), 'Remove star'));
    li.append(row);
    el.threadList.append(li);
  }
}

async function exportThread(id, fmt) {
  const t = (await getThreads()).find((x) => x.id === id);
  if (!t) return;
  const md = threadToMarkdown(t);
  if (fmt === 'md') {
    downloadPdfBlob(new Blob([md], { type: 'text/markdown' }), `${exportStem(t)}.md`);
    setStatus('Saved as Markdown');
  } else {
    downloadPdfBlob(markdownToPdf(md, pdfTitle(md)), pdfFilename(exportStem(t)));
    setStatus('Saved as PDF');
  }
  setTimeout(() => { if (!busy) setStatus(''); }, 2500);
}

// Delegated: the drawer's rows are rebuilt on every refreshDrawer() call, so a
// listener bound directly to a row is gone the moment the list re-renders.
// Binding once on the stable #thread-list container survives every re-render.
el.threadList.addEventListener('click', async (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  try {
    if (btn.classList.contains('t-del')) {
      await deleteThread(btn.dataset.threadId);
      refreshDrawer();
    } else if (btn.classList.contains('t-pin')) {
      const id = btn.dataset.threadId;
      const saved = (await getThreads()).find((x) => x.id === id);
      if (!saved) return;
      saved.pinned = !saved.pinned;
      if (thread.id === id) thread.pinned = saved.pinned; // the open conversation must not un-pin itself on its next save
      await saveThread(saved);
      refreshDrawer();
    } else if (btn.classList.contains('t-export')) {
      const li = btn.closest('li');
      const existing = li.querySelector('.t-export-menu');
      if (existing) {
        existing.remove();
        return;
      }
      el.threadList.querySelectorAll('.t-export-menu').forEach((n) => n.remove());
      const menu = document.createElement('div');
      menu.className = 't-export-menu';
      for (const [fmt, label] of [['md', 'Markdown (.md)'], ['pdf', 'PDF']]) {
        const b = document.createElement('button');
        b.type = 'button';
        b.dataset.fmt = fmt;
        b.dataset.threadId = btn.dataset.threadId;
        b.textContent = label;
        menu.append(b);
      }
      li.append(menu);
    } else if (btn.dataset.fmt) {
      await exportThread(btn.dataset.threadId, btn.dataset.fmt);
      btn.closest('.t-export-menu')?.remove();
    } else if (btn.classList.contains('s-open')) {
      const item = (await getStarred()).find((x) => x.key === btn.dataset.key);
      const owner = item && (await getThreads()).find((t) => t.id === item.threadId);
      if (!owner) {
        setStatus('That conversation was deleted — you can still copy the answer.');
        return;
      }
      loadThread(owner);
      requestAnimationFrame(() => {
        const node = [...el.thread.querySelectorAll('.msg.assistant')].find((n) => n.dataset.starKey === item.key);
        node?.scrollIntoView({ block: 'center' });
        node?.classList.add('flash-hl');
        setTimeout(() => node?.classList.remove('flash-hl'), 1800);
      });
    } else if (btn.classList.contains('s-copy')) {
      const item = (await getStarred()).find((x) => x.key === btn.dataset.key);
      if (item) {
        await copyText(item.text);
        btn.innerHTML = icon('check');
        setTimeout(() => { btn.innerHTML = icon('copy'); }, 1200);
      }
    } else if (btn.classList.contains('s-unstar')) {
      const list = (await getStarred()).filter((x) => x.key !== btn.dataset.key);
      starredKeys.delete(btn.dataset.key);
      await setStarred(list);
      document.querySelectorAll(`.msg.assistant[data-star-key="${btn.dataset.key}"] .act-star`).forEach((b) => {
        b.classList.remove('on');
        b.innerHTML = icon('star');
      });
      refreshDrawer();
    }
  } catch {
    setStatus("That didn't work — try again.");
  }
});

let drawerSearchTimer = 0;
el.threadSearch.addEventListener('input', () => {
  clearTimeout(drawerSearchTimer);
  drawerSearchTimer = setTimeout(() => {
    drawerQuery = el.threadSearch.value;
    refreshDrawer();
  }, 120);
});
el.threadSearch.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && el.threadSearch.value) {
    e.stopPropagation();
    el.threadSearch.value = '';
    drawerQuery = '';
    refreshDrawer();
  }
});
for (const [btn, tab] of [[el.tabChats, 'chats'], [el.tabStarred, 'starred']]) {
  btn.addEventListener('click', () => {
    drawerTab = tab;
    refreshDrawer();
  });
}

/** Draw one saved message into the conversation. */
function renderMessage(m) {
  if (m.role === 'user') {
    addUser(m.displayText ?? m.content, m.attachments || []);
    return;
  }
  const view = addAssistant();
  if (m.image) {
    view.setImage(m.image, m.imagePrompt);
    view.finish();
    return;
  }
  view.setReasoning(m.reasoning);
  view.setMarkdown(m.content);
  if (m.sources?.length && settings.prefs.citations) {
    linkInlineMarkers(view.body, m.sources);
    view.body.append(sourceStrip(m.sources));
    view.setSources(m.sources);
  }
  view.finish();
  if (m.pdf && m.content?.trim()) attachPdfFile(view, withSourceList(m.content, m.sources || []));
}

function loadThread(saved) {
  if (thread?.id && thread.id !== saved.id) askToLearn(thread.id, true);
  stopSpeaking();
  thread = structuredClone(saved);
  closeSheets();
  el.thread.replaceChildren();
  setModel(thread.model || 'flash');
  forcedMode = thread.model === 'humanize' || thread.model === 'automate' ? thread.model : null;
  renderModeChip();

  for (const m of thread.messages) renderMessage(m);
  scrollDown();
}

async function persist(firstPrompt) {
  if (thread.title === 'New conversation' && firstPrompt) {
    thread.title = firstPrompt.replace(/\s+/g, ' ').slice(0, 52) + (firstPrompt.length > 52 ? '…' : '');
  }
  await saveThread(thread);
  refreshDrawer();
  askToLearn(thread.id, false);
}

/** Ask the worker to read this chat for lasting facts and a note about it (it decides whether it has grown enough). */
function askToLearn(threadId, final) {
  chrome.runtime.sendMessage({ type: 'viora:digest', threadId, final }).catch(() => {});
}

/* ---------------- memory by conversation ---------------- */

/** "Remember that I'm vegetarian" / "call me Sam" / "forget the vegetarian thing" → an edit to memory, or null. */
function detectMemoryCommand(text) {
  const t = String(text || '').trim().replace(/[.!]+$/, '');
  if (t.length < 8 || t.length > 320) return null;
  const tidy = (v) => v.replace(/\s+/g, ' ').trim().slice(0, 260);
  let m = t.match(/^(?:please\s+|hey\s+viora[,!]?\s+)?remember\s+(?:that\s+)?(.{3,260})$/i);
  if (m) return { add: tidy(m[1]) };
  m = t.match(/^(?:please\s+)?(?:you can\s+)?call me\s+([A-Za-z][\w' -]{1,38})$/i);
  if (m) return { add: `Their name is ${tidy(m[1])} — call them that.` };
  m = t.match(/^my name is\s+([A-Za-z][\w' -]{1,38})$/i);
  if (m) return { add: `Their name is ${tidy(m[1])}.` };
  m = t.match(/^(?:please\s+)?forget\s+(?:that\s+|about\s+)?(.{3,200})$/i);
  if (m) return { forget: tidy(m[1]).toLowerCase() };
  return null;
}

let turnMemoryNote = '';

async function applyMemoryCommand(cmd) {
  const memory = Array.isArray(settings.memory) ? [...settings.memory] : [];
  if (cmd.add) {
    if (!memory.some((x) => String(x).toLowerCase() === cmd.add.toLowerCase())) memory.push(cmd.add);
    settings = await saveSettings({ memory: memory.slice(-40) });
    turnMemoryNote = 'Saved to memory';
  } else if (cmd.forget) {
    const FILLER = new Set(['the','thing','things','stuff','about','that','what','told','you','your','said','earlier','one','all']);
    const words = cmd.forget.split(/\W+/).filter((w) => w.length > 2 && !FILLER.has(w));
    const kept = memory.filter((x) => {
      const e = String(x).toLowerCase();
      return !(e.includes(cmd.forget) || cmd.forget.includes(e) || (words.length && words.every((w) => e.includes(w))));
    });
    if (kept.length !== memory.length) {
      settings = await saveSettings({ memory: kept });
      turnMemoryNote = 'Removed from memory';
    }
  }
}

/* ---------------- long conversations: a rolling recap ---------------- */

const SUMMARY_KEEP = 24;

/** One short line per recent *other* conversation: its title plus what it came down to. */
async function recentChatsDigest(currentId) {
  try {
    const others = (await getThreads())
      .filter((t) => t.id !== currentId && Array.isArray(t.messages) && t.messages.length > 1)
      .slice(0, 4);
    return others
      .map((t) => {
        const lastAnswer = [...t.messages].reverse().find((m) => m.role === 'assistant');
        const gist = String(t.summary || lastAnswer?.content || '').replace(/\s+/g, ' ').trim().slice(0, 170);
        return `- "${String(t.title || 'Untitled').slice(0, 60)}"${gist ? `: ${gist}` : ''}`;
      })
      .join('\n');
  } catch {
    return '';
  }
}

/** Compress everything older than the last SUMMARY_KEEP messages into a short recap, in the background. */
async function maybeSummarize(t) {
  const n = t.messages.length;
  const cut = n - SUMMARY_KEEP;
  if (n < 32 || cut - (t.summaryUpTo || 0) < 6) return;
  const fresh = t.messages.slice(t.summaryUpTo || 0, cut)
    .map((m) => `${m.role === 'user' ? 'Person' : 'Viora'}: ${String(m.displayText ?? m.content ?? '').replace(/\s+/g, ' ').slice(0, 500)}`)
    .join('\n')
    .slice(0, 10000);
  try {
    const { content } = await completeChat({
      config: configForChoice(settings, 'flash'),
      models: chain('flash'),
      messages: [
        {
          role: 'system',
          content:
            'You compress a conversation into a recap that a future assistant will rely on. Write under 260 words of plain notes: what the person is trying to do, facts about them, decisions made, numbers/names/code identifiers that matter, and anything still unresolved. No greeting, no fluff, no markdown headings.'
        },
        { role: 'user', content: `${t.summary ? `Recap so far:\n${t.summary}\n\n` : ''}New messages to fold in:\n${fresh}` }
      ],
      temperature: 0.2,
      maxTokens: 900,
      effort: 'low',
      timeoutMs: 20000
    });
    const text = content.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
    if (!text) return;
    t.summary = text.slice(0, 2200);
    t.summaryUpTo = cut;
    await saveThread(t);
  } catch (err) {
    console.warn('[Viora] could not summarise the thread:', err?.message || err);
  }
}

/* ---------------- follow-up suggestions ---------------- */

/** Three tappable next questions under a longer answer. Uses the reviewer's key so chat's budget is untouched. */
async function suggestFollowUps(view, question, answer) {
  if (!settings.prefs.followUps || answer.trim().length < 200) return;
  const t = thread;
  try {
    const { content } = await completeChat({
      config: partnerConfig(settings),
      models: partnerChain({ overrides: settings.modelOverrides, resolved: settings.resolvedModels }).slice(0, 2),
      messages: [
        {
          role: 'system',
          content:
            'You suggest what a curious person would tap next. Reply with exactly 3 lines, one question per line, each under 58 characters, written the way the PERSON would ask it (first person: "How do I…?", "Can you show an example?", "What about…?"). Make them specific to this answer — never generic like "Tell me more". No numbering, no quotes, nothing else.'
        },
        { role: 'user', content: `They asked: ${question.slice(0, 300)}\n\nAnswer given:\n${answer.slice(0, 1200)}` }
      ],
      temperature: 0.8,
      maxTokens: 400,
      effort: 'low',
      timeoutMs: 8000,
      timeoutAll: true
    });
    const items = content
      .replace(/<think>[\s\S]*?<\/think>/gi, '')
      .split('\n')
      .map((l) => l.replace(/^[\s\-*•\d.)"“]+|["”\s]+$/g, '').trim())
      .filter((l) => l.length >= 6 && l.length <= 80 && /[a-z]/i.test(l))
      .slice(0, 3);
    if (items.length < 2 || t !== thread || !view.node.isConnected || el.thread.lastElementChild !== view.node) return;
    const wrap = document.createElement('div');
    wrap.className = 'followups';
    for (const q of items) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'followup';
      b.textContent = q;
      b.addEventListener('click', () => {
        wrap.remove();
        send(q);
      });
      wrap.append(b);
    }
    view.node.append(wrap);
    scrollDown();
  } catch {
    // Suggestions are a nicety; silence is fine.
  }
}

/* ---------------- the turn ---------------- */

async function collectPage() {
  if (!selectedPage) return null;
  try {
    return await pageContext(selectedPage.id);
  } catch (err) {
    setStatus(err.message || "Viora can't read that page.");
    return null;
  }
}

/**
 * Groq counts a request's prompt *plus its max_tokens* against the minute's
 * token bucket before it runs, and Viora's shared key has only 8,000 a minute.
 * So keep the reservation honest: image turns stay small, and Flash — the
 * quick, chatty one — doesn't hold back 2,048 tokens for answers that run a
 * few hundred. Essays and the slower modes keep the user's full setting.
 * (If the bucket is still too full, providers.js shrinks it further, live;
 * if the prompt alone is over the model's ceiling, runChat() trims the
 * context and asks again rather than surfacing the refusal.)
 */
const FLASH_REPLY_TOKENS = 1500;

function outputReserve({ hasImages, choice, essay }) {
  const wanted = settings.prefs.maxTokens;
  if (hasImages) return Math.min(wanted, 1500);
  if (choice === 'flash' && !essay) return Math.min(wanted, FLASH_REPLY_TOKENS);
  return wanted;
}

/**
 * The live web and the conversation history share the same fixed allowance
 * (see lib/chatjob.js): Groq's free tier meters the whole shared key, so the
 * web block gets its own cap and history gives up exactly what it took.
 */
const WEB_BUDGET = 7000;
const WEB_BUDGET_IMAGES = 3200;
// Deep Search reads wider than the everyday modes: more pages and a bigger
// block. It is the one mode where a longer wait and a heavier turn is the
// point — but the shared free-tier key still meters tokens per minute, and
// the TRIMS ladder below shrinks the block automatically if a turn is refused.
const DEEP_BUDGET = 12000;
const DEEP_DOCS = 5;


async function runChat() {
  const model = current();
  let page = await collectPage();
  const attachments = pendingTurnAttachments;
  // Every turn knows which tab the person is on (title + address). When the
  // message is about the page — or "always send the page" is on in Settings —
  // its text is read too, with no need to attach the tab by hand first.
  const tabInfo = await currentTabInfo();
  const earlyAsk = String(thread.messages.at(-1)?.displayText ?? thread.messages.at(-1)?.content ?? '');
  // A PDF the person wants changed, or small talk ("hi", "what are you?"):
  // neither needs the web or the page, and small talk never gets sources.
  const pdfEdit = pendingPdfEdit;
  pendingPdfEdit = null;
  const casual = !pdfEdit && !attachments.length && isCasualChat(earlyAsk);
  let pageAutoRead = false;
  // Whatever text they've highlighted on the page: "explain this" then means that.
  let selection = '';
  if (tabInfo && !tabInfo.restricted && model.canAttach && !casual && !pdfEdit) selection = (await selectedText(tabInfo.id)).slice(0, 3000);
  if (!page && tabInfo && !tabInfo.restricted && model.canAttach && !casual && !pdfEdit && (settings.prefs.sendPageContext || refersToPage(earlyAsk))) {
    try {
      page = await pageContext(tabInfo.id);
      pageAutoRead = Boolean(page?.text);
    } catch (err) {
      console.warn('[Viora] could not read the current page:', err);
      // Tabs open before install need a refresh; say so instead of guessing.
      if (refersToPage(earlyAsk)) setStatus(err.message || "Viora can't read this page — try reloading it.");
    }
  }
  const hasImages = attachments.some((a) => a.kind === 'image' || a.kind === 'video');

  // Pictures and video frames need a vision model whichever personality is
  // selected: NVIDIA's multimodal models first, Groq's vision model as the
  // fallback if NVIDIA fails.
  const models = hasImages ? nvidiaVisionModels() : chain();
  const turnConfig = hasImages ? visionConfig(settings, VISION_CHAIN) : configForChoice(settings, thread.model);

  // The whole turn — the internet pass, the prompt, the model — runs in the
  // background runner (see lib/chatjob.js), so closing the panel doesn't lose
  // the answer: it is written into this conversation and a notification says
  // it is ready. While the panel stays open the reply streams in as before.
  const lastMessage = thread.messages.at(-1);
  const askText = String(lastMessage?.displayText ?? lastMessage?.content ?? '');
  const deep = thread.model === 'search';
  const onScreen = attachments.some((a) => a.screen);
  const pageOnly = (pageAutoRead || (selection && refersToPage(askText))) && thread.model !== 'search';
  const wantsWeb = Boolean(model.canWeb && !onScreen && !pageOnly && !casual && !pdfEdit);

  // Continuing an edit with no new attachment: the AI needs the current text of the PDF.
  let pdfContext = '';
  if (pdfEdit && !pdfEdit.fresh) {
    try {
      pdfContext = (await inspectPdf(pdfEdit.bytes, { maxChars: 7000 })).text;
    } catch {
      pdfContext = '';
    }
  }

  const recentChats = hasImages ? '' : await recentChatsDigest(thread.id);
  // Notes from older chats that are about what the person is asking now (see memory.js recallEpisodes).
  const recalled = hasImages || settings.prefs.learnChats === false
    ? ''
    : formatRecall(recallEpisodes(await getEpisodes(), askText, { exclude: thread.id }));

  const view = addAssistant();
  let content = '';
  let reasoning = '';

  // Free-tier Groq caps qwen3.8-27b (the vision model) at 1000 output tokens
  // per minute and rejects a request that *expects* more before it runs, so
  // keep image turns modest no matter what the default maxTokens is.
  const effort = hasImages ? '' : pickEffort(thread.model, askText);
  let maxTokens = outputReserve({ hasImages, choice: thread.model, essay: pendingEssayPdf });
  // Thinking tokens count against max_tokens, so a model asked to think hard
  // needs room left over for the actual answer. providers.js still shrinks
  // this live if the shared key's per-minute bucket can't hold it.
  if (effort === 'high') maxTokens = Math.max(maxTokens, 3500);
  else if (effort === 'medium') maxTokens = Math.max(maxTokens, 2600);

  // Everything the runner can't reach itself (the browser tabs, the picture
  // files) is gathered here and handed over as plain data.
  const ctx = {
    choice: thread.model,
    modelKey: hasImages ? 'vision' : thread.model,
    config: turnConfig,
    models,
    temperature: model.temperature,
    maxTokens,
    // Flash is the "quick, chatty" Viora — ask gpt-oss to keep its thinking
    // short so the first word lands sooner. Search/Math keep full reasoning.
    quick: !effort && thread.model === 'flash',
    effort,
    hasImages,
    casual,
    pdfEdit: Boolean(pdfEdit),
    pdfContext,
    askText,
    page: page || null,
    tabInfo: tabInfo || null,
    selection,
    summary: thread.messages.length > (hasImages ? 6 : SUMMARY_KEEP) ? thread.summary || '' : '',
    recentChats,
    recalled,
    history: thread.messages.slice(hasImages ? -6 : -SUMMARY_KEEP).map(({ role, content: c }) => ({ role, content: c })),
    attachments: hasImages
      ? attachments.filter((a) => a.kind === 'image' || a.kind === 'video').map(({ bytes, ...rest }) => rest)
      : [],
    web: wantsWeb
      ? {
          text: resolveFollowUp(askText, thread.messages),
          // Deep Search reads wider than the everyday modes; Flash opens one page, not three.
          budget: hasImages ? WEB_BUDGET_IMAGES : deep ? DEEP_BUDGET : WEB_BUDGET,
          maxDocs: hasImages ? 2 : deep ? DEEP_DOCS : thread.model === 'flash' ? 1 : 3,
          deep: deep && !hasImages
        }
      : null,
    preview: askText.replace(/\s+/g, ' ').trim().slice(0, 90),
    essay: Boolean(pendingEssayPdf),
    noSources: Boolean(casual || pdfEdit)
  };

  // The job writes its answer into the saved conversation, so save it first.
  await persist(askText || attachments[0]?.name || 'Shared a file');

  // While the reply is still arriving: the thinking, then the answer, painted as it grows.
  const paint = (rawContent, rawReasoning) => {
    if (rawReasoning) {
      reasoning = rawReasoning;
      view.setReasoning(reasoning);
    }
    if (rawContent) {
      setStatus('');
      content = rawContent;
      const { think, answer } = splitThink(content);
      if (think) view.setReasoning(reasoning + think);
      // The edit steps are for the panel, not the person: show the sentence, hide the JSON.
      let shown = answer;
      if (pdfEdit && answer.includes('```')) {
        shown = answer.slice(0, answer.indexOf('```')).trimEnd();
        setStatus('Preparing the edit…');
      }
      view.setMarkdown(shown);
    }
    scrollDown();
  };

  let job;
  try {
    job = await runJob('chat', ctx, {
      label: askText.slice(0, 60),
      signal: controller.signal,
      onEvent: (m) => {
        if (m.event === 'delta') paint(m.content, m.reasoning);
        else if (m.event === 'web' && m.sources?.length) view.setSources(m.sources, { live: true });
        else if (m.event === 'progress') {
          if (m.status !== undefined) setStatus(m.status);
          if (m.sources) setStatusSources(m.sources);
        }
      }
    });
  } catch (err) {
    if (hasImages && err.code === 'model_retired') {
      const e = new Error("I couldn't reach a model that can read images right now.");
      e.hint = 'The vision models may be changing — wait a minute and try again.';
      liveCatalogue = null;
      throw e;
    }
    throw err;
  }
  const out = job.out;

  setStatus('');
  const fin = finalizeChat(out, { noSources: casual || Boolean(pdfEdit) });
  let displayAnswer = fin.text;
  const sources = fin.sources;
  const cleaned = fin.plainAnswer;
  let pdfResult = null;
  if (pdfEdit) {
    const plan = parseEditPlan(cleaned);
    if (plan) {
      setStatus('Editing the PDF…');
      pdfResult = await applyPdfPlan(pdfEdit, plan);
      setStatus('');
      displayAnswer = [plan.text || 'Here is what I did:', pdfResult.markdown].join('\n\n');
    }
  }

  view.setMarkdown(displayAnswer);
  if (sources.length && settings.prefs.citations) {
    linkInlineMarkers(view.body, sources);
    view.body.append(sourceStrip(sources));
    view.setSources(sources);
  }
  view.finish();
  if (pdfResult?.bytes) attachEditedPdf(view, pdfResult.bytes, pdfResult.name);

  if (turnMemoryNote) {
    const note = document.createElement('div');
    note.className = 'memory-note';
    note.textContent = turnMemoryNote;
    view.node.append(note);
    turnMemoryNote = '';
  }

  // Carries the job's id so the copy the worker saved is recognised as this one.
  thread.messages.push({
    role: 'assistant',
    content: displayAnswer,
    reasoning: fin.reasoning,
    sources,
    jobId: job.id
  });

  // After the reply is on screen, and never in the way of it.
  if (!pendingEssayPdf && !pdfEdit && !casual) suggestFollowUps(view, askText, displayAnswer);
  maybeSummarize(thread);

  if (pendingEssayPdf) {
    pendingEssayPdf = false;
    if (displayAnswer.trim()) {
      // The on-screen reply shows chips; the file has to carry its own list,
      // so an exported essay still cites whatever the web pass found.
      attachPdfFile(view, withSourceList(displayAnswer, sources));
      // Remember it belongs to this message so a reloaded conversation
      // rebuilds the file chip from the stored markdown.
      const pushed = thread.messages.at(-1);
      if (pushed?.role === 'assistant') pushed.pdf = true;
    }
  }
}

/**
 * Viora Automate's eyes. Screenshots the tab, has the vision model describe it
 * in plain text, and hands that back as the step's result (which lands in the
 * planner's "Done so far"). Chrome can only capture the tab that's in front,
 * so a background tab is brought forward first.
 */
async function lookAtTab(tabId, action) {
  const tab = await chrome.tabs.get(tabId);
  if (isRestrictedUrl(tab.url)) throw new PageAccessError(tab.url);
  if (!tab.active) {
    await chrome.tabs.update(tabId, { active: true });
    await new Promise((r) => setTimeout(r, 300)); // let it paint
  }

  const shot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 70 });
  // Whole viewport, downscaled the same way uploaded images are.
  const image = await readScreenshot(shot, { x: 0, y: 0, width: 100000, height: 100000 }, 1);

  const focus = (action.value || '').trim();
  const ask =
    'You are the eyes of a browser assistant. Describe what is on this screenshot of a web page in plain text: ' +
    'the main sections and their layout, visible text that matters, buttons, fields and their state (filled, empty, disabled, error), ' +
    'images or charts and what they show, popups or banners in the way, and anything that looks loading or broken. ' +
    (focus ? `Pay special attention to: ${focus}. ` : '') +
    'Be specific and concise, under 180 words, no preamble.';

  const { content } = await completeChat({
    config: groqConfig(settings),
    models: await visionModels(),
    messages: [{ role: 'user', content: attachmentsToContent(ask, [image]) }],
    temperature: 0.2,
    // Free-tier Groq caps the vision model's output per minute; stay modest.
    maxTokens: 400,
    timeoutMs: 20000,
    signal: controller?.signal
  });
  const seen = content.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
  if (!seen) return { ok: false, detail: 'The vision model came back empty.' };
  return { ok: true, detail: `Saw: ${seen.slice(0, 900)}` };
}

/* ---------------- Humanizer onboarding: ten question cards ---------------- */

/**
 * The Humanizer rewrites in *the person's* voice, so before first use it asks
 * ten long-form questions (style-questions.js), one card at a time. Until
 * they're all answered the thread and composer are replaced by the cards
 * (body.gated); the header stays, so any other Viora is one tap away.
 * Progress is saved as they go, so closing the panel mid-way loses nothing.
 */
function humanizerReady() {
  const h = settings.humanizer;
  // `onboarded` alone is enough — a skipped run has no style answers at all,
  // a finished one has some, and prompts.js is already fine with an empty list.
  return Boolean(h?.onboarded);
}

const onboarding = {
  open: false,
  step: 0,
  answers: [],
  saveTimer: 0
};

/**
 * saveSettings is read-modify-write, so two overlapping calls can undo each
 * other — a draft save still in flight when Finish lands would flip
 * `onboarded` back to false. Run every onboarding write one after another.
 */
let onboardingSaves = Promise.resolve();
function queueSettingsSave(patch) {
  const run = onboardingSaves.then(() => saveSettings(patch));
  onboardingSaves = run.catch(() => {});
  return run;
}

function syncHumanizerGate() {
  const needed = thread.model === 'humanize' && !humanizerReady();
  if (needed && !onboarding.open) openOnboarding();
  else if (!needed && onboarding.open) closeOnboarding();
}

function openOnboarding({ fresh = false } = {}) {
  const draft = settings.humanizer?.draft;
  // Coming back to a half-finished run, or retaking with the old answers
  // filled in — never a blank start when there's something to keep.
  const saved = fresh ? [] : Array.isArray(draft?.answers) ? draft.answers : [];
  onboarding.answers = STYLE_QUESTIONS.map((_, i) => String(saved[i] || ''));
  onboarding.step = fresh ? 0 : Math.min(Math.max(Number(draft?.step) || 0, 0), STYLE_QUESTIONS.length - 1);
  onboarding.open = true;
  document.body.classList.add('gated');
  el.onboard.hidden = false;
  closeSheets();
  renderOnboarding();
  el.obAnswer.focus();
}

function closeOnboarding() {
  clearTimeout(onboarding.saveTimer);
  onboarding.open = false;
  document.body.classList.remove('gated');
  el.onboard.hidden = true;
}

const obDone = (i) => onboarding.answers[i].trim().length >= STYLE_ANSWER_MIN;

function renderOnboarding() {
  const { step } = onboarding;
  const total = STYLE_QUESTIONS.length;
  const q = STYLE_QUESTIONS[step];

  el.obDots.replaceChildren();
  STYLE_QUESTIONS.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.className = `ob-dot${i === step ? ' now' : obDone(i) && i < step ? ' done' : ''}`;
    dot.setAttribute('role', 'tab');
    dot.setAttribute('aria-selected', String(i === step));
    dot.setAttribute('aria-label', `Question ${i + 1}`);
    // Go back to a finished card; not ahead past one that isn't answered.
    dot.disabled = i > step;
    dot.addEventListener('click', () => goToStep(i));
    el.obDots.append(dot);
  });

  el.obCount.textContent = `Question ${step + 1} of ${total} — ${q.title}`;
  el.obTitle.textContent = q.title;
  el.obPrompt.textContent = q.prompt;
  el.obAnswer.placeholder = q.placeholder;
  el.obAnswer.maxLength = STYLE_ANSWER_MAX;
  el.obAnswer.value = onboarding.answers[step];
  el.obBack.hidden = step === 0;
  el.obNext.textContent = step === total - 1 ? 'Finish' : 'Next';
  updateOnboardingMeta();

  // Re-trigger the little entrance animation for each new card.
  const card = $('#ob-card');
  card.style.animation = 'none';
  void card.offsetWidth;
  card.style.animation = '';
  el.onboard.scrollTop = 0;
}

function updateOnboardingMeta() {
  const len = onboarding.answers[onboarding.step].trim().length;
  const ok = len >= STYLE_ANSWER_MIN;
  el.obNeed.className = `ob-need${ok ? ' ok' : ''}`;
  el.obNeed.textContent = ok ? 'Looks good' : `A few more words — ${STYLE_ANSWER_MIN - len} characters to go`;
  const raw = onboarding.answers[onboarding.step].length;
  el.obChars.textContent = `${raw} / ${STYLE_ANSWER_MAX}`;
  el.obChars.classList.toggle('near', raw > STYLE_ANSWER_MAX * 0.9);
  el.obNext.disabled = !ok;
}

function saveOnboardingDraft() {
  clearTimeout(onboarding.saveTimer);
  onboarding.saveTimer = setTimeout(() => {
    queueSettingsSave({ humanizer: { draft: { step: onboarding.step, answers: [...onboarding.answers] } } });
  }, 400);
}

function goToStep(i) {
  onboarding.step = i;
  saveOnboardingDraft();
  renderOnboarding();
  el.obAnswer.focus();
}

async function finishOnboarding() {
  clearTimeout(onboarding.saveTimer);
  const style = buildStyleProfile(onboarding.answers);
  settings = await queueSettingsSave({ humanizer: { onboarded: true, style, draft: { step: 0, answers: [] } } });
  closeOnboarding();
  el.restyle.hidden = thread.model !== 'humanize';
  setStatus('Got it — I’ll write like you now');
  setTimeout(() => setStatus(''), 2500);
  el.input.focus();
}

/**
 * Skip the cards outright. Whatever's been answered so far (maybe nothing)
 * is kept as a partial style profile, and the gate lifts anyway — the
 * Humanizer still rewrites without a voice to match, it just won't sound as
 * much like the person until they answer some cards later (Settings, or the
 * "Retake" link that appears once they're in).
 */
async function skipOnboarding() {
  clearTimeout(onboarding.saveTimer);
  const style = buildStyleProfile(onboarding.answers);
  settings = await queueSettingsSave({ humanizer: { onboarded: true, style, draft: { step: 0, answers: [] } } });
  closeOnboarding();
  el.restyle.hidden = thread.model !== 'humanize';
  setStatus('Skipped — you can answer these later from Settings');
  setTimeout(() => setStatus(''), 2500);
  el.input.focus();
}

el.obAnswer.addEventListener('input', () => {
  onboarding.answers[onboarding.step] = el.obAnswer.value;
  updateOnboardingMeta();
  saveOnboardingDraft();
});

el.obAnswer.addEventListener('keydown', (e) => {
  // Ctrl/Cmd+Enter moves on, like a send button; plain Enter stays a newline.
  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey) && !el.obNext.disabled) {
    e.preventDefault();
    el.obNext.click();
  }
});

el.obBack.addEventListener('click', () => {
  if (onboarding.step > 0) goToStep(onboarding.step - 1);
});

el.obNext.addEventListener('click', () => {
  if (!obDone(onboarding.step)) return;
  if (onboarding.step < STYLE_QUESTIONS.length - 1) goToStep(onboarding.step + 1);
  else finishOnboarding();
});

el.obSkip.addEventListener('click', () => skipOnboarding());

el.restyle.addEventListener('click', async () => {
  // Retake with the old answers filled in, so a tweak isn't a rewrite.
  const prior = STYLE_QUESTIONS.map((q) => settings.humanizer?.style?.find((s) => s.label === q.label)?.a || '');
  settings = await queueSettingsSave({ humanizer: { onboarded: false, draft: { step: 0, answers: prior } } });
  el.restyle.hidden = true;
  syncHumanizerGate();
});

/**
 * The Humanizer: paste AI-sounding text, get it back sounding human.
 *
 * One rewrite is never enough to lose the statistical fingerprint of machine
 * text, so this runs a loop (see lib/humanizer.js for the signals involved):
 *
 *   1. the model rewrites with the detector-aware prompt
 *   2. polish() deterministically strips what models always leave behind
 *      (stock words, connector openers, em dashes, missing contractions)
 *   3. analyzeText() scores the result locally, for free, in microseconds
 *   4. if it's still too high, the model gets a *specific* critique (which
 *      signals fail, which sentences) and tries again — up to three times
 *   5. ZeroGPT, when it can be reached, has the final say on the best candidate
 *
 * Two different numbers come out of this and they are labelled differently:
 * the "Viora check" is our own estimate of how machine-like the text reads;
 * "ZeroGPT" is the real detector's verdict, shown only when it really ran.
 */
// Sized to the shared key's 8,000-tokens-a-minute bucket. A retry request
// carries the system prompt + style profile (~1.7k tokens), the original
// (~chars/4), the previous draft (~chars/4), the critique (~0.4k) and room
// for the reply (~chars/3). 6,000 characters keeps even that comfortably under
// the limit; much more could never fit, however long it waited.
const HUMANIZE_MAX_CHARS = 6000;

/** How many extra rewrites the checks may ask for before settling for the best one. */
const HUMANIZE_MAX_RETRIES = 3;

/** The key ZeroGPT last refused ("needs a key"), so we stop asking with it — but a new key gets a fresh try. */
let zeroGptRefusedKey = null;

async function runHumanize() {
  const model = current();
  const lastUser = thread.messages.at(-1)?.content || '';
  if (lastUser.length > HUMANIZE_MAX_CHARS) {
    throw new ProviderError('That’s too much text for one go.', {
      hint: 'Paste about 900 words at a time and I’ll do it in pieces.'
    });
  }

  // Only the last few turns: enough for "shorter" or "warmer" to mean the
  // previous rewrite, short enough that the first word appears quickly.
  const recent = thread.messages.slice(-5).map(({ role, content }) => ({ role, content }));
  while (recent.length && recent[0].role !== 'user') recent.shift();

  const messages = [{ role: 'system', content: systemFor(model.prompt, settings.prefs, { settings }) }, ...recent];
  const view = addAssistant();
  setStatus('Rewriting');

  const words = (t) => (t.trim() ? t.trim().split(/\s+/).length : 0);
  const target = Math.min(50, Math.max(0, Number(settings.prefs.zerogptTarget ?? 10)));
  const zeroKey = settings.prefs.zerogptKey || '';
  // ZeroGPT needs a real chunk of text to score; below this it just guesses.
  const zeroOn =
    settings.prefs.zerogptCheck !== false && zeroGptRefusedKey !== zeroKey && words(lastUser) >= 30;

  // The rewrite runs in the background runner, so closing the panel doesn't lose it:
  // the conversation is saved first, and the finished text is written into it.
  await persist(lastUser);
  const job = await runJob('humanize', {
    source: lastUser,
    preview: lastUser.replace(/\s+/g, ' ').slice(0, 90),
    messages,
    zeroOn,
    zeroKey,
    target,
    temperature: model.temperature,
    maxRetries: HUMANIZE_MAX_RETRIES,
    // A rewrite is about as long as the original; leave headroom, not a cap that clips it.
    maxTokens: Math.min(4096, Math.max(600, Math.ceil(lastUser.length / 3)))
  }, {
    label: lastUser.slice(0, 60),
    signal: controller.signal,
    onEvent: (m) => { if (m.event === 'progress' && m.status) setStatus(m.status); }
  });
  const out = job.out;
  if (out.keyRefused) zeroGptRefusedKey = zeroKey; // retrying with this key can't work; a new key gets a fresh try
  const final = out;
  const zeroNote = out.zeroNote;
  const text = final.text;
  const local = final.local;
  const detectorScore = final.detector ? final.detector.percent : null;

  setStatus('');
  view.setMarkdown(text);
  view.finish();

  const bar = document.createElement('div');
  bar.className = 'humanize-bar';
  const count = document.createElement('span');
  const parts = [`${words(lastUser)} → ${words(text)} words`];
  if (local.enough) {
    parts.push(`Viora check: ${local.score}/100 (${riskLabel(local.score)})`);
  }
  if (detectorScore !== null) {
    parts.push(`ZeroGPT: ${Math.round(detectorScore)}% AI${detectorScore > target ? ` (best of ${HUMANIZE_MAX_RETRIES + 1} tries)` : ''}`);
  } else if (zeroNote) {
    parts.push(zeroNote);
  }
  count.textContent = parts.join(' · ');
  count.title =
    'Viora check is our own estimate of how machine-written the text reads (sentence-length variety, stock wording, connectors, dashes, contractions). ' +
    'It is not a real detector. Only a ZeroGPT percentage comes from an actual detector.';
  if (final.lost.length) {
    count.textContent += ` · check these details: ${final.lost.slice(0, 4).join(', ')}`;
  }
  const copy = document.createElement('button');
  copy.type = 'button';
  copy.className = 'copy-btn';
  copy.textContent = 'Copy';
  copy.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(text);
      copy.textContent = 'Copied';
    } catch {
      copy.textContent = 'Couldn’t copy';
    }
    setTimeout(() => { copy.textContent = 'Copy'; }, 1500);
  });
  bar.append(count, copy);
  view.node.append(bar);

  pushJobMessage(messageForJob({ id: job.id, kind: 'humanize' }, out));
}

/**
 * Works a task across as many planning turns as it needs, re-snapshotting the
 * page after each batch so the model always plans against what's on screen now.
 */
/**
 * The "may I?" card for a Linux command or file write. Resolves 'allow', 'always' (stop asking for
 * the rest of this task) or 'deny'. Stopping the run counts as a deny, so nothing runs behind a closed panel.
 */
function confirmLinux(host, { title, body, risks = [] }) {
  return new Promise((resolve) => {
    const box = document.createElement('div');
    box.className = 'shell-ask';
    if (risks.length) box.dataset.risky = 'yes';
    const head = document.createElement('div');
    head.className = 'shell-ask-title';
    head.textContent = title;
    const pre = document.createElement('pre');
    pre.textContent = body.length > 1500 ? `${body.slice(0, 1500)}…` : body;
    const row = document.createElement('div');
    row.className = 'shell-ask-actions';
    const onAbort = () => finish('deny');
    const finish = (verdict) => {
      controller?.signal.removeEventListener('abort', onAbort);
      const note = document.createElement('div');
      note.className = 'shell-ask-done';
      note.textContent = verdict === 'deny' ? 'Skipped. You chose not to run that.' : verdict === 'always' ? 'Allowed. I won’t ask again for this task.' : 'Allowed.';
      box.replaceChildren(note);
      resolve(verdict);
    };
    const button = (label, verdict, cls) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = cls;
      b.textContent = label;
      b.addEventListener('click', () => finish(verdict));
      return b;
    };
    row.append(button('Run it', 'allow', 'primary'), button('Run, and stop asking this task', 'always', ''), button('Don’t run', 'deny', ''));
    box.append(head, pre);
    if (risks.length) {
      const warn = document.createElement('div');
      warn.className = 'shell-ask-warn';
      warn.textContent = `Heads up: this ${risks.join(', ')}.`;
      box.append(warn);
    }
    box.append(row);
    host.append(box);
    controller?.signal.addEventListener('abort', onAbort);
    scrollDown();
  });
}

/** Older command output is trimmed in the log the planner re-reads each turn, so a long session stays inside the model's context. */
function squeezeHistory(history) {
  for (let i = 0; i < history.length - 4; i++) {
    if (history[i].length > 500) history[i] = `${history[i].slice(0, 500)} …[older output trimmed]`;
  }
}

async function runAutomation(prompt) {
  const linux = linuxConfig(settings);
  const linuxOn = linux.enabled;
  const tab = await activeTab();
  if (!linuxOn) {
    if (!tab?.id) throw new ProviderError('No active tab to work with.');
    if (isRestrictedUrl(tab.url)) {
      throw new ProviderError("I can't act on this tab — it's a browser page, not a website.", {
        hint: 'Switch to a normal website tab and ask me again.'
      });
    }
  }
  const turnCap = linuxOn ? LINUX_MAX_TURNS : MAX_TURNS;
  const actionCap = linuxOn ? LINUX_MAX_TOTAL_ACTIONS : MAX_TOTAL_ACTIONS;
  let askFirst = linux.confirm;

  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg assistant';
  el.thread.append(node);
  scrollDown();

  let currentTabId = tab?.id ?? null;
  const history = [];
  let lastThought = '';
  let totalActions = 0;
  let turn = 0;
  let finished = false;
  let failStreak = 0;
  let stopNote = '';
  const reasoningLog = [];

  /** A collapsible "Working it out" box for one planning turn (respects the showReasoning pref). */
  function makeTrace() {
    const root = document.createElement('details');
    root.className = 'reasoning';
    root.hidden = true;
    const summary = document.createElement('summary');
    summary.textContent = turn > 1 ? `Working it out (step ${turn})` : 'Working it out';
    const pre = document.createElement('div');
    pre.className = 'trace';
    root.append(summary, pre);
    return {
      root,
      set(text) {
        if (!settings.prefs.showReasoning || !text) return;
        root.hidden = false;
        pre.textContent = text;
        pre.scrollTop = pre.scrollHeight;
      }
    };
  }

  /**
   * The planner ⇄ reviewer conversation for one turn, shown as a chat: name
   * tag, bubble, and a "…" bubble while the other AI is thinking. `say` can
   * carry the proposed steps as a small muted line under the message so the
   * reviewer's "ref 5 is wrong" is something the person can follow.
   */
  function makeDuo() {
    const root = document.createElement('div');
    root.className = 'duo';
    const lines = [];
    let typingRow = null;
    const clearTyping = () => {
      typingRow?.remove();
      typingRow = null;
    };
    let liveRow = null;
    const clearLive = () => {
      liveRow?.remove();
      liveRow = null;
    };
    // A bubble that fills in word by word while the AI is still writing.
    // `pick(raw)` turns the half-written JSON into the sentence so far.
    const stream = (who, pick) => (raw) => {
      const text = pick(raw);
      if (!text) return;
      if (!liveRow) {
        clearTyping();
        liveRow = document.createElement('div');
        liveRow.className = 'duo-row duo-live';
        liveRow.dataset.who = who;
        const tag = document.createElement('span');
        tag.className = 'duo-who';
        tag.textContent = who === 'planner' ? 'Planner' : 'Reviewer';
        const bubble = document.createElement('div');
        bubble.className = 'duo-text';
        liveRow.append(tag, bubble);
        root.append(liveRow);
      }
      liveRow.querySelector('.duo-text').textContent = text;
      scrollDown();
    };
    const say = (who, text, tone, steps) => {
      clearTyping();
      clearLive();
      const row = document.createElement('div');
      row.className = 'duo-row';
      row.dataset.who = who;
      if (tone) row.dataset.tone = tone;
      const tag = document.createElement('span');
      tag.className = 'duo-who';
      tag.textContent = who === 'planner' ? 'Planner' : 'Reviewer';
      const bubble = document.createElement('div');
      bubble.className = 'duo-text';
      bubble.textContent = text;
      if (steps?.length) {
        const st = document.createElement('div');
        st.className = 'duo-steps';
        st.textContent = steps.map((a, i) => `${i + 1}. ${describeAction(a)}`).join('  ·  ');
        bubble.append(st);
      }
      row.append(tag, bubble);
      root.append(row);
      lines.push(`${tag.textContent}: ${text}${steps?.length ? `\n   ${steps.map((a, i) => `${i + 1}. ${describeAction(a)}`).join('\n   ')}` : ''}`);
      scrollDown();
    };
    const typing = (who) => {
      clearTyping();
      clearLive();
      const row = document.createElement('div');
      row.className = 'duo-row duo-typing';
      row.dataset.who = who;
      const tag = document.createElement('span');
      tag.className = 'duo-who';
      tag.textContent = who === 'planner' ? 'Planner' : 'Reviewer';
      const bubble = document.createElement('div');
      bubble.className = 'duo-text';
      bubble.innerHTML = '<i></i><i></i><i></i>';
      row.append(tag, bubble);
      root.append(row);
      typingRow = row;
      scrollDown();
    };
    const note = (text, cls = 'duo-note') => {
      clearTyping();
      const p = document.createElement('div');
      p.className = cls;
      p.textContent = text;
      root.append(p);
      lines.push(text);
      scrollDown();
    };
    return {
      root,
      say,
      stream,
      typing,
      note,
      agreed: (text = 'Both agree — here is the plan.') => note(text, 'duo-note duo-agreed'),
      transcript: () => lines.join('\n')
    };
  }

  while (!finished && turn < turnCap && totalActions < actionCap) {
    turn++;

    setStatus(linuxOn ? 'Looking at where things stand' : 'Reading the page');
    const noPage = { title: '(no web page is open for Viora to use)', url: '', elements: [], none: true };
    let snap;
    let usable = false;
    if (currentTabId != null) {
      try { usable = !isRestrictedUrl((await chrome.tabs.get(currentTabId))?.url); } catch { usable = false; }
    }
    if (!usable && linuxOn) {
      snap = noPage;
    } else {
      try {
        snap = await snapshot(currentTabId);
      } catch (err) {
        if (!linuxOn) {
          stopNote = err instanceof PageAccessError ? err.message : 'Lost track of the tab.';
          break;
        }
        snap = noPage;
      }
    }
    const elements = snap.elements
      .map((e) => `${e.ref}. <${e.tag}${e.type ? ` ${e.type}` : ''}> ${e.label}`)
      .join('\n');

    const trace = makeTrace();
    node.append(trace.root);
    // Two AIs, one plan: the NVIDIA planner drafts, a Groq reviewer checks it
    // against the same snapshot, and they trade notes until they agree (or the
    // round cap is hit). Nothing touches the page before that.
    const duo = settings.prefs.duoAutomate ? makeDuo() : null;
    if (duo) node.append(duo.root);

    const context = `Overall task: ${prompt}\n\n${
      history.length ? `Done so far:\n${history.join('\n')}\n\n` : ''
    }Current page: ${snap.title}\n${snap.url}\n\n${snap.none ? 'There is no usable web page right now. Use Linux for this, or open_tab to go to a site.' : `Elements:\n${elements}`}`;

    const convo = [
      { role: 'system', content: systemFor('automate', settings.prefs, { settings }) + (linuxOn ? LINUX_NOTE : '') },
      { role: 'user', content: context }
    ];

    // Streamed, not one blocking call: the planner's own reasoning (when it
    // exposes any) shows up live in the "Working it out" box while it plans.
    const draftPlan = async (messages, onLive) => {
      const ask = async (msgs) => {
        let native = '';
        let liveRaw = '';
        const res = await streamChat({
          config: configForChoice(settings, 'automate'),
          models: chain('automate'),
          messages: msgs,
          temperature: getModel('automate').temperature,
          // Headroom for a reasoning model's chain plus the JSON plan — max_tokens
          // counts both, and a plan cut off mid-JSON is a wasted turn.
          maxTokens: linuxOn ? 6000 : 1600,
          // The lead model is a large reasoning model: give it time to start.
          firstTokenMs: 15000,
          signal: controller.signal,
          onModel: noteModel('automate'),
          onRetry: (ms) => setStatus(`Rate limited — waiting ${ms < 1500 ? 'a moment' : `~${Math.ceil(ms / 1000)}s`}`),
          onDelta: (d) => {
            if (d.content && onLive) {
              liveRaw += d.content;
              onLive(liveRaw);
            }
            if (d.reasoning) {
              native += d.reasoning;
              trace.set(native);
              scrollDown();
            }
          }
        });
        return { res, native };
      };

      let { res, native } = await ask(messages);
      let plan;
      try {
        plan = parsePlan(res.content, { linux: linuxOn });
      } catch (firstErr) {
        if (firstErr.name === 'AbortError') throw firstErr;
        // One corrective retry: quote the malformed reply back and ask for
        // clean JSON. Plans usually come back valid on the second pass.
        setStatus('Fixing the plan format');
        const retryMessages = [
          ...messages,
          { role: 'assistant', content: res.content },
          {
            role: 'user',
            content:
              `That reply was not valid JSON (${firstErr.message}). Reply with ONLY the corrected plan as JSON — no prose, no code fences — in exactly this shape:\n` +
              '{"thought":"…","reasoning":"…","actions":[{"type":"click","ref":1,"summary":"…"}]}'
          }
        ];
        const second = await ask(retryMessages);
        res = second.res;
        native = second.native;
        plan = parsePlan(res.content, { linux: linuxOn });
      }
      return { raw: res.content, native: res.reasoning || native, plan };
    };

    const reviewPlan = async (plan, earlier = [], onLive) => {
      let liveRaw = '';
      const { content } = await streamChat({
        config: partnerConfig(settings),
        // The reviewer only says "agree" or "here's what's wrong", so it gets
        // two tries at most and a short leash — a slow reviewer is skipped
        // rather than waited for. Streamed so the person watches it talk.
        models: partnerChain({ overrides: settings.modelOverrides, resolved: settings.resolvedModels }).slice(0, 2),
        messages: [
          { role: 'system', content: REVIEWER_SYSTEM + (linuxOn ? LINUX_REVIEW_NOTE : '') },
          {
            role: 'user',
            content: `${context}\n\n${
              earlier.length ? `Earlier in this chat (your own comments, oldest first):\n${earlier.map((c) => `- ${c}`).join('\n')}\n\n` : ''
            }Proposed plan:\n${JSON.stringify({
              thought: plan.thought,
              reasoning: plan.reasoning,
              actions: plan.actions
            })}`
          }
        ],
        temperature: 0.1,
        maxTokens: 300,
        quick: true,
        firstTokenMs: 5000,
        signal: controller.signal,
        onModel: noteModel('automatePartner'),
        onDelta: (d) => {
          if (d.content && onLive) {
            liveRaw += d.content;
            onLive(liveRaw);
          }
        }
      });
      return parseReview(content);
    };

    let drafted;
    let plan;
    let nativeReasoning = '';
    let settled = true; // did the reviewer sign off on the plan that runs?

    // What the planner "says" in the chat: its one-line intent, then why.
    const plannerSays = (p) => [p.thought, p.reasoning].filter(Boolean).join(' ') || 'Here is my plan.';

    if (!duo) {
      setStatus('Planning');
      drafted = await draftPlan(convo);
      plan = drafted.plan;
      nativeReasoning = drafted.native;
    } else {
      // A real exchange, one message at a time, that the person can read:
      // the planner proposes, the reviewer answers, and if the reviewer
      // objects the planner replies with a fix — up to MAX_ROUNDS reviews.
      // Nothing touches the page until the chat is over.
      const MAX_ROUNDS = 3;
      const heard = [];

      duo.typing('planner');
      setStatus('Planner is drafting');
      drafted = await draftPlan(convo, duo.stream('planner', livePlannerText));
      plan = drafted.plan;
      nativeReasoning = drafted.native;
      duo.say('planner', plannerSays(plan), null, plan.actions);

      for (let round = 1; round <= MAX_ROUNDS; round++) {
        duo.typing('reviewer');
        setStatus('Reviewer is checking');
        let review;
        try {
          review = await reviewPlan(plan, heard, duo.stream('reviewer', liveReviewerText));
        } catch (err) {
          if (err.name === 'AbortError') throw err;
          // A slow or unreachable reviewer never blocks the planner.
          settled = false;
          duo.note("The reviewer didn't answer in time — going with the planner's plan.");
          break;
        }

        if (review.verdict === 'agree') {
          duo.say('reviewer', review.comment || 'Looks right to me.', 'agree');
          duo.agreed();
          break;
        }

        duo.say('reviewer', review.comment || 'I have a doubt about this plan.', 'revise');
        heard.push(review.comment || 'Had a doubt.');
        if (round === MAX_ROUNDS) {
          settled = false;
          duo.note("They couldn't fully agree — running the planner's final call.");
          break;
        }

        duo.typing('planner');
        setStatus('Planner is replying');
        try {
          const revised = await draftPlan([
            ...convo,
            { role: 'assistant', content: drafted.raw },
            {
              role: 'user',
              content:
                `The reviewer replied to your plan: "${review.comment}"\n\n` +
                'Answer them. If they are right, fix the plan and start "thought" with "Fixed:". If you are sure the original is correct, keep it and start "thought" with "Keeping it:", ' +
                'then in "reasoning" say why. Check every ref against the Elements list. JSON only, same format as before.'
            }
          ], duo.stream('planner', livePlannerText));
          drafted = revised;
          plan = revised.plan;
          nativeReasoning = [nativeReasoning, revised.native].filter(Boolean).join('\n\n');
          duo.say('planner', plannerSays(plan), null, plan.actions);
        } catch (err) {
          if (err.name === 'AbortError') throw err;
          settled = false;
          duo.note("Couldn't rework the plan — running the planner's last version.");
          break;
        }
      }
    }

    lastThought = plan.thought || lastThought;

    // Final trace = the planner's native chain (if it has one) + the short
    // "why these steps" it wrote into the plan itself.
    const traceText = [nativeReasoning.trim(), plan.reasoning].filter(Boolean).join('\n\n');
    trace.set(traceText);
    const logged = [traceText, duo?.transcript()].filter(Boolean).join('\n\n');
    if (logged) reasoningLog.push(`Turn ${turn}:\n${logged}`);

    if (plan.thought && !duo) {
      const body = document.createElement('div');
      body.className = 'body';
      body.innerHTML = `<p>${escapeHtml(plan.thought)}</p>`;
      node.append(body);
    }

    if (duo) {
      const banner = document.createElement('div');
      banner.className = 'agreed-banner';
      banner.dataset.settled = settled ? 'yes' : 'no';
      banner.textContent = `${settled ? 'The plan they agreed on' : 'Final plan'} · ${plan.actions.length} step${plan.actions.length === 1 ? '' : 's'}`;
      node.append(banner);
    }
    const list = document.createElement('div');
    list.className = 'plan';
    node.append(list);

    const rows = plan.actions.map((action) => {
      const row = document.createElement('div');
      row.className = 'step';
      row.dataset.state = 'idle';
      const dot = document.createElement('span');
      dot.className = 'dot';
      const label = document.createElement('span');
      label.textContent = describeAction(action);
      const detail = document.createElement('span');
      detail.className = 'detail';
      row.append(dot, label, detail);
      list.append(row);
      // Command output lives in a drawer under its step, closed by default.
      const out = document.createElement('details');
      out.className = 'shell-out';
      out.hidden = true;
      const outSummary = document.createElement('summary');
      outSummary.textContent = 'Output';
      const outPre = document.createElement('pre');
      out.append(outSummary, outPre);
      list.append(out);
      return { row, detail, out, outPre };
    });
    scrollDown();

    // Linux handlers: ask first (unless told to stop asking), run through the bridge, hand back output for the log.
    const linuxHandlers = !linuxOn ? {} : {
      shell: async (action) => {
        if (askFirst) {
          const verdict = await confirmLinux(node, { title: 'Run this command in Linux?', body: action.command, risks: riskOf(action.command) });
          if (verdict === 'deny') return { ok: false, detail: 'You chose not to run it.', output: 'The person declined to run this command. Do not retry it; take another route or say what you need.' };
          if (verdict === 'always') askFirst = false;
        }
        setStatus('Running in Linux');
        try {
          const res = await linuxRun(action.command, linux, { timeout: action.timeout });
          return { ok: res.ok && res.exitCode === 0, ran: res.ok, detail: summarizeRun(res), output: formatRun(res) };
        } catch (err) {
          return { ok: false, detail: `${err.message}${err.hint ? ` ${err.hint}` : ''}`.trim(), output: err.message };
        }
      },
      write_file: async (action) => {
        if (askFirst) {
          const verdict = await confirmLinux(node, { title: 'Write this file in Linux?', body: `${action.path}\n\n${action.content}` });
          if (verdict === 'deny') return { ok: false, detail: 'You chose not to write it.', output: 'The person declined to write this file.' };
          if (verdict === 'always') askFirst = false;
        }
        setStatus('Writing the file');
        try {
          const res = await linuxWrite(action.path, action.content, linux);
          return { ok: res.ok, ran: res.ok, detail: res.ok ? res.message || 'written' : res.error };
        } catch (err) {
          return { ok: false, detail: `${err.message}${err.hint ? ` ${err.hint}` : ''}`.trim() };
        }
      },
      read_file: async (action) => {
        setStatus('Reading the file');
        try {
          const res = await linuxRead(action.path, linux, 12000);
          const text = res.ok ? res.content : '';
          return {
            ok: res.ok,
            ran: res.ok,
            detail: res.ok ? `${text.length} characters` : res.error,
            output: res.ok ? (text.length > 3500 ? `${text.slice(0, 1200)}\n…[${text.length - 3500} characters cut]…\n${text.slice(-2300)}` : text || '(empty file)') : res.error
          };
        } catch (err) {
          return { ok: false, detail: `${err.message}${err.hint ? ` ${err.hint}` : ''}`.trim() };
        }
      }
    };

    setStatus('Running');
    let i = 0;
    const { results, finalTabId } = await runPlan(currentTabId, plan, (step) => {
      const ui = rows[i++];
      if (!ui) return;
      ui.row.dataset.state = step.ok ? 'ok' : 'fail';
      ui.detail.textContent = (step.detail || '').slice(0, 120);
      if (step.output && ui.out) {
        ui.out.hidden = false;
        ui.outPre.textContent = step.output;
      }
      scrollDown();
    }, { look: lookAtTab, ...linuxHandlers });
    setStatus('');

    currentTabId = finalTabId;
    totalActions += plan.actions.length;
    for (const r of results) {
      const line = `- ${describeAction(r.action)}: ${r.ok ? r.detail || 'ok' : `failed — ${r.detail}`}`;
      history.push(r.output ? `${line}\n  ${String(r.output).replace(/\n/g, '\n  ')}` : line);
    }
    squeezeHistory(history);

    // A look ends its batch early, so a "done" queued behind it never ran.
    finished = results.some((r) => r.action.type === 'done');
    // A command that ran and failed is how a coding session normally goes; only steps that never ran count as being stuck.
    failStreak = results.some((r) => r.ok || r.ran) ? 0 : failStreak + 1;
    if (failStreak >= 2) {
      stopNote = "Stopping — the last two batches didn't get anywhere. Try rephrasing, or check the page is what you expect.";
      break;
    }
  }

  if (!finished) {
    if (!stopNote) {
      stopNote = `Paused after ${totalActions} steps across ${turn} turn${turn === 1 ? '' : 's'} — say "continue" and I'll pick it up.`;
    }
    const note = document.createElement('div');
    note.className = 'body';
    note.innerHTML = `<p>${escapeHtml(stopNote)}</p>`;
    node.append(note);
  }

  thread.messages.push({
    role: 'assistant',
    content: `${lastThought}\n\n${history.join('\n')}${finished ? '' : `\n\n${stopNote}`}`,
    reasoning: reasoningLog.join('\n\n')
  });
}

/* ---------------- quiz ("test me on ...") ---------------- */

/** "test me on X", "quiz me on X", "test me about X" — X becomes the topic, verbatim. */
const QUIZ_RE = /^(?:test|quiz)\s+me\s+(?:on|about|in)\s+(.+?)[\s.!?]*$/i;

function detectQuizTopic(text) {
  const m = QUIZ_RE.exec(text.trim());
  return m ? m[1].trim() : null;
}

/**
 * Essay requests come back as a downloadable .pdf instead of only on-screen
 * text. Matches "write me an essay about X", "draft a paper on Y" and friends
 * — phrased as an ask to *produce* the piece, not a question that merely
 * mentions essays ("what's an essay?" must not trigger a file download).
 * Can be turned off in Settings (prefs.essayPdf).
 */
const ESSAY_RE =
  /\b(?:write|create|draft|compose|make|produce|generate|give me|help me (?:write|with))\b[^.!?\n]{0,70}\b(?:essay|paper|composition|report)\b|\b(?:essay|paper)\s+(?:for|about|on|called|titled)\b/i;

/** Set per turn in send(); consumed once by runChat() when the answer lands. */
let pendingEssayPdf = false;

function detectEssayRequest(text) {
  if (settings.prefs.essayPdf === false) return false;
  return ESSAY_RE.test(text);
}

/* ---------------- editing a PDF the person attached ---------------- */

/** PDFs the AI can keep editing in this conversation. In memory only — never saved with the chat. */
const pdfSessions = new Map();
/** Set per turn in send(); consumed once by runChat(). */
let pendingPdfEdit = null;

const PDF_EDIT_VERBS =
  /\b(edit|change|replace|swap|fix|correct|update|modify|rewrite|redact|black(?:ed)?[- ]?out|censor|remove|delete|erase|hide|highlight|mark up|add|insert|put|stamp|watermark|rotate|flip|reorder|rearrange|extract|split|crop|number|renumber|rename|sign)\b/i;
const PDF_EDIT_TOPICS = /\b(pdf|pages?|document|file|text|line|heading|title|name|date|total|price|amount|paragraph|header|footer|word|sentence|typo|watermark|number)\b/i;

/** Which PDF (if any) this message is asking to change. */
function pdfEditSource(text, attachments) {
  const attached = attachments.find((a) => a.kind === 'pdf' && a.bytes);
  if (!PDF_EDIT_VERBS.test(text)) return null;
  if (attached) return { name: attached.name, bytes: attached.bytes, fresh: true };
  const session = pdfSessions.get(thread.id);
  if (session && PDF_EDIT_TOPICS.test(text)) return { ...session, fresh: false };
  return null;
}

function editedPdfName(name) {
  const base = String(name || 'document').replace(/\.pdf$/i, '');
  return `${/-edited$/.test(base) ? base : `${base}-edited`}.pdf`;
}

/** Run the AI's edit steps on the real file; the report becomes the visible answer. */
async function applyPdfPlan(source, plan) {
  try {
    const { bytes, changed, report } = await editPdf(source.bytes, plan.ops);
    const lines = report.map((r) => `- ${r.ok ? '\u2713' : '\u2717'} ${r.text}`).join('\n');
    if (!changed) return { markdown: `${lines}\n\nNothing was changed, so there is no new file.` };
    const name = editedPdfName(source.name);
    pdfSessions.set(thread.id, { name, bytes });
    return { markdown: lines, bytes, name };
  } catch (err) {
    return { markdown: `\u2717 ${err?.message || "I couldn't edit that PDF."}` };
  }
}

/** The edited PDF as a file chip under the reply; one click saves it. */
function attachEditedPdf(view, bytes, name) {
  const blob = new Blob([bytes], { type: 'application/pdf' });
  const chip = document.createElement('button');
  chip.type = 'button';
  chip.className = 'attach-chip file-chip';
  chip.title = `Download ${name}`;
  const ic = document.createElement('span');
  ic.className = 'attach-icon';
  ic.textContent = 'PDF';
  const label = document.createElement('span');
  label.className = 'attach-name';
  label.textContent = name;
  const size = document.createElement('span');
  size.className = 'attach-size';
  const sizeText = `${Math.max(1, Math.round(blob.size / 1024))} KB`;
  size.textContent = sizeText;
  chip.append(ic, label, size);
  chip.addEventListener('click', () => {
    downloadPdfBlob(blob, name);
    chip.classList.add('saved');
    size.textContent = 'Saved \u2713';
    setTimeout(() => {
      chip.classList.remove('saved');
      size.textContent = sizeText;
    }, 2200);
  });
  const tray = document.createElement('div');
  tray.className = 'attach-chips';
  tray.append(chip);
  view.node.append(tray);
  scrollDown();
}

/**
 * Offer the finished answer as an attached .pdf file — a real file chip on
 * the reply (PDF icon + filename), the way an attachment should look. The
 * PDF is built locally (no service, no key) once and kept in memory; one
 * click on the chip saves it. Marking the message with `pdf: true` lets a
 * reloaded conversation rebuild the chip from the stored markdown.
 */
function attachPdfFile(view, markdown) {
  let blob = null;
  try {
    blob = markdownToPdf(markdown);
  } catch {
    /* handled below: the chip still works by rebuilding on click */
  }
  const name = pdfFilename(pdfTitle(markdown));

  const chip = document.createElement('button');
  chip.type = 'button';
  chip.className = 'attach-chip file-chip';
  chip.title = `Download ${name}`;

  const icon = document.createElement('span');
  icon.className = 'attach-icon';
  icon.textContent = 'PDF';

  const label = document.createElement('span');
  label.className = 'attach-name';
  label.textContent = name;

  const size = document.createElement('span');
  size.className = 'attach-size';
  size.textContent = blob ? `${Math.max(1, Math.round(blob.size / 1024))} KB` : 'Save';

  chip.append(icon, label, size);

  chip.addEventListener('click', () => {
    try {
      const file = blob || markdownToPdf(markdown);
      downloadPdfBlob(file, name);
      chip.classList.add('saved');
      size.textContent = 'Saved ✓';
      setTimeout(() => {
        chip.classList.remove('saved');
        size.textContent = file ? `${Math.max(1, Math.round(file.size / 1024))} KB` : 'Save';
      }, 2200);
    } catch {
      size.textContent = 'Failed';
      setTimeout(() => { size.textContent = 'Save'; }, 2200);
    }
  });

  const tray = document.createElement('div');
  tray.className = 'attach-chips';
  tray.append(chip);
  view.node.append(tray);
  scrollDown();
}

/** Ask the math model for one multiple-choice question, strictly as JSON. */
async function fetchQuizQuestion(topic, avoid = []) {
  const avoidLine = avoid.length
    ? `\n\nAlready asked on this topic — write a different question, don't repeat or reword these:\n- ${avoid.join('\n- ')}`
    : '';
  const { content: raw } = await completeChat({
    config: configForChoice(settings, 'math'),
    models: chain('math'),
    messages: [
      { role: 'system', content: systemFor('quiz', settings.prefs, { settings }) },
      { role: 'user', content: `Test me on: ${topic}${avoidLine}` }
    ],
    temperature: 0.6,
    maxTokens: 500,
    quick: true,
    // A stalled quiz question shouldn't hang the round — give up and retry.
    timeoutMs: 20000,
    signal: controller.signal,
    onModel: noteModel('math'),
    onRetry: (ms) => setStatus(`Rate limited — waiting ${ms < 1500 ? 'a moment' : `~${Math.ceil(ms / 1000)}s`}`)
  });
  return parseQuiz(raw);
}

/** Pull the JSON object out of the reply and check its shape before trusting it. */
function parseQuiz(raw) {
  const data = extractJson(String(raw).replace(/<think>[\s\S]*?<\/think>/gi, ''));
  const { question, choices, correctIndex, explanation } = data || {};
  if (
    typeof question !== 'string' || !question.trim() ||
    !Array.isArray(choices) || choices.length < 2 ||
    !choices.every((c) => typeof c === 'string' && c.trim()) ||
    !Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex >= choices.length
  ) {
    throw new ProviderError("That question came back malformed — try again, or rephrase the topic.");
  }
  return { question, choices, correctIndex, explanation: typeof explanation === 'string' ? explanation : '' };
}

function addQuizCard() {
  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg assistant';

  const badge = document.createElement('span');
  badge.className = 'who';
  badge.innerHTML = icon(MODEL_ICON.math);

  const card = document.createElement('div');
  card.className = 'quiz-card';
  card.textContent = 'Putting a question together…';

  node.append(badge, card);
  el.thread.append(node);
  scrollDown();
  return card;
}

/** Render one question into the card as tappable choices, flashcard style. */
function renderQuizQuestion(card, topic, q, asked, score) {
  card.dataset.state = 'unanswered';
  card.replaceChildren();

  const head = document.createElement('div');
  head.className = 'quiz-head';
  const topicEl = document.createElement('span');
  topicEl.className = 'quiz-topic';
  topicEl.textContent = topic;
  const scoreEl = document.createElement('span');
  scoreEl.className = 'quiz-score';
  scoreEl.textContent = `${score.right}/${score.total}`;
  head.append(topicEl, scoreEl);

  const qEl = document.createElement('div');
  qEl.className = 'quiz-question';
  qEl.innerHTML = renderInline(q.question);

  const choicesEl = document.createElement('div');
  choicesEl.className = 'quiz-choices';
  const buttons = q.choices.map((choiceText, i) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'quiz-choice';
    btn.innerHTML = renderInline(choiceText);
    btn.addEventListener('click', () => answer(i));
    choicesEl.append(btn);
    return btn;
  });

  card.append(head, qEl, choicesEl);
  scrollDown();

  function answer(i) {
    if (card.dataset.state !== 'unanswered') return;
    card.dataset.state = 'answered';
    const correct = i === q.correctIndex;
    score.total++;
    if (correct) score.right++;
    scoreEl.textContent = `${score.right}/${score.total}`;

    buttons.forEach((btn, idx) => {
      btn.disabled = true;
      if (idx === q.correctIndex) btn.classList.add('correct');
      else if (idx === i) btn.classList.add('wrong');
    });

    if (q.explanation) {
      const exp = document.createElement('div');
      exp.className = 'quiz-explain';
      exp.innerHTML = renderMarkdown(q.explanation);
      card.append(exp);
    }

    const next = document.createElement('button');
    next.type = 'button';
    next.className = 'quiz-next';
    next.textContent = correct ? 'Nice — next question' : 'Next question';
    next.addEventListener('click', async () => {
      next.disabled = true;
      next.textContent = 'Loading…';
      try {
        const nextQ = await fetchQuizQuestion(topic, asked);
        asked.push(nextQ.question);
        if (asked.length > 12) asked.shift();
        renderQuizQuestion(card, topic, nextQ, asked, score);
      } catch (err) {
        next.disabled = false;
        next.textContent = 'Try again';
        setStatus(err.message || "Couldn't get the next question.");
      }
    });
    card.append(next);
    scrollDown();
  }
}

async function runQuiz(topic) {
  const card = addQuizCard();
  const score = { right: 0, total: 0 };
  const asked = [];
  let q;
  try {
    q = await fetchQuizQuestion(topic, asked);
  } catch (err) {
    card.closest('.msg')?.remove();
    throw err;
  }
  asked.push(q.question);
  renderQuizQuestion(card, topic, q, asked, score);

  thread.messages.push({
    role: 'assistant',
    content: `Quiz on **${topic}** — tap an answer above to keep going.`
  });
}

/* ---------------- send ---------------- */

const IMAGE_ACTIONS = [
  ['Explain', 'Explain what this shows and what matters in it.'],
  ['Extract text', 'Transcribe all the text in this picture exactly as written, keeping its structure (headings, lists, tables).'],
  ['Solve it', 'Solve or answer whatever this asks, step by step, and give the final answer clearly.'],
  ['Fix the error', 'This shows an error or a problem. Tell me exactly what is wrong, why it happens, and the steps to fix it.'],
  ['Translate', 'Translate all the text in this picture into English, keeping the layout.']
];

function renderTray() {
  el.attachTray.replaceChildren();
  el.attachTray.hidden = pendingAttachments.length === 0;
  pendingAttachments.forEach((a) => {
    el.attachTray.append(attachmentChip(a, true));
  });

  // One tap turns a fresh screenshot into a good question.
  if (pendingAttachments.some((a) => a.kind === 'image')) {
    const row = document.createElement('div');
    row.className = 'shot-actions';
    for (const [label, ask] of IMAGE_ACTIONS) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'shot-action';
      b.textContent = label;
      b.addEventListener('click', () => {
        if (busy) return;
        el.input.value = el.input.value.trim() ? `${el.input.value.trim()}\n${ask}` : ask;
        el.form.requestSubmit();
      });
      row.append(b);
    }
    el.attachTray.append(row);
  }
}

// Delegated for the same reason as the drawer's delete button: renderTray()
// rebuilds every chip from scratch, so the container is the only listener
// target guaranteed to stick around.
el.attachTray.addEventListener('click', (e) => {
  const x = e.target.closest('.attach-remove');
  if (!x) return;
  const chip = x.closest('.attach-chip');
  const i = [...el.attachTray.children].indexOf(chip);
  if (i < 0) return;
  pendingAttachments.splice(i, 1);
  renderTray();
});

/** Trim what a saved attachment carries — images keep their data URL, the rest just a name. */
function attachmentMeta(a) {
  return a.kind === 'image' || a.kind === 'video'
    ? { kind: a.kind, name: a.name, dataUrl: a.dataUrl }
    : { kind: a.kind, name: a.name };
}

let pendingTurnAttachments = [];

/* ---------------- instant answers: tools and memory questions ---------------- */

const rateCache = new Map();

/** Live exchange rate, two free no-key sources, cached for half an hour. Never guessed. */
async function getRate(from, to) {
  const key = `${from}>${to}`;
  const hit = rateCache.get(key);
  if (hit && Date.now() - hit.at < 30 * 60 * 1000) return hit.value;
  setStatus('Checking the exchange rate…');
  const get = async (url, pick) => {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 8000);
    try {
      const res = await fetch(url, { signal: ctl.signal });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return pick(await res.json());
    } finally {
      clearTimeout(timer);
    }
  };
  let value;
  try {
    value = await get(`https://api.frankfurter.app/latest?from=${from}&to=${to}`, (j) => ({ rate: j?.rates?.[to], date: j?.date, source: 'European Central Bank via frankfurter.app' }));
    if (!(value.rate > 0)) throw new Error('no rate');
  } catch {
    value = await get(`https://open.er-api.com/v6/latest/${from}`, (j) => ({ rate: j?.rates?.[to], date: String(j?.time_last_update_utc || '').slice(5, 16), source: 'open.er-api.com' }));
  } finally {
    setStatus('');
  }
  if (!(value.rate > 0)) throw new Error('no rate');
  rateCache.set(key, { at: Date.now(), value });
  return value;
}

/** A reply that needs no model: a memory question, or one of the built-in tools. Null → ask the AI as usual. */
async function localAnswer(text) {
  const q = detectMemoryQuery(text);
  if (q === 'show') return describeMemory(settings.memory, await getEpisodes());
  if (q === 'clear') {
    const n = (settings.memory || []).length;
    return n
      ? `That would erase all ${n} thing${n === 1 ? '' : 's'} I have saved about you. Say **forget everything, yes** to confirm.`
      : "I don't have anything saved about you, so there's nothing to clear.";
  }
  if (q === 'clear-confirmed') {
    settings = await saveSettings({ memory: [] });
    await setEpisodes([]);
    return 'Done. I no longer have anything saved about you. You can start fresh any time by telling me about yourself.';
  }
  if (settings.prefs.tools === false) return null;
  const hit = await runTools(text, { now: new Date(), getRate });
  return hit ? hit.markdown : null;
}

async function answerLocally(text, markdown) {
  document.querySelectorAll('.followups').forEach((n) => n.remove());
  addUser(text);
  thread.messages.push({ role: 'user', content: text, displayText: text, attachments: [] });
  el.input.value = '';
  autosize();
  const view = addAssistant();
  view.setMarkdown(markdown);
  view.finish();
  thread.messages.push({ role: 'assistant', content: markdown, reasoning: '', local: true });
  await persist(text);
}

/* ---------------- learning about the person, visibly ---------------- */

/** Under the reply: what was just remembered, with Undo. Nothing is ever learned silently. */
function showRemembered(added, before) {
  const bubble = [...el.thread.querySelectorAll('.msg.assistant')].at(-1);
  if (!bubble) return;
  const note = document.createElement('div');
  note.className = 'memory-note';
  const label = document.createElement('span');
  label.textContent = `Remembered: ${added.join(' · ')}`;
  const undo = document.createElement('button');
  undo.type = 'button';
  undo.textContent = 'Undo';
  undo.addEventListener('click', async () => {
    settings = await saveSettings({ memory: before });
    note.remove();
  });
  const close = document.createElement('button');
  close.type = 'button';
  close.textContent = '×';
  close.setAttribute('aria-label', 'Dismiss');
  close.addEventListener('click', () => note.remove());
  note.append(label, undo, close);
  bubble.append(note);
}

/** After a normal reply: if the person said something lasting about themselves, keep it. Fire and forget. */
async function learnFromTurn(text) {
  if (settings.prefs.learnMemory === false || !looksPersonal(text)) return;
  try {
    const { content } = await completeChat({
      config: configForChoice(settings, 'flash'),
      models: chain('flash'),
      messages: [
        { role: 'system', content: LEARN_PROMPT },
        { role: 'user', content: String(text).slice(0, 1200) }
      ],
      temperature: 0,
      maxTokens: 300,
      effort: 'low',
      timeoutMs: 12000
    });
    const facts = parseFacts(content);
    if (!facts.length) return;
    const before = Array.isArray(settings.memory) ? [...settings.memory] : [];
    const { memory, added } = mergeMemory(before, facts);
    if (!added.length) return;
    settings = await saveSettings({ memory });
    showRemembered(added, before);
  } catch (err) {
    console.warn('[Viora] could not learn from that message:', err?.message || err);
  }
}

async function send(prompt, attachments = []) {
  const text = prompt.trim();
  if (busy || localBusy || (!text && !attachments.length)) return;

  // "What's on my screen?" — look first, then answer with the picture and the page text.
  if (
    text && current().canAttach && !attachments.some((a) => a.kind === 'image' || a.kind === 'video') &&
    attachments.length < LIMITS.maxFiles && wantsScreen(text)
  ) {
    try {
      setStatus('Looking at your screen…');
      const { tab, shot } = await captureScreen();
      attachments = [...attachments, shot];
      if (!selectedPage) {
        selectedPage = { id: tab.id, title: tab.title, url: tab.url, favIconUrl: tab.favIconUrl };
        turnPageIsTemporary = true;
        renderPageChip();
      }
      setStatus('');
    } catch (err) {
      // No tab to look at (or a browser page): answer anyway, but say why there was no look.
      setStatus(err.message || '');
    }
  }

  // A PDF in this turn stays editable for follow-ups ("now also change the date").
  for (const a of attachments) if (a.kind === 'pdf' && a.bytes) pdfSessions.set(thread.id, { name: a.name, bytes: a.bytes });
  const pdfEdit = ['flash', 'math', 'search'].includes(thread.model) ? pdfEditSource(text, attachments) : null;
  pendingPdfEdit = pdfEdit;

  if (!forcedMode && !pdfEdit && ['flash', 'math', 'search'].includes(thread.model)) {
    const route = autoRoute(text, thread.model);
    if (route !== thread.model) setModel(route);
  }

  // The Humanizer can't rewrite in a voice it hasn't met. If something got
  // past the hidden composer (a right-click "Humanize", say), keep the text
  // for after the cards instead of dropping it.
  if (thread.model === 'humanize' && !humanizerReady()) {
    el.input.value = prompt;
    syncHumanizerGate();
    return;
  }

  const wantsImage = !attachments.length && current().canAttach &&
    (imageMode ? text.length > 0 : !!detectImageRequest(text));
  const reportRequest =
    !wantsImage && !pdfEdit && !attachments.length && ['flash', 'math', 'search'].includes(thread.model)
      ? detectReportRequest(text)
      : null;
  // Deep Search, picked on purpose from the "+" menu, researches every ask in full —
  // plan, many sources, verification, a report. A short follow-up to a finished
  // report, or a message starting "quick:", takes the fast path instead.
  const deepTopic =
    !reportRequest && !wantsImage && !pdfEdit && !attachments.length && thread.model === 'search' && forcedMode === 'search' &&
    text.length >= 6 && !isQuickFollowUp(text)
      ? researchTopicFrom(text)
      : null;
  const reportTopic = reportRequest || deepTopic;
  stopSpeaking();

  // Maths, units, currency, time and date, and "what do you remember about me" —
  // answered on the spot, exactly, in every chat mode, with no model call.
  if (text && !wantsImage && !pdfEdit && !attachments.length && !imageMode && !['humanize', 'automate'].includes(thread.model)) {
    localBusy = true;
    try {
      const local = await localAnswer(text);
      if (local) {
        await answerLocally(text, local);
        return;
      }
    } catch (err) {
      console.warn('[Viora] local answer failed, asking the AI instead:', err?.message || err);
    } finally {
      localBusy = false;
      setStatus('');
    }
  }
  const wasImageMode = imageMode;
  const quizTopic = !wantsImage && !reportTopic && !pdfEdit && !attachments.length ? detectQuizTopic(text) : null;

  // Essays become a file (see detectEssayRequest); chat modes only — the
  // Humanizer must return bare text and Automate must return its JSON plan.
  pendingEssayPdf = !wantsImage && !reportTopic && !quizTopic &&
    thread.model !== 'humanize' && thread.model !== 'automate' &&
    !attachments.length && detectEssayRequest(text);

  document.querySelectorAll('.followups').forEach((n) => n.remove());
  if (settings.prefs.autoMemory && ['flash', 'math', 'search'].includes(thread.model) && !attachments.length) {
    const cmd = detectMemoryCommand(text);
    if (cmd) await applyMemoryCommand(cmd);
  }

  pendingTurnAttachments = attachments;
  const folded = attachmentsToText(attachments);
  const hasPicture = attachments.some((a) => a.kind === 'image' || a.kind === 'video');
  const fullText = [text, folded].filter(Boolean).join('\n\n') ||
    (hasPicture
      ? 'Look closely at this and tell me what it shows. Then give me what I most likely need from it: the cause and fix if it is an error, the answer if it is a question or problem, the key points if it is text.'
      : 'Tell me about the attached file.');

  addUser(text, attachments);
  thread.messages.push({
    role: 'user',
    content: fullText,
    displayText: text,
    attachments: attachments.map(attachmentMeta)
  });
  el.input.value = '';
  autosize();

  controller = new AbortController();
  setBusy(true);

  try {
    if (wantsImage) {
      setImageMode(false);
      await runImage(text);
    }
    else if (reportTopic) {
      if (!forcedMode && thread.model !== 'search') setModel('search');
      reportSeeds = extractUrls(text);
      await planReport(reportTopic);
    } else if (quizTopic) await runQuiz(quizTopic);
    else if (thread.model === 'automate') await runAutomation(prompt);
    else if (thread.model === 'humanize') await runHumanize();
    else {
      await runChat();
      if (!attachments.length && !detectMemoryCommand(text)) learnFromTurn(text);
    }
    await persist(text || attachments[0]?.name || 'Shared a file');
  } catch (err) {
    // A turn that failed before saying anything leaves an empty bubble behind — clear it.
    const dead = document.querySelector('.msg.assistant.streaming');
    if (dead && !dead.querySelector('.body')?.textContent.trim()) dead.remove();
    else dead?.classList.remove('streaming');
    setStatus('');

    // "Try again" must not stack a second copy of the same question: take the
    // failed turn's user message back out (thread + screen) before re-sending.
    const retryTurn = () => {
      document.querySelectorAll('.msg.assistant .error').forEach((n) => n.closest('.msg')?.remove());
      if (thread.messages.at(-1)?.role === 'user') thread.messages.pop();
      [...el.thread.querySelectorAll('.msg.user')].at(-1)?.remove();
      if (wasImageMode) setImageMode(true);
      send(prompt, attachments);
    };

    if (err.name === 'AbortError') {
      setStatus('Stopped');
    } else if (err.code === 'model_retired') {
      addError(err, null, modelPicker(thread.model, retryTurn));
    } else {
      if (err.detail) console.warn('[Viora] provider said:', err.detail);
      addError(err, retryTurn);
    }
  } finally {
    setBusy(false);
    controller = null;
    if (turnPageIsTemporary) {
      turnPageIsTemporary = false;
      selectedPage = null;
      renderPageChip();
    }
  }
}

/* ---------------- events ---------------- */

el.form.addEventListener('submit', (e) => {
  e.preventDefault();
  if (busy) {
    controller?.abort();
    return;
  }
  const attachments = pendingAttachments;
  pendingAttachments = [];
  renderTray();
  send(el.input.value, attachments);
});

el.attach.addEventListener('click', () => {
  const open = el.attachSheet.hidden;
  closeSheets();
  el.attachSheet.hidden = !open;
  setAttachOpen(open);
  if (open) renderTabList();
});

el.attachUpload.addEventListener('click', () => {
  closeSheets();
  el.fileInput.click();
});

$('#mode-humanize').addEventListener('click', () => enterMode('humanize'));
$('#mode-search').addEventListener('click', () => enterMode('search'));
$('#mode-automate').addEventListener('click', () => enterMode('automate'));
el.modeChipRemove.addEventListener('click', leaveMode);

el.attachScreen.addEventListener('click', async () => {
  closeSheets();
  if (pendingAttachments.length >= LIMITS.maxFiles) {
    setStatus(`I can take up to ${LIMITS.maxFiles} files at a time.`);
    return;
  }
  setStatus('Looking at your screen…');
  try {
    const { tab, shot } = await captureScreen();
    pendingAttachments.push(shot);
    renderTray();
    pickPage(tab);
    setStatus('');
  } catch (err) {
    setStatus(err.message || "Couldn't look at the screen — try again.");
  }
});

el.attachImage.addEventListener('click', () => {
  closeSheets();
  setImageMode(true);
  el.input.focus();
});

el.imageChipRemove.addEventListener('click', () => {
  setImageMode(false);
  el.input.focus();
});

el.attachScreenshot.addEventListener('click', async () => {
  closeSheets();

  const tab = await activeTab();
  if (!tab?.id) {
    setStatus("Can't find the tab to screenshot.");
    return;
  }
  if (isRestrictedUrl(tab.url)) {
    setStatus("Viora can't screenshot a browser or extension page — switch to a regular website tab.");
    return;
  }
  if (pendingAttachments.length >= LIMITS.maxFiles) {
    setStatus(`I can take up to ${LIMITS.maxFiles} files at a time.`);
    return;
  }

  // Freeze first: capture the tab as it is right now, hand that picture to
  // the page to lay over itself, and crop from the same picture afterwards —
  // so what is selected is exactly what was on screen, even if the page is
  // playing a video or updating a ticker underneath.
  setStatus('Freezing the page…');
  let frozenUrl;
  try {
    frozenUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
  } catch (err) {
    console.warn('[Viora] could not capture the tab:', err);
    setStatus("Couldn't capture this page — try again.");
    return;
  }

  setStatus('Page frozen — drag to select an area…');
  let selection;
  try {
    selection = await screenshotSelect(tab.id, frozenUrl);
  } catch (err) {
    setStatus(err.message || "Couldn't start the screenshot tool on this page.");
    return;
  }
  if (!selection?.ok) {
    setStatus('');
    return; // cancelled — Esc, or too small a drag
  }

  try {
    const result = await readScreenshot(frozenUrl, selection.rect, selection.view || selection.dpr);
    result.source = pageSource(tab);
    pendingAttachments.push(result);
    renderTray();
    setStatus('');
    el.input.focus();
  } catch (err) {
    console.warn('[Viora] screenshot crop failed:', err);
    setStatus("Couldn't capture that screenshot — try again.");
  }
});

el.pageChipRemove.addEventListener('click', () => {
  selectedPage = null;
  renderPageChip();
});

el.fileInput.addEventListener('change', async () => {
  const files = [...el.fileInput.files];
  el.fileInput.value = '';

  for (const file of files) {
    if (pendingAttachments.length >= LIMITS.maxFiles) {
      setStatus(`I can take up to ${LIMITS.maxFiles} files at a time.`);
      break;
    }
    try {
      if (kindOf(file) === 'video') setStatus('Looking through the video…');
      const result = await readFile(file);
      if (kindOf(file) === 'video') setStatus('');
      pendingAttachments.push(result);
      if (result.warning) setStatus(result.warning);
    } catch (err) {
      setStatus(err.message);
    }
  }
  renderTray();
});

el.input.addEventListener('input', autosize);

el.input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    el.form.requestSubmit();
  }
});


$('#new-thread').addEventListener('click', () => {
  if (thread.messages.length) askToLearn(thread.id, true);
  stopSpeaking();
  controller?.abort();
  forcedMode = null;
  thread = newThread('flash');
  el.thread.replaceChildren(el.welcome);
  setModel('flash');
  renderModeChip();
  closeSheets();
  el.input.focus();
});

$('#history').addEventListener('click', (e) => {
  const open = el.drawer.hidden;
  closeSheets();
  el.drawer.hidden = !open;
  e.currentTarget.setAttribute('aria-expanded', String(open));
  if (open) {
    refreshDrawer();
    el.threadSearch.focus();
  }
});

/**
 * The gear opens Viora's settings page. The tiny Viora mark next to it opens
 * the panel itself in a normal browser tab — same chat, history, voice and
 * settings, except screenshots and Automation can't run there because both
 * need a *different* tab to act on, and a chrome-extension:// page can't be
 * scripted or captured by Chrome at all.
 */
$('#open-settings').addEventListener('click', () => chrome.runtime.openOptionsPage());

$('#open-viora').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('src/sidepanel/index.html') });
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeSheets();
});

document.addEventListener('click', (e) => {
  if (el.modelSheet.hidden && el.drawer.hidden && el.attachSheet.hidden) return;
  if (e.target.closest('#model-sheet, #drawer, #attach-sheet, #model-btn, #history, #attach')) return;
  closeSheets();
});

chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area === 'local' && changes.threads) syncJobMessages();
  if (area === 'local' && changes.openThread?.newValue) openRequestedThread();
  if (area === 'local' && changes.lastLearned?.newValue) showLearnedFromChats();
  if (area === 'local' && changes.settings) {
    settings = await getSettings();
    config = groqConfig(settings);
    // Settings can reset or clear the style profile while the panel is open.
    el.restyle.hidden = thread.model !== 'humanize' || !humanizerReady();
    syncHumanizerGate();
  }
});

/* ---------------- voice input ---------------- */

// Tap the mic and the message box turns into a recording bar: the "+" on the
// left, a live waveform that moves with your voice, a square that stops and
// puts the words in the box so you can edit them, and a blue arrow that stops
// and sends them straight away. Esc throws the recording away.
//
// Viora transcribes speech with Groq's whisper-large-v3. It uses its own key
// (GROQ_STT_KEY), so the shared chat key's budget stays untouched; a personal
// key from settings still wins for both. The mic records locally
// (MediaRecorder) and the audio is transcribed once you stop. If the
// microphone can't be captured it falls back to Chrome's built-in recognizer,
// and if neither exists the mic button stays hidden.
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

const canCapture =
  typeof MediaRecorder !== 'undefined' &&
  Boolean(navigator.mediaDevices?.getUserMedia);

if (!canCapture && !SpeechRecognition) {
  el.mic.hidden = true;
} else {
  /** 'idle' | 'requesting' | 'capturing' | 'transcribing' */
  let state = 'idle';
  let audioStream = null; // live mic, released as soon as recording stops
  let recorder = null;    // active MediaRecorder, if any
  let recognizer = null;  // active Chrome recognizer, if any
  /** What happens to the words when recording stops: 'edit' (into the box), 'send', or 'cancel'. */
  let after = 'edit';

  const dict = {
    bar: $('#dictation'),
    slot: $('#dict-slot'),
    canvas: $('#dict-wave'),
    stop: $('#dict-stop'),
    send: $('#dict-send'),
    inner: el.form.querySelector('.composer-inner')
  };
  // The "+" menu keeps working while you record: its button moves into the bar and back.
  const attachWrap = el.attach.closest('.attach-wrap');
  const attachHome = attachWrap.parentElement;

  const setMicState = (next) => {
    state = next;
    el.mic.classList.toggle('recording', next === 'capturing');
    el.mic.disabled = next === 'requesting' || next === 'transcribing';
    el.mic.setAttribute(
      'aria-label',
      next === 'capturing' ? 'Stop listening'
        : next === 'requesting' ? 'Starting mic'
        : next === 'transcribing' ? 'Transcribing'
        : 'Voice input'
    );
  };

  const releaseMic = () => {
    audioStream?.getTracks().forEach((t) => t.stop());
    audioStream = null;
  };

  const withTimeout = (promise, ms) =>
    Promise.race([
      promise,
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), ms))
    ]);

  /* -------- the recording bar and its waveform -------- */

  let wave = null; // { raf, actx }

  /**
   * Bars grow out from the middle: each new loudness reading appears at the
   * centre and is pushed outward as time passes, so the bar is tallest where
   * you are speaking now and fades to dots at both ends. With no audio to
   * read (Chrome's recognizer) it ripples gently instead.
   */
  function startWave(stream) {
    stopWave();
    const canvas = dict.canvas;
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth || 200;
    const h = canvas.clientHeight || 32;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    const g = canvas.getContext('2d');
    g.scale(dpr, dpr);
    const color = getComputedStyle(canvas).color;

    let actx = null;
    let analyser = null;
    let data = null;
    if (stream) {
      try {
        const AC = window.AudioContext || window.webkitAudioContext;
        actx = new AC();
        const source = actx.createMediaStreamSource(stream);
        analyser = actx.createAnalyser();
        analyser.fftSize = 512;
        source.connect(analyser);
        data = new Uint8Array(analyser.fftSize);
      } catch {
        analyser = null;
      }
    }

    const STEP = 6;
    const BAR = 3;
    const half = Math.max(8, Math.floor(w / STEP / 2));
    const levels = new Array(half).fill(0); // levels[0] is the newest, drawn in the middle
    let smooth = 0;
    let lastPush = 0;

    const draw = () => {
      g.clearRect(0, 0, w, h);
      g.fillStyle = color;
      const cx = w / 2;
      for (let i = 0; i < half; i++) {
        const f = i / half; // 0 in the middle, 1 at the ends
        const taper = 1 - Math.pow(f, 1.7);
        const height = Math.max(BAR, 2 + levels[i] * (h - 4) * taper);
        g.globalAlpha = 0.3 + 0.7 * (1 - f);
        for (const x of i === 0 ? [cx] : [cx - i * STEP, cx + i * STEP]) {
          g.beginPath();
          g.roundRect(x - BAR / 2, (h - height) / 2, BAR, height, BAR / 2);
          g.fill();
        }
      }
      g.globalAlpha = 1;
    };

    const frame = (now) => {
      if (analyser && now - lastPush > 55) {
        analyser.getByteTimeDomainData(data);
        let sum = 0;
        for (const v of data) { const x = (v - 128) / 128; sum += x * x; }
        const level = Math.min(1, Math.sqrt(sum / data.length) * 5); // a quiet room is ~0, speech 0.3–1
        smooth = level > smooth ? level : smooth * 0.65 + level * 0.35;
        levels.unshift(smooth);
        levels.pop();
        lastPush = now;
      } else if (!analyser && now - lastPush > 90) {
        levels.unshift(0.14 + 0.1 * Math.sin(now / 260));
        levels.pop();
        lastPush = now;
      }
      draw();
      wave.raf = requestAnimationFrame(frame);
    };
    wave = { raf: 0, actx, canvas, draw: () => { levels.fill(0); draw(); } };
    wave.raf = requestAnimationFrame(frame);
  }

  /** Stop moving; leave a flat row of dots (the bar stays up while the words are transcribed). */
  function stopWave() {
    if (!wave) return;
    cancelAnimationFrame(wave.raf);
    wave.actx?.close().catch(() => {});
    wave.draw();
    wave = null;
  }

  function showBar(on) {
    closeSheets();
    dict.inner.classList.toggle('dictating', on);
    dict.bar.hidden = !on;
    dict.bar.classList.remove('working');
    if (on) dict.slot.append(attachWrap);
    else attachHome.prepend(attachWrap);
  }

  /** Stop recording; what happens to the words depends on which button it was. */
  function finishDictation(mode) {
    if (state !== 'capturing') return;
    after = mode;
    recorder?.stop();
    recognizer?.stop();
  }

  /** The words are in the box — send them, unless an answer is still being worked on. */
  function sendDictation() {
    if (!el.input.value.trim()) return;
    if (busy) {
      setStatus('Viora is still answering — your words are in the box.');
      return;
    }
    el.form.requestSubmit();
  }

  /**
   * Make sure the extension may use the mic. Chrome won't show the permission
   * prompt inside a docked side panel (a known limitation), so when permission
   * isn't already granted this opens the mic-permission page in a small popup
   * window where the prompt CAN be shown. A "blocked" state opens the site
   * settings so the user can flip it to Allow. Returns false when the user
   * shouldn't proceed (and has been told why in the status line).
   */
  async function ensureMicPermission() {
    try {
      const status = await navigator.permissions.query({ name: 'microphone' });
      if (status.state === 'granted') return true;
      if (status.state === 'denied') {
        chrome.tabs.create({
          url: `chrome://settings/content/siteDetails?site=chrome-extension%3A%2F%2F${chrome.runtime.id}%2F`
        });
        setStatus('Microphone is blocked — set it to Allow in the settings tab that opened, then tap the mic again.');
        return false;
      }
    } catch {
      // Permission query unsupported — fall through to a direct request.
    }

    // Try a direct request first; Chrome may show the prompt here normally.
    let direct = null;
    try {
      direct = navigator.mediaDevices.getUserMedia({ audio: true });
      const stream = await withTimeout(direct, 4000);
      direct = null;
      stream.getTracks().forEach((t) => t.stop());
      return true;
    } catch {
      direct?.then((s) => s.getTracks().forEach((t) => t.stop())).catch(() => {});
      /* expected — side panels suppress the prompt */
    }

    // Open the permission bridge in a popup window and wait for it to close.
    setStatus('Allow the microphone in the popup that just opened.');
    try {
      const win = await chrome.windows.create({
        url: chrome.runtime.getURL('src/mic/mic-permission.html'),
        type: 'popup',
        width: 440,
        height: 340,
        focused: true
      });
      if (!win?.id) return false;
      await new Promise((resolve) => {
        const onClose = (windowId) => {
          if (windowId !== win.id) return;
          chrome.windows.onRemoved.removeListener(onClose);
          setTimeout(resolve, 350);
        };
        chrome.windows.onRemoved.addListener(onClose);
      });
      return true;
    } catch {
      return false;
    }
  }

  /** Record until stopped, then POST the audio to Groq's whisper model. */
  async function transcribeWithWhisper() {
    setMicState('requesting');
    setStatus('Requesting microphone…');

    if (!(await ensureMicPermission())) {
      if (!el.status.textContent) setStatus("Couldn't get microphone access — try again.");
      setMicState('idle');
      return;
    }

    let stream;
    let pending = null;
    try {
      pending = navigator.mediaDevices.getUserMedia({ audio: true });
      stream = await withTimeout(pending, 6000);
      pending = null;
    } catch {
      // The prompt was denied or never answered. If a stream now shows up
      // late, drop it so the mic light doesn't stay on. Fall back to Chrome's
      // recognizer when there is one, else say what happened.
      pending?.then((s) => s.getTracks().forEach((t) => t.stop())).catch(() => {});
      if (SpeechRecognition) { captureLocally(); return; }
      setMicState('idle');
      setStatus('Microphone access was blocked.');
      return;
    }
    audioStream = stream;

    let rec;
    try {
      rec = new MediaRecorder(stream);
    } catch {
      releaseMic();
      if (SpeechRecognition) { captureLocally(); return; }
      setMicState('idle');
      setStatus('Audio recording is not supported here.');
      return;
    }
    recorder = rec;

    const chunks = [];
    rec.addEventListener('dataavailable', (e) => {
      if (e.data.size) chunks.push(e.data);
    });

    after = 'edit';
    setMicState('capturing');
    setStatus('');
    showBar(true);
    startWave(stream);
    rec.start();

    await new Promise((resolve) => {
      rec.addEventListener('stop', resolve, { once: true });
      rec.addEventListener('error', resolve, { once: true });
    });
    releaseMic();
    recorder = null;
    stopWave();

    if (after === 'cancel' || !chunks.length) {
      showBar(false);
      setMicState('idle');
      setStatus('');
      el.input.focus();
      return;
    }

    setMicState('transcribing');
    dict.bar.classList.add('working');
    setStatus('Transcribing');
    let text = '';
    try {
      const blob = new Blob(chunks, { type: rec.mimeType || 'audio/webm' });
      text = await transcribeAudio({ config, blob });
    } catch (err) {
      showBar(false);
      setMicState('idle');
      setStatus(err.hint || 'Transcription failed — try again.');
      el.input.focus();
      return;
    }

    showBar(false);
    setMicState('idle');
    if (text) {
      el.input.value = el.input.value.trim() ? `${el.input.value.trim()} ${text}` : text;
      autosize();
      setStatus('');
    } else {
      setStatus("Didn't catch that — try again.");
    }
    el.input.focus();
    if (text && after === 'send') sendDictation();
  }

  /** Chrome's built-in recognizer — the fallback when the mic can't be captured. */
  function captureLocally() {
    const before = el.input.value.trim();
    after = 'edit';
    recognizer = new SpeechRecognition();
    recognizer.lang = navigator.language || 'en-US';
    recognizer.interimResults = true;
    recognizer.continuous = false;

    recognizer.addEventListener('start', () => {
      setMicState('capturing');
      setStatus('');
      showBar(true);
      startWave(null);
    });

    recognizer.addEventListener('result', (e) => {
      let transcript = '';
      for (const r of e.results) transcript += r[0].transcript;
      el.input.value = before ? `${before} ${transcript}` : transcript;
      autosize();
    });

    recognizer.addEventListener('error', (e) => {
      setStatus(
        e.error === 'not-allowed' || e.error === 'service-not-allowed'
          ? 'Microphone access was blocked.'
          : e.error === 'no-speech'
            ? ''
            : "Didn't catch that — try again."
      );
    });

    recognizer.addEventListener('end', () => {
      recognizer = null;
      stopWave();
      showBar(false);
      setMicState('idle');
      if (after === 'cancel') {
        el.input.value = before;
        autosize();
      }
      el.input.focus();
      if (after === 'send') sendDictation();
    });

    try {
      recognizer.start();
    } catch {
      recognizer = null;
      setMicState('idle');
    }
  }

  el.mic.addEventListener('click', () => {
    if (state !== 'idle') return;
    if (canCapture) transcribeWithWhisper();
    else captureLocally();
  });
  dict.stop.addEventListener('click', () => finishDictation('edit'));
  dict.send.addEventListener('click', () => finishDictation('send'));
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && state === 'capturing') finishDictation('cancel');
  });
}

/* ---------------- boot ---------------- */

el.attachUploadIcon.innerHTML = icon('upload');
el.attachScreenshotIcon.innerHTML = icon('camera');
el.attachImageIcon.innerHTML = icon('image');
el.attachScreenIcon.innerHTML = icon('screen');
$('#mode-humanize-icon').innerHTML = icon('humanize');
$('#mode-search-icon').innerHTML = icon('search');
$('#mode-automate-icon').innerHTML = icon('automate');
el.imageChipIcon.innerHTML = icon('image');
el.micIcon.innerHTML = icon('mic');

setModel('flash');
refreshDrawer();
el.input.focus();

// Welcome screen life: the logo flips and the greeting changes every few
// seconds while the welcome is showing, the tab is visible and the person
// isn't in the middle of typing.
el.welcomeLogo.addEventListener('click', flipLogo);
setInterval(() => {
  if (!el.welcome.isConnected || document.hidden || busy || el.input.value.trim()) return;
  rotateGreeting();
  flipLogo();
}, 6500);

// Pick up anything queued from a context-menu click.
const task = await chrome.runtime.sendMessage({ type: 'viora:get-task' }).catch(() => null);
if (task?.prompt) {
  if (task.model && task.model !== 'flash') {
    if (task.model === 'humanize' || task.model === 'automate' || task.model === 'search') enterMode(task.model);
    else setModel(task.model);
  } else {
    setModel('flash');
  }
  if (task.usePage && task.tabId != null) {
    try {
      pickPage(await chrome.tabs.get(task.tabId));
    } catch {
      // The tab closed before the panel opened — nothing to attach.
    }
  }
  send(task.prompt);
}

// Background work: anything still running from before this panel opened, anything that finished while it was closed, and a tapped notification.
refreshJobBanner();
openRequestedThread();
showLearnedFromChats();
window.addEventListener('pagehide', () => { if (thread.messages.length) askToLearn(thread.id, true); });
