#!/usr/bin/env python3
"""
Viora Linux bridge: a Chrome Native Messaging host.

Chrome extensions can't run programs. This tiny host is the one thing that can: the
extension sends it a JSON message, the host runs it in a real Linux shell and sends the
result back. On Linux and macOS that shell is your own bash. On Windows it is your WSL
distro (install one with `wsl --install`).

It has no network listener. Chrome starts it only when the Viora extension asks, and only
extensions listed in the host manifest's "allowed_origins" can ask (install.ps1 / install.sh
write that list). Whatever the AI is allowed to run, runs as YOU, with your files.

Messages (one JSON object in, one JSON object out, Chrome's 4-byte length framing):
  {"op":"ping"}
  {"op":"run",   "command":"ls -la", "cwd":"~/proj", "timeout":120, "distro":"", "root":false}
  {"op":"write", "path":"~/a.txt", "content":"text", "distro":"", "root":false}
  {"op":"read",  "path":"~/a.txt", "maxBytes":200000, "distro":"", "root":false}
  {"op":"reset"}                          # forget the remembered working folder
  {"op":"run", "stream":true, ...}        # same as run, but over a long-lived port: the host sends
                                          # {"type":"started"}, {"type":"chunk","stream":"stdout|stderr","text":"…"},
                                          # {"type":"tick","elapsed":12.3} every 2s, then the final result
                                          # ({"type":"result", …}). Send {"op":"cancel"} (or close the port) to stop it.
The working folder is remembered between commands (cd carries over), like a terminal tab.
"""
import base64
import codecs
import json
import os
import queue
import shlex
import shutil
import signal
import struct
import subprocess
import sys
import threading
import time

HOST_VERSION = '1.2.0'
IS_WIN = os.name == 'nt'
STATE_DIR = os.path.join(os.path.expanduser('~'), '.viora')
STATE_FILE = os.path.join(STATE_DIR, 'state.json')
LOCK_FILE = os.path.join(STATE_DIR, 'state.lock')
LOG_FILE = os.path.join(STATE_DIR, 'host.log')
DEFAULT_CWD = '~/viora-workspace'
MARK = '__VIORA_CWD__'
SID_MARK = '__VIORA_SID__'
SEND_EVERY = 0.4                          # seconds between batches of streamed output
TICK_EVERY = 2.0                          # heartbeat while a streamed command runs
MAX_TIMEOUT = 3600
KEEP_HEAD, KEEP_TAIL = 20000, 40000      # characters of each stream sent back
MAX_ARG = 24000                           # Windows command lines top out near 32k
KILL_RETRY_AFTER = 5.0                    # seconds to wait before retrying a stuck kill
FORCE_CLOSE_AFTER = 20.0                  # seconds after a kill attempt before we give up waiting on it


# ---------------------------------------------------------------- logging
#
# Never write diagnostics to stdout — that stream is Chrome's native-messaging framing, and a
# stray print() there corrupts every message after it. This goes to a small log file instead,
# best-effort, so a hung command or a failed kill leaves a trail instead of vanishing silently.

def log(msg):
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(f'{time.strftime("%Y-%m-%d %H:%M:%S")} [{os.getpid()}] {msg}\n')
    except Exception:
        pass


# ---------------------------------------------------------------- framing

def _binary_stdio():
    if IS_WIN:
        import msvcrt
        msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
        msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)


def read_message():
    head = sys.stdin.buffer.read(4)
    if len(head) < 4:
        return None
    (size,) = struct.unpack('=I', head)
    body = sys.stdin.buffer.read(size)
    return json.loads(body.decode('utf-8'))


_send_lock = threading.Lock()


def send_message(obj):
    data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
    with _send_lock:
        sys.stdout.buffer.write(struct.pack('=I', len(data)))
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()


# ---------------------------------------------------------------- helpers

def decode(raw):
    """Linux output is UTF-8; wsl.exe's own messages are UTF-16LE."""
    if not raw:
        return ''
    if raw.count(b'\x00') > len(raw) // 4:
        return raw.decode('utf-16-le', 'replace')
    return raw.decode('utf-8', 'replace')


def clip(text):
    if len(text) <= KEEP_HEAD + KEEP_TAIL:
        return text, False
    cut = len(text) - KEEP_HEAD - KEEP_TAIL
    return f'{text[:KEEP_HEAD]}\n…[{cut} characters cut from the middle]…\n{text[-KEEP_TAIL:]}', True


class _StateLock:
    """
    Guards state.json against two host processes racing on it — a streamed command gets its
    own host process (one per run, by design), and a non-streamed op can be handled by another
    one started a moment earlier, so a plain read-modify-write here can silently drop a `cd`.
    Best-effort: on any platform where locking itself fails, we fall back to no lock rather
    than blocking a command on a bookkeeping file.
    """

    def __enter__(self):
        self._fh = None
        try:
            os.makedirs(STATE_DIR, exist_ok=True)
            self._fh = open(LOCK_FILE, 'w')
            if IS_WIN:
                import msvcrt
                for _ in range(50):  # ~5s of retries, then give up and proceed unlocked
                    try:
                        msvcrt.locking(self._fh.fileno(), msvcrt.LK_NBLCK, 1)
                        break
                    except OSError:
                        time.sleep(0.1)
            else:
                import fcntl
                fcntl.flock(self._fh.fileno(), fcntl.LOCK_EX)
        except Exception as exc:
            log(f'state lock unavailable, proceeding without it: {exc}')
            self._fh = None
        return self

    def __exit__(self, *exc):
        if self._fh is None:
            return
        try:
            if IS_WIN:
                import msvcrt
                try:
                    msvcrt.locking(self._fh.fileno(), msvcrt.LK_UNLCK, 1)
                except OSError:
                    pass
            else:
                import fcntl
                fcntl.flock(self._fh.fileno(), fcntl.LOCK_UN)
        except Exception:
            pass
        finally:
            try:
                self._fh.close()
            except Exception:
                pass


def load_state():
    with _StateLock():
        try:
            with open(STATE_FILE, encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}


def save_state(state):
    with _StateLock():
        try:
            os.makedirs(STATE_DIR, exist_ok=True)
            tmp = f'{STATE_FILE}.tmp.{os.getpid()}'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(state, f)
            os.replace(tmp, STATE_FILE)  # atomic on POSIX and Windows, so a reader never sees a half-written file
        except Exception as exc:
            log(f'could not save state: {exc}')


def linux_argv(wrapper, distro='', root=False):
    """The argv that runs `bash -lc <wrapper>` inside Linux."""
    if IS_WIN:
        wsl = shutil.which('wsl.exe') or shutil.which('wsl')
        if not wsl:
            raise RuntimeError('WSL is not installed. In an admin terminal run: wsl --install')
        argv = [wsl]
        if distro:
            argv += ['-d', distro]
        if root:
            argv += ['-u', 'root']
        return argv + ['-e', 'bash', '-lc', wrapper]
    bash = shutil.which('bash')
    if not bash:
        raise RuntimeError('bash was not found on this machine.')
    if root and os.geteuid() != 0:
        sudo = shutil.which('sudo')
        if not sudo:
            raise RuntimeError('Running as root needs sudo, which was not found.')
        return [sudo, '-n', bash, '-lc', wrapper]
    return [bash, '-lc', wrapper]


def wrap(script, timeout=None, stdin_free=True, live=False):
    """
    Put a script into a temp file inside Linux (base64, so no quoting can break it), run it, clean up.
    The wrapper has no double quotes, because wsl.exe re-parses the command line.
    live=True is for streamed runs: stdbuf (when present) makes tools like nmap flush each line as it is
    written instead of in 4 KB blocks, and on WSL the shell's session id is printed first so the host
    can stop everything inside Linux if the person cancels.
    """
    b64 = base64.b64encode(script.encode('utf-8')).decode('ascii')
    buf = '${S:+$S -oL -eL} ' if live else ''
    run = f'timeout -k 5 {int(timeout)} {buf}bash $f' if timeout else f'{buf}bash $f'
    if stdin_free:
        run += ' </dev/null'
    pre = ''
    if live:
        pre = 'S=$(command -v stdbuf); '
        if IS_WIN:
            pre += f'read -r a b c d e sid rest < /proc/$$/stat; echo {SID_MARK}$sid; '
    return f'{pre}f=$(mktemp); echo {b64} | base64 -d > $f; {run}; rc=$?; rm -f $f; exit $rc'


def cd_prelude(cwd):
    q = shlex.quote(cwd)
    return (
        f'd={q}; case $d in "~"|"~/"*) d="$HOME${{d#\\~}}";; esac\n'
        'mkdir -p -- "$d" 2>/dev/null; cd -- "$d" 2>/dev/null || cd "$HOME"\n'
    )


def run_process(argv, stdin_bytes=None, timeout=120):
    kwargs = {}
    if IS_WIN:
        kwargs['creationflags'] = 0x08000000  # CREATE_NO_WINDOW
    else:
        kwargs['start_new_session'] = True
    proc = subprocess.Popen(
        argv,
        stdin=subprocess.PIPE if stdin_bytes is not None else subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        **kwargs,
    )
    try:
        out, err = proc.communicate(stdin_bytes, timeout=timeout)
        return proc.returncode, out, err, False
    except subprocess.TimeoutExpired:
        try:
            if IS_WIN:
                proc.kill()
            else:
                os.killpg(proc.pid, signal.SIGKILL)
        except Exception:
            pass
        out, err = proc.communicate()
        return 124, out or b'', err or b'', True


# ---------------------------------------------------------------- operations

def op_run(req):
    command = str(req.get('command', ''))
    if not command.strip():
        return {'ok': False, 'error': 'No command given.'}
    timeout = max(1, min(int(req.get('timeout') or 120), MAX_TIMEOUT))
    state = load_state()
    cwd = str(req.get('cwd') or state.get('cwd') or DEFAULT_CWD)
    script = (
        cd_prelude(cwd)
        + f"trap 'printf \"\\n{MARK}%s\\n\" \"$PWD\"' EXIT\n"
        + command
        + '\n'
    )
    wrapper = wrap(script, timeout=timeout)
    if IS_WIN and len(wrapper) > MAX_ARG:
        return {'ok': False, 'error': 'That command is too long for Windows. Save it as a script with the write op, then run the file.'}
    began = time.time()
    code, out, err, timed_out = run_process(linux_argv(wrapper, req.get('distro', ''), bool(req.get('root'))), timeout=timeout + 15)
    text, text_err = decode(out), decode(err)
    new_cwd = cwd
    if MARK in text:
        head, _, tail = text.rpartition(MARK)
        text = head.rstrip('\n')
        new_cwd = tail.strip().splitlines()[0] if tail.strip() else cwd
        state['cwd'] = new_cwd
        save_state(state)
    if code == 124:
        timed_out = True
    stdout, cut1 = clip(text)
    stderr, cut2 = clip(text_err)
    return {
        'ok': True,
        'exitCode': code,
        'stdout': stdout,
        'stderr': stderr,
        'cwd': new_cwd,
        'timedOut': timed_out,
        'truncated': cut1 or cut2,
        'ms': int((time.time() - began) * 1000),
    }


def kill_tree(proc, sid=None, argv_opts=None):
    """
    Stop a streamed command and everything it started (nmap, make, a pipeline, ...).
    Returns True if every step believed it worked, False if something is logged as suspect —
    the caller uses that to decide whether a retry (and eventually a forced pipe close) is needed.
    """
    ok = True
    if IS_WIN:
        # wsl.exe is only the doorway; the real processes live inside Linux, so ask Linux to kill that session.
        if sid:
            try:
                code, _, err, _ = run_process(linux_argv(f'pkill -KILL -s {int(sid)}', *(argv_opts or ('', False))), timeout=10)
                if code not in (0, 1):  # pkill returns 1 when nothing matched, which is fine (already dead)
                    ok = False
                    log(f'pkill -s {sid} inside WSL exited {code}: {decode(err)[:200]}')
            except Exception as exc:
                ok = False
                log(f'pkill -s {sid} inside WSL raised: {exc}')
        else:
            # No session id captured (the marker line never arrived, or was corrupted): we can only
            # kill the wsl.exe wrapper itself, so whatever it started inside the distro is orphaned.
            ok = False
            log('no WSL session id captured; killing the wsl.exe wrapper only — Linux-side children may be left running')
        try:
            proc.kill()
        except Exception as exc:
            log(f'proc.kill() (wsl.exe wrapper) raised: {exc}')
    else:
        # `timeout` moves itself into its own process group, so a group kill alone would miss the real
        # command. Everything we started shares one session, so kill by session first, then by group.
        pkill = shutil.which('pkill')
        if pkill:
            try:
                r = subprocess.run([pkill, '-KILL', '-s', str(proc.pid)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
                if r.returncode not in (0, 1):
                    ok = False
                    log(f'pkill -s {proc.pid} exited {r.returncode}')
            except Exception as exc:
                ok = False
                log(f'pkill -s {proc.pid} raised: {exc}')
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass  # already gone — fine
        except Exception as exc:
            ok = False
            log(f'killpg({proc.pid}) raised: {exc}')
        try:
            proc.kill()
        except Exception as exc:
            log(f'proc.kill() raised: {exc}')
    return ok


def op_run_stream(req):
    """
    Like op_run, but the person sees output while it happens: batches of text every ~0.4 s, a heartbeat every 2 s,
    then the same result op_run returns. Runs over a port Chrome keeps open, one command per host process.
    """
    command = str(req.get('command', ''))
    if not command.strip():
        return {'type': 'result', 'ok': False, 'error': 'No command given.'}
    timeout = max(1, min(int(req.get('timeout') or 120), MAX_TIMEOUT))
    state = load_state()
    cwd = str(req.get('cwd') or state.get('cwd') or DEFAULT_CWD)
    script = (
        cd_prelude(cwd)
        + f"trap 'printf \"\\n{MARK}%s\\n\" \"$PWD\"' EXIT\n"
        + command
        + '\n'
    )
    wrapper = wrap(script, timeout=timeout, live=True)
    if IS_WIN and len(wrapper) > MAX_ARG:
        return {'type': 'result', 'ok': False, 'error': 'That command is too long for Windows. Save it as a script with the write op, then run the file.'}
    opts = (req.get('distro', ''), bool(req.get('root')))
    argv = linux_argv(wrapper, *opts)
    kwargs = {}
    if IS_WIN:
        kwargs['creationflags'] = 0x08000000
    else:
        kwargs['start_new_session'] = True
    began = time.time()
    proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kwargs)
    send_message({'type': 'started', 'pid': proc.pid})

    q = queue.Queue()
    cancel = threading.Event()

    def pump(pipe, name):
        try:
            while True:
                raw = pipe.read1(4096)
                if not raw:
                    break
                q.put((name, raw))
        except Exception:
            pass
        q.put((name, None))

    def watch():
        # Chrome closing the port (panel closed, Stop pressed) or an explicit cancel both mean: stop the command.
        try:
            while True:
                msg = read_message()
                if msg is None or msg.get('op') == 'cancel':
                    break
        except Exception:
            pass
        cancel.set()

    for pipe, name in ((proc.stdout, 'stdout'), (proc.stderr, 'stderr')):
        threading.Thread(target=pump, args=(pipe, name), daemon=True).start()
    threading.Thread(target=watch, daemon=True).start()

    decoders = {n: codecs.getincrementaldecoder('utf-8')('replace') for n in ('stdout', 'stderr')}
    kept = {'stdout': [], 'stderr': []}
    held = {'stdout': '', 'stderr': ''}   # an unfinished last line is held back until it ends, so a marker never leaks
    pending = []
    sid = None
    new_cwd = cwd
    open_pipes = 2
    last_send = last_beat = time.time()
    timed_out = cancelled = False
    kill_tried_at = None     # when we first attempted to stop it
    kill_retried = False     # whether we've already given it one retry
    forced_close = False     # whether we had to give up waiting and close the pipes ourselves

    def emit(name, text, final=False):
        """Pass text on, minus the bookkeeping lines the wrapper prints (working folder, session id)."""
        nonlocal sid, new_cwd
        *lines, rest = (held[name] + text).split('\n')
        held[name] = ''
        out = []
        for ln in lines:
            if SID_MARK in ln:
                tail = ln.split(SID_MARK, 1)[1].strip()
                if tail.isdigit():
                    sid = int(tail)
            elif ln.startswith(MARK):
                new_cwd = ln[len(MARK):].strip() or new_cwd
            else:
                out.append(ln + '\n')
        if rest:
            # An unfinished last line goes out at once (progress bars never end with a newline), unless it might
            # be the start of one of our own marker lines, which are held until they are whole.
            if not final and any(m.startswith(rest) or rest.startswith(m) for m in (MARK, SID_MARK)):
                held[name] = rest
            else:
                out.append(rest)
        keep = ''.join(out)
        if keep:
            kept[name].append(keep)
            pending.append((name, keep))

    def flush():
        merged = []
        for name, text in pending:
            if merged and merged[-1][0] == name:
                merged[-1][1] += text
            else:
                merged.append([name, text])
        pending.clear()
        for name, text in merged:
            if text:
                send_message({'type': 'chunk', 'stream': name, 'text': text})

    while True:
        try:
            name, data = q.get(timeout=0.25)
            if data is None:
                open_pipes -= 1
            else:
                emit(name, decoders[name].decode(data).replace('\x00', ''))
        except queue.Empty:
            pass
        now = time.time()
        if pending and now - last_send >= SEND_EVERY:
            flush(); last_send = now
        if now - last_beat >= TICK_EVERY:
            send_message({'type': 'tick', 'elapsed': round(now - began, 1)}); last_beat = now
        if cancel.is_set() and not cancelled:
            cancelled = True
            if not kill_tree(proc, sid, opts):
                log(f'kill_tree reported trouble on first attempt (pid={proc.pid}, sid={sid})')
            kill_tried_at = now
        if now - began > timeout + 15 and not timed_out:
            timed_out = True
            if not kill_tree(proc, sid, opts):
                log(f'kill_tree reported trouble on first attempt (pid={proc.pid}, sid={sid})')
            kill_tried_at = now
        # The command should be dead by now (or never needed killing). If the pipes still
        # haven't closed, one quiet failure in kill_tree (a missing pkill, a lost WSL session id,
        # a grandchild that escaped the process group) must not hang this host forever.
        if kill_tried_at is not None and open_pipes > 0:
            since_kill = now - kill_tried_at
            if since_kill >= KILL_RETRY_AFTER and not kill_retried:
                kill_retried = True
                log(f'pipes still open {since_kill:.1f}s after kill; retrying (pid={proc.pid}, sid={sid})')
                kill_tree(proc, sid, opts)
            if since_kill >= FORCE_CLOSE_AFTER and not forced_close:
                forced_close = True
                log(f'pipes still open {since_kill:.1f}s after kill + retry; forcing them closed (pid={proc.pid})')
                for pipe in (proc.stdout, proc.stderr):
                    try:
                        pipe.close()
                    except Exception:
                        pass
        if open_pipes <= 0:
            break
        if forced_close and now - kill_tried_at >= FORCE_CLOSE_AFTER + 5:
            # Closing the pipes should have unstuck the pump threads within a beat; if it somehow
            # didn't, stop waiting on them rather than hang the host indefinitely.
            log(f'giving up waiting on pump threads after a forced close (pid={proc.pid})')
            break
    for name in ('stdout', 'stderr'):
        emit(name, decoders[name].decode(b'', True), final=True)
    flush()
    try:
        code = proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        kill_tree(proc, sid, opts)
        try:
            code = proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            # Truly stuck (a kernel-level hang, not just a slow exit) — don't let this host process
            # hang forever on it. Report what we have; the OS process table still shows it.
            log(f'process {proc.pid} did not exit even after a second kill attempt; giving up waiting on it')
            code = -1
            forced_close = True

    text, text_err = ''.join(kept['stdout']).rstrip('\n'), ''.join(kept['stderr'])
    if new_cwd != cwd:
        state['cwd'] = new_cwd
        save_state(state)
    if code == 124:
        timed_out = True
    if forced_close:
        text_err += ('\n' if text_err else '') + '[viora: had to force-close this command\'s output; it may still be running in the background — check with `ps` if that matters]'
    stdout, cut1 = clip(text)
    stderr, cut2 = clip(text_err)
    return {
        'type': 'result',
        'ok': True,
        'exitCode': code,
        'stdout': stdout,
        'stderr': stderr,
        'cwd': new_cwd,
        'timedOut': timed_out,
        'cancelled': cancelled,
        'truncated': cut1 or cut2,
        'forcedClose': forced_close,
        'ms': int((time.time() - began) * 1000),
    }


def op_write(req):
    path = str(req.get('path', ''))
    if not path:
        return {'ok': False, 'error': 'No path given.'}
    content = req.get('content', '')
    data = base64.b64decode(req['b64']) if req.get('b64') else str(content).encode('utf-8')
    state = load_state()
    cwd = str(state.get('cwd') or DEFAULT_CWD)
    q = shlex.quote(path)
    script = (
        cd_prelude(cwd)
        + f'p={q}; case $p in "~"|"~/"*) p="$HOME${{p#\\~}}";; esac\n'
        + 'mkdir -p -- "$(dirname -- "$p")" && cat > "$p" && printf "wrote %s bytes to %s\\n" "$(wc -c < "$p")" "$p"\n'
    )
    code, out, err, _ = run_process(linux_argv(wrap(script, stdin_free=False), req.get('distro', ''), bool(req.get('root'))), stdin_bytes=data, timeout=60)
    if code != 0:
        return {'ok': False, 'error': (decode(err) or decode(out) or f'write failed ({code})').strip()[:2000]}
    return {'ok': True, 'message': decode(out).strip()}


def op_read(req):
    path = str(req.get('path', ''))
    if not path:
        return {'ok': False, 'error': 'No path given.'}
    limit = max(1, min(int(req.get('maxBytes') or 200000), 600000))
    state = load_state()
    cwd = str(state.get('cwd') or DEFAULT_CWD)
    q = shlex.quote(path)
    script = cd_prelude(cwd) + f'p={q}; case $p in "~"|"~/"*) p="$HOME${{p#\\~}}";; esac\nhead -c {limit} -- "$p"\n'
    code, out, err, _ = run_process(linux_argv(wrap(script), req.get('distro', ''), bool(req.get('root'))), timeout=60)
    if code != 0:
        return {'ok': False, 'error': (decode(err) or f'read failed ({code})').strip()[:2000]}
    return {'ok': True, 'content': out.decode('utf-8', 'replace')}


def distros():
    if not IS_WIN:
        return []
    wsl = shutil.which('wsl.exe') or shutil.which('wsl')
    if not wsl:
        return []
    try:
        code, out, _, _ = run_process([wsl, '-l', '-q'], timeout=15)
        return [line.strip().strip('\x00') for line in decode(out).splitlines() if line.strip()]
    except Exception:
        return []


def op_ping(req):
    info = {'ok': True, 'host': HOST_VERSION, 'platform': sys.platform, 'wsl': IS_WIN, 'distros': distros()}
    try:
        script = 'echo "$(whoami)@$(uname -sr)"; echo "${BASH_VERSION%%(*}"; (sudo -n true 2>/dev/null && echo yes) || echo no\n'
        code, out, err, _ = run_process(linux_argv(wrap(script), req.get('distro', ''), False), timeout=30)
        lines = decode(out).strip().splitlines()
        if code != 0 or not lines:
            return {**info, 'ok': False, 'error': (decode(err) or 'Linux did not answer.').strip()[:500]}
        info.update(who=lines[0], bash=lines[1] if len(lines) > 1 else '', sudo=(lines[2] == 'yes') if len(lines) > 2 else False)
    except Exception as exc:
        return {**info, 'ok': False, 'error': str(exc)}
    return info


def op_reset(req):
    save_state({})
    return {'ok': True}


OPS = {'ping': op_ping, 'run': op_run, 'write': op_write, 'read': op_read, 'reset': op_reset}


def handle(req):
    try:
        fn = OPS.get(req.get('op'))
        if not fn:
            return {'ok': False, 'error': f'Unknown op: {req.get("op")!r}'}
        return fn(req)
    except Exception as exc:  # never let one bad request kill the host
        return {'ok': False, 'error': f'{type(exc).__name__}: {exc}'}


def main():
    _binary_stdio()
    while True:
        try:
            req = read_message()
        except Exception:
            break
        if req is None:
            break
        if req.get('op') == 'run' and req.get('stream'):
            # One streamed command per host process: a watcher thread owns stdin while it runs (to hear "cancel").
            try:
                send_message(op_run_stream(req))
            except Exception as exc:
                send_message({'type': 'result', 'ok': False, 'error': f'{type(exc).__name__}: {exc}'})
            sys.stdout.flush()
            os._exit(0)
        send_message(handle(req))


if __name__ == '__main__':
    main()
