#!/usr/bin/env python3
"""Checks the Linux bridge with Chrome's real message framing. Run:  python3 native-host/test_host.py
Uses a throwaway HOME, so it never touches your own files. Needs bash (on Windows, run it inside WSL)."""
import json, os, struct, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
home = tempfile.mkdtemp(prefix='viora-test-')
env = dict(os.environ, HOME=home, USERPROFILE=home)
proc = subprocess.Popen([sys.executable, os.path.join(HERE, 'viora_host.py')], stdin=subprocess.PIPE, stdout=subprocess.PIPE, env=env)
passed = failed = 0


def call(obj):
    data = json.dumps(obj).encode()
    proc.stdin.write(struct.pack('=I', len(data)) + data)
    proc.stdin.flush()
    (n,) = struct.unpack('=I', proc.stdout.read(4))
    return json.loads(proc.stdout.read(n))


def check(cond, label):
    global passed, failed
    if cond:
        passed += 1
    else:
        failed += 1
        print('FAIL:', label)


r = call({'op': 'ping'}); check(r['ok'] and r['bash'], 'ping reaches bash')
r = call({'op': 'run', 'command': 'pwd; echo "it\'s \\"quoted\\" é"; echo err >&2; (exit 3)'})
check(r['stdout'].splitlines()[0].endswith('viora-workspace'), 'starts in ~/viora-workspace')
check(r['exitCode'] == 3 and 'err' in r['stderr'] and 'quoted' in r['stdout'], 'exit code, stderr, quoting and unicode')
call({'op': 'run', 'command': 'mkdir -p sub && cd sub'})
check(call({'op': 'run', 'command': 'pwd'})['stdout'].strip().endswith('/sub'), 'cd carries over between commands')
check(call({'op': 'run', 'command': 'cat'})['exitCode'] == 0, 'stdin is closed, so a command that waits for input ends')
t = time.time(); r = call({'op': 'run', 'command': 'sleep 30', 'timeout': 2})
check(r['timedOut'] and time.time() - t < 12, 'a runaway command is stopped at its timeout')
r = call({'op': 'run', 'command': 'head -c 300000 /dev/zero | tr "\\0" x'})
check(r['truncated'] and len(r['stdout']) < 61000, 'huge output is cut to fit Chrome\'s 1 MB reply limit')
body = 'line "with" quotes\n$HOME `x` \\ ünï\n' * 500
check(call({'op': 'write', 'path': '~/deep/er/f.txt', 'content': body})['ok'], 'write creates folders')
check(call({'op': 'read', 'path': '~/deep/er/f.txt'})['content'] == body, 'a file round-trips byte for byte')
r = call({'op': 'run', 'command': 'false || echo recovered; exit 7'}); check(r['exitCode'] == 7 and 'recovered' in r['stdout'], 'exit inside a command is reported')
check(not call({'op': 'run', 'command': ''})['ok'], 'an empty command is refused')
check(not call({'op': 'nope'})['ok'], 'an unknown op is refused')
call({'op': 'reset'}); check(call({'op': 'run', 'command': 'pwd'})['stdout'].strip().endswith('viora-workspace'), 'reset forgets the folder')

def stream(req, cancel_after=None):
    """One streamed command = its own host process (that is how the extension uses it)."""
    p = subprocess.Popen([sys.executable, os.path.join(HERE, 'viora_host.py')], stdin=subprocess.PIPE, stdout=subprocess.PIPE, env=env)
    data = json.dumps(req).encode(); p.stdin.write(struct.pack('=I', len(data)) + data); p.stdin.flush()
    got, t0, cancelled = [], time.time(), False
    while True:
        head = p.stdout.read(4)
        if len(head) < 4:
            break
        (n,) = struct.unpack('=I', head)
        msg = json.loads(p.stdout.read(n)); msg['_t'] = time.time() - t0; got.append(msg)
        if cancel_after and not cancelled and msg['_t'] > cancel_after:
            data = json.dumps({'op': 'cancel'}).encode(); p.stdin.write(struct.pack('=I', len(data)) + data); p.stdin.flush(); cancelled = True
        if msg.get('type') == 'result':
            break
    p.wait(timeout=10)
    return got

got = stream({'op': 'run', 'stream': True, 'command': 'echo one; sleep 1.2; echo two >&2; (exit 5)', 'timeout': 30})
chunks = [m for m in got if m.get('type') == 'chunk']
check(chunks and chunks[0]['text'].startswith('one') and chunks[0]['_t'] < 1.0, 'streamed output arrives while the command is still running')
check(got[-1]['type'] == 'result' and got[-1]['exitCode'] == 5 and 'two' in got[-1]['stderr'] and got[-1]['stdout'] == 'one', 'a streamed run ends with the same result as run')
check(not any('__VIORA' in m.get('text', '') for m in chunks), 'bookkeeping lines never reach the person')
t = time.time(); got = stream({'op': 'run', 'stream': True, 'command': 'echo go; sleep 73', 'timeout': 60}, cancel_after=1.0)
check(got[-1].get('cancelled') and time.time() - t < 8, 'cancel stops a streamed command quickly')
time.sleep(0.5)
alive = [l for l in subprocess.run(['ps', '-eo', 'stat=,args='], capture_output=True, text=True).stdout.splitlines() if l.split(None, 1)[-1].startswith('sleep 73') and not l.lstrip().startswith('Z')]
check(not alive, 'cancel leaves nothing running (the whole process tree is stopped, not just the shell)')
got = stream({'op': 'run', 'stream': True, 'command': 'sleep 74', 'timeout': 2})
check(got[-1].get('timedOut'), 'a streamed runaway is stopped at its timeout')

proc.stdin.close(); proc.wait(timeout=5)
check(proc.returncode == 0, 'the host exits cleanly when Chrome closes the pipe')
print(f'pass {passed} fail {failed}')
sys.exit(1 if failed else 0)
