/* Viora 7.23.0 — the small bits of script behind viora-fx.css. No dependencies, no network. */
(() => {
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  // 1. Header gets a shadow only once the conversation has scrolled.
  // 2. A round "jump to latest" button appears when you've scrolled up.
  const thread = document.getElementById('thread');
  if (thread) {
    const jump = document.createElement('button');
    jump.type = 'button';
    jump.className = 'fx-jump';
    jump.title = 'Jump to the latest message';
    jump.setAttribute('aria-label', 'Jump to the latest message');
    jump.innerHTML = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 4v11M5 10.5l5 5 5-5"/></svg>';
    document.body.appendChild(jump);
    const update = () => {
      document.body.classList.toggle('fx-scrolled', thread.scrollTop > 6);
      const away = thread.scrollHeight - thread.scrollTop - thread.clientHeight;
      jump.classList.toggle('show', away > 160);
    };
    thread.addEventListener('scroll', update, { passive: true });
    new MutationObserver(update).observe(thread, { childList: true, subtree: true });
    jump.addEventListener('click', () => thread.scrollTo({ top: thread.scrollHeight, behavior: reduce ? 'auto' : 'smooth' }));
    update();
  }

  // 3. Tap ripple on the buttons people press most.
  if (!reduce) {
    document.addEventListener('pointerdown', (e) => {
      const b = e.target.closest && e.target.closest('.send, .suggestion, .icon-btn, .model-pill, .sb-new, .ob-btn, .drawer-tab');
      if (!b || b.disabled) return;
      const r = b.getBoundingClientRect();
      const size = Math.max(r.width, r.height) * 2;
      const dot = document.createElement('span');
      dot.className = 'fx-ripple';
      dot.style.width = dot.style.height = size + 'px';
      dot.style.left = e.clientX - r.left - size / 2 + 'px';
      dot.style.top = e.clientY - r.top - size / 2 + 'px';
      if (getComputedStyle(b).position === 'static') b.style.position = 'relative';
      b.style.overflow = b.style.overflow || 'hidden';
      b.appendChild(dot);
      setTimeout(() => dot.remove(), 620);
    }, { passive: true });

    // 4. The welcome logo leans gently toward the pointer.
    const logo = document.getElementById('welcome-logo');
    const stage = logo && logo.parentElement;
    if (stage) {
      stage.addEventListener('pointermove', (e) => {
        const r = stage.getBoundingClientRect();
        const x = ((e.clientX - r.left) / r.width - 0.5) * 18;
        const y = ((e.clientY - r.top) / r.height - 0.5) * -18;
        stage.style.transform = `rotateY(${x}deg) rotateX(${y}deg)`;
      });
      stage.addEventListener('pointerleave', () => { stage.style.transform = ''; });
      stage.style.transition = 'transform 260ms ease';
    }
  }
})();
