import { getSettings, saveSettings, groqConfig, configForChoice, DEFAULTS, getEpisodes, setEpisodes } from '../lib/storage.js';
import { MODELS, MODEL_ORDER, chainFor } from '../lib/models.js';
import { listModels } from '../lib/providers.js';
import { icon, MODEL_ICON } from '../lib/icons.js';
import { STYLE_QUESTIONS } from '../lib/style-questions.js';
import { AUTH_SITE } from '../lib/access.js';
import { linuxPing, linuxConfig, installCommand, requestNative } from '../lib/linux.js';

const result = document.getElementById('result');
const read = (obj, path) => path.split('.').reduce((o, k) => o?.[k], obj);

function write(obj, path, value) {
  const keys = path.split('.');
  const last = keys.pop();
  const target = keys.reduce((o, k) => (o[k] ??= {}), obj);
  target[last] = value;
}

const say = (text) => { result.textContent = text; };

/* ---- the default-model radio group ---- */

function buildDefaultModel(settings) {
  const host = document.getElementById('default-model');
  host.replaceChildren();
  for (const id of MODEL_ORDER) {
    const model = MODELS[id];
    const label = document.createElement('label');
    label.className = 'choice';

    const radio = document.createElement('input');
    radio.type = 'radio';
    radio.name = 'default-model';
    radio.value = id;
    radio.checked = settings.prefs.model === id;

    const rowIcon = document.createElement('span');
    rowIcon.className = 'choice-icon';
    rowIcon.innerHTML = icon(MODEL_ICON[id]);

    const copy = document.createElement('span');
    copy.className = 'choice-copy';
    const name = document.createElement('strong');
    name.textContent = model.name;
    const blurb = document.createElement('span');
    blurb.textContent = model.blurb;
    copy.append(name, blurb);

    label.append(radio, rowIcon, copy);
    host.append(label);
  }
}

/* ---- per-model ID overrides ---- */

function buildOverrides(settings) {
  const host = document.getElementById('overrides');
  host.replaceChildren();
  for (const id of MODEL_ORDER) {
    const model = MODELS[id];
    const label = document.createElement('label');
    label.className = 'override-label';

    const labelIcon = document.createElement('span');
    labelIcon.className = 'choice-icon choice-icon-sm';
    labelIcon.innerHTML = icon(MODEL_ICON[id]);
    const labelText = document.createElement('span');
    labelText.textContent = model.name;
    label.append(labelIcon, labelText);

    const input = document.createElement('input');
    input.type = 'text';
    input.setAttribute('list', 'groq-models');
    input.dataset.override = id;
    input.value = settings.modelOverrides?.[id] ?? '';
    input.placeholder = chainFor(id, { resolved: settings.resolvedModels })[0];

    label.append(input);
    host.append(label);
  }
}

/* ---- memory: the list of things Viora is told to remember ---- */

// Kept as a plain array in module state while the page is open; collected
// wholesale on save (chrome.storage merges arrays by replacement, which is
// what we want — removing an entry should actually remove it).
let memoryItems = [];

function buildMemory() {
  const host = document.getElementById('memory-list');
  const empty = document.getElementById('memory-empty');
  host.replaceChildren();

  memoryItems.forEach((item, i) => {
    const li = document.createElement('li');
    const text = document.createElement('span');
    text.textContent = item;
    const del = document.createElement('button');
    del.type = 'button';
    del.textContent = 'Forget';
    del.setAttribute('aria-label', `Stop remembering: ${item}`);
    del.addEventListener('click', () => {
      memoryItems.splice(i, 1);
      buildMemory();
    });
    li.append(text, del);
    host.append(li);
  });

  if (empty) empty.hidden = memoryItems.length > 0;
}

function wireMemory() {
  const input = document.getElementById('memory-input');
  const add = document.getElementById('memory-add-btn');

  const addCurrent = () => {
    const value = input.value.trim();
    if (!value) return;
    if (memoryItems.includes(value)) {
      input.value = '';
      return;
    }
    memoryItems.push(value);
    input.value = '';
    buildMemory();
    input.focus();
  };

  add.addEventListener('click', addCurrent);
  // Enter adds (there's no form here — the save button is page-wide).
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addCurrent();
    }
  });
}

function fill(settings) {
  for (const field of document.querySelectorAll('[data-path]')) {
    const path = field.dataset.path;
    if (field.type === 'checkbox') field.checked = Boolean(read(settings, path));
    else field.value = read(settings, path) ?? '';
  }
  memoryItems = Array.isArray(settings.memory) ? settings.memory.filter((m) => String(m).trim()) : [];
  buildMemory();
  buildDefaultModel(settings);
  buildOverrides(settings);
  showStyleStatus(settings);
}

/* ---- Humanizer writing style: retake or clear the ten-card profile ---- */

function showStyleStatus(settings) {
  const note = document.getElementById('style-status');
  const h = settings.humanizer;
  const ready = Boolean(h?.onboarded);
  const styled = ready && h.style?.length;
  const partial = !ready && (h?.draft?.answers || []).some((a) => String(a).trim());
  note.textContent = styled
    ? `Set up — the Humanizer is matching ${h.style.length} answers about how you write.`
    : ready
      ? 'Skipped — the Humanizer will rewrite without matching your voice until you answer some cards.'
      : partial
        ? 'Half-finished — open the Humanizer in the panel to pick up where you left off.'
        : 'Not set up yet — the Humanizer asks you ten short question cards the first time you open it (or you can skip them).';
  document.getElementById('style-retake').disabled = !ready;
  document.getElementById('style-clear').disabled = !ready && !partial;
}

document.getElementById('style-retake').addEventListener('click', async () => {
  const settings = await getSettings();
  // Keep their old answers on the cards so tweaking one isn't rewriting ten.
  const prior = STYLE_QUESTIONS.map((q) => settings.humanizer?.style?.find((s) => s.label === q.label)?.a || '');
  const next = await saveSettings({ humanizer: { onboarded: false, draft: { step: 0, answers: prior } } });
  showStyleStatus(next);
  say('Open the Humanizer in the panel to retake the questions.');
});

document.getElementById('style-clear').addEventListener('click', async () => {
  const next = await saveSettings({ humanizer: { onboarded: false, style: [], draft: { step: 0, answers: [] } } });
  showStyleStatus(next);
  say('Style profile cleared.');
});

function collect() {
  const patch = { modelOverrides: {}, memory: memoryItems.map((m) => m.trim()).filter(Boolean) };
  for (const field of document.querySelectorAll('[data-path]')) {
    const value =
      field.type === 'checkbox' ? field.checked
      : field.type === 'number' ? Number(field.value)
      : field.value.trim();
    write(patch, field.dataset.path, value);
  }
  for (const input of document.querySelectorAll('[data-override]')) {
    patch.modelOverrides[input.dataset.override] = input.value.trim();
  }
  write(patch, 'prefs.pageCtxMigrated', true);
  const picked = document.querySelector('input[name="default-model"]:checked');
  if (picked) write(patch, 'prefs.model', picked.value);
  return patch;
}

document.getElementById('save').addEventListener('click', async () => {
  await saveSettings(collect());
  say('Saved.');
  setTimeout(() => say(''), 2200);
});

document.getElementById('reset').addEventListener('click', async () => {
  await chrome.storage.local.set({ settings: DEFAULTS });
  fill(DEFAULTS);
  say('Back to defaults.');
});

document.getElementById('test').addEventListener('click', async () => {
  await saveSettings(collect());
  const settings = await getSettings();
  const groq = groqConfig(settings);
  say('Testing…');

  const lines = [groq.usingPersonalKey ? 'Using your Groq key' : 'Using the built-in Groq key'];
  for (const id of MODEL_ORDER) {
    const config = configForChoice(settings, id);
    const model = chainFor(id, {
      overrides: settings.modelOverrides,
      resolved: settings.resolvedModels
    })[0];
    try {
      const res = await fetch(`${config.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${config.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model, messages: [{ role: 'user', content: 'ping' }], max_tokens: 1 })
      });
      const label = MODELS[id].name.replace('Viora ', '');
      lines.push(`${label} (${config.label}): ${res.ok ? 'ready' : `failed (${res.status})`}`);
    } catch {
      lines.push(`${MODELS[id].name.replace('Viora ', '')} (${config.label}): unreachable`);
    }
  }
  say(lines.join(' · '));
});

document.getElementById('load-models').addEventListener('click', async (e) => {
  const btn = e.currentTarget;
  btn.disabled = true;
  btn.textContent = 'Loading';
  try {
    await saveSettings(collect());
    const settings = await getSettings();
    const models = await listModels({ config: groqConfig(settings) });
    const list = document.getElementById('groq-models');
    list.replaceChildren();
    for (const id of models) {
      const opt = document.createElement('option');
      opt.value = id;
      list.append(opt);
    }
    btn.textContent = `${models.length} models loaded`;
    say('Click any model field above to pick from the live list.');
  } catch (err) {
    btn.textContent = 'Load what Groq is serving now';
    say(err.message);
  } finally {
    btn.disabled = false;
  }
});

fill(await getSettings());
wireMemory();

/* ---- notes from past chats: listed, deletable one by one, applied immediately ---- */

async function buildEpisodes() {
  const host = document.getElementById('episode-list');
  const empty = document.getElementById('episode-empty');
  const clear = document.getElementById('episode-clear');
  const list = await getEpisodes();
  host.replaceChildren();
  for (const ep of list) {
    const li = document.createElement('li');
    const text = document.createElement('span');
    text.textContent = ep.text;
    const del = document.createElement('button');
    del.type = 'button';
    del.textContent = 'Forget';
    del.setAttribute('aria-label', `Forget this chat note: ${ep.text}`);
    del.addEventListener('click', async () => {
      await setEpisodes((await getEpisodes()).filter((e) => e.id !== ep.id));
      buildEpisodes();
    });
    li.append(text, del);
    host.append(li);
  }
  empty.hidden = list.length > 0;
  clear.hidden = list.length === 0;
}
document.getElementById('episode-clear').addEventListener('click', async () => {
  await setEpisodes([]);
  buildEpisodes();
});
buildEpisodes();

/* ---- Linux bridge: the install command for this copy of Viora, and a connection test ---- */

{
  const id = chrome.runtime.id;
  document.getElementById('linux-id').textContent = id;
  document.getElementById('linux-cmd').textContent = installCommand(id, navigator.platform);
  document.getElementById('linux-copy').addEventListener('click', async (e) => {
    try {
      await navigator.clipboard.writeText(document.getElementById('linux-cmd').textContent);
      e.currentTarget.textContent = 'Copied';
      setTimeout(() => { e.currentTarget.textContent = 'Copy command'; }, 1600);
    } catch {
      say('Select the command and copy it by hand.');
    }
  });
  const linuxToggle = document.querySelector('[data-path="prefs.linux.enabled"]');
  if (linuxToggle) linuxToggle.addEventListener('change', () => { if (linuxToggle.checked) requestNative(); });
  document.getElementById('linux-test').addEventListener('click', async () => {
    const out = document.getElementById('linux-status');
    if (!(await requestNative())) { out.textContent = 'Viora needs your permission to talk to the Linux helper. Click Test connection again and choose Allow.'; return; }
    out.textContent = 'Testing…';
    try {
      await saveSettings(collect());
      const res = await linuxPing(linuxConfig(await getSettings()));
      if (res.ok) {
        out.textContent = `Connected: ${res.who}, bash ${res.bash}. Passwordless sudo: ${res.sudo ? 'yes' : 'no'}.${res.distros?.length ? ` WSL distros: ${res.distros.join(', ')}.` : ''}`;
      } else {
        out.textContent = `The helper answered, but Linux didn't: ${res.error || 'unknown error'}${res.wsl ? ' (On Windows, install WSL with: wsl --install)' : ''}`;
      }
    } catch (err) {
      out.textContent = `${err.message} ${err.hint || ''}`.trim();
    }
  });
}

/* ---- Account: sign in / sign up, then back up or restore through cloud storage ---- */

{
  const cloud = await import('../lib/cloud.js');
  const $ = (id) => document.getElementById(id);
  const status = (t) => { $('acct-status').textContent = t; };
  const when = (ms) => new Date(ms).toLocaleString();

  const show = (account) => {
    $('account-out').hidden = !!account;
    $('account-in').hidden = !account;
    if (account) {
      $('acct-who').textContent = account.name ? `${account.name} (${account.email})` : account.email;
      $('acct-provider').textContent = account.provider === 'google' ? 'Google' : '';
      let av = document.getElementById('acct-avatar');
      if (!av) { av = document.createElement('img'); av.id = 'acct-avatar'; av.alt = ''; av.width = 44; av.height = 44; av.style.cssText = 'border-radius:50%;vertical-align:middle;margin-right:10px;object-fit:cover'; $('acct-who').parentElement.prepend(av); }
      av.hidden = !account.picture;
      if (account.picture) av.src = account.picture;
      const nameField = document.querySelector('[data-path="prefs.name"]');
      const callMe = account.givenName || account.name;
      if (nameField && callMe && !nameField.value.trim()) nameField.value = callMe;
    }
  };

  const run = (button, work) => async () => {
    const buttons = [...document.querySelectorAll('#account-out button, #account-in button')];
    buttons.forEach((b) => { b.disabled = true; });
    try { await work(); } catch (err) { status(err.message); } finally { buttons.forEach((b) => { b.disabled = false; }); }
  };

  const creds = () => [$('acct-email').value, $('acct-pass').value];
  const entered = async (fn, done) => {
    status('Working…');
    show(await fn(...creds()));
    $('acct-pass').value = '';
    status(done);
  };

  $('acct-signin').addEventListener('click', run('signin', () => entered(cloud.signIn, 'Signed in.')));
  $('acct-signup').addEventListener('click', run('signup', () => entered(cloud.signUp, 'Account created and signed in.')));
  $('acct-google').addEventListener('click', run('google', async () => {
    status('Opening Google…');
    show(await cloud.signInWithGoogle());
    status('Signed in with Google.');
  }));
  $('acct-show').addEventListener('click', () => {
    const p = $('acct-pass');
    const hide = p.type === 'text';
    p.type = hide ? 'password' : 'text';
    $('acct-show').textContent = hide ? 'Show' : 'Hide';
    $('acct-show').setAttribute('aria-pressed', String(!hide));
    $('acct-show').setAttribute('aria-label', hide ? 'Show password' : 'Hide password');
  });
  for (const id of ['acct-email', 'acct-pass']) {
    $(id).addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('acct-signin').click(); } });
  }
  $('acct-google-note').textContent = `Google sign-in runs through ${AUTH_SITE}. Extension ID: ${chrome.runtime.id}`;
  $('acct-signout').addEventListener('click', run('signout', async () => { await cloud.signOut(); show(null); status('Signed out.'); }));
  $('acct-backup').addEventListener('click', run('backup', async () => {
    status('Backing up…');
    await saveSettings(collect());
    const r = await cloud.backup();
    status(`Backed up ${when(r.savedAt)}: ${r.chats} chats, ${r.memory} memory items.`);
  }));
  $('acct-restore').addEventListener('click', run('restore', async () => {
    if (!confirm('Replace this device\'s settings, memory and chats with the cloud backup?')) return;
    status('Restoring…');
    const r = await cloud.restore();
    fill(await getSettings());
    buildEpisodes();
    status(`Restored the backup from ${when(r.savedAt)}: ${r.chats} chats, ${r.memory} memory items.`);
  }));

  // Automatic sync: the switch (on by default) and a plain-words status that follows the worker.
  const paintSync = async () => {
    const got = await chrome.storage.local.get([cloud.AUTO_KEY, cloud.SYNC_KEY]);
    $('acct-auto').checked = got[cloud.AUTO_KEY] !== false;
    const st = got[cloud.SYNC_KEY];
    let text = '';
    if (got[cloud.AUTO_KEY] === false) text = 'Automatic sync is off. Use "Back up now" when you want to save.';
    else if (!st) text = 'Waiting for the first sync.';
    else if (st.status === 'conflict') text = 'Not syncing: the cloud already holds a backup this device has not seen (made on another device, or before automatic sync). Press "Restore from cloud" to take it, or "Back up now" to replace it with this device.';
    else if (st.status === 'error') text = `Last sync failed (${st.error || 'unknown error'}). It will try again.`;
    else text = `Synced ${when(st.at)}.`;
    $('acct-sync').textContent = text;
  };
  $('acct-auto').addEventListener('change', async () => {
    await chrome.storage.local.set({ [cloud.AUTO_KEY]: $('acct-auto').checked });
    if ($('acct-auto').checked) chrome.runtime.sendMessage({ type: 'viora:autosync-now' }).catch(() => {});
    paintSync();
  });
  chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && (c[cloud.SYNC_KEY] || c[cloud.AUTO_KEY])) paintSync(); });
  const account = await cloud.getAccount();
  show(account);
  paintSync();
  if (account) chrome.runtime.sendMessage({ type: 'viora:autosync-now' }).catch(() => {});
}
