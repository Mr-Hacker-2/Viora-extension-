// Settings, laid out like any AI app: a menu of sections on the left, the chosen section on the right.
import { ic } from '../tab/icons.js';

const GROUPS = [
  { id: 'general', label: 'General', icon: 'gear', blurb: 'How Viora looks, talks and replies.', match: ['Appearance', 'Which Viora', 'How Viora talks', 'Replies'] },
  { id: 'personal', label: 'Personalization', icon: 'user', blurb: 'Your name, memory and writing style.', match: ['You', 'Memory', 'Humanizer writing'] },
  { id: 'account', label: 'Account & backup', icon: 'shield', blurb: 'Sign in to back up your settings and chats.', match: ['Account'] },
  { id: 'tools', label: 'Tools', icon: 'terminal', blurb: 'Humanizer checks, Automate and Linux.', match: ['Humanizer AI check', 'Automate', 'Linux'] },
  { id: 'models', label: 'Models & keys', icon: 'bolt', blurb: 'Model IDs and your own API key.', match: ['Model IDs', 'Your own'] },
  { id: 'help', label: 'Help', icon: 'help', blurb: 'Privacy, permissions and how to use Viora.', match: ['Privacy and permissions', 'How to use'] }
];

const page = document.querySelector('.page');
const head = page.querySelector('.head');
const actions = page.querySelector('.actions');
const cards = [...page.querySelectorAll(':scope > .card')];

const nav = document.createElement('aside');
nav.className = 's-nav';
nav.innerHTML = `<div class="s-brand"><img src="../../icons/icon32.png" alt="" width="26" height="26"><b>Viora AI</b></div><h1>Settings</h1><nav></nav>`;
// Light/dark switch (theme.js does the saving and painting; light is the default).
const themeBtn = document.createElement('button');
themeBtn.type = 'button';
themeBtn.className = 's-theme';
const paintThemeBtn = () => { themeBtn.textContent = document.documentElement.dataset.theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'; };
themeBtn.addEventListener('click', () => window.vioraTheme && window.vioraTheme.toggle());
new MutationObserver(paintThemeBtn).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
paintThemeBtn();
nav.append(themeBtn);
const main = document.createElement('div');
main.className = 's-main';
const title = document.createElement('div');
title.className = 's-head';
main.append(title);

const panes = {};
for (const g of GROUPS) {
  const sec = document.createElement('section');
  sec.className = 's-group';
  sec.hidden = true;
  panes[g.id] = sec;
  main.append(sec);
  const b = document.createElement('button');
  b.type = 'button';
  b.dataset.g = g.id;
  b.innerHTML = `${ic(g.icon)}<span>${g.label}</span>`;
  b.addEventListener('click', () => show(g.id));
  nav.querySelector('nav').append(b);
}
for (const card of cards) {
  const h = (card.querySelector('h2')?.firstChild?.textContent || card.querySelector('h2')?.textContent || '').trim();
  const g = GROUPS.find((x) => x.match.some((m) => h.startsWith(m))) || GROUPS[0];
  panes[g.id].append(card);
}
main.append(actions);
head.remove();
page.append(nav, main);
page.classList.add('s-layout');

function show(id) {
  const g = GROUPS.find((x) => x.id === id) || GROUPS[0];
  for (const x of GROUPS) panes[x.id].hidden = x.id !== g.id;
  nav.querySelectorAll('nav button').forEach((b) => b.classList.toggle('on', b.dataset.g === g.id));
  title.innerHTML = `<h2>${g.label}</h2><p>${g.blurb}</p>`;
  if (location.hash.slice(1) !== g.id) history.replaceState(null, '', `#${g.id}`);
  main.scrollTop = 0;
}
addEventListener('hashchange', () => show(location.hash.slice(1)));
show(location.hash.slice(1) || 'general');
