// In the Viora AI style, the Viora tab is the three-column app (src/tab). ?classic=1 keeps the old Workspace;
// ?embed=nb is the Notebook shown inside that app.
(async () => {
  try {
    const q = new URLSearchParams(location.search);
    if (q.get('embed') === 'nb') { document.documentElement.classList.add('embed'); return; }
    if (q.has('classic')) return;
    const { settings } = await chrome.storage.local.get('settings');
    if (settings?.prefs?.uiStyle === 'viora') location.replace(chrome.runtime.getURL('src/tab/index.html'));
  } catch { /* stay on the Workspace */ }
})();
