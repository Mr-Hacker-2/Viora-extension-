import { startDeemoji } from '../tab/icons.js';
if (document.documentElement.classList.contains('embed')) {
  startDeemoji();
  // Drop files anywhere on the notebook to add them as sources.
  const over = (on) => document.documentElement.classList.toggle('dragging', on);
  let depth = 0;
  addEventListener('dragenter', (e) => { if ([...(e.dataTransfer?.types || [])].includes('Files')) { depth++; over(true); } });
  addEventListener('dragleave', () => { depth = Math.max(0, depth - 1); if (!depth) over(false); });
  addEventListener('dragover', (e) => { if ([...(e.dataTransfer?.types || [])].includes('Files')) e.preventDefault(); });
  addEventListener('drop', (e) => {
    const files = [...(e.dataTransfer?.files || [])];
    depth = 0; over(false);
    if (!files.length) return;
    e.preventDefault();
    const give = () => {
      const input = document.getElementById('nbf');
      if (!input) return false;
      const dt = new DataTransfer();
      files.forEach((f) => dt.items.add(f));
      input.files = dt.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    };
    if (!give()) {
      document.querySelector('[data-n=tab][data-k=refs]')?.click();
      setTimeout(give, 80);
    }
  });
}
