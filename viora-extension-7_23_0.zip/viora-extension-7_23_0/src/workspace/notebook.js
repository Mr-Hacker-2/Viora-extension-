/**
 * Viora Notebooks — a place to gather references, chat with them, and have Viora
 * write documents (pages) from them. Lives inside the Workspace page.
 *
 *   references  files, PDFs, links, pasted text, web search, workspace docs/tasks
 *   chat        answers only from the references that are switched on, with [n] citations
 *   pages       Viora writes them from templates or your own prompt; you edit, improve,
 *               listen, export (.md / PDF), turn lines into tasks, or save to Docs
 *
 * Data: S.nb = { cur, list: [{ id, t, at, refs, pages, chat }] } — saved with the rest of
 * the workspace in chrome.storage.local. Nothing leaves the device except the model request.
 */

import { streamChat } from '../lib/providers.js';
import { getSettings, configForChoice } from '../lib/storage.js';
import { chainFor } from '../lib/models.js';
import { renderMarkdown } from '../lib/markdown.js';
import { kindOf, extractPdfBest } from '../lib/files.js';
import { readPage, searchWeb } from '../lib/web.js';
import { markdownToPdf, pdfFilename, downloadPdfBlob } from '../lib/pdf.js';
import {
  REF_CAP, TEMPLATES, EDITS, chatSystem, docSystem, editSystem,
  pack, citeHtml, sourcesFooter, cleanDoc, titleOf, fileSafe, refNameFor, isHttp
} from './nbcore.js';

/**
 * Which of Viora's built-in models and keys the Notebook runs on.
 * 'search' = the Deep Search key (its own budget, the strongest model, Groq keys behind it as
 * fallback). Change to 'flash' for quicker, lighter answers on the Flash key.
 */
export const NB_CHOICE = 'search';

const $ = (s) => document.querySelector(s);
const ICON = { url: '🔗', pdf: '📄', file: '📄', paste: '📝', doc: '▤', tasks: '☑' };
const CHIPS = ['Summarize everything', 'What are the key takeaways?', 'Where do my references disagree?', 'What should I look into next?'];

export function createNotebooks(h) {
  const E = h.E;
  let cur = null, tab = 'pages', pgId = '', open = '', form = '', menu = false, preview = false;
  let busy = '', ctl = null, draft = '', rnote = '', pnote = '', inited = false;
  let timer;

  const root = () => { const s = h.S(); return (s.nb = s.nb || { list: [] }); };
  const NB = () => root().list.find((n) => n.id === cur);
  const page = () => { const nb = NB(); return nb && (nb.pages.find((p) => p.id === pgId) || nb.pages[0]); };
  const later = () => { clearTimeout(timer); timer = setTimeout(h.save, 400); };
  const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
  const errText = (e) => e?.hint || e?.message || 'Viora AI is unavailable right now. Try again shortly.';

  /* ---------------------------------- AI ---------------------------------- */

  async function run(system, hist, user, { onText, max = 3000, temp = 0.35 } = {}) {
    const st = await getSettings();
    const c = (ctl = new AbortController());
    let txt = '';
    try {
      const r = await streamChat({
        config: configForChoice(st, NB_CHOICE),
        models: chainFor(NB_CHOICE, { overrides: st.modelOverrides, resolved: st.resolvedModels }),
        temperature: temp,
        maxTokens: max,
        signal: c.signal,
        messages: [{ role: 'system', content: system }, ...hist, { role: 'user', content: user }],
        onDelta: (d) => { if (d.content) { txt += d.content; onText && onText(txt); } }
      });
      return (r && r.content) || txt;
    } catch (e) {
      if (c.signal.aborted) return txt;
      throw e;
    } finally {
      ctl = null;
    }
  }

  async function ask(q) {
    const nb = NB();
    q = String(q || '').trim();
    if (!nb || busy || !q) return;
    nb.chat.push({ r: 'u', t: q }, { r: 'v', t: '' });
    const m = nb.chat[nb.chat.length - 1];
    draft = ''; busy = 'chat'; up('c');
    try {
      const { block } = pack(nb.refs, q);
      const hist = nb.chat.slice(-9, -2).filter((x) => x.t).map((x) => ({ role: x.r === 'u' ? 'user' : 'assistant', content: x.t.slice(0, 1500) }));
      const user = (block || '<references>\n(no references are switched on)\n</references>') + '\n\nQuestion: ' + q;
      const out = await run(chatSystem(), hist, user, { max: 2500, onText: (t) => { m.t = t; msgs(); } });
      m.t = out.trim() || m.t || '(stopped)';
    } catch (e) {
      m.t = errText(e);
    }
    busy = ''; nb.at = Date.now(); h.save(); up('c');
  }

  /** Create a new page and let Viora write it, live, from the references. */
  async function gen(instr, name) {
    const nb = NB();
    if (!nb || busy) return;
    const p = { id: h.uid(), t: name, b: '', hist: [] };
    nb.pages.push(p);
    pgId = p.id; menu = false; preview = false; busy = 'page'; pnote = ''; tab = 'pages'; up('p');
    try {
      const { block } = pack(nb.refs, instr + ' ' + nb.t);
      const user = (block ? block + '\n\n' : '') + `Notebook: ${nb.t}\nDocument to write: ${instr}`;
      const out = await run(docSystem(!!block), [], user, { max: 7000, temp: 0.45, onText: (t) => live(p, t) });
      if (out.trim()) { p.b = sourcesFooter(cleanDoc(out), nb.refs); p.t = titleOf(p.b, name); }
    } catch (e) {
      pnote = errText(e);
    }
    if (!p.b.trim()) { nb.pages = nb.pages.filter((x) => x !== p); pgId = nb.pages[0]?.id || ''; pnote = pnote || 'Nothing was written.'; }
    busy = ''; nb.at = Date.now(); h.save(); up('p');
  }

  /** Improve / shorten / expand / continue — on the selection if there is one, else the whole page. */
  async function edit(k) {
    const nb = NB(), p = page();
    if (!nb || !p || busy || !EDITS[k]) return;
    const el = $('#nbb');
    let a = 0, b = p.b.length;
    if (el && el.tagName === 'TEXTAREA' && el.selectionEnd > el.selectionStart) { a = el.selectionStart; b = el.selectionEnd; }
    const cont = k === 'continue';
    if (!p.b.trim()) { pnote = 'Write something first, or use ✦ Create with Viora.'; return up('p'); }
    const orig = p.b, before = p.b.slice(0, a), mid = p.b.slice(a, b), after = p.b.slice(b);
    busy = 'page'; pnote = ''; preview = false; up('p');
    try {
      const { block } = pack(nb.refs, (cont ? orig.slice(-500) : mid.slice(0, 500)));
      const withRefs = block && (k === 'expand' || cont);
      const user = (withRefs ? block + '\n\n' : '') + `Instruction: ${EDITS[k]}\n\n<text>\n${(cont ? orig : mid).slice(0, 30000)}\n</text>`;
      const join = (t) => (cont ? orig.replace(/\s+$/, '') + '\n\n' + t.trim() : before + t.trim() + after);
      const out = await run(editSystem(), [], user, { max: 6000, onText: (t) => live(p, join(cleanDoc(t))) });
      if (out.trim()) {
        p.hist = (p.hist || []).concat({ b: orig }).slice(-8);
        p.b = join(cleanDoc(out));
      }
    } catch (e) {
      pnote = errText(e);
    }
    busy = ''; nb.at = Date.now(); h.save(); up('p');
  }

  function live(p, text) {
    p.b = text;
    const el = $('#nbb');
    if (!el || pgId !== p.id) return;
    if (el.tagName === 'TEXTAREA') { el.value = text; el.scrollTop = 1e9; }
    else el.innerHTML = citeHtml(renderMarkdown(text), NB().refs);
    const s = $('#nbs');
    if (s) s.textContent = `Writing… ${text.length.toLocaleString()} characters`;
  }

  /* ---------------------------------- references ---------------------------------- */

  function addRef(nb, r) {
    r.text = String(r.text || '').replace(/\u0000/g, '').trim().slice(0, REF_CAP);
    if (!r.text) throw new Error(`Nothing readable in ${r.name}.`);
    if (nb.refs.some((x) => x.name === r.name && (x.url || '') === (r.url || ''))) return false;
    nb.refs.push({ id: h.uid(), on: 1, ...r });
    return true;
  }

  async function addFiles(files) {
    const nb = NB(), bad = [];
    let n = 0;
    for (const f of files) {
      try {
        if (f.size > 15 * 1024 * 1024) throw new Error(`${f.name} is larger than 15MB.`);
        const k = kindOf(f);
        if (k === 'pdf') {
          const x = await extractPdfBest(new Uint8Array(await f.arrayBuffer()), REF_CAP);
          if (x.sparse) bad.push(`${f.name}: very little text came out; it may be scanned.`);
          if (addRef(nb, { kind: 'pdf', name: f.name, text: x.text })) n++;
        } else if (k === 'text' || /\.(md|txt|csv|log|json)$/i.test(f.name)) {
          if (addRef(nb, { kind: 'file', name: f.name, text: await f.text() })) n++;
        } else {
          throw new Error(`${f.name}: Notebooks read PDFs and text files (.txt, .md, .csv). For Word files, paste the text.`);
        }
      } catch (e) { bad.push(e.message); }
    }
    return { n, bad };
  }

  async function addAction(kind) {
    const nb = NB();
    if (!nb || busy) return;
    const v = ($('#nbi')?.value || '').trim();
    const say = (t) => { rnote = t; up('r'); };
    try {
      if (kind === 'url') {
        if (!isHttp(v)) return say('Paste a full link starting with https://');
        busy = 'ref'; say('Reading the page…');
        const d = await readPage(v);
        addRef(nb, { kind: 'url', name: refNameFor(v, d.title), url: v, text: d.text });
        rnote = ''; form = '';
      } else if (kind === 'paste') {
        const t = ($('#nbt2')?.value || '').trim();
        if (!t) return say('Paste some text first.');
        addRef(nb, { kind: 'paste', name: v || t.split('\n')[0].slice(0, 50) || 'Pasted text', text: t });
        rnote = ''; form = '';
      } else if (kind === 'web') {
        if (v.length < 2) return say('Type what to search for.');
        busy = 'ref'; say('Searching the web…');
        const hits = (await searchWeb(v, { limit: 6 })).filter((r) => isHttp(r.url)).slice(0, 4);
        if (!hits.length) throw new Error('The search came back empty. Try different words.');
        say(`Reading ${plural(hits.length, 'page')}…`);
        const got = await Promise.allSettled(hits.map((r) => readPage(r.url)));
        let n = 0;
        got.forEach((g, i) => {
          if (g.status !== 'fulfilled') return;
          try { if (addRef(nb, { kind: 'url', name: refNameFor(hits[i].url, g.value.title || hits[i].title), url: hits[i].url, text: g.value.text })) n++; } catch { /* unreadable page */ }
        });
        rnote = n ? `Added ${plural(n, 'page')} from the web.` : 'None of those pages could be read.'; form = '';
      } else if (kind === 'ws') {
        const S = h.S();
        if (v === 'tasks') {
          const lines = S.tasks.map((t) => `- ${t.t} (${S.st[t.st]}${t.due ? ', due ' + t.due : ''}${t.pr ? ', ' + t.pr : ''})`);
          addRef(nb, { kind: 'tasks', name: 'Workspace tasks', text: lines.join('\n') });
        } else {
          const d = S.docs.find((x) => x.id === v);
          if (!d) return say('Pick a document first.');
          addRef(nb, { kind: 'doc', name: d.t, text: d.b });
        }
        rnote = ''; form = '';
      }
    } catch (e) { rnote = errText(e); }
    busy = ''; nb.at = Date.now(); h.save(); up('r');
  }

  /* ---------------------------------- views ---------------------------------- */

  function home() {
    const L = root().list.slice().sort((a, b) => b.at - a.at);
    return `<div class="nbh"><div class="nbhd"><h2>Notebooks</h2><p>Keep sources, notes and AI-written pages together for each topic.</p></div><div class="add"><input id="nbn" placeholder="Name a notebook, e.g. “Biology unit 3” or “Trip to Japan”"><button class="p" data-n="new">＋ New notebook</button></div>` +
      (L.length
        ? `<div class="nbgrid">${L.map((n) => `<div class="nbcard" data-n="open" data-id="${n.id}"><b>${E(n.t)}</b><span class="mu">${plural(n.refs.length, 'reference')} · ${plural(n.pages.length, 'page')}</span><span class="mu">Updated ${new Date(n.at).toLocaleDateString()}</span><button data-n="del" data-id="${n.id}" title="Delete notebook" aria-label="Delete notebook">✕</button></div>`).join('')}</div>`
        : `<div class="nbintro"><h3>Think with your own sources</h3><p>A notebook keeps everything about one topic together. Add files, links, notes or web pages as <b>references</b>, ask Viora questions that are answered only from them (with numbered citations), and have Viora write <b>pages</b> from them: briefing docs, study guides, FAQs, plans, emails and more.</p></div>`) + `</div>`;
  }

  function refsH(nb) {
    const on = nb.refs.filter((r) => r.on !== false).length, S = h.S();
    const forms = {
      url: `<div class="nbfm"><input id="nbi" placeholder="https://…" autocomplete="off"><button class="p" data-n="addurl">Add</button></div>`,
      paste: `<div class="nbfm col"><input id="nbi" placeholder="Name (optional)"><textarea id="nbt2" rows="6" placeholder="Paste notes, an article, a transcript…"></textarea><button class="p" data-n="addpaste">Add</button></div>`,
      web: `<div class="nbfm"><input id="nbi" placeholder="Search the web for sources…" autocomplete="off"><button class="p" data-n="addweb">Find &amp; add</button></div>`,
      ws: `<div class="nbfm"><select id="nbi"><option value="">Choose…</option><option value="tasks">All workspace tasks</option>${S.docs.map((d) => `<option value="${d.id}">${E(d.t)}</option>`).join('')}</select><button class="p" data-n="addws">Add</button></div>`
    };
    return `<div class="nbsh"><b>References</b><span class="mu">${on} of ${nb.refs.length} on</span></div>
<label class="nbdrop"><b>Add files</b><small>Drop PDFs or text files here, or click to browse</small><input id="nbf" type="file" multiple hidden accept=".txt,.md,.csv,.log,.json,.pdf,text/*,application/pdf"></label>
<div class="nbadd"><button data-n="f" data-k="url" class="${form === 'url' ? 'on' : ''}">🔗 Link</button><button data-n="f" data-k="paste" class="${form === 'paste' ? 'on' : ''}">📝 Paste</button><button data-n="f" data-k="web" class="${form === 'web' ? 'on' : ''}">🌐 Search</button><button data-n="f" data-k="ws" class="${form === 'ws' ? 'on' : ''}">▤ Workspace</button></div>
${forms[form] || ''}${rnote ? `<div class="nbnote">${E(rnote)}</div>` : ''}
<div class="nbrl">${nb.refs.map((r, i) => `<div class="nbref ${r.on === false ? 'off' : ''}"><input type="checkbox" data-n="rt" data-id="${r.id}" ${r.on === false ? '' : 'checked'} aria-label="Use this reference"><span class="nbn">${i + 1}</span><div class="nbrb" data-n="ro" data-id="${r.id}"><b>${ICON[r.kind] || '📄'} ${E(r.name)}</b><span class="mu">${(r.text.length / 1000).toFixed(1)}k characters</span></div><button data-n="rx" data-id="${r.id}" title="Remove" aria-label="Remove reference">✕</button></div>${open === r.id ? `<pre class="nbpre">${E(r.text.slice(0, 1500))}${r.text.length > 1500 ? '…' : ''}</pre>${r.url ? `<a class="mu" href="${E(r.url)}" target="_blank" rel="noopener noreferrer">${E(r.url)}</a>` : ''}` : ''}`).join('') || '<div class="empty">Add files, links, pasted notes or web pages. Viora only answers from the references that are switched on.</div>'}</div>`;
  }

  function pagesH(nb) {
    const p = nb.pages.find((x) => x.id === pgId) || nb.pages[0];
    const tpl = `<div class="nbmenu"><div class="nbtp">${TEMPLATES.map((t) => `<button data-n="gen" data-t="${t.id}"><span>${t.icon}</span>${t.name}</button>`).join('')}</div><div class="nbfm"><input id="nbcu" placeholder="Or describe the page you want…" autocomplete="off"><button class="p" data-n="gencu">Create</button></div>${nb.refs.some((r) => r.on !== false) ? '' : '<div class="mu">Tip: add references first and Viora will write from them. Without any, it writes from general knowledge.</div>'}</div>`;
    const tools = p ? `<div class="nbtools"><button data-n="pv" class="${preview ? 'on' : ''}">${preview ? '✎ Edit' : '👁 Preview'}</button>${['improve|✦ Improve', 'shorten|Shorter', 'expand|Longer'].map((x) => { const [k, l] = x.split('|'); return `<button data-n="ed" data-k="${k}" ${busy ? 'disabled' : ''}>${l}</button>`; }).join('')}<details class="nbmore"><summary>More</summary><div class="nbmorebox">${['grammar|Fix grammar', 'formal|Formal', 'friendly|Friendly', 'continue|Continue'].map((x) => { const [k, l] = x.split('|'); return `<button data-n="ed" data-k="${k}" ${busy ? 'disabled' : ''}>${l}</button>`; }).join('')}<button data-n="say">🔊 Listen</button><button data-n="cp">Copy</button><button data-n="md">⬇ .md</button><button data-n="pdf">⬇ PDF</button><button data-n="p2t">→ Tasks</button><button data-n="p2d">→ Docs</button>${p.hist?.length && !busy ? '<button data-n="undo">↶ Undo AI edit</button>' : ''}<button data-n="pdel" class="dng">Delete page</button></div></details></div>` : '';
    return `<div class="nbsh"><b>Pages</b>${busy === 'page' ? '<button data-n="stop">■ Stop</button>' : ''}</div>
<div class="nbpt">${nb.pages.map((x) => `<button data-n="pg" data-id="${x.id}" class="${p && x.id === p.id ? 'on' : ''}">${E(x.t || 'Untitled')}</button>`).join('')}<button data-n="np" title="New blank page" aria-label="New blank page">＋</button><button class="p" data-n="menu">✦ Create with Viora</button></div>
${menu || (!p && nb.refs.length) ? tpl : ''}${pnote && !busy ? `<div class="nbnote">${E(pnote)}</div>` : ''}
${p ? `<input class="nbpn" data-nf="pt" value="${E(p.t)}" aria-label="Page title" ${busy ? 'readonly' : ''}>${tools}<div class="mu" id="nbs">${busy === 'page' ? 'Writing…' : 'Select text first to change just that part.'}</div>${preview ? `<div class="md nbprev" id="nbb">${citeHtml(renderMarkdown(p.b), nb.refs)}</div>` : `<textarea id="nbb" data-nf="pb" placeholder="Write here, or use ✦ Create with Viora…" ${busy ? 'readonly' : ''}>${E(p.b)}</textarea>`}` : (!nb.refs.length ? '<div class="empty">No pages yet. Add references, then ✦ Create with Viora, or start a blank page with ＋.</div>' : '')}`;
  }

  function msgHtml(nb) {
    return nb.chat.map((m, i) => m.r === 'u'
      ? `<div class="msg">${E(m.t)}</div>`
      : `<div class="msg v">${m.t ? `<div class="md">${citeHtml(renderMarkdown(m.t), nb.refs)}</div>` : '<span class="mu">Thinking…</span>'}${!busy && m.t ? `<div class="nbma"><button data-n="m2p" data-i="${i}">＋ Save as page</button><button data-n="mcp" data-i="${i}">Copy</button></div>` : ''}</div>`).join('');
  }

  function chatH(nb) {
    return `<div class="nbsh"><b>Chat</b><span class="mu">answers only from your references</span>${nb.chat.length && !busy ? '<button data-n="cc">Clear</button>' : ''}</div>
<div id="nbm" class="nbms">${msgHtml(nb) || '<div class="empty">Ask anything about your references. Answers cite them like <sup class="nbc-c">1</sup>.</div>'}</div>
${!nb.chat.length && nb.refs.length ? `<div class="chips">${CHIPS.map((c) => `<button data-n="chip" data-t="${E(c)}">${E(c)}</button>`).join('')}</div>` : ''}
<div class="nbin"><textarea id="nbq" data-nf="q" rows="2" placeholder="${nb.refs.length ? 'Ask about your references…' : 'Add a reference first, or just ask…'}">${E(draft)}</textarea><button class="p" data-n="${busy === 'chat' ? 'stop' : 'ask'}">${busy === 'chat' ? 'Stop' : 'Send'}</button></div>`;
  }

  function nbView(nb) {
    return `<div class="nbx"><div class="nbbar"><button data-n="home">← Notebooks</button><input class="nbt" data-nf="nt" value="${E(nb.t)}" aria-label="Notebook name"></div>
<div class="nbmt">${[['refs', 'References', nb.refs.length], ['pages', 'Pages', nb.pages.length], ['chat', 'Chat', nb.chat.length]].map(([k, l, c]) => `<button data-n="tab" data-k="${k}" class="${tab === k ? 'on' : ''}">${l}${c ? ` <i>${c}</i>` : ''}</button>`).join('')}</div>
<div class="nbg tb-${tab}"><section id="nbr" class="nbr">${refsH(nb)}</section><section id="nbp" class="nbp">${pagesH(nb)}</section><section id="nbc" class="nbc">${chatH(nb)}</section></div></div>`;
  }

  const view = () => {
    if (!inited) { inited = true; cur = root().list.some((n) => n.id === root().cur) ? root().cur : null; }
    const nb = NB();
    return nb ? nbView(nb) : home();
  };
  function up(w) {
    const nb = NB(); if (!nb) return;
    const f = { r: ['#nbr', refsH], p: ['#nbp', pagesH], c: ['#nbc', chatH] }[w], el = $(f[0]);
    if (el) el.innerHTML = f[1](nb);
    if (w === 'c') after();
  }
  function msgs() {
    const nb = NB(), el = $('#nbm'); if (!nb || !el) return;
    el.innerHTML = msgHtml(nb); el.scrollTop = 1e9;
  }
  function after() { const m = $('#nbm'); if (m) m.scrollTop = 1e9; }

  /* ---------------------------------- actions ---------------------------------- */

  const dl = (name, blob) => { const u = URL.createObjectURL(blob), a = document.createElement('a'); a.href = u; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(u), 3e4); };
  const copy = (t) => navigator.clipboard?.writeText(t).catch(() => {});
  const flash = (el, t) => { if (!el) return; const o = el.textContent; el.textContent = t; setTimeout(() => { el.textContent = o; }, 1200); };
  const plain = (md) => String(md).replace(/```[\s\S]*?```/g, ' ').replace(/\[(\d{1,3}(?:\s*,\s*\d{1,3})*)\]/g, '').replace(/[#*_`>|]/g, '').replace(/\n{2,}/g, '. ');

  async function onClick(e) {
    const el = e.target.closest('[data-n]');
    if (!el) return;
    const a = el.dataset.n, id = el.dataset.id, nb = NB(), S = h.S();
    const go = () => h.render();
    if (a === 'new') { const v = $('#nbn').value.trim(); const n = { id: h.uid(), t: v || 'Untitled notebook', refs: [], pages: [], chat: [], at: Date.now() }; root().list.unshift(n); cur = root().cur = n.id; tab = 'refs'; pgId = ''; rnote = pnote = ''; form = ''; return go(); }
    if (a === 'open') { cur = root().cur = id; tab = 'pages'; pgId = ''; rnote = pnote = ''; form = ''; return go(); }
    if (a === 'home') { cur = root().cur = null; return go(); }
    if (a === 'del') { e.stopPropagation(); const n = root().list.find((x) => x.id === id); if (n && confirm(`Delete “${n.t}” and everything in it?`)) { root().list = root().list.filter((x) => x !== n); h.save(); go(); } return; }
    if (!nb) return;
    const cp = (el2) => nb.chat[+el.dataset.i]?.t;
    if (a === 'tab') { tab = el.dataset.k; return go(); }
    if (a === 'f') { form = form === el.dataset.k ? '' : el.dataset.k; rnote = ''; return up('r'); }
    if (a === 'addurl' || a === 'addpaste' || a === 'addweb' || a === 'addws') return addAction(a.slice(3));
    if (a === 'rt') { const r = nb.refs.find((x) => x.id === id); r.on = el.checked ? 1 : 0; h.save(); return up('r'); }
    if (a === 'ro') { open = open === id ? '' : id; return up('r'); }
    if (a === 'rx') { nb.refs = nb.refs.filter((x) => x.id !== id); h.save(); return up('r'); }
    if (a === 'cite') { const r = nb.refs[+el.dataset.i - 1]; if (r) { open = r.id; tab = 'refs'; go(); setTimeout(() => document.querySelector(`[data-n=ro][data-id="${r.id}"]`)?.scrollIntoView({ block: 'center' }), 0); } return; }
    if (a === 'menu') { menu = !menu; return up('p'); }
    if (a === 'gen') { const t = TEMPLATES.find((x) => x.id === el.dataset.t); return gen(t.p, t.name); }
    if (a === 'gencu') { const v = $('#nbcu').value.trim(); return v && gen(v, v.slice(0, 40)); }
    if (a === 'np') { const p = { id: h.uid(), t: 'Untitled', b: '', hist: [] }; nb.pages.push(p); pgId = p.id; menu = false; preview = false; h.save(); return up('p'); }
    if (a === 'pg') { pgId = id; preview = false; return up('p'); }
    if (a === 'stop') { ctl?.abort(); return; }
    if (a === 'ask') return ask($('#nbq').value);
    if (a === 'chip') return ask(el.dataset.t);
    if (a === 'cc') { nb.chat = []; h.save(); return up('c'); }
    if (a === 'mcp') { copy(cp()); return flash(el, 'Copied ✓'); }
    if (a === 'm2p') { const t = cp(); if (t) { const p = { id: h.uid(), t: titleOf(t, 'From chat'), b: sourcesFooter(t, nb.refs), hist: [] }; nb.pages.push(p); pgId = p.id; tab = 'pages'; preview = true; h.save(); go(); } return; }
    const p = page();
    if (!p) return;
    if (a === 'pv') { preview = !preview; return up('p'); }
    if (a === 'ed') return edit(el.dataset.k);
    if (a === 'cp') { copy(p.b); return flash(el, 'Copied ✓'); }
    if (a === 'md') return dl(fileSafe(p.t) + '.md', new Blob([p.b], { type: 'text/markdown' }));
    if (a === 'pdf') { try { downloadPdfBlob(markdownToPdf(p.b, p.t), pdfFilename(p.t)); } catch (x) { pnote = 'Could not build the PDF: ' + errText(x); up('p'); } return; }
    if (a === 'say') { const s = window.speechSynthesis; if (!s) return; if (s.speaking) { s.cancel(); return flash(el, '🔊 Listen'); } s.speak(new SpeechSynthesisUtterance(plain(p.b).slice(0, 12000))); return flash(el, '■ Stop'); }
    if (a === 'p2t') { let n = 0; p.b.split('\n').forEach((l) => { const m = l.match(/^\s*(?:[-*]\s+(?:\[ \]\s*)?)(.{3,200})$/); if (m && !S.tasks.some((t) => t.t === m[1].trim())) { S.tasks.push({ id: h.uid(), st: 0, pr: 'med', t: m[1].trim() }); n++; } }); h.save(); return flash(el, n ? `${plural(n, 'task')} added ✓` : 'No list lines'); }
    if (a === 'p2d') { S.docs.push({ id: h.uid(), t: p.t, b: p.b }); h.save(); return flash(el, 'Saved to Docs ✓'); }
    if (a === 'undo') { const x = p.hist.pop(); if (x) { p.b = x.b; h.save(); up('p'); } return; }
    if (a === 'pdel') { if (confirm(`Delete the page “${p.t}”?`)) { nb.pages = nb.pages.filter((x) => x !== p); pgId = nb.pages[0]?.id || ''; h.save(); up('p'); } }
  }

  document.addEventListener('click', onClick);
  document.addEventListener('input', (e) => {
    const x = e.target, f = x.dataset?.nf, nb = NB();
    if (!f || !nb) return;
    if (f === 'nt') nb.t = x.value;
    else if (f === 'pt') { const p = page(); if (p) { p.t = x.value; const b = document.querySelector(`[data-n=pg][data-id="${p.id}"]`); if (b) b.textContent = x.value || 'Untitled'; } }
    else if (f === 'pb') { const p = page(); if (p) p.b = x.value; }
    else if (f === 'q') draft = x.value;
    nb.at = Date.now(); later();
  });
  document.addEventListener('change', async (e) => {
    const x = e.target, nb = NB();
    if (x.id !== 'nbf' || !nb) return;
    const files = [...x.files]; x.value = '';
    busy = 'ref'; rnote = 'Reading files…'; up('r');
    const { n, bad } = await addFiles(files);
    busy = ''; rnote = bad.length ? bad.join(' ') : n ? '' : 'Nothing new was added.';
    nb.at = Date.now(); h.save(); up('r');
  });
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || e.shiftKey || e.isComposing) return;
    const id = e.target.id;
    if (id === 'nbq') { e.preventDefault(); ask(e.target.value); }
    else if (id === 'nbn') { e.preventDefault(); document.querySelector('[data-n=new]')?.click(); }
    else if (id === 'nbi' && e.target.tagName === 'INPUT') { e.preventDefault(); e.target.closest('.nbfm')?.querySelector('button.p')?.click(); }
    else if (id === 'nbcu') { e.preventDefault(); document.querySelector('[data-n=gencu]')?.click(); }
  });

  return { view, after };
}
