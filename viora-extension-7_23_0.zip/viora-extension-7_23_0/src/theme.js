// Light is the default. Dark only when the person switches it on (the sun/moon button).
// Classic script, loaded in <head> so the right theme is painted before the page shows.
(() => {
  const KEY = 'viora-theme';
  const root = document.documentElement;
  const norm = (t) => (t === 'dark' ? 'dark' : 'light');
  const paint = (t) => {
    t = norm(t);
    root.dataset.theme = t;
    try { localStorage.setItem(KEY, t); } catch { /* storage can be blocked */ }
    const b = document.getElementById('theme-btn');
    if (b) {
      const label = t === 'dark' ? 'Switch to light mode' : 'Switch to dark mode';
      b.title = label;
      b.setAttribute('aria-label', label);
    }
  };
  let cached = 'light';
  try { cached = localStorage.getItem(KEY) || 'light'; } catch { /* default light */ }
  paint(cached);

  const store = typeof chrome !== 'undefined' ? chrome.storage : null;
  const area = store && store.local;
  if (area) {
    area.get('settings').then(({ settings }) => paint(settings && settings.prefs && settings.prefs.theme)).catch(() => {});
    store.onChanged.addListener((ch, name) => {
      if (name === 'local' && ch.settings) paint(ch.settings.newValue && ch.settings.newValue.prefs && ch.settings.newValue.prefs.theme);
    });
  }
  const set = async (t) => {
    paint(t);
    if (!area) return;
    try {
      const { settings = {} } = await area.get('settings');
      await area.set({ settings: { ...settings, prefs: { ...(settings.prefs || {}), theme: norm(t) } } });
    } catch { /* the theme still changed on screen */ }
  };
  window.vioraTheme = { get: () => root.dataset.theme, set, toggle: () => set(root.dataset.theme === 'dark' ? 'light' : 'dark') };
  document.addEventListener('DOMContentLoaded', () => {
    paint(root.dataset.theme);
    const b = document.getElementById('theme-btn');
    if (b) b.addEventListener('click', () => window.vioraTheme.toggle());
  });
})();
