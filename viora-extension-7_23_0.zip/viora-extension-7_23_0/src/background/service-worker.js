/**
 * Viora — service worker.
 * Opens the panel, sets up context menus, and relays selected text.
 * Model calls run in the panel itself, where the stream can render directly.
 */

import { getSettings, saveSettings } from '../lib/storage.js';
import { reapOrphans } from './jobs.js'; // also registers the background-job listeners
import { digestThread, sweepQuietChats } from './digest.js';

const MENUS = [
  { id: 'viora-ask', title: 'Ask Viora about “%s”', contexts: ['selection'] },
  { id: 'viora-explain', title: 'Explain this code with Viora', contexts: ['selection'] },
  { id: 'viora-page', title: 'Summarise this page with Viora', contexts: ['page'] }
];

chrome.runtime.onInstalled.addListener(async (details) => {
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

  chrome.contextMenus.removeAll(() => {
    for (const menu of MENUS) chrome.contextMenus.create(menu);
  });

  // Touch storage once so defaults exist before the panel first reads them.
  await saveSettings({});

  // Nothing to configure on a fresh install any more — the panel just works.
  if (details.reason === 'install') {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  }
});

chrome.runtime.onStartup.addListener(() => {
  scheduleAutoSync(0.5);
  reapOrphans().catch(() => {});
  sweepQuietChats().catch(() => {});
});

// Chats that have gone quiet get read once, so Viora can learn from them.
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'viora-digest-sweep') sweepQuietChats().catch(() => {});
  if (alarm.name === 'viora-autosync') runAutoSync();
});

/**
 * Auto-sync to cloud storage: anything in a backup changing (a chat, a setting, memory, an agent, a delegated job)
 * schedules one sync about 30 seconds later, so a burst of changes is one upload. The alarm survives the worker
 * going to sleep. See cloud.js autoSync for what it will and won't overwrite.
 */
const WATCHED = ['settings', 'threads', 'starred', 'episodes', 'viora_agents', 'cloudAccount'];
async function scheduleAutoSync(delayInMinutes = 0.5) {
  if (await chrome.alarms.get('viora-autosync')) return;
  chrome.alarms.create('viora-autosync', { delayInMinutes });
}
async function runAutoSync() {
  const { autoSync } = await import('../lib/cloud.js');
  const r = await autoSync();
  // Offline or the service hiccuped: try again in a few minutes rather than waiting for the next edit.
  if (r.status === 'error') scheduleAutoSync(5);
  return r;
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && WATCHED.some((k) => k in changes)) scheduleAutoSync();
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const task =
    info.menuItemId === 'viora-explain'
      ? { model: 'math', prompt: `Explain this:\n\n${info.selectionText ?? ''}` }
      : info.menuItemId === 'viora-page'
        ? { model: 'flash', prompt: 'Summarise the page I am reading.', usePage: true }
        : { model: 'flash', prompt: info.selectionText ?? '' };

  await chrome.storage.session.set({ pendingTask: { ...task, tabId: tab?.id, at: Date.now() } });
  if (tab?.windowId != null) await chrome.sidePanel.open({ windowId: tab.windowId });
});

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === 'viora:get-task') {
    chrome.storage.session.get('pendingTask').then(({ pendingTask }) => {
      chrome.storage.session.remove('pendingTask');
      reply(pendingTask || null);
    });
    return true;
  }

  if (msg?.type === 'viora:digest') {
    // The panel says a turn finished (or the person is leaving a chat). Read it now if it has grown enough, and again once it goes quiet.
    digestThread(msg.threadId, { minNew: msg.final ? 2 : 6 }).catch(() => {});
    chrome.alarms.create('viora-digest-sweep', { delayInMinutes: 10 });
    reply({ ok: true });
    return false;
  }

  if (msg?.type === 'viora:autosync-now') {
    runAutoSync().then(reply, () => reply({ status: 'error' }));
    return true;
  }

  if (msg?.type === 'viora:settings') {
    getSettings().then(reply);
    return true;
  }

  return false;
});
