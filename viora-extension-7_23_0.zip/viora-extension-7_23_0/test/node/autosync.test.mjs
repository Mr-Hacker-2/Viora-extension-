let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? 'ok  ' : 'FAIL', m); };

// fake chrome.storage.local and a fake bucket behind fetch
const store = {};
globalThis.chrome = { storage: { local: {
  get: async (keys) => { const ks = Array.isArray(keys) ? keys : [keys]; return Object.fromEntries(ks.filter((k) => k in store).map((k) => [k, structuredClone(store[k])])); },
  set: async (o) => Object.assign(store, structuredClone(o)),
  remove: async (k) => { for (const x of [].concat(k)) delete store[x]; }
} }, runtime: { id: 'x' } };
const bucket = {}; let puts = 0, failNext = false;
globalThis.fetch = async (url, init = {}) => {
  if (failNext) return new Response('', { status: 500 });
  const key = decodeURIComponent(new URL(url).pathname);
  if (init.method === 'PUT') { bucket[key] = init.body; puts++; return new Response('', { status: 200 }); }
  return key in bucket ? new Response(bucket[key], { status: 200 }) : new Response('', { status: 404 });
};
const cloud = await import('../../src/lib/cloud.js');
const { syncDecision, autoSync, backup, restore, snapshotPayload, SYNC_KEY, AUTO_KEY } = cloud;

ok(syncDecision({ remoteSavedAt: null, lastSyncedAt: null }) === 'push', 'nothing in the cloud: push');
ok(syncDecision({ remoteSavedAt: 5, lastSyncedAt: 5 }) === 'push', 'cloud is what this device last wrote: push');
ok(syncDecision({ remoteSavedAt: 9, lastSyncedAt: 5 }) === 'conflict', 'another device wrote since: conflict');
ok(syncDecision({ remoteSavedAt: 9, lastSyncedAt: null }) === 'conflict', 'a never-synced device must not overwrite an existing backup');

store.settings = { personalKey: 'SECRET', resolvedModels: { flash: 'm' }, memory: ['likes tea'], prefs: { zerogptKey: 'Z', name: 'Sam' } };
store.threads = [{ id: 'c1', title: 'hi', messages: [] }, { id: 'agent-a1', agent: { id: 'a1' }, unread: 1, messages: [] }];
store.viora_agents = [{ id: 'a1', name: 'Coder', handle: 'coder' }];
ok((await autoSync()).status === 'signed-out', 'not signed in: nothing is sent');
store.cloudAccount = { email: 'a@b.com', uid: 'u1' };
store[AUTO_KEY] = false;
ok((await autoSync()).status === 'off' && puts === 0, 'switched off: nothing is sent');
delete store[AUTO_KEY];

const pl = await snapshotPayload();
ok(!JSON.stringify(pl).includes('SECRET') && !JSON.stringify(pl).includes('"Z"') && !pl.settings.resolvedModels && pl.agents.length === 1, 'payload leaves out personal keys and includes agents');

let r = await autoSync();
ok(r.status === 'synced' && puts === 2 && '/VioraAI/data/u1/backup.json' in bucket && '/VioraAI/data/u1/meta.json' in bucket, 'first change: backup and meta uploaded');
const sent = JSON.parse(bucket['/VioraAI/data/u1/backup.json']);
ok(sent.agents[0].handle === 'coder' && sent.threads.some((t) => t.id === 'agent-a1') && !sent.settings.personalKey, 'cloud copy has agents and private agent chats, no keys');
puts = 0;
ok((await autoSync()).status === 'unchanged' && puts === 0, 'no change: nothing re-uploaded');
store.threads.push({ id: 'c2', title: 'new', messages: [] });
ok((await autoSync()).status === 'synced' && puts === 2, 'a new chat is synced');
puts = 0;

// another device writes to the cloud
bucket['/VioraAI/data/u1/meta.json'] = JSON.stringify({ savedAt: 123 });
store.threads.push({ id: 'c3', title: 'later', messages: [] });
r = await autoSync();
ok(r.status === 'conflict' && puts === 0 && store[SYNC_KEY].status === 'conflict', 'cloud changed elsewhere: no overwrite, conflict recorded');
ok((await autoSync()).status === 'conflict' && puts === 0, 'stays in conflict until the person chooses');

// the person picks "Back up now" (overwrite on purpose) -> auto-sync resumes
await backup();
ok(store[SYNC_KEY].status === 'synced', 'Back up now resolves the conflict');
store.threads.push({ id: 'c4', title: 'after', messages: [] });
puts = 0; ok((await autoSync()).status === 'synced' && puts === 2, 'auto-sync resumes');

// restore: this device equals the cloud, auto-sync sees no change; old backups don't wipe agents
const remote = JSON.parse(bucket['/VioraAI/data/u1/backup.json']);
delete remote.agents; bucket['/VioraAI/data/u1/backup.json'] = JSON.stringify(remote);
await restore();
ok(store.viora_agents.length === 1, 'restoring a backup that has no agents keeps this device\'s agents');
ok(store.settings.personalKey === 'SECRET', 'restore keeps this device\'s own key');
puts = 0; ok((await autoSync()).status === 'unchanged' && puts === 0, 'right after a restore there is nothing to upload');

// failures are reported, never thrown
store.threads.push({ id: 'c5', title: 'offline', messages: [] });
failNext = true; r = await autoSync(); failNext = false;
ok(r.status === 'error' && store[SYNC_KEY].status === 'error', 'a failed upload is reported and kept for retry');
ok((await autoSync()).status === 'synced', 'next attempt succeeds');
await cloud.signOut();
ok(!(SYNC_KEY in store), 'signing out forgets the sync state');
console.log(pass + ' passed, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
