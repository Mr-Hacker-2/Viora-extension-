import { sigv4, hashPassword, sha256Hex, parseAuthRedirect } from '../../src/lib/cloud.js';
let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? 'ok  ' : 'FAIL', m); };
// AWS's published SigV4 example: GET /test.txt with a Range header
const r = await sigv4({
  method: 'GET', host: 'examplebucket.s3.amazonaws.com', path: '/test.txt', headers: { Range: 'bytes=0-9' },
  payloadHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
  region: 'us-east-1', keyId: 'AKIAIOSFODNN7EXAMPLE', secret: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY', amzDate: '20130524T000000Z'
});
ok(r.signature === 'f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41', 'SigV4 matches the AWS example signature');
const salt = new Uint8Array(16).fill(7);
ok((await hashPassword('hunter2hunter2', salt)) === (await hashPassword('hunter2hunter2', salt)), 'same password and salt, same hash');
ok((await hashPassword('hunter2hunter2', salt)) !== (await hashPassword('hunter3hunter3', salt)), 'different password, different hash');
ok((await sha256Hex('abc')).startsWith('ba7816bf'), 'sha256');
const got = parseAuthRedirect('https://abc.chromiumapp.org/?token=tok123&email=a%40b.com&name=Ann');
ok(got.token === 'tok123' && got.email === 'a@b.com' && got.name === 'Ann', 'parses the sign-in site redirect');
let denied = ''; try { parseAuthRedirect('https://abc.chromiumapp.org/?error=access_denied'); } catch (e) { denied = e.message; }
ok(/test user/.test(denied), 'access_denied gives a readable error');
let none = false; try { parseAuthRedirect('https://abc.chromiumapp.org/'); } catch { none = true; }
ok(none, 'missing token throws');
console.log(pass + ' passed, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
