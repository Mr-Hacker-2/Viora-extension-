import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { systemFor } from '../../src/lib/prompts.js';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? 'ok  ' : 'FAIL', m); };
const root = path.resolve(import.meta.dirname, '../..');
const exists = (p) => fs.existsSync(path.join(root, p));
const m = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));

// --- manifest
ok(m.manifest_version === 3, 'manifest v3');
ok(/^\d+(\.\d+){1,3}$/.test(m.version), 'version is well formed');
ok(exists(m.background.service_worker), 'service worker file exists');
ok(exists(m.side_panel.default_path) && exists(m.options_ui.page), 'side panel and options pages exist');
ok(m.content_scripts.every((c) => [...(c.js || []), ...(c.css || [])].every(exists)), 'content scripts exist');
ok(Object.values({ ...m.icons, ...m.action.default_icon }).every(exists), 'all icons exist');
ok(!m.permissions.includes('nativeMessaging') && (m.optional_permissions || []).includes('nativeMessaging'), 'nativeMessaging is optional, not granted up front');
ok(m.permissions.every((p) => ['storage', 'sidePanel', 'activeTab', 'tabs', 'scripting', 'contextMenus', 'windows', 'downloads', 'offscreen', 'notifications', 'alarms', 'identity'].includes(p)), 'no unexpected permission was added');
// The fixed extension ID the sign-in site allows: kkcljeingbbpgbilahlaganmmgggbkik
const id = crypto.createHash('sha256').update(Buffer.from(m.key, 'base64')).digest('hex').slice(0, 32).replace(/[0-9a-f]/g, (c) => 'abcdefghijklmnop'[parseInt(c, 16)]);
ok(id === 'kkcljeingbbpgbilahlaganmmgggbkik', 'manifest key gives the fixed extension ID');

// --- every page loads only files that exist
const pages = ['src/sidepanel/index.html', 'src/tab/index.html', 'src/options/options.html', 'src/workspace/index.html'];
let broken = [];
for (const pg of pages) {
  const html = fs.readFileSync(path.join(root, pg), 'utf8');
  for (const [, ref] of html.matchAll(/(?:src|href)="([^"#?]+\.(?:js|css))"/g)) {
    if (/^https?:/.test(ref)) continue;
    if (!fs.existsSync(path.join(root, path.dirname(pg), ref))) broken.push(`${pg} -> ${ref}`);
  }
}
ok(broken.length === 0, 'every script and stylesheet a page loads exists' + (broken.length ? ': ' + broken.join(', ') : ''));
ok(pages.every((pg) => fs.readFileSync(path.join(root, pg), 'utf8').includes('theme.js')), 'every page loads theme.js');

// --- light is the default; the OS dark setting is ignored
const css = ['src/sidepanel/sidepanel.css', 'src/tab/tab.css', 'src/workspace/workspace.css', 'src/options/options.css', 'src/options/settings.css', 'src/tab/viora-theme.css', 'src/workspace/dark.css', 'src/fx/viora-fx.css'];
ok(css.every((f) => !fs.readFileSync(path.join(root, f), 'utf8').includes('prefers-color-scheme')), 'no stylesheet follows the OS dark setting');
ok(/theme:\s*'light'/.test(fs.readFileSync(path.join(root, 'src/lib/storage.js'), 'utf8')), 'default theme is light');
const themeJs = fs.readFileSync(path.join(root, 'src/theme.js'), 'utf8');
ok(/norm = \(t\) => \(t === 'dark' \? 'dark' : 'light'\)/.test(themeJs), 'anything but "dark" paints light');

// --- effects: loaded by both chat pages, and silenced by reduced-motion
ok(['src/sidepanel/index.html', 'src/tab/index.html'].every((pg) => /fx\/viora-fx\.css/.test(fs.readFileSync(path.join(root, pg), 'utf8')) && /fx\/viora-fx\.js/.test(fs.readFileSync(path.join(root, pg), 'utf8'))), 'side panel and tab load the effects stylesheet and script');
ok(/prefers-reduced-motion: reduce/.test(fs.readFileSync(path.join(root, 'src/fx/viora-fx.css'), 'utf8')), 'effects respect reduced motion');

// --- the AI's honesty and heart rules ride on chat turns
const chat = systemFor('chat', {});
ok(chat.includes('Heart and teaching'), 'chat prompt carries the heart and teaching block');
ok(chat.includes('Never say an action worked'), 'chat prompt forbids claiming an action worked when it did not');
ok(!systemFor('chat', { voice: 'plain' }).includes('Heart and teaching'), 'plain voice drops the heart block');

console.log(pass + ' passed, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
