import {
  slugify, uniqueHandle, cleanAgent, upsertAgent, parseMentions, mentionAtCaret, suggestAgents, insertMention,
  agentPrompt, rosterPrompt, LINUX_CHAT_NOTE, parseShellBlock, parseAgentCalls, stripToolBlocks, visibleWhileStreaming,
  historyContent, AGENT_TEMPLATES, MAX_AGENTS, MAX_DELEGATIONS,
  AGENT_INTERVIEW, interviewSteps, interviewAnswered, interviewReady, agentFromAnswers, nameFromJob, taglineFromJob,
  interviewTranscript, agentWriterMessages, cleanWrittenInstructions, AGENT_WRITER_SYSTEM, splitMentions, removeMention,
  AGENT_INTERVIEWER_SYSTEM, interviewerMessages, parseInterviewReply, agentFromInterview, PLANNER_AGENT, withStarterAgents
} from '../../src/lib/agents.js';
import { systemFor } from '../../src/lib/prompts.js';
import { buildChatMessages } from '../../src/lib/chatjob.js';

let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? 'ok  ' : 'FAIL', m); };

// ---- handles and cleaning
ok(slugify('Linux Helper!') === 'linux-helper' && slugify('  ') === 'agent' && slugify('Zoë Ünï') === 'zoe-uni', 'slugify');
ok(slugify('x'.repeat(60)).length <= 24, 'slug is capped');
let list = upsertAgent([], { name: 'Linux Helper', instructions: 'do linux', linux: true, model: 'math' });
ok(list?.length === 1 && list[0].handle === 'linux-helper' && list[0].linux === true && list[0].model === 'math', 'upsert creates an agent');
ok(upsertAgent([], { name: '', instructions: 'x' }) === null && upsertAgent([], { name: 'A', instructions: ' ' }) === null, 'no name or no instructions is refused');
list = upsertAgent(list, { name: 'Linux Helper', instructions: 'again' });
ok(list.length === 2 && list[1].handle === 'linux-helper-2', 'a second agent with the same name gets its own handle');
const edited = upsertAgent(list, { ...list[0], instructions: 'changed', handle: list[0].handle });
ok(edited.length === 2 && edited[0].instructions === 'changed' && edited[0].handle === 'linux-helper', 'editing keeps the handle and the count');
ok(cleanAgent({ name: 'S', instructions: 'i', model: 'search' }).web === true, 'Deep Search agents always have the web');
ok(cleanAgent({ name: 'S', instructions: 'i', model: 'nonsense' }).model === 'flash', 'unknown brain falls back to Flash');
let many = [];
for (let i = 0; i < MAX_AGENTS; i++) many = upsertAgent(many, { name: `A${i}`, instructions: 'x' });
ok(upsertAgent(many, { name: 'one more', instructions: 'x' }) === null, 'agents are capped');
ok(AGENT_TEMPLATES.every((t) => cleanAgent(t)), 'every template makes a valid agent');

// ---- the interview
ok(interviewSteps({ kind: 'search' }).every((q) => q.id !== 'web' && q.id !== 'linux'), 'a research agent is not asked about web or Linux');
ok(interviewSteps({ kind: 'math' }).some((q) => q.id === 'linux') && !interviewSteps({ kind: 'flash' }).some((q) => q.id === 'linux'), 'Linux is only asked for Math & Code agents');
ok(!interviewAnswered(AGENT_INTERVIEW[0], { job: '  ' }) && interviewAnswered(AGENT_INTERVIEW[0], { job: 'x' }) && interviewAnswered(AGENT_INTERVIEW.find((q) => q.optional), {}), 'required questions need an answer, optional ones do not');
const made = agentFromAnswers({ job: 'review my Python code and find bugs.', kind: 'math', style: 'direct', never: 'never rewrite my whole file', linux: 'no', name: 'Bug Hunter' });
ok(made.name === 'Bug Hunter' && made.model === 'math' && made.linux === false && made.web === false, 'answers become name, brain and powers');
ok(made.instructions.includes('review my Python code and find bugs.') && /short and direct/i.test(made.instructions) && /Never rewrite my whole file\./.test(made.instructions), 'answers become instructions (job, voice, never)');
ok(cleanAgent(made) && upsertAgent([], made)?.length === 1, 'an interview agent is a valid agent');
const researcher = agentFromAnswers({ job: 'research questions', kind: 'search', style: 'formal' });
ok(researcher.model === 'search' && researcher.web === true && /source/i.test(researcher.instructions), 'Deep Search agents get the web and cite sources');
ok(agentFromAnswers({ job: 'x', kind: 'flash', linux: 'yes' }).linux === false, 'Linux is only granted to Math & Code agents');
ok(agentFromAnswers({ job: 'tidy my notes', kind: 'flash', web: 'yes' }).web === true, 'the web answer is honoured');
ok(agentFromAnswers({ job: 'x', kind: 'nonsense' }).model === 'flash', 'unknown kind falls back to Flash');
ok(nameFromJob('help me study for biology tests') === 'Study Biology Tests' && nameFromJob('') === 'My Agent', 'a name is picked from the job when none is given');
ok(agentFromAnswers({ job: 'j'.repeat(5000), name: 'n'.repeat(100) }).name.length <= 40, 'a name is capped at 40 characters');

// ---- richer interview, better instructions, no length limit
ok(cleanAgent({ name: 'Big', instructions: 'word '.repeat(20000) }).instructions.length === 'word '.repeat(20000).trim().length, 'instructions have no length limit');
ok(AGENT_INTERVIEW.filter((q) => !q.optional).map((q) => q.id).join() === 'job,kind' && AGENT_INTERVIEW.length >= 12, 'only the job and the kind of work are required; there are plenty of questions to learn more');
ok(interviewReady({ job: 'x', kind: 'flash' }) && !interviewReady({ job: 'x' }) && !interviewReady({}), 'the interview can be finished early once job and kind are answered');
const rich = agentFromAnswers({ job: 'help me study for biology tests', kind: 'flash', expert: 'a patient biology tutor', audience: 'Me, a high-school student', good: 'A short explanation, then two quiz questions', process: 'clarify', style: 'teacher', format: 'bullets', length: 'medium', unsure: 'admit', never: 'use jargon\nreveal answers before I try', example: 'I send: what is osmosis?\nIt answers: Water moving…', extra: 'My test is on Friday' });
ok(['## Your job', '## Who you help', '## What a great answer looks like', '## How you work', '## Voice, format and length', '## Rules', '## Example', '## Background to remember'].every((h) => rich.instructions.includes(h)), 'a full interview gives a full brief with every section');
ok(/acting as a patient biology tutor/.test(rich.instructions) && /- Never use jargon\./.test(rich.instructions) && /- Never reveal answers before I try\./.test(rich.instructions), 'the expert and each "never" line make it in');
ok(rich.instructions.includes('I send: what is osmosis?\nIt answers: Water moving…') && rich.instructions.includes('My test is on Friday'), 'the example and background are kept word for word');
const thin = agentFromAnswers({ job: 'tidy my notes', kind: 'flash' });
ok(!thin.instructions.includes('## Who you help') && !thin.instructions.includes('## Example') && thin.instructions.includes('## Rules'), 'skipped questions leave their sections out');
ok(rich.tagline === 'Study for biology tests' || /biology/i.test(rich.tagline), 'a short description is made from the job');
ok(taglineFromJob('x'.repeat(300)).length <= 90 && taglineFromJob('') === '', 'tagline is short and never invented');
ok(cleanAgent(rich)?.tagline === rich.tagline, 'a tagline is kept on the agent');
const tr = interviewTranscript({ job: 'j', kind: 'math', style: 'formal', linux: 'yes' });
ok(tr.includes('Q: What should this agent do?\nA: j') && tr.includes('A: Code, maths or computer tasks') && tr.includes('A: Formal and careful') && !tr.includes('Q: How should it sound?\nA: \n'), 'the transcript reads in plain words and skips unanswered questions');
const wm = agentWriterMessages({ job: 'review code', kind: 'math', linux: 'yes' });
ok(wm.length === 2 && wm[0].role === 'system' && wm[0].content === AGENT_WRITER_SYSTEM && /Can run Linux commands: yes/.test(wm[1].content) && wm[1].content.includes('review code'), 'the writer is told the job, the tools and the first draft');
ok(cleanWrittenInstructions('<think>hmm</think>\n```markdown\n' + 'You are X. '.repeat(30) + '\n```').startsWith('You are X.') && cleanWrittenInstructions('too short') === '' && !cleanWrittenInstructions('<think>a</think>' + 'ok. '.repeat(60)).includes('think'), 'a model reply is cleaned, or refused when unusable');

// ---- @mentions drawn nicely
const ag2 = upsertAgent(upsertAgent([], { name: 'Linux Helper', instructions: 'a' }), { name: 'Code Reviewer', instructions: 'b' });
const segs = splitMentions('hey @linux-helper, and (@code-reviewer) look', ag2);
ok(segs.filter((s) => s.agent).map((s) => s.agent.name).join() === 'Linux Helper,Code Reviewer', 'mentions are found as pieces');
ok(segs.map((s) => s.text ?? s.raw).join('') === 'hey @linux-helper, and (@code-reviewer) look', 'the pieces join back into the original message');
ok(splitMentions('mail bob@linux-helper.com @nobody', ag2).every((s) => !s.agent), 'e-mail addresses and unknown handles stay plain text');
ok(removeMention('@linux-helper list my files', ag2[0], ag2) === 'list my files' && removeMention('ask @linux-helper now', ag2[0], ag2) === 'ask now', 'removing a mention tidies the spaces');
ok(removeMention('@linux-helper and @code-reviewer go', ag2[0], ag2) === 'and @code-reviewer go', 'removing one mention leaves the other');

// ---- mentions
const agents = upsertAgent(upsertAgent([], { name: 'Linux Helper', instructions: 'a', linux: true }), { name: 'Code Reviewer', instructions: 'b' });
ok(parseMentions('@linux-helper list my files', agents).map((a) => a.name).join() === 'Linux Helper', 'parses an @mention');
ok(parseMentions('hey @Code-Reviewer and @linux-helper please', agents).length === 2, 'two mentions, case-insensitive');
ok(parseMentions('mail me at bob@linux-helper.com', agents).length === 0, 'an e-mail address is not a mention');
ok(parseMentions('@nobody hi', agents).length === 0, 'unknown handle ignored');
ok(parseMentions('@linuxhelper hi', agents).length === 1, 'the name without dashes also works');
ok(parseMentions('(@linux-helper) go', agents).length === 1, 'a mention in brackets works');
const m = mentionAtCaret('ask @lin', 8);
ok(m && m.start === 4 && m.query === 'lin', 'mention in progress at the caret');
ok(mentionAtCaret('ask @lin and more', 8)?.query === 'lin' && mentionAtCaret('no mention', 4) === null && mentionAtCaret('a@b', 3) === null, 'only a word-start @ counts');
ok(suggestAgents(agents, '').length === 2 && suggestAgents(agents, 'co')[0].name === 'Code Reviewer' && suggestAgents(agents, 'zzz').length === 0, 'suggestions filter');
ok(suggestAgents(agents, 'review')[0].name === 'Code Reviewer', 'suggestions also match inside the name');
const ins = insertMention('ask @lin now', mentionAtCaret('ask @lin now', 8), 'linux-helper');
ok(ins.value === 'ask @linux-helper now' || ins.value === 'ask @linux-helper  now' || ins.value.startsWith('ask @linux-helper '), 'insertMention puts the handle in: ' + JSON.stringify(ins.value));
ok(ins.caret === 'ask @linux-helper '.length, 'caret lands after the handle');

// ---- prompts
ok(agentPrompt(agents[0]).includes('Linux Helper') && agentPrompt(agents[0]).includes('Your instructions') && agentPrompt(null) === '', 'agent prompt');
const roster = rosterPrompt(agents);
ok(roster.includes('@linux-helper') && roster.includes('viora-agent') && roster.includes('can run Linux commands') && rosterPrompt([]) === '', 'roster lists agents and how to call one');
const sysAgent = systemFor('chat', {}, { agent: agents[0], roster, linuxChat: true });
ok(sysAgent.includes('You are Linux Helper') && !sysAgent.includes('viora-agent'), 'an agent turn gets its job and never the roster');
const sysFlash = systemFor('chat', {}, { roster, linuxChat: true });
ok(sysFlash.includes('viora-agent') && sysFlash.includes('viora-shell'), 'Flash gets the roster and the Linux note');
ok(!systemFor('chat', {}, {}).includes('viora-shell') && !systemFor('chat', {}, {}).includes('viora-agent'), 'ordinary turns carry neither');
ok(sysAgent.indexOf('You are Linux Helper') < sysAgent.indexOf('How you talk') || sysAgent.indexOf('You are Linux Helper') < 6000, 'the job description sits near the top');

// ---- tool blocks
const reply = 'Let me check.\n```viora-shell\nls -la ~\n```';
const sh = parseShellBlock(reply);
ok(sh?.command === 'ls -la ~' && sh.before === 'Let me check.', 'parses a shell block');
ok(parseShellBlock('no block') === null && parseShellBlock('```viora-shell\n\n```') === null && parseShellBlock('```bash\nls\n```') === null, 'plain bash blocks and empty blocks are not commands');
ok(parseShellBlock('Run:\n```viora-shell\nfind . -name "*.js" | head\n```\nthen\n```viora-shell\nsecond\n```').command.startsWith('find'), 'only the first command is taken');
const calls = parseAgentCalls('Asking.\n```viora-agent\n{"agent":"@Linux-Helper","task":"list files"}\n```', agents);
ok(calls.length === 1 && calls[0].agent.handle === 'linux-helper' && calls[0].task === 'list files', 'parses an agent call');
ok(parseAgentCalls('```viora-agent\n{"agent":"ghost","task":"x"}\n```', agents).length === 0, 'unknown agent ignored');
ok(parseAgentCalls('```viora-agent\nnot json\n```', agents).length === 0, 'broken JSON ignored');
const two = parseAgentCalls('```viora-agent\n{"agent":"linux-helper","task":"a"}\n```\n```viora-agent\n{"agent":"code-reviewer","task":"b"}\n```\n```viora-agent\n{"agent":"linux-helper","task":"c"}\n```', agents);
ok(two.length <= MAX_DELEGATIONS && new Set(two.map((c) => c.agent.id)).size === two.length, 'at most ' + MAX_DELEGATIONS + ' calls, one per agent');
ok(stripToolBlocks(reply) === 'Let me check.\n```bash\nls -la ~\n```', 'a command block becomes a plain bash block');
ok(stripToolBlocks('Sure.\n```viora-agent\n{"agent":"a","task":"b"}\n```') === 'Sure.', 'agent blocks disappear from the reply');
const live = visibleWhileStreaming('Checking now\n```viora-sh');
ok(live.tool && live.shown === 'Checking now' && !visibleWhileStreaming('plain text').tool, 'a half-typed block never flashes on screen');
ok(historyContent({ role: 'assistant', content: 'hi', agent: { handle: 'x' } }).startsWith('[Reply from agent @x]') && historyContent({ role: 'assistant', content: 'hi' }) === 'hi' && historyContent({ role: 'user', content: 'q', agent: { handle: 'x' } }) === 'q', 'history says which agent spoke');
ok(LINUX_CHAT_NOTE.includes('viora-shell') && /exit code/.test(LINUX_CHAT_NOTE), 'the Linux note explains the block and exit codes');

// ---- through the real prompt builder
const base = {
  choice: 'flash', settings: { prefs: {} }, config: {}, models: ['m'], temperature: 0.5, maxTokens: 500, quick: true, effort: '',
  hasImages: false, casual: false, pdfEdit: false, askText: '', page: null, tabInfo: null, selection: '', summary: '',
  recentChats: '', recalled: '', history: [{ role: 'user', content: 'list my files' }], attachments: [], web: null
};
const flashMsgs = buildChatMessages({ ...base, roster, linuxChat: true }, null, 0);
ok(flashMsgs[0].content.includes('viora-agent') && flashMsgs[0].content.includes('viora-shell'), 'the chat job gives Flash the roster and Linux');
const agentMsgs = buildChatMessages({ ...base, agent: { name: 'Code Reviewer', handle: 'code-reviewer', instructions: 'review code' }, noWeb: true }, null, 0);
ok(agentMsgs[0].content.includes('You are Code Reviewer') && !agentMsgs[0].content.includes('viora-shell'), 'the chat job plays the agent, without Linux unless allowed');

import { threadToMarkdown } from '../../src/lib/chats.js';
import { digestTranscript } from '../../src/lib/memory.js';
const thr = { title: 'T', model: 'flash', messages: [
  { role: 'user', content: 'list files', displayText: 'list files' },
  { role: 'assistant', content: 'On it.', agent: { name: 'Linux Helper', handle: 'linux-helper' } },
  { role: 'user', content: 'Linux result:\nexit code 0', displayText: '', hidden: true }
] };
const md = threadToMarkdown(thr);
ok(md.includes('Linux Helper (@linux-helper):') && !md.includes('Linux result') && !/\*\*You:\*\*\s*\n/.test(md.replace('list files', 'x')) , 'exports name the agent and skip hidden results');
ok(!digestTranscript(thr.messages).includes('Linux result'), 'memory never reads hidden command results');

// ---- the Viora Flash interview
const LONG = 'You are Bug Hunter.\n## Role\nReview Python code and point out bugs.\n## Rules\n- Use emoji frequently.';
const done = parseInterviewReply(JSON.stringify({ say: 'All set! 🎉', done: true, agent: { name: 'Bug Hunter', tagline: 'Finds bugs', emoji: '🐛', model: 'math', web: false, linux: true, instructions: LONG } }));
ok(done.done && done.agent?.name === 'Bug Hunter' && done.agent.model === 'math' && done.agent.linux === true && done.agent.emoji === '🐛', 'a finished interview reply becomes an agent');
ok(upsertAgent([], done.agent)?.[0]?.handle === 'bug-hunter', 'the agent Flash wrote is saved with its @handle');
const asking = parseInterviewReply('{"say":"What should it do? 😊","done":false}');
ok(!asking.done && asking.say.startsWith('What should it do') && asking.agent === null, 'a question stays a question');
const fenced = parseInterviewReply('Sure!\n```json\n{"say":"Who is it for? 🙂","done":false}\n```');
ok(!fenced.done && fenced.say === 'Who is it for? 🙂', 'JSON inside fences or prose is still found');
const thinky = parseInterviewReply('<think>hm {"x":1}</think>{"say":"Tone? 🎯","done":false}');
ok(thinky.say === 'Tone? 🎯', 'reasoning tags are dropped');
const plain = parseInterviewReply('What do you want it to do? 🚀');
ok(!plain.done && plain.say === 'What do you want it to do? 🚀', 'plain text is shown as the next question instead of breaking the chat');
const half = parseInterviewReply('{"say":"Tell me more about the \\"job\\" 🤔","don');
ok(!half.done && half.say.includes('Tell me more about the "job"'), 'a cut-off JSON reply still yields its question');
const early = parseInterviewReply(JSON.stringify({ say: 'Done!', done: true, agent: { name: 'X', instructions: 'too short' } }));
ok(!early.done, 'done without real instructions keeps interviewing');
ok(agentFromInterview({ name: 'N', model: 'weird', web: false, linux: true, instructions: LONG }).model === 'flash' && agentFromInterview({ name: 'N', model: 'weird', linux: true, instructions: LONG }).linux === false, 'unknown brain falls back to Flash and Linux needs Math & Code');
ok(agentFromInterview({ name: 'N', model: 'search', web: false, instructions: LONG }).web === true, 'a research agent always gets the web');
ok(agentFromInterview({ instructions: LONG }).name.length > 0, 'a missing name is filled in');
const iMsgs = interviewerMessages([{ role: 'assistant', content: 'Hi! What job?' }, { role: 'user', content: 'review my code' }]);
ok(iMsgs[0].role === 'system' && iMsgs[1].role === 'user' && iMsgs.at(-1).content === 'review my code', 'the interview always starts on a user turn');
ok(interviewerMessages([]).length === 2 && interviewerMessages([], { force: true }).at(-1).content.includes('Create the agent now'), 'an empty chat gets a kick-off and "wrap up" can be forced');
ok(/ONE short question/.test(AGENT_INTERVIEWER_SYSTEM) && /did not understand/.test(AGENT_INTERVIEWER_SYSTEM) && /emoji/.test(AGENT_INTERVIEWER_SYSTEM), 'Flash is told to ask one question, re-ask what it did not understand, and use emoji');

// ---- emoji everywhere
const emojiSys = (prefs) => systemFor('chat', prefs, {});
ok(/use them frequently/i.test(emojiSys({})) && /use them frequently/i.test(emojiSys({ emoji: 'light' })) && /use them frequently/i.test(emojiSys({ emoji: 'lots' })), 'chat AIs use emoji frequently by default, even for the old "light" setting');
ok(/Do not use emoji/.test(emojiSys({ emoji: 'none' })), 'an explicit "none" is still respected');
ok(/Use emoji frequently/.test(agentPrompt({ name: 'A', handle: 'a', instructions: 'do things' })), 'agents are told to use emoji too');
ok(/use them frequently/i.test(systemFor('math', {}, {})) && /use them frequently/i.test(systemFor('research', {}, {})), 'Math & Code and Deep Search get the emoji rule as well');


// ---- the built-in Planner agent
ok(cleanAgent(PLANNER_AGENT)?.handle === 'planner' && AGENT_TEMPLATES[0] === PLANNER_AGENT, 'Planner is a valid agent and the first template');
ok(/emoji/i.test(PLANNER_AGENT.instructions) && /Next step/.test(PLANNER_AGENT.instructions), 'Planner plans in steps and uses emoji');
const first = withStarterAgents([], []);
ok(first.list.length === 1 && first.list[0].handle === 'planner' && first.list[0].name === 'Planner' && first.seeded.includes('planner') && first.changed, 'a fresh install gets Planner');
const again = withStarterAgents(first.list, first.seeded);
ok(again.list.length === 1 && !again.changed, 'it is not added twice');
const deleted = withStarterAgents([], ['planner']);
ok(deleted.list.length === 0 && !deleted.changed, 'a deleted Planner stays deleted');
const mine = upsertAgent([], { name: 'Planner', handle: 'planner', instructions: 'my own planner' });
const kept = withStarterAgents(mine, []);
ok(kept.list.length === 1 && kept.list[0].instructions === 'my own planner', 'an existing @planner is never overwritten');
ok(withStarterAgents(many, []).list.length === MAX_AGENTS, 'a full list is left alone');
// loadAgents seeds and saves
const store = {};
globalThis.chrome = { storage: { local: { get: async (k) => Object.fromEntries([].concat(k).map((n) => [n, store[n]])), set: async (o) => Object.assign(store, o) } } };
const { loadAgents } = await import('../../src/lib/agents.js');
const loaded = await loadAgents();
ok(loaded.length === 1 && loaded[0].handle === 'planner' && store.viora_agents?.length === 1 && store.viora_agents_seeded?.includes('planner'), 'loadAgents installs Planner and remembers it');
ok((await loadAgents()).length === 1, 'loading again does not add another');

console.log(pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
