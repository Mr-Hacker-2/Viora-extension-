import {profileOf,profileNote,locateSentences,parseRepairs,repairFlagged,humanizeLoop,analyzeText,polish,registerOf,registerHint,critique,cleanOutput} from '../../src/lib/humanizer.js';
import {systemFor,NOWEB_NOTE} from '../../src/lib/prompts.js';
import {skipsWeb,isCasualChat} from '../../src/lib/web.js';
let pass=0,fail=0;const ok=(c,m)=>{c?pass++:fail++;console.log(c?'ok  ':'FAIL',m)};
const sample=`I never planned on writing this. Honestly, I just needed to get it down. The first week was a mess, and I mean a real mess, with boxes everywhere and no clue where the kettle was. We found it on day four. Behind the sofa? Don't ask. Then things settled, slowly, the way they do when you stop fighting them. My sister came round and laughed at the state of the kitchen. She wasn't wrong. By the end of the month I could find my keys again, which felt like winning something. It's funny how small the wins get. But they count. And I'll take them. Looking back, I'd do it all the same, except maybe the sofa bit. The neighbours were kind, mostly. One brought round a lasagne and a spare lamp, which we still use. I keep meaning to return the dish. It's been months, and that's a bit embarrassing, but she hasn't asked. Maybe I'll bake something instead. Nothing fancy. Just something warm.`;
const p=profileOf(sample);ok(p&&p.mean>3&&p.shortPct>0&&p.contractions>0,'profileOf measures a real sample: '+JSON.stringify(p));
ok(profileOf('too short')===null,'tiny sample ignored');
ok(/Sentences average/.test(profileNote(p))&&/never the sample/.test(profileNote(p)),'note tells model to copy habits not sentences');
// prompt wiring
const sys=systemFor('humanize',{}, {settings:{prefs:{writingSample:sample},humanizer:{style:[]}}});
ok(sys.includes('Measured from this person'),'writing sample reaches the humanize system prompt');
ok(!systemFor('humanize',{}, {settings:{prefs:{},humanizer:{style:[]}}}).includes('Measured from'),'no sample, no block');
// locate / parse
const text='One thing is clear. Furthermore, it is important to note that results vary widely. We tested 42 devices in 2024.';
ok(locateSentences(text,['Furthermore,  it is important to note that results vary widely.']).length===1,'locates flagged sentence despite whitespace diff');
ok(parseRepairs('```json\n["a b","c d"]\n```',2)?.length===2&&parseRepairs('["a"]',2)===null&&parseRepairs('nope',1)===null,'parseRepairs strict on count/shape');
// repairFlagged: fixes flagged, protects facts, leaves others
const msgs=[{role:'system',content:'S'},{role:'user',content:'u'}];
let r=await repairFlagged({text,flagged:['Furthermore, it is important to note that results vary widely.'],messages:msgs,rewrite:async()=>'["Results swing a lot."]'});
ok(r&&r.includes('Results swing a lot.')&&r.includes('One thing is clear.')&&r.includes('42 devices'),'only the flagged sentence changed');
r=await repairFlagged({text,flagged:['We tested 42 devices in 2024.'],messages:msgs,rewrite:async()=>'["We tried a bunch of devices."]'});
ok(r===null,'replacement that drops "42"/"2024" is rejected');
r=await repairFlagged({text,flagged:['One thing is clear.'],messages:msgs,rewrite:async()=>'garbage'});ok(r===null,'unusable model reply -> null (falls back)');
// loop: targeted repair is used, then detector rescored
const src='The framework is robust. Furthermore, it is crucial to understand that outcomes may vary. In conclusion, the approach is effective and scalable for many teams today. We shipped 3 releases.';
let calls=[];const rewrite=async(m)=>{const u=m.at(-1).content;calls.push(u.startsWith('Rewrite each numbered')?'repair':'full');if(u.startsWith('Rewrite each numbered'))return JSON.stringify(['Honestly it holds up fine.','Results swing, so test it first.'].slice(0,(u.match(/^\d+\. /gm)||[]).length));return 'The framework holds up. Furthermore, it is crucial to understand that outcomes may vary. It scales for plenty of teams. We shipped 3 releases.';return 'The framework holds up. Results swing, so test it first. It scales for plenty of teams. We shipped 3 releases.'};
let n=0;const check=async(t)=>({percent:n++===0?80:5,flagged:[t.split(/(?<=[.!?])\s+/)[1]]});
const out=await humanizeLoop({source:src,messages:msgs,rewrite,check,targeted:true,escalate:false,maxRetries:3,target:10});
ok(calls.includes('repair'),'loop attempted targeted repair after detector flagged sentences ('+calls.join(',')+')');
ok(out.detector?.percent<=10||out.passed,'final result passes after repair');
// regression: targeted=false behaves as before (no repair prompts)
calls=[];n=0;await humanizeLoop({source:src,messages:msgs,rewrite,check,targeted:false,escalate:false,maxRetries:2,target:10});
ok(!calls.includes('repair'),'targeted off -> old behaviour');

// --- the "Grammarly voice" fix ---
const tidy="Relocating to a new city can feel overwhelming, yet it offers many opportunities for growth. Stepping outside your comfort zone helps you build resilience, form connections, and discover new passions. The experience also encourages independence and confidence in everyday situations. Organizations that invest in their people tend to see better outcomes over time. Effective communication is essential to an organization's success, as it promotes collaboration. It also keeps everyone aligned on shared goals and priorities.";
const rough="Moving to a new city is a lot. It's also kind of great, though, because you get pushed out of your comfort zone and come out tougher than you went in. You meet people you'd never have crossed paths with. And half the time, out of nowhere, you stumble into something you end up loving. Companies do better when people actually talk to each other. Teams work together more easily and get more done, and everybody ends up knowing what the goal is. Simple as that.";
const tA=analyzeText(tidy),rA=analyzeText(rough);
ok(tA.score>rA.score+20,'over-polished text scores clearly worse than loose human text ('+tA.score+' vs '+rA.score+')');
ok(analyzeText(tidy).parts.some(p=>['texture','rhythm','vocab'].includes(p.key)),'tidy text is flagged for something concrete');
ok(/Too polished/.test(critique({score:40,signals:{meanSentence:15},parts:[{key:'texture',weight:9,risk:1,why:''}],flagged:[]})),'critique tells the model to let a person back in');
ok(registerOf(rough)==='casual'&&registerOf('too short')==='','register: casual text and tiny text');
const formalText="This paper argues that organisational frameworks require substantial methodological consideration. Furthermore, the literature suggests that stakeholders respond to implementation variability. Consequently, the analysis proposes a comprehensive evaluation of institutional arrangements, respectively. Research suggests that this methodology remains appropriate, whereas earlier implementation studies were limited.";
ok(registerOf(formalText)==='formal'&&/formal/.test(registerHint(formalText)),'register: formal text gets a formal hint');
ok(!/;/.test(polish('The first idea is simple and clear to every reader here today. The second idea is just as simple and clear to every reader here today. The third idea is also simple and clear to every reader here today. The fourth one wraps up the whole point nicely for everybody.',{rhythm:'force'}).text),'rhythm joins never use a semicolon');
ok(polish('We should utilize numerous methods to obtain additional data.',{register:''}).text.includes('get extra data'),'informal swaps apply to ordinary text');
ok(polish('We should obtain additional data.',{register:'formal'}).text.includes('obtain additional'),'but not to formal text');
ok(!/a many of|an more/.test(polish('A myriad of options and a plethora of choices exist.').text),'swaps keep articles agreeing');
// 7.12: output cleanup, new AI tells, and the wider no-web gate
ok(cleanOutput("Sure! Here's the rewritten version:\n\n\"It's a lot.\"\n\nLet me know if you want it shorter.")==="It's a lot.",'cleanOutput strips preface, quotes and closing offer');
ok(cleanOutput('```\nPlain text here.\n```')==='Plain text here.','cleanOutput unwraps a code fence');
ok(cleanOutput('He said "no" and left. Then "yes".')==='He said "no" and left. Then "yes".','cleanOutput leaves real quotes alone');
ok(analyzeText('The plan went well, ensuring that every team stayed aligned, allowing leaders to act fast, highlighting the value of clear goals. It stands as a testament to what a cornerstone habit can do for a committed group of people.').parts.some(p=>p.key==='vocab'),'participle tails and cornerstone/testament count as stock wording');
for(const t of ['hi','hey bro whats up','write me a poem about dogs','rewrite this email to be nicer: hi John, price results are in','how do I reverse a string in python','whats 2+2','what is 15% of 240','explain that again','tell me a joke','shorter please','can you help me write a cover letter']) ok(skipsWeb(t),'no web for: '+t);
for(const t of ['latest iphone price','who is the ceo of apple','weather in Detroit','hi, what is the weather in Detroit','write a post about the latest iPhone','summarize https://example.com','bitcoin price','who won the game last night','best laptops 2026']) ok(!skipsWeb(t),'still searches: '+t);
ok(systemFor('chat',{}, {noWeb:true}).includes(NOWEB_NOTE)&&!systemFor('chat',{}, {}).includes(NOWEB_NOTE),'no-web turns carry the note, others do not');
ok(isCasualChat('hi')&&!isCasualChat('write me a poem'),'small talk check unchanged');
console.log(pass+' passed, '+fail+' failed');process.exit(fail?1:0)
