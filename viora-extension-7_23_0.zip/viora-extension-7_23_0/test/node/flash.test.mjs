import { flashTier, flashIntent, flashTemperature, flashModels } from '../../src/lib/flash.js';
import { MODELS, chainFor } from '../../src/lib/models.js';
import { systemFor } from '../../src/lib/prompts.js';
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? 'ok  ' : 'FAIL', m); };

ok(flashTier('hi') === 'quick', 'greeting is quick');
ok(flashTier('what is a good name for a cat') === 'quick', 'short plain question is quick');
ok(flashTier('') === 'quick', 'empty text is quick');
ok(flashTier('explain how closures work') === 'smart', '"explain" is smart');
ok(flashTier('compare postgres and mysql') === 'smart', 'comparison is smart');
ok(flashTier('why is this broken?\n```js\nfoo()\n```') === 'smart', 'code block is smart');
ok(flashTier('x '.repeat(200)) === 'smart', 'long message is smart');
ok(flashTier('what is this?', { hasImages: true }) === 'smart', 'pictures are smart');
ok(flashTier('what is this?', { attachments: 1 }) === 'smart', 'attached files are smart');
ok(flashTier('and what about the second option you mentioned earlier', { historyChars: 9000 }) === 'smart', 'follow-up in a long chat is smart');
ok(flashTier('one thing? and another?') === 'smart', 'several questions are smart');
ok(flashTier('solve 3x + 4 = 19') === 'smart', 'maths is smart');

ok(flashIntent('fix this function') === 'code', 'code intent');
ok(flashIntent('give me ideas for a party') === 'creative', 'creative intent');
ok(flashIntent('how is your day') === 'chat', 'chat intent');
ok(flashTemperature('fix this function', 0.6) === 0.3, 'code runs cooler');
ok(flashTemperature('write me a poem', 0.6) === 0.85, 'creative runs warmer');
ok(flashTemperature('how is your day', 0.6) === 0.6, 'chat keeps the default');

const base = MODELS.flash.chain;
const plain = chainFor('flash', { overrides: {}, resolved: {} });
const quick = flashModels('quick', { chain: plain, base });
ok(quick[0] === base[0], 'quick keeps the fast model first');
ok(JSON.stringify(quick) === JSON.stringify(plain), 'quick leaves the chain alone');
const remembered = chainFor('flash', { overrides: {}, resolved: { flash: base[0] } });
const smart = flashModels('smart', { chain: remembered, base });
ok(smart[0] === base[1], 'smart puts the stronger model first even when the small one answered last');
ok(smart.includes(base[0]) && smart.length === new Set(remembered).size, 'smart drops nothing and adds nothing');
const pinned = flashModels('smart', { chain: chainFor('flash', { overrides: { flash: 'my/model' }, resolved: {} }), base, override: 'my/model' });
ok(pinned[0] === 'my/model', 'a model pinned in Settings still wins');

const chat = systemFor('chat', {});
ok(chat.includes('Quality bar'), 'chat prompt carries the Flash quality bar');
ok(chat.includes('Heart and teaching') && chat.includes('Never say an action worked'), 'older chat rules are still there');
console.log(pass + ' passed, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
