// Phase 0A: the storage interface, and the memory journey (J6) through it.
let pass = 0, fail = 0;
const ok = (c, l) => { if (c) { pass++; console.log('ok  ', l); } else { fail++; console.log('FAIL', l); } };

const data = {};
let quota = false;
globalThis.chrome = { storage: { local: {
  get: async (k) => Object.fromEntries([].concat(k).map((n) => [n, structuredClone(data[n])]).filter(([, v]) => v !== undefined)),
  set: async (o) => { if (quota) throw new Error('QUOTA_BYTES quota exceeded'); Object.assign(data, structuredClone(o)); }
} } };

const { chromeBackend, KINDS } = await import('../../src/lib/store.js');
const { getEpisodes, setEpisodes } = await import('../../src/lib/storage.js');
const { mergeEpisode, recallEpisodes, EPISODE_CAP } = await import('../../src/lib/memory.js');

const s = chromeBackend();
const rec = (id, extra = {}) => ({ id, text: `note ${id}`, ...extra });

// --- contract
ok((await s.list('episodes')).length === 0, 'empty kind lists as []');
ok((await s.get('episodes', 'x')) === null, 'missing record is null');
ok((await s.put('episodes', rec('a'))).ok, 'put returns ok');
await s.put('episodes', rec('b')); await s.put('episodes', rec('c'));
ok((await s.list('episodes')).map((r) => r.id).join() === 'a,b,c', 'put appends in order');
await s.put('episodes', rec('b', { text: 'changed' }));
ok((await s.list('episodes')).length === 3 && (await s.get('episodes', 'b')).text === 'changed', 'put with same id replaces');
ok((await s.list('episodes', { limit: 2 })).length === 2, 'limit');
ok((await s.list('episodes', { after: 'a', limit: 1 }))[0].id === 'b', 'after + limit pages');
await s.delete('episodes', 'b');
ok((await s.list('episodes')).map((r) => r.id).join() === 'a,c', 'delete removes one');
const st = await s.stat('episodes');
ok(st.count === 2 && st.bytes > 0 && st.backend === 'chrome', 'stat');
ok(!(await s.put('episodes', { text: 'no id' })).ok, 'record without id is refused');
let threw = false; try { await s.list('nope'); } catch { threw = true; }
ok(threw, 'unknown kind is a programming error, not silent');
ok(KINDS.episodes === 'episodes', 'episodes keep their original storage key (no data move)');

// --- errors are returned, never thrown
quota = true;
const before = JSON.stringify(data.episodes);
const r = await s.put('episodes', rec('z'));
ok(r.ok === false && /quota/i.test(r.error), 'quota failure returned as {ok:false,error}');
quota = false;
ok(JSON.stringify(data.episodes) === before, 'failed write leaves existing data untouched');

// --- bad stored value degrades to empty, not a crash
data.episodes = 'corrupt';
ok((await s.list('episodes')).length === 0, 'non-array stored value reads as empty');
await s.replaceAll('episodes', []);

// --- old data written by 7.18/7.19 (plain array under "episodes") is read as-is
data.episodes = [{ id: 't1', text: 'Pi wifi setup', title: 'Pi', at: 1, count: 6 }];
ok((await getEpisodes())[0].id === 't1', 'legacy stored array is readable through getEpisodes');

// --- J6: memory learn + recall round-trip through storage.js
data.episodes = [];
let list = await getEpisodes();
list = mergeEpisode(list, { id: 'a', text: 'Planned a Raspberry Pi weather station with a BME280 sensor', title: 'Pi weather', at: 1000, count: 8 });
await setEpisodes(list);
list = mergeEpisode(await getEpisodes(), { id: 'b', text: 'Chose sourdough hydration ratios for baking', title: 'Bread', at: 2000, count: 6 });
await setEpisodes(list);
const saved = await getEpisodes();
ok(saved.length === 2, 'two episodes persisted');
const hit = recallEpisodes(saved, 'raspberry pi sensor wiring', { exclude: 'current' });
ok(hit.length >= 1 && hit[0].id === 'a', 'recall finds the relevant episode');
ok(!recallEpisodes(saved, 'raspberry pi sensor', { exclude: 'a' }).some((e) => e.id === 'a'), 'recall excludes the current thread');
await setEpisodes(mergeEpisode(await getEpisodes(), { id: 'a', text: 'updated', title: 'Pi weather', at: 3000, count: 12 }));
ok((await getEpisodes()).length === 2 && (await getEpisodes()).find((e) => e.id === 'a').text === 'updated', 'merge updates an existing episode in place');
await setEpisodes([]);
ok((await getEpisodes()).length === 0, 'clearing memory empties episodes');
quota = true;
let rejected = false; try { await setEpisodes([rec('q')]); } catch { rejected = true; }
quota = false;
ok(rejected, 'setEpisodes still rejects on a failed write (old contract)');
ok(EPISODE_CAP > 0, 'episode cap exists');

console.log(`${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
