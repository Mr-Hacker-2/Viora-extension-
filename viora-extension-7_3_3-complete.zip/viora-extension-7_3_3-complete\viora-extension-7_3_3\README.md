# Viora

A browser side panel with five assistants in it. Everything runs on Groq's free
tier, so there is no API key to find, paste, or pay for — install it and talk.

## The five

| | | |
|---|---|---|
| ⚡ | **Viora Flash** | Quick, chatty, good for most things |
| 🔎 | **Viora Deep Search** | Reads the live web and cites what it found |
| 🧮 | **Viora Math & Code** | Shows its working, writes proper fractions |
| 🤖 | **Viora Automate** | Clicks, types, navigates and *looks* at the page you're on |
| ✍️ | **Viora Humanizer** | Paste AI-sounding text, get it back in a human voice |

Switch with the pill next to the wordmark. Each one has its own accent colour,
its own opening line, and its own model behind it.

## Always on the web

**Every assistant checks the internet before it answers, every time** — Viora
Flash, Deep Search, Math & Code, Automate, the Humanizer, and a quiz round.
The pass runs in the panel itself — no API key, no server of ours
(`src/lib/web.js`):

1. Any link in your message is opened and read first. A `.pdf` link goes
   through the very same extractor file uploads use, so a paper you pasted is
   read, not guessed at.
2. The message (with its URLs removed) is searched — DuckDuckGo's HTML
   endpoint, its Lite one, and Bing's keyless RSS *race* each other, so the
   first engine that answers supplies the results. DuckDuckGo is preferred
   but bot-challenges whole networks for hours at a time; waiting out two
   dead endpoints before asking the one that works would cost twenty seconds
   and still end with no sources.
3. The top results' pages are opened and stripped to readable text — nav,
   scripts, footers and forms dropped, article text kept.
4. All of it is laid out as a numbered block in the system prompt: `[1] Title`,
   its URL, the search snippet, then the page's own words. The chat modes are
   told to answer *from those sources*, cite them as `[1]`, `[2]`…, and never
   to claim it searched when the lookup failed; Automate, the Humanizer and
   quiz rounds get the same block marked reference-only instead (below).
5. Whatever survives the budget (7000 characters, shared with history so the
   free-tier token meter isn't blown by research — 2500–3000 for the modes
   that re-send their prompt every retry or planning turn) is exactly the list
   the panel renders under the reply: inline `[1]` markers linking out, plus a
   strip of favicon chips. One list, so a marker can never point at a chip
   that doesn't exist.

Failures are honest rather than fatal: a page that refuses to read is listed
with "could not read it: …", a page that is too slow is reported as such (a
timeout is a failure, never mistaken for you pressing Stop), and if the whole
lookup fails the model is told the check didn't happen instead of being left
free to pretend it did — the chat modes say so out loud, the fixed-output
modes are told to stand down quietly rather than invent a claim about it.
Stop aborts the web pass mid-read like any other part of the turn.

**Automate, the Humanizer and quiz cards can't *write* citations** — one has
to reply with a single JSON object, another with the rewritten text and
nothing else. So for them the numbered block arrives under a **Reference
only** heading: use it to check your work, never to quote it, cite it, or
mention that a search happened. The strip of chips at the end of the reply is
drawn by the panel either way, so you see what the answer was checked against
without a single source having to be written into the answer itself.

**Source favicons** in Settings (`prefs.citations`, on by default) turns the
markers and chips off if you'd rather read an answer clean; the model still
sees the sources either way.

## Automate can see

Besides the numbered list of buttons and fields it always gets, Automate has a
`look` action: it screenshots the tab, a vision model (`VISION_CHAIN`) describes
the screenshot in plain text, and the planner reads that on its next turn. Use
it for canvas apps, image-heavy pages, or to confirm a click really worked. It
ends the current batch, since what it sees can change the plan. Writing into
rich editors (chat boxes, comment fields) now goes through `execCommand`
rather than assigning `textContent`, which those editors ignore.

## Humanizer

Paste text that reads like an AI wrote it; the reply is the same text with the
stock phrases and even rhythm removed — same meaning, facts and structure. Say
"shorter", "more casual" or "for a school essay" and it redoes the last rewrite
that way. It runs on Groq (`openai/gpt-oss-120b`, falling back to
`openai/gpt-oss-20b`, then `qwen/qwen3.8-27b`) with its own key,
`GROQ_HUMANIZER_KEY` in `src/lib/access.js`. It's a rewriting aid, not a
guarantee against AI detectors — those are unreliable in both directions.

**Learning your voice.** The first time you open the Humanizer it shows ten
question cards, one at a time, in place of the composer (`src/lib/style-questions.js`).
Seven are short writing tasks (introduce yourself, cancel plans, a formal email…)
and three ask you to describe your own habits and what sounds fake to you. Each
answer needs at least 25 and at most 500 characters — but **Skip** is on every
card and never blocked, so a card you don't want to answer doesn't hold up the
rest (one answer is enough to finish; skip all ten and it says so rather than
starting). Progress is saved after
every keystroke, so closing the panel mid-way loses nothing, and the header
stays usable — pick another Viora and the gate lifts. The answers are stored
on-device (`settings.humanizer`) and added to every rewrite's system prompt as
data about your style. Retake or clear them from the Humanizer's welcome screen
or Settings → *Humanizer writing style*.

**The AI check.** Every rewrite is scored before it is shown
(`src/lib/detector.js`). While it comes back above the target — 10% by default,
settable in Settings → *Humanizer AI check* — the Humanizer rewrites again,
feeding back the flagged sentences, up to five extra times. **If it is still
over the target after that, the draft is held back rather than shown**: you get
the score and a *Try again* button, and the whole rewrite starts over, so the
only text you are ever handed is text that passed. Six rewrites in a row can
trip the shared key's 8,000-tokens-a-minute bucket, so a stubborn piece may
need a second run. Texts under 15 words aren't scored — there isn't enough
there to read.

**Which detector.** By default it is Viora's own check, `localScore()` in
`src/lib/detector.js`: a weighted heuristic over the signals detectors
actually use — stock phrases (weighted by how much of a giveaway each is),
sentence-length evenness, repeated sentence openers, punctuation variety,
missing contractions and average word length, minus points for writing that
sounds like a person. It needs no key, runs offline, and the text never leaves
your machine. Paste a **ZeroGPT API key** into Settings and that takes over
instead; if ZeroGPT then refuses, Viora's check quietly takes the score rather
than leaving the rewrite unscored.

**How it is calibrated.** `test/tests.js` carries a corpus of five machine
passages and eight human ones — including formal, contraction-free human prose,
which is the case that matters: careless signals (even sentences, no
contractions, sparse punctuation) condemn careful human writing exactly as they
condemn machine prose, so those three only count once a stock phrase has
already been hit. Current spread: machine 44–83, human 0–4, so the 10% target
is reachable by a good rewrite and not by raw AI. Run `test/run.ps1` to see the
scores; the calibration row prints them.

Be honest about what this is: it is a much weaker instrument than a trained
detector, and 10% from it is a nudge rather than a verdict. **If the check
genuinely cannot run**, the rewrite still goes out but the bar under it reads
*NOT checked* with the reason in amber — an unscored rewrite must never look
like a passing one.

> **Why not ZeroGPT.** `api.zerogpt.com/api/detect/detectText` answers
> `403 "Please make a purchase before accessing this resource"` to anything
> that doesn't carry an `Origin: https://www.zerogpt.com` header — i.e. to
> anything that isn't their own website. Cookies make no difference; only the
> `Origin`/`Referer` header does (verified 2026-09). That header is a forbidden
> header name in `fetch()`, and setting it via `declarativeNetRequest` would
> mean impersonating their site to reach the free website tier through the paid
> API path — so Viora does **not** do it. GPTZero's API is a paid add-on
> (`401 Require login or API key` keyless), and every other "free detector API"
> I tested either needs a key or rejects every payload. There is no stable
> keyless detector API, which is why the default check is local.

## Speed

- A model that hasn't produced a first token in 10 seconds is dropped and the
  next one in its chain takes the turn (the last model is never timed out).
  A model is only remembered as "working" once it has actually started answering.
- Automate's reviewer gets at most two models, 6 seconds each, low reasoning
  effort and a short answer; if it's slow it's skipped and the planner's steps run.
- `quick` mode asks `openai/gpt-oss-*` models to think briefly.
- Groq counts the prompt *plus* the reserved reply against a small per-minute
  token ceiling, so a research-heavy turn can be refused as "request too large"
  before it runs. The reserved reply is shrunk to fit when that is enough
  (`providers.js` learns each model's ceiling from the refusal and sizes later
  turns to fit first time); when the prompt itself is over the ceiling the panel
  rebuilds the same turn with less context — page, then history, then the web
  block's text — rather than surfacing the error.

## The "+" menu

Click it to upload a file, to take a screenshot, to **Create Image**, or to
hand Viora one of your open tabs — pick one and its page content is read on
every turn until you remove the chip. Tab picking is a `pageContext()` read
(same one automation already used), not a screenshot: Viora gets the page's
text, not a picture of it. Listing tabs needs the `tabs` permission, which is
why Chrome will ask you to re-approve Viora after this update.

## Voice input

The mic button records your speech and transcribes it with Groq's
`whisper-large-v3`. It uses its own key (`GROQ_STT_KEY` in `src/lib/access.js`),
so transcription never draws on the shared chat budget (a personal key from
settings still wins for both). Tap to record, tap again when you're done, and
the text lands in the input box for you to review before sending.

Chrome hides the mic-permission prompt inside a docked side panel, so the
first time you tap the mic Viora opens a small popup that asks for microphone
access once (see `src/mic/`). If permission is blocked, it opens the site
settings instead. If the mic still can't be captured it falls back to Chrome's
built-in speech recognition, and the button hides if the browser supports
neither.

## Create Image

**Create Image** in the "+" menu drops `Create an image of ` into the box and
puts the cursor after it — you describe the picture, press Enter, and it comes
back as an image on the reply. Typing the request yourself works the same way:
"Create an image of a fox in the snow", "draw me a picture of a cat in the
rain", "can you make a logo for my bakery". Both routes run through
`detectImageRequest()` (`src/lib/image-request.js`), which parses the subject
out of the sentence rather than matching the button's wording.

Saying just "Create an image" gets you "what should it show?" instead of a
blank render — the next thing you type is taken as the subject, and the flag
clears after that turn so an unrelated remark can't get drawn by accident.

Detection is deliberately conservative. A creation verb or an explicit ask has
to be there, so "what does the image of the chart show?" is left alone; the
noun has to be a picture-word, so "draw me a diagram of the cycle" stays a chat
reply; and if the words between the ask and the noun are about *reading* an
image (explain, describe, what, …) it's a question about something that
already exists. A false positive here doesn't just answer badly, it steals the
turn from the chat and spends a render.

The render itself is FLUX.1-dev on NVIDIA, with its own key
(`NVIDIA_IMAGE_KEY` in `src/lib/access.js`) so a few pictures never eat
Automate's planner budget. The endpoint needed four measurements to pin down
(all of it is written up at the top of `src/lib/imagegen.js`), but the two
worth repeating here: it is **not** the OpenAI-compatible
`integrate.api.nvidia.com/v1` the chat calls use — `/v1/images/generations`
there answers `404 page not found`, cloud image generation lives on
`ai.api.nvidia.com/v1/genai/<vendor>/<model>` with every model on its own URL —
and FLUX.1-**schnell**, the obvious pick, is unusable: it accepts the request
and then hangs for 302 seconds before answering `504`, four times out of four.
FLUX.1-dev answers in one to two seconds instead. Its size fields are an
allow-list rather than a range, so 512 comes back 422 and 768 is the floor, and
its parameters are stricter than schnell's — `cfg_scale` above 1 and `steps` of
at least 5, or the call is rejected before it runs.

The answer is JPEG whatever the docs promise, so the format is sniffed from the
bytes rather than assumed. A prompt can also come back `finishReason:
"CONTENT_FILTERED"` with a few kilobytes of blank image in it — that gets one
retry against a fresh seed, then is reported as a refusal rather than shown as
a picture. Images are re-encoded to a capped JPEG before storage
(`toJpegDataUrl`) and kept **out of the message's `content`**, because content
is what goes back to the model as history and a big base64 blob would blow the
context budget on the very next turn. Saving a thread now degrades instead of
failing if storage fills up: the oldest images are dropped and the write
retried, rather than turning a finished reply into an error.

## Copy, view, download

Every finished reply carries a **Copy** button. It takes the text as it reads on
screen — not the markdown it was rendered from — read from a laid-out clone of
the bubble so the block breaks survive: source chips and per-block buttons are
dropped, `[1]` citation markers are written back as `[1]` rather than copying as
a bare favicon-less digit. `navigator.clipboard` first, with a hidden-textarea
`execCommand` fallback for the times the side panel has just lost focus.

A generated picture adds **View** and **Download** next to Copy, and the picture
itself is clickable (Enter, since it is focusable) to open the same full-size
viewer — Esc, the backdrop or the Close button dismiss it, and it carries its own
Download. Saving goes through `chrome.downloads` with a plain anchor behind it
and lands as `viora-image-YYYYMMDD-HHMMSS.jpg`. The buttons hang off the message
node rather than inside `.body`, because the body's HTML is replaced on every
streamed frame; only the final renderer attaches them, so nothing flickers while
a reply streams.

## Images

Uploaded images go to `qwen/qwen3.8-27b` — the vision model Groq serves today
(`VISION_CHAIN` in `src/lib/models.js`). Images are downscaled client-side, up
to three per request, and sent alongside your message; any model you're
talking to will use them. If Groq ever retires that model, the chat will say
so and Settings can list what's live to pin a replacement.

## Icons, not emoji

The interface itself never speaks in emoji — `src/lib/icons.js` is a small
set of stroke icons (one per assistant, plus upload/tab/mic/check/plus/image) that
every bit of chrome draws from instead: the model pill, the welcome screen,
the picker rows, the reply badge, thread history. Only Viora's own replies
use emoji, and only at whatever level is set in **Emoji** under settings.

## Maths

Viora renders LaTeX itself — no engine is bundled, because the extension's CSP
forbids remote scripts and KaTeX is far too heavy for a side panel. `src/lib/math.js`
covers what an assistant actually writes:

- `\frac{3}{4}` draws as a stacked fraction with a rule, not `3/4`
- `\sqrt{x}`, `\sqrt[3]{x}`, `x^{2}`, `a_{n}`
- `\le \ge \ne \approx \pm \times \cdot \infty \sum \int` and the Greek alphabet
- `\begin{pmatrix} … \end{pmatrix}`, `cases` and `aligned` render as a grid of
  rows and cells with the brackets drawn round it, not the word "pmatrix"
- `\%`, `\{…\}`, `\&` keep their character instead of disappearing
- ASCII stand-ins typed by habit (`>=`, `<=`, `!=`, `->`, `+-`) are converted
- a bare `3/4` between `$…$` is promoted to a real fraction

The system prompt tells every model to write maths this way, so it usually
arrives already correct.

## Voice

Viora is warm by default: it reacts, has opinions, and uses the occasional
emoji. That's a character, not a claim about inner life — and it never buys
agreeableness with accuracy. It still says "I'm not sure", still disagrees when
you're about to do something that won't work. Both can be turned down in
settings: **Voice → Plain** and **Emoji → None**.

## 100+ ways to write

`src/lib/styles.js` is a catalogue of over 100 writing techniques — structures
(numbered lists, tables, timelines, decision trees), tones (blunt, deadpan,
tactful…), sentence craft (rule of three, antithesis, fragments), reasoning
rhetoric (steelman, pre-mortem, inversion) and ready-made formats (emails,
cover letters, poems, release notes, post-mortems). Ask for one by name —
"write this as a bulleted list, formal tone", "draft a cover letter", "as a
haiku" — and the matching techniques are folded into that turn's system
prompt, each with a one-line instruction.

They load **on demand only**: `matchStyles()` requires the message to both
name a technique and read as a writing request (a stray "did you get my
email?" pulls in nothing), caps what's injected at four techniques and 900
characters, and an ordinary turn pays zero tokens — which matters, because
the shared key meters 8,000 tokens a minute. The Humanizer, Automate and
quiz cards never receive them: those must emit only rewritten text or only
their JSON object.

## Settings

There are no credential fields, because there are no credentials to enter. What
is there:

- which Viora opens by default
- voice and emoji level
- reply length, working-shown, source favicons
- model IDs, if you want to pin a specific Groq model to one of the four
- an optional personal Groq key, for when the shared one hits a rate limit

## Tests

There is no bundler and no test framework here, so the suite is a web page:
`test/server.ps1` serves the workspace (and proxies `/proxy?url=…`, which
reproduces the `<all_urls>` host permission an extension page has and a web
page doesn't), and `test/run.ps1` opens `test/index.html` in headless Chrome,
lets it run in real time, and prints the verdict. The live checks hit the real
DuckDuckGo/Bing and real pages through that proxy.

```
powershell -NoProfile -ExecutionPolicy Bypass -File .\test\server.ps1   # keep running
powershell -NoProfile -ExecutionPolicy Bypass -File .\test\run.ps1
```

## About the shipped key

`src/lib/access.js` contains a Groq key in plain text. Two consequences worth
knowing about:

1. Anyone who installs Viora can read it out of the source. It is not secret.
2. Groq counts free-tier limits **per key, not per user**. Every install shares
   one budget, so rate limits arrive quickly once more than a handful of people
   are using it.

Viora softens this in the client (`src/lib/providers.js`): a request that only
just misses the minute's token budget is shrunk to fit and re-sent at once, short
resets are waited out, and only then does it fall back to the next model. Page
context, chat history and Flash's reply reservation are kept lean for the same
reason. It can't create budget that isn't there, though — with many installs on
one key, the fix is per-user keys or a proxy.

The optional key field in settings is the escape hatch: a free key from
console.groq.com, stored on-device, takes over for that install. If the shared
key gets abused, rotate it in `access.js` and ship a new version.

## Model IDs

Groq retires model IDs on its own schedule. Each assistant carries a fallback
chain (`src/lib/models.js`); a dead ID is skipped automatically and the one that
answered is remembered. If a whole chain dies, the error offers a live list of
what Groq is serving so you can pin a replacement without editing code.

## Install

1. `chrome://extensions` → enable Developer mode
2. Load unpacked → choose this folder
3. Ctrl+Shift+Y (Cmd+Shift+Y) opens the panel

## Build

```
./scripts/build.sh
```

Validates the manifest, checks every referenced file exists, checks no key has
leaked outside `access.js`, and writes `dist/viora-extension-<version>.zip`.

## Layout

```
src/
  lib/
    access.js      the shipped keys + base URLs
    models.js      the five assistants and their model chains
    providers.js   Groq streaming client with chain fallback
    prompts.js     system prompts: voice, emoji, maths rules
    styles.js      100+ writing techniques, injected on demand
    math.js        LaTeX subset → HTML
    markdown.js    markdown + maths + tables, escaped throughout
    storage.js     settings and saved threads
    style-questions.js  the Humanizer's ten onboarding cards
    citations.js   source chips and inline markers
    web.js         the always-on web pass: search, page/PDF reading, budget
    automation.js  page snapshots and action running
    files.js       attachments (and the shared PDF text extractor)
  mic/             microphone permission bridge (popup that asks Chrome once)
  sidepanel/       the panel
  options/         settings
  background/      service worker
  content/         page-side helpers
```
