/**
 * Viora — side panel controller.
 * One backend, four personalities. Owns the thread, runs the turn, renders it.
 */

import {
  getSettings, saveSettings, getThreads, saveThread, deleteThread, newThread,
  groqConfig, rememberModel
} from '../lib/storage.js';
import { MODELS, MODEL_ORDER, VISION_CHAIN, getModel, chainFor } from '../lib/models.js';
import { streamChat, completeChat, listModels, ProviderError, transcribeAudio } from '../lib/providers.js';
import { renderMarkdown, bindCodeCopy, escapeHtml } from '../lib/markdown.js';
import { sourceStrip, linkInlineMarkers, extractTrailingSources } from '../lib/citations.js';
import { systemFor, withPageContext } from '../lib/prompts.js';
import { readFile, attachmentsToText, attachmentsToContent, LIMITS } from '../lib/files.js';
import { icon, MODEL_ICON } from '../lib/icons.js';
import {
  activeTab, openTabs, snapshot, pageContext, parsePlan, runPlan, describeAction,
  isRestrictedUrl, PageAccessError, MAX_TURNS, MAX_TOTAL_ACTIONS
} from '../lib/automation.js';

const $ = (sel) => document.querySelector(sel);

const el = {
  root: document.documentElement,
  thread: $('#thread'),
  welcome: $('#welcome'),
  welcomeIcon: $('#welcome-icon'),
  welcomeLine: $('#welcome-line'),
  suggestions: $('#suggestions'),
  form: $('#composer'),
  input: $('#input'),
  send: $('#send'),
  hint: $('#hint'),
  status: $('#status'),
  attach: $('#attach'),
  attachSheet: $('#attach-sheet'),
  attachUpload: $('#attach-upload'),
  attachUploadIcon: $('#attach-upload-icon'),
  tabsDivider: $('#tabs-divider'),
  tabList: $('#tab-list'),
  fileInput: $('#file-input'),
  attachTray: $('#attach-tray'),
  pageChip: $('#page-chip'),
  pageChipIcon: $('#page-chip-icon'),
  pageChipTitle: $('#page-chip-title'),
  pageChipRemove: $('#page-chip-remove'),
  mic: $('#mic'),
  micIcon: $('#mic-icon'),
  modelBtn: $('#model-btn'),
  modelSheet: $('#model-sheet'),
  modelList: $('#model-list'),
  pillIcon: $('#pill-icon'),
  pillName: $('#pill-name'),
  drawer: $('#drawer'),
  threadList: $('#thread-list'),
  threadEmpty: $('#thread-empty')
};

const OPENERS = {
  flash: 'What are we working on?',
  search: 'What should I go and find out?',
  math: 'Give me something to chew on.',
  automate: 'What should I do on this page?'
};

const SUGGESTIONS = {
  flash: ['Summarise what I am reading', 'Draft a reply to this email', 'Talk me through two options'],
  search: ['What changed in EU AI rules this year?', 'Compare this year’s flagship phone cameras', 'Is this library still maintained?'],
  math: ['Solve 3x² − 7x + 2 = 0 step by step', 'Why does this throw a null reference?', 'Write a debounce hook in TypeScript'],
  automate: ['Fill this form with my details', 'Read me the pricing table', 'Open the first search result']
};

let settings = await getSettings();
let config = groqConfig(settings);
let thread = newThread(settings.prefs.model);
let controller = null;
let busy = false;
let pendingAttachments = [];
/** The tab picked from the "+" menu, if any — its page is read on every turn until removed. */
let selectedPage = null;

/* ---------------- shell ---------------- */

function current() {
  return getModel(thread.model);
}

function chain(choice = thread.model) {
  return chainFor(choice, {
    overrides: settings.modelOverrides,
    resolved: settings.resolvedModels
  });
}

/** Remember which ID answered, so the dead ones aren't retried next turn. */
function noteModel(choice) {
  return async (modelId) => {
    if (settings.resolvedModels[choice] !== modelId) {
      settings = await rememberModel(choice, modelId);
    }
  };
}

function setModel(choice) {
  thread.model = choice;
  const model = current();
  el.root.dataset.model = choice;
  el.pillIcon.innerHTML = icon(MODEL_ICON[choice]);
  el.pillName.textContent = model.name;
  el.modelBtn.title = model.blurb;
  el.input.placeholder = model.placeholder;
  el.welcomeIcon.innerHTML = icon(MODEL_ICON[choice]);
  el.welcomeLine.textContent = OPENERS[choice] || OPENERS.flash;

  el.attach.hidden = !model.canAttach;
  if (!model.canAttach) {
    if (pendingAttachments.length) {
      pendingAttachments = [];
      renderTray();
    }
    if (selectedPage) {
      selectedPage = null;
      renderPageChip();
    }
  }

  renderSuggestions();
  renderModelList();
  saveSettings({ prefs: { model: choice } });
}

function renderModelList() {
  el.modelList.replaceChildren();
  for (const id of MODEL_ORDER) {
    const model = MODELS[id];
    const li = document.createElement('li');

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'model-row';
    btn.dataset.model = id;
    btn.setAttribute('role', 'option');
    btn.setAttribute('aria-selected', String(id === thread.model));

    const rowIcon = document.createElement('span');
    rowIcon.className = 'row-icon';
    rowIcon.innerHTML = icon(MODEL_ICON[id]);

    const copy = document.createElement('span');
    copy.className = 'row-copy';
    const name = document.createElement('span');
    name.className = 'row-name';
    name.textContent = model.name;
    const blurb = document.createElement('span');
    blurb.className = 'row-blurb';
    blurb.textContent = model.blurb;
    copy.append(name, blurb);

    const tick = document.createElement('span');
    tick.className = 'row-tick';
    if (id === thread.model) tick.innerHTML = icon('check');

    btn.append(rowIcon, copy, tick);
    btn.addEventListener('click', () => {
      setModel(id);
      closeSheets();
      el.input.focus();
    });

    li.append(btn);
    el.modelList.append(li);
  }
}

function renderSuggestions() {
  el.suggestions.replaceChildren();
  for (const text of SUGGESTIONS[thread.model] || []) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'suggestion';
    b.textContent = text;
    b.addEventListener('click', () => {
      el.input.value = text;
      el.input.focus();
      autosize();
    });
    el.suggestions.append(b);
  }
}

function closeSheets() {
  el.modelSheet.hidden = true;
  el.drawer.hidden = true;
  el.attachSheet.hidden = true;
  el.modelBtn.setAttribute('aria-expanded', 'false');
  $('#history').setAttribute('aria-expanded', 'false');
  el.attach.setAttribute('aria-expanded', 'false');
}

/* ---------------- the "+" menu: upload a file, or read an open tab ---------------- */

/** Set an icon element's content to a tab's favicon, falling back to the generic tab glyph. */
function setFavicon(target, favIconUrl) {
  target.replaceChildren();
  if (!favIconUrl) {
    target.innerHTML = icon('tab');
    return;
  }
  const img = document.createElement('img');
  img.src = favIconUrl;
  img.alt = '';
  img.addEventListener('error', () => { target.innerHTML = icon('tab'); }, { once: true });
  target.append(img);
}

function renderPageChip() {
  if (!selectedPage) {
    el.pageChip.hidden = true;
    return;
  }
  el.pageChip.hidden = false;
  el.pageChipTitle.textContent = selectedPage.title;
  el.pageChipTitle.title = selectedPage.url;
  setFavicon(el.pageChipIcon, selectedPage.favIconUrl);
}

function pickPage(tab) {
  selectedPage = { id: tab.id, title: tab.title, url: tab.url, favIconUrl: tab.favIconUrl };
  renderPageChip();
  closeSheets();
  el.input.focus();
}

async function renderTabList() {
  el.tabList.replaceChildren();
  el.tabsDivider.hidden = true;

  let tabs;
  try {
    tabs = await openTabs();
  } catch {
    return;
  }
  // The panel's own window still counts, but there's nothing useful to
  // hand back for a tab Viora structurally can't read — show it, but disabled.
  if (!tabs.length) return;

  el.tabsDivider.hidden = false;
  for (const tab of tabs) {
    const li = document.createElement('li');
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'sheet-action tab-row';
    row.disabled = tab.restricted;
    if (tab.restricted) row.title = "Viora can't read this page.";

    const favicon = document.createElement('span');
    favicon.className = 'sheet-action-icon';
    setFavicon(favicon, tab.favIconUrl);

    const copy = document.createElement('span');
    copy.className = 'tab-copy';
    const title = document.createElement('span');
    title.className = 'tab-title';
    title.textContent = tab.title;
    const host = document.createElement('span');
    host.className = 'tab-host';
    try {
      host.textContent = new URL(tab.url).hostname;
    } catch {
      host.textContent = tab.url;
    }
    copy.append(title, host);

    row.append(favicon, copy);
    if (!tab.restricted) row.addEventListener('click', () => pickPage(tab));
    li.append(row);
    el.tabList.append(li);
  }
}

function setStatus(text) {
  el.status.textContent = text;
  el.status.hidden = !text;
}

function setBusy(state) {
  busy = state;
  el.send.classList.toggle('stop', state);
  el.send.setAttribute('aria-label', state ? 'Stop' : 'Send');
  el.hint.textContent = state ? 'Thinking' : '';
}

function scrollDown() {
  el.thread.scrollTop = el.thread.scrollHeight;
}

function autosize() {
  el.input.style.height = 'auto';
  el.input.style.height = `${Math.min(el.input.scrollHeight, 168)}px`;
}

/* ---------------- rendering ---------------- */

function clearWelcome() {
  if (el.welcome.isConnected) el.welcome.remove();
}

function attachmentChip(a, onRemove) {
  const chip = document.createElement('span');
  chip.className = 'attach-chip' + (a.warning ? ' has-warning' : '');
  if (a.warning) chip.title = a.warning;

  if (a.kind === 'image' && a.dataUrl) {
    const img = document.createElement('img');
    img.src = a.dataUrl;
    img.alt = '';
    chip.append(img);
  } else {
    const icon = document.createElement('span');
    icon.className = 'attach-icon';
    icon.textContent = a.kind === 'pdf' ? 'PDF' : 'TXT';
    chip.append(icon);
  }

  const name = document.createElement('span');
  name.className = 'attach-name';
  name.textContent = a.name;
  chip.append(name);

  if (onRemove) {
    const x = document.createElement('button');
    x.type = 'button';
    x.className = 'attach-remove';
    x.textContent = '×';
    x.setAttribute('aria-label', `Remove ${a.name}`);
    x.addEventListener('click', onRemove);
    chip.append(x);
  }
  return chip;
}

function addUser(text, attachments = []) {
  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg user';

  if (attachments.length) {
    const tray = document.createElement('div');
    tray.className = 'attach-chips';
    attachments.forEach((a) => tray.append(attachmentChip(a)));
    node.append(tray);
  }
  if (text) {
    const p = document.createElement('div');
    p.className = 'user-text';
    p.textContent = text;
    node.append(p);
  }

  el.thread.append(node);
  scrollDown();
}

function addAssistant() {
  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg assistant streaming';

  const badge = document.createElement('span');
  badge.className = 'who';
  badge.innerHTML = icon(MODEL_ICON[thread.model]);

  const trace = document.createElement('details');
  trace.className = 'reasoning';
  trace.hidden = true;
  const summary = document.createElement('summary');
  summary.textContent = 'Working it out';
  const pre = document.createElement('div');
  pre.className = 'trace';
  trace.append(summary, pre);

  const body = document.createElement('div');
  body.className = 'body';

  node.append(badge, trace, body);
  el.thread.append(node);
  scrollDown();

  return {
    node,
    body,
    setReasoning(text) {
      if (!settings.prefs.showReasoning || !text) return;
      trace.hidden = false;
      pre.textContent = text;
    },
    setMarkdown(text) {
      body.innerHTML = renderMarkdown(text);
    },
    finish() {
      node.classList.remove('streaming');
      bindCodeCopy(body);
    }
  };
}

function addError(err, retry, extra) {
  clearWelcome();
  const box = document.createElement('div');
  box.className = 'msg assistant';
  const inner = document.createElement('div');
  inner.className = 'error';
  inner.textContent = err.message || 'Something went wrong.';
  if (err.hint) {
    const fix = document.createElement('span');
    fix.className = 'fix';
    fix.textContent = err.hint;
    inner.append(fix);
  }
  if (retry) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'Try again';
    btn.addEventListener('click', () => {
      box.remove();
      retry();
    });
    inner.append(btn);
  }
  box.append(inner);
  if (extra) inner.append(extra);
  el.thread.append(box);
  scrollDown();
}

/**
 * When every model in a chain is gone, ask Groq what it does serve and let the
 * user pin one, rather than sending them hunting through settings.
 */
function modelPicker(choice, retryFn) {
  const wrap = document.createElement('div');
  wrap.className = 'model-fix';

  const load = document.createElement('button');
  load.type = 'button';
  load.textContent = 'Show what Groq is serving';

  load.addEventListener('click', async () => {
    load.disabled = true;
    load.textContent = 'Loading';
    try {
      const models = await listModels({ config });
      load.remove();

      const note = document.createElement('p');
      note.className = 'fix';
      note.textContent = `Groq has ${models.length} models right now. Pick the one ${getModel(choice).name} should use.`;

      const list = document.createElement('div');
      list.className = 'id-list';

      for (const id of models) {
        const b = document.createElement('button');
        b.type = 'button';
        b.textContent = id;
        b.addEventListener('click', async () => {
          settings = await saveSettings({ modelOverrides: { [choice]: id } });
          retryFn?.();
        });
        list.append(b);
      }

      wrap.append(note, list);
    } catch (err) {
      load.disabled = false;
      load.textContent = 'Show what Groq is serving';
      const fail = document.createElement('span');
      fail.className = 'fix';
      fail.textContent = err.message;
      wrap.append(fail);
    }
  });

  wrap.append(load);
  return wrap;
}

/* ---------------- history ---------------- */

async function refreshDrawer() {
  const threads = await getThreads();
  el.threadList.replaceChildren();
  el.threadEmpty.hidden = threads.length > 0;

  for (const t of threads) {
    const li = document.createElement('li');
    const row = document.createElement('div');
    row.className = 'thread-item';

    const open = document.createElement('button');
    open.type = 'button';
    open.className = 't-title';
    open.textContent = t.title;
    open.addEventListener('click', () => loadThread(t));

    const mark = document.createElement('span');
    mark.className = 't-mode';
    mark.innerHTML = icon(MODEL_ICON[t.model] || 'flash');
    mark.title = getModel(t.model).name;

    const del = document.createElement('button');
    del.type = 'button';
    del.className = 't-del';
    del.title = 'Delete';
    del.setAttribute('aria-label', `Delete ${t.title}`);
    del.textContent = '×';
    del.addEventListener('click', async () => {
      await deleteThread(t.id);
      refreshDrawer();
    });

    row.append(open, mark, del);
    li.append(row);
    el.threadList.append(li);
  }
}

function loadThread(saved) {
  thread = structuredClone(saved);
  closeSheets();
  el.thread.replaceChildren();
  setModel(thread.model || 'flash');

  for (const m of thread.messages) {
    if (m.role === 'user') {
      addUser(m.displayText ?? m.content, m.attachments || []);
    } else {
      const view = addAssistant();
      view.setReasoning(m.reasoning);
      view.setMarkdown(m.content);
      if (m.sources?.length) {
        linkInlineMarkers(view.body, m.sources);
        view.body.append(sourceStrip(m.sources));
      }
      view.finish();
    }
  }
  scrollDown();
}

async function persist(firstPrompt) {
  if (thread.title === 'New conversation' && firstPrompt) {
    thread.title = firstPrompt.replace(/\s+/g, ' ').slice(0, 52) + (firstPrompt.length > 52 ? '…' : '');
  }
  await saveThread(thread);
  refreshDrawer();
}

/* ---------------- the turn ---------------- */

async function collectPage() {
  if (!selectedPage) return null;
  try {
    return await pageContext(selectedPage.id);
  } catch (err) {
    setStatus(err.message || "Viora can't read that page.");
    return null;
  }
}

async function runChat() {
  const model = current();
  const page = await collectPage();
  const attachments = pendingTurnAttachments;
  const hasImages = attachments.some((a) => a.kind === 'image');

  // Images need a vision model whichever personality is selected.
  const models = hasImages ? [...VISION_CHAIN, ...chain()] : chain();
  const canSearch = model.canSearch && !hasImages;

  const messages = [
    { role: 'system', content: withPageContext(systemFor(model.prompt, settings.prefs), page) },
    ...thread.messages.map(({ role, content }) => ({ role, content }))
  ];

  if (hasImages) {
    const last = messages[messages.length - 1];
    last.content = attachmentsToContent(last.content, attachments);
  }

  const view = addAssistant();
  let content = '';
  let reasoning = '';

  // Some hosted reasoning models put their chain inline in <think> tags
  // instead of a separate field, so split it back out before rendering.
  const split = (raw) => {
    const open = raw.indexOf('<think>');
    if (open < 0) return { think: '', answer: raw };
    const close = raw.indexOf('</think>');
    return close < 0
      ? { think: raw.slice(open + 7), answer: '' }
      : { think: raw.slice(open + 7, close), answer: raw.slice(0, open) + raw.slice(close + 8) };
  };

  if (canSearch) setStatus('Searching the web');

  // Free-tier Groq caps qwen3.8-27b (the vision model) at 1000 output tokens
  // per minute and rejects a request that *expects* more before it runs, so
  // keep image turns modest no matter what the default maxTokens is.
  const maxTokens = hasImages ? Math.min(settings.prefs.maxTokens, 768) : settings.prefs.maxTokens;

  const result = await streamChat({
    config,
    models,
    messages,
    temperature: model.temperature,
    maxTokens,
    tools: canSearch ? [{ type: 'browser_search' }] : undefined,
    toolChoice: canSearch ? 'auto' : undefined,
    signal: controller.signal,
    onModel: noteModel(hasImages ? 'vision' : thread.model),
    onDelta: (d) => {
      if (d.reasoning) {
        reasoning += d.reasoning;
        view.setReasoning(reasoning);
      }
      if (d.content) {
        setStatus('');
        content += d.content;
        const { think, answer } = split(content);
        if (think) view.setReasoning(reasoning + think);
        view.setMarkdown(answer);
      }
      scrollDown();
    }
  });

  setStatus('');
  const { think, answer } = split(result.content);
  const cleaned = answer.trim();
  const { text: displayAnswer, sources } = canSearch
    ? extractTrailingSources(cleaned)
    : { text: cleaned, sources: [] };

  view.setMarkdown(displayAnswer);
  if (sources.length && settings.prefs.citations) {
    linkInlineMarkers(view.body, sources);
    view.body.append(sourceStrip(sources));
  }
  view.finish();

  thread.messages.push({
    role: 'assistant',
    content: displayAnswer,
    reasoning: (result.reasoning || think).trim(),
    sources
  });
}

/**
 * Works a task across as many planning turns as it needs, re-snapshotting the
 * page after each batch so the model always plans against what's on screen now.
 */
async function runAutomation(prompt) {
  const tab = await activeTab();
  if (!tab?.id) throw new ProviderError('No active tab to work with.');
  if (isRestrictedUrl(tab.url)) {
    throw new ProviderError("I can't act on this tab — it's a browser page, not a website.", {
      hint: 'Switch to a normal website tab and ask me again.'
    });
  }

  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg assistant';
  el.thread.append(node);
  scrollDown();

  let currentTabId = tab.id;
  const history = [];
  let lastThought = '';
  let totalActions = 0;
  let turn = 0;
  let finished = false;
  let failStreak = 0;
  let stopNote = '';

  while (!finished && turn < MAX_TURNS && totalActions < MAX_TOTAL_ACTIONS) {
    turn++;

    setStatus('Reading the page');
    let snap;
    try {
      snap = await snapshot(currentTabId);
    } catch (err) {
      stopNote = err instanceof PageAccessError ? err.message : 'Lost track of the tab.';
      break;
    }
    const elements = snap.elements
      .map((e) => `${e.ref}. <${e.tag}${e.type ? ` ${e.type}` : ''}> ${e.label}`)
      .join('\n');

    setStatus('Planning');
    const { content: raw } = await completeChat({
      config,
      models: chain('automate'),
      messages: [
        { role: 'system', content: systemFor('automate', settings.prefs) },
        {
          role: 'user',
          content: `Overall task: ${prompt}\n\n${
            history.length ? `Done so far:\n${history.join('\n')}\n\n` : ''
          }Current page: ${snap.title}\n${snap.url}\n\nElements:\n${elements}`
        }
      ],
      maxTokens: 700,
      signal: controller.signal,
      onModel: noteModel('automate')
    });

    const plan = parsePlan(raw);
    lastThought = plan.thought || lastThought;

    if (plan.thought) {
      const body = document.createElement('div');
      body.className = 'body';
      body.innerHTML = `<p>${escapeHtml(plan.thought)}</p>`;
      node.append(body);
    }

    const list = document.createElement('div');
    list.className = 'plan';
    node.append(list);

    const rows = plan.actions.map((action) => {
      const row = document.createElement('div');
      row.className = 'step';
      row.dataset.state = 'idle';
      const dot = document.createElement('span');
      dot.className = 'dot';
      const label = document.createElement('span');
      label.textContent = describeAction(action);
      const detail = document.createElement('span');
      detail.className = 'detail';
      row.append(dot, label, detail);
      list.append(row);
      return { row, detail };
    });
    scrollDown();

    setStatus('Running');
    let i = 0;
    const { results, finalTabId } = await runPlan(currentTabId, plan, (step) => {
      const ui = rows[i++];
      if (!ui) return;
      ui.row.dataset.state = step.ok ? 'ok' : 'fail';
      ui.detail.textContent = (step.detail || '').slice(0, 120);
      scrollDown();
    });
    setStatus('');

    currentTabId = finalTabId;
    totalActions += plan.actions.length;
    for (const r of results) {
      history.push(`- ${describeAction(r.action)}: ${r.ok ? r.detail || 'ok' : `failed — ${r.detail}`}`);
    }

    finished = plan.actions.some((a) => a.type === 'done');
    failStreak = results.some((r) => r.ok) ? 0 : failStreak + 1;
    if (failStreak >= 2) {
      stopNote = "Stopping — the last two batches didn't get anywhere. Try rephrasing, or check the page is what you expect.";
      break;
    }
  }

  if (!finished) {
    if (!stopNote) {
      stopNote = `Paused after ${totalActions} steps across ${turn} turn${turn === 1 ? '' : 's'} — say "continue" and I'll pick it up.`;
    }
    const note = document.createElement('div');
    note.className = 'body';
    note.innerHTML = `<p>${escapeHtml(stopNote)}</p>`;
    node.append(note);
  }

  thread.messages.push({
    role: 'assistant',
    content: `${lastThought}\n\n${history.join('\n')}${finished ? '' : `\n\n${stopNote}`}`
  });
}

/* ---------------- send ---------------- */

function renderTray() {
  el.attachTray.replaceChildren();
  el.attachTray.hidden = pendingAttachments.length === 0;
  pendingAttachments.forEach((a, i) => {
    el.attachTray.append(
      attachmentChip(a, () => {
        pendingAttachments.splice(i, 1);
        renderTray();
      })
    );
  });
}

/** Trim what a saved attachment carries — images keep their data URL, the rest just a name. */
function attachmentMeta(a) {
  return a.kind === 'image'
    ? { kind: 'image', name: a.name, dataUrl: a.dataUrl }
    : { kind: a.kind, name: a.name };
}

let pendingTurnAttachments = [];

async function send(prompt, attachments = []) {
  const text = prompt.trim();
  if (busy || (!text && !attachments.length)) return;

  pendingTurnAttachments = attachments;
  const folded = attachmentsToText(attachments);
  const fullText = [text, folded].filter(Boolean).join('\n\n') || 'Tell me about the attached file.';

  addUser(text, attachments);
  thread.messages.push({
    role: 'user',
    content: fullText,
    displayText: text,
    attachments: attachments.map(attachmentMeta)
  });
  el.input.value = '';
  autosize();

  controller = new AbortController();
  setBusy(true);

  try {
    if (thread.model === 'automate') await runAutomation(prompt);
    else await runChat();
    await persist(text || attachments[0]?.name || 'Shared a file');
  } catch (err) {
    document.querySelector('.msg.assistant.streaming')?.classList.remove('streaming');
    setStatus('');
    if (err.name === 'AbortError') {
      setStatus('Stopped');
    } else if (err.code === 'model_retired') {
      const retry = () => {
        document.querySelectorAll('.msg.assistant .error').forEach((n) => n.closest('.msg')?.remove());
        if (thread.messages.at(-1)?.role === 'user') thread.messages.pop();
        el.thread.querySelector('.msg.user:last-of-type')?.remove();
        send(prompt, attachments);
      };
      addError(err, null, modelPicker(thread.model, retry));
    } else {
      addError(err, () => send(prompt, attachments));
    }
  } finally {
    setBusy(false);
    controller = null;
  }
}

/* ---------------- events ---------------- */

el.form.addEventListener('submit', (e) => {
  e.preventDefault();
  if (busy) {
    controller?.abort();
    return;
  }
  const attachments = pendingAttachments;
  pendingAttachments = [];
  renderTray();
  send(el.input.value, attachments);
});

el.attach.addEventListener('click', () => {
  const open = el.attachSheet.hidden;
  closeSheets();
  el.attachSheet.hidden = !open;
  el.attach.setAttribute('aria-expanded', String(open));
  if (open) renderTabList();
});

el.attachUpload.addEventListener('click', () => {
  closeSheets();
  el.fileInput.click();
});

el.pageChipRemove.addEventListener('click', () => {
  selectedPage = null;
  renderPageChip();
});

el.fileInput.addEventListener('change', async () => {
  const files = [...el.fileInput.files];
  el.fileInput.value = '';

  for (const file of files) {
    if (pendingAttachments.length >= LIMITS.maxFiles) {
      setStatus(`I can take up to ${LIMITS.maxFiles} files at a time.`);
      break;
    }
    try {
      const result = await readFile(file);
      pendingAttachments.push(result);
      if (result.warning) setStatus(result.warning);
    } catch (err) {
      setStatus(err.message);
    }
  }
  renderTray();
});

el.input.addEventListener('input', autosize);

el.input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    el.form.requestSubmit();
  }
});

el.modelBtn.addEventListener('click', () => {
  const open = el.modelSheet.hidden;
  closeSheets();
  el.modelSheet.hidden = !open;
  el.modelBtn.setAttribute('aria-expanded', String(open));
});

$('#new-thread').addEventListener('click', () => {
  controller?.abort();
  const keep = thread.model;
  thread = newThread(keep);
  el.thread.replaceChildren(el.welcome);
  setModel(keep);
  closeSheets();
  el.input.focus();
});

$('#history').addEventListener('click', (e) => {
  const open = el.drawer.hidden;
  closeSheets();
  el.drawer.hidden = !open;
  e.currentTarget.setAttribute('aria-expanded', String(open));
  if (open) refreshDrawer();
});

$('#open-settings').addEventListener('click', () => chrome.runtime.openOptionsPage());

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeSheets();
});

document.addEventListener('click', (e) => {
  if (el.modelSheet.hidden && el.drawer.hidden && el.attachSheet.hidden) return;
  if (e.target.closest('#model-sheet, #drawer, #attach-sheet, #model-btn, #history, #attach')) return;
  closeSheets();
});

chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area === 'local' && changes.settings) {
    settings = await getSettings();
    config = groqConfig(settings);
  }
});

/* ---------------- voice input ---------------- */

// Viora transcribes speech with Groq's whisper-large-v3. It uses its own key
// (GROQ_STT_KEY), so the shared chat key's budget stays untouched; a personal
// key from settings still wins for both. The mic records locally
// (MediaRecorder) and the audio is transcribed once you tap stop. If the
// microphone can't be captured it falls back to Chrome's built-in recognizer,
// and if neither exists the mic button stays hidden.
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

const canCapture =
  typeof MediaRecorder !== 'undefined' &&
  Boolean(navigator.mediaDevices?.getUserMedia);

if (!canCapture && !SpeechRecognition) {
  el.mic.hidden = true;
} else {
  /** 'idle' | 'requesting' | 'capturing' | 'transcribing' */
  let state = 'idle';
  let audioStream = null; // live mic, released as soon as recording stops
  let recorder = null;    // active MediaRecorder, if any
  let recognizer = null;  // active Chrome recognizer, if any

  const setMicState = (next) => {
    state = next;
    el.mic.classList.toggle('recording', next === 'capturing');
    el.mic.disabled = next === 'requesting' || next === 'transcribing';
    el.mic.setAttribute(
      'aria-label',
      next === 'capturing' ? 'Stop listening'
        : next === 'requesting' ? 'Starting mic'
        : next === 'transcribing' ? 'Transcribing'
        : 'Voice input'
    );
  };

  const releaseMic = () => {
    audioStream?.getTracks().forEach((t) => t.stop());
    audioStream = null;
  };

  const withTimeout = (promise, ms) =>
    Promise.race([
      promise,
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), ms))
    ]);

  /**
   * Make sure the extension may use the mic. Chrome won't show the permission
   * prompt inside a docked side panel (a known limitation), so when permission
   * isn't already granted this opens the mic-permission page in a small popup
   * window where the prompt CAN be shown. A "blocked" state opens the site
   * settings so the user can flip it to Allow. Returns false when the user
   * shouldn't proceed (and has been told why in the status line).
   */
  async function ensureMicPermission() {
    try {
      const status = await navigator.permissions.query({ name: 'microphone' });
      if (status.state === 'granted') return true;
      if (status.state === 'denied') {
        chrome.tabs.create({
          url: `chrome://settings/content/siteDetails?site=chrome-extension%3A%2F%2F${chrome.runtime.id}%2F`
        });
        setStatus('Microphone is blocked — set it to Allow in the settings tab that opened, then tap the mic again.');
        return false;
      }
    } catch {
      // Permission query unsupported — fall through to a direct request.
    }

    // Try a direct request first; Chrome may show the prompt here normally.
    let direct = null;
    try {
      direct = navigator.mediaDevices.getUserMedia({ audio: true });
      const stream = await withTimeout(direct, 4000);
      direct = null;
      stream.getTracks().forEach((t) => t.stop());
      return true;
    } catch {
      direct?.then((s) => s.getTracks().forEach((t) => t.stop())).catch(() => {});
      /* expected — side panels suppress the prompt */
    }

    // Open the permission bridge in a popup window and wait for it to close.
    setStatus('Allow the microphone in the popup that just opened.');
    try {
      const win = await chrome.windows.create({
        url: chrome.runtime.getURL('src/mic/mic-permission.html'),
        type: 'popup',
        width: 440,
        height: 340,
        focused: true
      });
      if (!win?.id) return false;
      await new Promise((resolve) => {
        const onClose = (windowId) => {
          if (windowId !== win.id) return;
          chrome.windows.onRemoved.removeListener(onClose);
          setTimeout(resolve, 350);
        };
        chrome.windows.onRemoved.addListener(onClose);
      });
      return true;
    } catch {
      return false;
    }
  }

  /** Record until stopped, then POST the audio to Groq's whisper model. */
  async function transcribeWithWhisper() {
    setMicState('requesting');
    setStatus('Requesting microphone…');

    if (!(await ensureMicPermission())) {
      if (!el.status.textContent) setStatus("Couldn't get microphone access — try again.");
      setMicState('idle');
      return;
    }

    let stream;
    let pending = null;
    try {
      pending = navigator.mediaDevices.getUserMedia({ audio: true });
      stream = await withTimeout(pending, 6000);
      pending = null;
    } catch {
      // The prompt was denied or never answered. If a stream now shows up
      // late, drop it so the mic light doesn't stay on. Fall back to Chrome's
      // recognizer when there is one, else say what happened.
      pending?.then((s) => s.getTracks().forEach((t) => t.stop())).catch(() => {});
      if (SpeechRecognition) { captureLocally(); return; }
      setMicState('idle');
      setStatus('Microphone access was blocked.');
      return;
    }
    audioStream = stream;

    let rec;
    try {
      rec = new MediaRecorder(stream);
    } catch {
      releaseMic();
      if (SpeechRecognition) { captureLocally(); return; }
      setMicState('idle');
      setStatus('Audio recording is not supported here.');
      return;
    }
    recorder = rec;

    const chunks = [];
    rec.addEventListener('dataavailable', (e) => {
      if (e.data.size) chunks.push(e.data);
    });

    setMicState('capturing');
    setStatus('Recording — tap again when done');
    rec.start();

    await new Promise((resolve) => {
      rec.addEventListener('stop', resolve, { once: true });
      rec.addEventListener('error', resolve, { once: true });
    });
    releaseMic();
    recorder = null;

    if (!chunks.length) {
      setMicState('idle');
      return;
    }

    setMicState('transcribing');
    setStatus('Transcribing');
    let text = '';
    try {
      const blob = new Blob(chunks, { type: rec.mimeType || 'audio/webm' });
      text = await transcribeAudio({ config, blob });
    } catch (err) {
      setMicState('idle');
      setStatus(err.hint || 'Transcription failed — try again.');
      el.input.focus();
      return;
    }

    setMicState('idle');
    if (text) {
      el.input.value = el.input.value.trim() ? `${el.input.value.trim()} ${text}` : text;
      autosize();
      setStatus('');
    } else {
      setStatus("Didn't catch that — try again.");
    }
    el.input.focus();
  }

  /** Chrome's built-in recognizer — the fallback when the mic can't be captured. */
  function captureLocally() {
    recognizer = new SpeechRecognition();
    recognizer.lang = navigator.language || 'en-US';
    recognizer.interimResults = true;
    recognizer.continuous = false;

    recognizer.addEventListener('start', () => {
      setMicState('capturing');
      setStatus('Listening');
    });

    recognizer.addEventListener('result', (e) => {
      let transcript = '';
      for (const r of e.results) transcript += r[0].transcript;
      el.input.value = transcript;
      autosize();
    });

    recognizer.addEventListener('error', (e) => {
      setStatus(
        e.error === 'not-allowed' || e.error === 'service-not-allowed'
          ? 'Microphone access was blocked.'
          : e.error === 'no-speech'
            ? ''
            : "Didn't catch that — try again."
      );
    });

    recognizer.addEventListener('end', () => {
      recognizer = null;
      setMicState('idle');
      setStatus('');
      el.input.focus();
    });

    try {
      recognizer.start();
    } catch {
      recognizer = null;
      setMicState('idle');
    }
  }

  el.mic.addEventListener('click', () => {
    if (state === 'requesting' || state === 'transcribing') return;
    if (state === 'capturing') {
      recorder?.stop();
      recognizer?.stop();
      return;
    }
    if (canCapture) transcribeWithWhisper();
    else captureLocally();
  });
}

/* ---------------- boot ---------------- */

el.attachUploadIcon.innerHTML = icon('upload');
el.micIcon.innerHTML = icon('mic');

setModel(settings.prefs.model || 'flash');
refreshDrawer();
el.input.focus();

// Pick up anything queued from a context-menu click.
const task = await chrome.runtime.sendMessage({ type: 'viora:get-task' }).catch(() => null);
if (task?.prompt) {
  setModel(task.model || 'flash');
  if (task.usePage && task.tabId != null) {
    try {
      pickPage(await chrome.tabs.get(task.tabId));
    } catch {
      // The tab closed before the panel opened — nothing to attach.
    }
  }
  send(task.prompt);
}
