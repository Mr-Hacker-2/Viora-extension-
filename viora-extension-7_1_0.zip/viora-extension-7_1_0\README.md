# Viora

A browser side panel with four assistants in it. Everything runs on Groq's free
tier, so there is no API key to find, paste, or pay for — install it and talk.

## The four

| | | |
|---|---|---|
| ⚡ | **Viora Flash** | Quick, chatty, good for most things |
| 🔎 | **Viora Deep Search** | Reads the live web and cites what it found |
| 🧮 | **Viora Math & Code** | Shows its working, writes proper fractions |
| 🤖 | **Viora Automate** | Clicks, types and navigates on the page you're on |

Switch with the pill next to the wordmark. Each one has its own accent colour,
its own opening line, and its own model behind it.

## The "+" menu

Click it to upload a file, or to hand Viora one of your open tabs — pick one
and its page content is read on every turn until you remove the chip. That's
a `pageContext()` read (same one automation already used), not a screenshot:
Viora gets the page's text, not a picture of it. Listing tabs needs the
`tabs` permission, which is why Chrome will ask you to re-approve Viora after
this update.

## Voice input

The mic button records your speech and transcribes it with Groq's
`whisper-large-v3`. It uses its own key (`GROQ_STT_KEY` in `src/lib/access.js`),
so transcription never draws on the shared chat budget (a personal key from
settings still wins for both). Tap to record, tap again when you're done, and
the text lands in the input box for you to review before sending.

Chrome hides the mic-permission prompt inside a docked side panel, so the
first time you tap the mic Viora opens a small popup that asks for microphone
access once (see `src/mic/`). If permission is blocked, it opens the site
settings instead. If the mic still can't be captured it falls back to Chrome's
built-in speech recognition, and the button hides if the browser supports
neither.

## Images

Uploaded images go to `qwen/qwen3.8-27b` — the vision model Groq serves today
(`VISION_CHAIN` in `src/lib/models.js`). Images are downscaled client-side, up
to three per request, and sent alongside your message; any model you're
talking to will use them. If Groq ever retires that model, the chat will say
so and Settings can list what's live to pin a replacement.

## Icons, not emoji

The interface itself never speaks in emoji — `src/lib/icons.js` is a small
set of stroke icons (one per assistant, plus upload/tab/mic/check/plus) that
every bit of chrome draws from instead: the model pill, the welcome screen,
the picker rows, the reply badge, thread history. Only Viora's own replies
use emoji, and only at whatever level is set in **Emoji** under settings.

## Maths

Viora renders LaTeX itself — no engine is bundled, because the extension's CSP
forbids remote scripts and KaTeX is far too heavy for a side panel. `src/lib/math.js`
covers what an assistant actually writes:

- `\frac{3}{4}` draws as a stacked fraction with a rule, not `3/4`
- `\sqrt{x}`, `\sqrt[3]{x}`, `x^{2}`, `a_{n}`
- `\le \ge \ne \approx \pm \times \cdot \infty \sum \int` and the Greek alphabet
- ASCII stand-ins typed by habit (`>=`, `<=`, `!=`, `->`, `+-`) are converted
- a bare `3/4` between `$…$` is promoted to a real fraction

The system prompt tells every model to write maths this way, so it usually
arrives already correct.

## Voice

Viora is warm by default: it reacts, has opinions, and uses the occasional
emoji. That's a character, not a claim about inner life — and it never buys
agreeableness with accuracy. It still says "I'm not sure", still disagrees when
you're about to do something that won't work. Both can be turned down in
settings: **Voice → Plain** and **Emoji → None**.

## Settings

There are no credential fields, because there are no credentials to enter. What
is there:

- which Viora opens by default
- voice and emoji level
- reply length, working-shown, source favicons
- model IDs, if you want to pin a specific Groq model to one of the four
- an optional personal Groq key, for when the shared one hits a rate limit

## About the shipped key

`src/lib/access.js` contains a Groq key in plain text. Two consequences worth
knowing about:

1. Anyone who installs Viora can read it out of the source. It is not secret.
2. Groq counts free-tier limits **per key, not per user**. Every install shares
   one budget, so rate limits arrive quickly once more than a handful of people
   are using it.

The optional key field in settings is the escape hatch: a free key from
console.groq.com, stored on-device, takes over for that install. If the shared
key gets abused, rotate it in `access.js` and ship a new version.

## Model IDs

Groq retires model IDs on its own schedule. Each of the four carries a fallback
chain (`src/lib/models.js`); a dead ID is skipped automatically and the one that
answered is remembered. If a whole chain dies, the error offers a live list of
what Groq is serving so you can pin a replacement without editing code.

## Install

1. `chrome://extensions` → enable Developer mode
2. Load unpacked → choose this folder
3. Ctrl+Shift+Y (Cmd+Shift+Y) opens the panel

## Build

```
./scripts/build.sh
```

Validates the manifest, checks every referenced file exists, checks no key has
leaked outside `access.js`, and writes `dist/viora-extension-<version>.zip`.

## Layout

```
src/
  lib/
    access.js      the shipped Groq key + base URL
    models.js      the four assistants and their model chains
    providers.js   Groq streaming client with chain fallback
    prompts.js     system prompts: voice, emoji, maths rules
    math.js        LaTeX subset → HTML
    markdown.js    markdown + maths + tables, escaped throughout
    storage.js     settings and saved threads
    citations.js   source chips and inline markers
    automation.js  page snapshots and action running
    files.js       attachments
  mic/             microphone permission bridge (popup that asks Chrome once)
  sidepanel/       the panel
  options/         settings
  background/      service worker
  content/         page-side helpers
```
