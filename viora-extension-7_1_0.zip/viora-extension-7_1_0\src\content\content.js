/**
 * Viora — content script.
 * Builds the numbered element snapshot the planner reads, performs the
 * actions it returns, and briefly outlines whatever it touches so the user
 * can see what happened.
 */

(() => {
  if (window.__vioraContentReady) return;
  window.__vioraContentReady = true;

  const INTERACTIVE = 'a[href], button, input, select, textarea, [role="button"], [role="link"], [role="tab"], [contenteditable="true"]';
  let refs = new Map();

  const visible = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity) > 0.05;
  };

  const label = (el) => {
    const text =
      el.getAttribute('aria-label') ||
      el.getAttribute('placeholder') ||
      el.getAttribute('title') ||
      el.value ||
      el.innerText ||
      el.getAttribute('name') ||
      '';
    return text.replace(/\s+/g, ' ').trim().slice(0, 80);
  };

  function buildSnapshot() {
    refs = new Map();
    const items = [];
    let ref = 1;
    for (const el of document.querySelectorAll(INTERACTIVE)) {
      if (!visible(el) || el.disabled) continue;
      refs.set(ref, el);
      items.push({
        ref,
        tag: el.tagName.toLowerCase(),
        type: el.getAttribute('type') || el.getAttribute('role') || '',
        label: label(el)
      });
      ref++;
      if (ref > 120) break;
    }
    return { url: location.href, title: document.title, elements: items };
  }

  function readableText() {
    const clone = document.body.cloneNode(true);
    clone.querySelectorAll('script, style, noscript, svg, nav, footer, aside').forEach((n) => n.remove());
    return clone.innerText.replace(/\n{3,}/g, '\n\n').trim();
  }

  function flash(el) {
    el.classList.add('viora-touch');
    setTimeout(() => el.classList.remove('viora-touch'), 900);
  }

  async function act(action) {
    const el = action.ref != null ? refs.get(action.ref) : null;
    if (action.type !== 'scroll' && !el) {
      return { ok: false, detail: `No element with ref ${action.ref}. Take a fresh snapshot.` };
    }

    switch (action.type) {
      case 'click':
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        flash(el);
        el.click();
        return { ok: true, detail: `Clicked "${label(el) || el.tagName.toLowerCase()}"` };

      case 'fill': {
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        flash(el);
        el.focus();
        if (el.isContentEditable) {
          el.textContent = action.value ?? '';
        } else {
          const setter = Object.getOwnPropertyDescriptor(
            el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype,
            'value'
          )?.set;
          setter ? setter.call(el, action.value ?? '') : (el.value = action.value ?? '');
        }
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return { ok: true, detail: `Filled "${label(el) || 'field'}"` };
      }

      case 'scroll':
        window.scrollTo({
          top: action.to === 'top' ? 0 : document.body.scrollHeight,
          behavior: 'smooth'
        });
        return { ok: true, detail: `Scrolled to ${action.to || 'bottom'}` };

      case 'extract':
        flash(el);
        return { ok: true, detail: (el.innerText || el.value || '').trim().slice(0, 1500) };

      case 'set_file': {
        if (el.tagName !== 'INPUT' || el.type !== 'file') {
          return { ok: false, detail: 'That element is not a file picker (input type="file").' };
        }
        try {
          const res = await fetch(action.url);
          if (!res.ok) return { ok: false, detail: `Could not fetch the file (HTTP ${res.status}).` };
          const blob = await res.blob();
          const name = action.url.split('/').pop()?.split('?')[0] || 'file';
          const file = new File([blob], name, { type: blob.type || 'application/octet-stream' });
          const dt = new DataTransfer();
          dt.items.add(file);
          el.files = dt.files;
          flash(el);
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          return { ok: true, detail: `Added "${name}" to "${label(el) || 'file input'}"` };
        } catch (err) {
          return { ok: false, detail: `Could not load that file: ${err.message}` };
        }
      }

      default:
        return { ok: false, detail: `Unknown action: ${action.type}` };
    }
  }

  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    switch (msg?.type) {
      case 'viora:ping':
        reply({ ok: true });
        return true;
      case 'viora:snapshot':
        reply(buildSnapshot());
        return true;
      case 'viora:page-context':
        reply({ url: location.href, title: document.title, text: readableText().slice(0, 12000) });
        return true;
      case 'viora:selection':
        reply({ text: String(getSelection() || '').trim() });
        return true;
      case 'viora:act':
        act(msg.action).then(reply);
        return true;
      default:
        return false;
    }
  });
})();
