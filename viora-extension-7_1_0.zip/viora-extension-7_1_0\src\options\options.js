import { getSettings, saveSettings, groqConfig, DEFAULTS } from '../lib/storage.js';
import { MODELS, MODEL_ORDER, chainFor } from '../lib/models.js';
import { listModels } from '../lib/providers.js';
import { icon, MODEL_ICON } from '../lib/icons.js';

const result = document.getElementById('result');
const read = (obj, path) => path.split('.').reduce((o, k) => o?.[k], obj);

function write(obj, path, value) {
  const keys = path.split('.');
  const last = keys.pop();
  const target = keys.reduce((o, k) => (o[k] ??= {}), obj);
  target[last] = value;
}

const say = (text) => { result.textContent = text; };

/* ---- the default-model radio group ---- */

function buildDefaultModel(settings) {
  const host = document.getElementById('default-model');
  host.replaceChildren();
  for (const id of MODEL_ORDER) {
    const model = MODELS[id];
    const label = document.createElement('label');
    label.className = 'choice';

    const radio = document.createElement('input');
    radio.type = 'radio';
    radio.name = 'default-model';
    radio.value = id;
    radio.checked = settings.prefs.model === id;

    const rowIcon = document.createElement('span');
    rowIcon.className = 'choice-icon';
    rowIcon.innerHTML = icon(MODEL_ICON[id]);

    const copy = document.createElement('span');
    copy.className = 'choice-copy';
    const name = document.createElement('strong');
    name.textContent = model.name;
    const blurb = document.createElement('span');
    blurb.textContent = model.blurb;
    copy.append(name, blurb);

    label.append(radio, rowIcon, copy);
    host.append(label);
  }
}

/* ---- per-model ID overrides ---- */

function buildOverrides(settings) {
  const host = document.getElementById('overrides');
  host.replaceChildren();
  for (const id of MODEL_ORDER) {
    const model = MODELS[id];
    const label = document.createElement('label');
    label.className = 'override-label';

    const labelIcon = document.createElement('span');
    labelIcon.className = 'choice-icon choice-icon-sm';
    labelIcon.innerHTML = icon(MODEL_ICON[id]);
    const labelText = document.createElement('span');
    labelText.textContent = model.name;
    label.append(labelIcon, labelText);

    const input = document.createElement('input');
    input.type = 'text';
    input.setAttribute('list', 'groq-models');
    input.dataset.override = id;
    input.value = settings.modelOverrides?.[id] ?? '';
    input.placeholder = chainFor(id, { resolved: settings.resolvedModels })[0];

    label.append(input);
    host.append(label);
  }
}

function fill(settings) {
  for (const field of document.querySelectorAll('[data-path]')) {
    const path = field.dataset.path;
    if (field.type === 'checkbox') field.checked = Boolean(read(settings, path));
    else field.value = read(settings, path) ?? '';
  }
  buildDefaultModel(settings);
  buildOverrides(settings);
}

function collect() {
  const patch = { modelOverrides: {} };
  for (const field of document.querySelectorAll('[data-path]')) {
    const value =
      field.type === 'checkbox' ? field.checked
      : field.type === 'number' ? Number(field.value)
      : field.value.trim();
    write(patch, field.dataset.path, value);
  }
  for (const input of document.querySelectorAll('[data-override]')) {
    patch.modelOverrides[input.dataset.override] = input.value.trim();
  }
  const picked = document.querySelector('input[name="default-model"]:checked');
  if (picked) write(patch, 'prefs.model', picked.value);
  return patch;
}

document.getElementById('save').addEventListener('click', async () => {
  await saveSettings(collect());
  say('Saved.');
  setTimeout(() => say(''), 2200);
});

document.getElementById('reset').addEventListener('click', async () => {
  await chrome.storage.local.set({ settings: DEFAULTS });
  fill(DEFAULTS);
  say('Back to defaults.');
});

document.getElementById('test').addEventListener('click', async () => {
  await saveSettings(collect());
  const settings = await getSettings();
  const config = groqConfig(settings);
  say('Testing…');

  const lines = [config.usingPersonalKey ? 'Using your key' : 'Using the built-in key'];
  for (const id of MODEL_ORDER) {
    const model = chainFor(id, {
      overrides: settings.modelOverrides,
      resolved: settings.resolvedModels
    })[0];
    try {
      const res = await fetch(`${config.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${config.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model, messages: [{ role: 'user', content: 'ping' }], max_tokens: 1 })
      });
      const label = MODELS[id].name.replace('Viora ', '');
      lines.push(`${label}: ${res.ok ? 'ready' : `failed (${res.status})`}`);
    } catch {
      lines.push(`${MODELS[id].name.replace('Viora ', '')}: unreachable`);
    }
  }
  say(lines.join(' · '));
});

document.getElementById('load-models').addEventListener('click', async (e) => {
  const btn = e.currentTarget;
  btn.disabled = true;
  btn.textContent = 'Loading';
  try {
    await saveSettings(collect());
    const settings = await getSettings();
    const models = await listModels({ config: groqConfig(settings) });
    const list = document.getElementById('groq-models');
    list.replaceChildren();
    for (const id of models) {
      const opt = document.createElement('option');
      opt.value = id;
      list.append(opt);
    }
    btn.textContent = `${models.length} models loaded`;
    say('Click any model field above to pick from the live list.');
  } catch (err) {
    btn.textContent = 'Load what Groq is serving now';
    say(err.message);
  } finally {
    btn.disabled = false;
  }
});

fill(await getSettings());
