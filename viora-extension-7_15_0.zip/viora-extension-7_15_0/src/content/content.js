/**
 * Viora — content script.
 * Builds the numbered element snapshot the planner reads, performs the
 * actions it returns, and briefly outlines whatever it touches so the user
 * can see what happened.
 */

(() => {
  if (window.__vioraContentReady) return;
  window.__vioraContentReady = true;

  const INTERACTIVE = 'a[href], button, input, select, textarea, [role="button"], [role="link"], [role="tab"], [contenteditable="true"]';
  let refs = new Map();

  const visible = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity) > 0.05;
  };

  const label = (el) => {
    const text =
      el.getAttribute('aria-label') ||
      el.getAttribute('placeholder') ||
      el.getAttribute('title') ||
      el.value ||
      el.innerText ||
      el.getAttribute('name') ||
      '';
    return text.replace(/\s+/g, ' ').trim().slice(0, 80);
  };

  function buildSnapshot() {
    refs = new Map();
    const items = [];
    let ref = 1;
    for (const el of document.querySelectorAll(INTERACTIVE)) {
      if (!visible(el) || el.disabled) continue;
      refs.set(ref, el);
      items.push({
        ref,
        tag: el.tagName.toLowerCase(),
        type: el.getAttribute('type') || el.getAttribute('role') || '',
        label: label(el)
      });
      ref++;
      if (ref > 120) break;
    }
    return { url: location.href, title: document.title, elements: items };
  }

  function readableText() {
    const clone = document.body.cloneNode(true);
    clone.querySelectorAll('script, style, noscript, svg, nav, footer, aside').forEach((n) => n.remove());
    return clone.innerText.replace(/\n{3,}/g, '\n\n').trim();
  }

  /**
   * Raw markup of the page, for tasks that need actual tags/attributes
   * (structure, data-* attributes, hrefs, form field names) rather than
   * just the rendered text. Scripts, styles, comments and inline event
   * handlers are stripped — they're irrelevant to reading the page and
   * scripts in particular are the one part of "the page's HTML" that
   * should never be replayed back through a prompt.
   */
  function rawHtml() {
    // Prefer the part of the page that holds the content being read, so the
    // limited HTML budget isn't spent on menus, headers and sidebars.
    const root = document.querySelector('main, article, [role="main"]') || document.body;
    const clone = root.cloneNode(true);
    clone.querySelectorAll('nav, footer, aside, header[role="banner"]').forEach((n) => n.remove());
    clone.querySelectorAll('script, style, noscript, template').forEach((n) => n.remove());
    clone.querySelectorAll('*').forEach((el) => {
      for (const attr of [...el.attributes]) {
        if (/^on/i.test(attr.name)) el.removeAttribute(attr.name);
      }
    });
    const html = clone.innerHTML
      .replace(/<!--[\s\S]*?-->/g, '')
      .replace(/[ \t]{2,}/g, ' ')
      .replace(/\n{2,}/g, '\n')
      .trim();
    return html;
  }

  function flash(el) {
    el.classList.add('viora-touch');
    setTimeout(() => el.classList.remove('viora-touch'), 900);
  }

  async function act(action) {
    const el = action.ref != null ? refs.get(action.ref) : null;
    if (action.type !== 'scroll' && !el) {
      return { ok: false, detail: `No element with ref ${action.ref}. Take a fresh snapshot.` };
    }

    switch (action.type) {
      case 'click':
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        flash(el);
        // Menus and custom buttons often listen for the pointer events that
        // come before a click, not the click itself, so send those first.
        for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) {
          const Ctor = type.startsWith('pointer') && window.PointerEvent ? PointerEvent : MouseEvent;
          el.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, view: window }));
        }
        el.click();
        return { ok: true, detail: `Clicked "${label(el) || el.tagName.toLowerCase()}"` };

      case 'fill': {
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        flash(el);
        el.focus();
        if (el.isContentEditable) {
          // Rich editors (chat boxes, Notion-style editors, comment fields)
          // keep their own model of the text, so writing straight into the DOM
          // gets ignored or wiped. execCommand goes through the same path as
          // real typing, which they do listen to; the plain assignment is only
          // the fallback for pages where that isn't available.
          const text = action.value ?? '';
          const range = document.createRange();
          range.selectNodeContents(el);
          const sel = window.getSelection();
          sel.removeAllRanges();
          sel.addRange(range);
          const typed = document.execCommand && (text ? document.execCommand('insertText', false, text) : document.execCommand('delete'));
          if (!typed) el.textContent = text;
        } else {
          const setter = Object.getOwnPropertyDescriptor(
            el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype,
            'value'
          )?.set;
          setter ? setter.call(el, action.value ?? '') : (el.value = action.value ?? '');
        }
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return { ok: true, detail: `Filled "${label(el) || 'field'}"` };
      }

      case 'scroll':
        window.scrollTo({
          top: action.to === 'top' ? 0 : document.body.scrollHeight,
          behavior: 'smooth'
        });
        return { ok: true, detail: `Scrolled to ${action.to || 'bottom'}` };

      case 'extract':
        flash(el);
        return { ok: true, detail: (el.innerText || el.value || '').trim().slice(0, 1500) };

      case 'set_file': {
        if (el.tagName !== 'INPUT' || el.type !== 'file') {
          return { ok: false, detail: 'That element is not a file picker (input type="file").' };
        }
        try {
          const res = await fetch(action.url);
          if (!res.ok) return { ok: false, detail: `Could not fetch the file (HTTP ${res.status}).` };
          const blob = await res.blob();
          const name = action.url.split('/').pop()?.split('?')[0] || 'file';
          const file = new File([blob], name, { type: blob.type || 'application/octet-stream' });
          const dt = new DataTransfer();
          dt.items.add(file);
          el.files = dt.files;
          flash(el);
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          return { ok: true, detail: `Added "${name}" to "${label(el) || 'file input'}"` };
        } catch (err) {
          return { ok: false, detail: `Could not load that file: ${err.message}` };
        }
      }

      default:
        return { ok: false, detail: `Unknown action: ${action.type}` };
    }
  }

  /**
   * Screenshot area picker. Drag to draw a rectangle; when the mouse stops
   * the selection stays on screen and can still be fixed — drag the handles
   * to resize, drag the inside to move, arrow keys to nudge, or drag on the
   * dimmed area to start over. Enter / the Attach button confirms, Esc
   * cancels. It resolves with viewport-space coordinates — capturing the
   * pixels themselves happens on the extension side (a content script has
   * no API for that), so this just answers "which rectangle".
   */
  async function pickScreenshotArea(frozenUrl = '') {
    // Freeze: lay the capture over the live page before anything else, and
    // wait for it to be decoded so the swap never flashes.
    let frozen = null;
    if (frozenUrl) {
      frozen = document.createElement('img');
      frozen.className = 'viora-shot-frozen';
      frozen.alt = '';
      frozen.draggable = false;
      frozen.src = frozenUrl;
      try {
        await frozen.decode();
      } catch {
        frozen = null; // an undecodable capture: fall back to selecting on the live page
      }
    }
    return new Promise((resolve) => {
      const MIN = 12;
      const HANDLES = ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'];

      const veil = document.createElement('div');
      veil.className = 'viora-shot-veil is-idle';

      const hint = document.createElement('div');
      hint.className = 'viora-shot-hint';
      const idleText = frozen ? 'Page frozen · drag to select an area · Esc to cancel' : 'Drag to select an area · Esc to cancel';
      hint.textContent = idleText;

      const box = document.createElement('div');
      box.className = 'viora-shot-box';
      box.hidden = true;
      for (const h of HANDLES) {
        const dot = document.createElement('i');
        dot.className = `viora-shot-handle h-${h}`;
        dot.dataset.handle = h;
        box.append(dot);
      }

      const size = document.createElement('div');
      size.className = 'viora-shot-size';
      size.hidden = true;

      const bar = document.createElement('div');
      bar.className = 'viora-shot-bar';
      bar.hidden = true;
      const mkBtn = (cls, label, title) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = `viora-shot-btn ${cls}`;
        b.textContent = label;
        b.title = title;
        return b;
      };
      const retake = mkBtn('ghost', 'Retake', 'Clear the selection and draw again');
      const cancel = mkBtn('ghost', 'Cancel', 'Cancel (Esc)');
      const attach = mkBtn('primary', 'Attach', 'Attach this area (Enter)');
      bar.append(retake, cancel, attach);

      let rect = null; // { x, y, width, height } in viewport px
      let drag = null; // { kind: 'draw'|'move'|'resize', ... }
      let done = false;

      const vw = () => document.documentElement.clientWidth;
      const vh = () => document.documentElement.clientHeight;
      const clamp = (v, lo, hi) => Math.min(Math.max(v, lo), hi);

      function paint() {
        const editing = Boolean(rect);
        box.hidden = !editing;
        size.hidden = !editing;
        bar.hidden = !editing || Boolean(drag);
        veil.classList.toggle('is-idle', !editing);
        hint.textContent = editing
          ? 'Drag the edges or move it · Enter to attach · Esc to cancel'
          : idleText;
        if (!editing) return;

        box.style.left = `${rect.x}px`;
        box.style.top = `${rect.y}px`;
        box.style.width = `${rect.width}px`;
        box.style.height = `${rect.height}px`;

        const dpr = window.devicePixelRatio || 1;
        size.textContent = `${Math.round(rect.width * dpr)} × ${Math.round(rect.height * dpr)}`;
        size.style.left = `${clamp(rect.x, 8, Math.max(8, vw() - 96))}px`;
        size.style.top = `${rect.y > 34 ? rect.y - 30 : rect.y + 8}px`;

        // The toolbar sits under the selection, flipping above (or inside)
        // when there is no room, and never leaves the viewport.
        const barW = 232;
        const barH = 40;
        const below = rect.y + rect.height + 12;
        let top = below + barH <= vh() - 6 ? below : rect.y - barH - 12;
        if (top < 6) top = clamp(rect.y + rect.height - barH - 10, 6, vh() - barH - 6);
        bar.style.top = `${top}px`;
        bar.style.left = `${clamp(rect.x + rect.width - barW, 6, Math.max(6, vw() - barW - 6))}px`;
      }

      function cleanup() {
        window.removeEventListener('pointermove', onMove, true);
        window.removeEventListener('pointerup', onUp, true);
        document.removeEventListener('keydown', onKey, true);
        frozen?.remove();
        veil.remove();
        hint.remove();
        box.remove();
        size.remove();
        bar.remove();
      }

      // The pixels come from the frozen capture, so nothing here has to wait
      // for the overlay to leave the screen.
      function finish(result) {
        if (done) return;
        done = true;
        cleanup();
        resolve(result);
      }

      function confirm() {
        if (!rect || rect.width < MIN || rect.height < MIN) return;
        finish({
          ok: true,
          rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
          dpr: window.devicePixelRatio || 1,
          // The size the capture covers, so the crop scales against the real viewport.
          view: { width: window.innerWidth, height: window.innerHeight },
          frozen: Boolean(frozen)
        });
      }

      function onKey(e) {
        if (e.key === 'Escape') {
          e.preventDefault();
          e.stopPropagation();
          finish({ ok: false, cancelled: true });
          return;
        }
        if (!rect) return;
        if (e.key === 'Enter') {
          e.preventDefault();
          e.stopPropagation();
          confirm();
          return;
        }
        const step = e.shiftKey ? 10 : 1;
        const moves = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] };
        const m = moves[e.key];
        if (!m) return;
        e.preventDefault();
        e.stopPropagation();
        if (e.altKey) {
          // Alt + arrows resizes from the bottom-right corner instead of moving.
          rect.width = clamp(rect.width + m[0], MIN, vw() - rect.x);
          rect.height = clamp(rect.height + m[1], MIN, vh() - rect.y);
        } else {
          rect.x = clamp(rect.x + m[0], 0, vw() - rect.width);
          rect.y = clamp(rect.y + m[1], 0, vh() - rect.height);
        }
        paint();
      }

      function onMove(e) {
        if (!drag) return;
        const px = clamp(e.clientX, 0, vw());
        const py = clamp(e.clientY, 0, vh());
        if (drag.kind === 'draw') {
          rect = {
            x: Math.min(drag.sx, px),
            y: Math.min(drag.sy, py),
            width: Math.abs(px - drag.sx),
            height: Math.abs(py - drag.sy)
          };
        } else if (drag.kind === 'move') {
          rect = {
            ...rect,
            x: clamp(drag.orig.x + (px - drag.sx), 0, vw() - rect.width),
            y: clamp(drag.orig.y + (py - drag.sy), 0, vh() - rect.height)
          };
        } else if (drag.kind === 'resize') {
          const o = drag.orig;
          let left = o.x;
          let top = o.y;
          let right = o.x + o.width;
          let bottom = o.y + o.height;
          if (drag.handle.includes('w')) left = clamp(px, 0, right - MIN);
          if (drag.handle.includes('e')) right = clamp(px, left + MIN, vw());
          if (drag.handle.includes('n')) top = clamp(py, 0, bottom - MIN);
          if (drag.handle.includes('s')) bottom = clamp(py, top + MIN, vh());
          rect = { x: left, y: top, width: right - left, height: bottom - top };
        }
        paint();
      }

      function onUp() {
        if (!drag) return;
        const wasDraw = drag.kind === 'draw';
        drag = null;
        if (wasDraw && (!rect || rect.width < MIN || rect.height < MIN)) {
          // A click or a tiny wiggle is not a selection — go back to the start.
          rect = null;
        }
        paint();
      }

      function startDrag(e, kind, extra = {}) {
        if (e.button !== 0) return;
        e.preventDefault();
        e.stopPropagation();
        drag = { kind, sx: e.clientX, sy: e.clientY, orig: rect ? { ...rect } : null, ...extra };
        window.addEventListener('pointermove', onMove, true);
        window.addEventListener('pointerup', onUp, true);
        paint();
      }

      // Dragging on the dimmed area (re)starts a selection.
      veil.addEventListener('pointerdown', (e) => {
        rect = null;
        startDrag(e, 'draw');
      });
      // Drag a handle to resize, or the inside of the box to move it.
      box.addEventListener('pointerdown', (e) => {
        const handle = e.target?.dataset?.handle;
        if (handle) startDrag(e, 'resize', { handle });
        else startDrag(e, 'move');
      });
      box.addEventListener('dblclick', (e) => {
        e.preventDefault();
        confirm();
      });
      // The page must not scroll under the overlay or the rectangle would
      // stop matching what is on screen.
      veil.addEventListener('wheel', (e) => e.preventDefault(), { passive: false });
      bar.addEventListener('pointerdown', (e) => e.stopPropagation());
      retake.addEventListener('click', () => {
        rect = null;
        paint();
      });
      cancel.addEventListener('click', () => finish({ ok: false, cancelled: true }));
      attach.addEventListener('click', confirm);

      document.addEventListener('keydown', onKey, true);
      if (frozen) document.body.append(frozen);
      document.body.append(veil, box, size, hint, bar);
      paint();
    });
  }

  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    switch (msg?.type) {
      case 'viora:ping':
        reply({ ok: true });
        return true;
      case 'viora:snapshot':
        reply(buildSnapshot());
        return true;
      case 'viora:page-context':
        reply({
          url: location.href,
          title: document.title,
          description: document.querySelector('meta[name="description"], meta[property="og:description"]')?.content || '',
          headings: [...document.querySelectorAll('h1, h2, h3')].slice(0, 25).map((h) => h.innerText.replace(/\s+/g, ' ').trim()).filter(Boolean),
          text: readableText().slice(0, 12000),
          html: rawHtml().slice(0, 20000)
        });
        return true;
      case 'viora:selection':
        reply({ text: String(getSelection() || '').trim() });
        return true;
      case 'viora:act':
        act(msg.action).then(reply);
        return true;
      case 'viora:screenshot-select':
        pickScreenshotArea(msg.frozen).then(reply);
        return true;
      default:
        return false;
    }
  });
})();
