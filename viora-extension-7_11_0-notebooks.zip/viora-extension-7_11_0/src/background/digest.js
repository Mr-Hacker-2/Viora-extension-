/**
 * Viora — learning from whole past chats, service-worker side.
 *
 * Runs when a conversation has been going a while or has gone quiet. One
 * short model call reads the recent turns and returns lasting facts about the
 * person plus a one-line note about what the chat was about; both are stored
 * on-device. All the safety rules live in memory.js (parseFacts / parseDigest).
 */

import { getSettings, saveSettings, getThreads, getEpisodes, setEpisodes, configForChoice } from '../lib/storage.js';
import { chainFor } from '../lib/models.js';
import { completeChat } from '../lib/providers.js';
import { DIGEST_PROMPT, digestTranscript, shouldDigest, parseDigest, mergeMemory, mergeEpisode } from '../lib/memory.js';

const inFlight = new Set();

export async function digestThread(threadId, { minNew = 6 } = {}) {
  if (!threadId || inFlight.has(threadId)) return;
  inFlight.add(threadId);
  try {
    const settings = await getSettings();
    if (settings.prefs.learnChats === false) return;
    const thread = (await getThreads()).find((t) => t.id === threadId);
    const episodes = await getEpisodes();
    const prior = episodes.find((e) => e.id === threadId);
    if (!thread || !shouldDigest(thread, prior?.count || 0, minNew)) return;

    const transcript = digestTranscript(thread.messages);
    if (transcript.length < 60) return;

    const { content } = await completeChat({
      config: configForChoice(settings, 'flash'),
      models: chainFor('flash', { overrides: settings.modelOverrides, resolved: settings.resolvedModels }),
      messages: [
        { role: 'system', content: DIGEST_PROMPT },
        { role: 'user', content: `${prior ? `Earlier note about this conversation: ${prior.text}\n\n` : ''}Conversation:\n${transcript}` }
      ],
      temperature: 0,
      maxTokens: 400,
      effort: 'low',
      timeoutMs: 20000
    });
    const { facts, episode } = parseDigest(content);

    // The conversation moves on even if nothing lasting came out of it.
    const fresh = await getEpisodes();
    await setEpisodes(mergeEpisode(fresh, { id: threadId, text: episode || prior?.text || '', title: thread.title, count: thread.messages.length }));

    if (facts.length && settings.prefs.learnMemory !== false) {
      const before = Array.isArray(settings.memory) ? [...settings.memory] : [];
      const { memory, added } = mergeMemory(before, facts);
      if (added.length) {
        await saveSettings({ memory });
        // The panel shows this as "Remembered: …" with Undo the next time it looks.
        await chrome.storage.local.set({ lastLearned: { added, before, at: Date.now() } });
      }
    }
  } catch (err) {
    console.warn('[Viora] could not learn from that chat:', err?.message || err);
  } finally {
    inFlight.delete(threadId);
  }
}

/** Digest chats that have gone quiet (called by an alarm): most recent first, a few at a time. */
export async function sweepQuietChats() {
  const settings = await getSettings();
  if (settings.prefs.learnChats === false) return;
  const episodes = await getEpisodes();
  const quiet = (await getThreads())
    .filter((t) => shouldDigest(t, episodes.find((e) => e.id === t.id)?.count || 0, 2))
    .slice(0, 3);
  for (const t of quiet) await digestThread(t.id, { minNew: 2 });
}
