/**
 * Viora — background jobs, service-worker side.
 *
 * Starts jobs in the offscreen document, keeps a record of them in storage,
 * writes the result into the conversation when one finishes (whether or not
 * the panel is open), and tells the person with a notification. The panel
 * talks to this file through runtime messages; see sidepanel.js runJob().
 */

import { getSettings, getThreads, saveThread, rememberModel } from '../lib/storage.js';
import { messageForJob, notificationFor, JOB_NOUN } from '../lib/jobs.js';
import { digestThread } from './digest.js';

const OFFSCREEN_URL = 'src/offscreen/offscreen.html';
const panelPorts = new Set();
const watched = new Map(); // port -> job ids that panel is waiting on
const isWatched = (id) => [...watched.values()].some((set) => set.has(id));

/* ---------------- job records ---------------- */

async function getJobs() {
  const { jobs } = await chrome.storage.local.get('jobs');
  return Array.isArray(jobs) ? jobs : [];
}
async function putJob(job) {
  const jobs = await getJobs();
  const i = jobs.findIndex((j) => j.id === job.id);
  if (i >= 0) jobs[i] = job;
  else jobs.push(job);
  // Keep the last handful of finished jobs so a reopened panel can tell what happened.
  const live = jobs.filter((j) => j.status === 'running');
  const done = jobs.filter((j) => j.status !== 'running').sort((a, b) => (b.endedAt || 0) - (a.endedAt || 0)).slice(0, 10);
  await chrome.storage.local.set({ jobs: [...live, ...done] });
}
async function getJob(id) {
  return (await getJobs()).find((j) => j.id === id) || null;
}

/* ---------------- offscreen document ---------------- */

async function hasOffscreen() {
  if (chrome.runtime.getContexts) {
    const ctx = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    return ctx.length > 0;
  }
  return false;
}
async function ensureOffscreen() {
  if (await hasOffscreen()) return;
  await chrome.offscreen.createDocument({
    url: OFFSCREEN_URL,
    reasons: ['DOM_PARSER'],
    justification: 'Read web pages and resize generated images while the side panel is closed.'
  });
}
async function closeOffscreenIfIdle() {
  const running = (await getJobs()).filter((j) => j.status === 'running');
  if (running.length) return;
  if (await hasOffscreen()) await chrome.offscreen.closeDocument().catch(() => {});
}

/** Jobs marked running whose runner is gone (the browser was closed mid-job) can never finish. */
export async function reapOrphans() {
  if (await hasOffscreen()) return;
  const jobs = await getJobs();
  for (const j of jobs.filter((x) => x.status === 'running')) {
    await finish(j, 'failed', { message: 'The browser was closed before this finished.' });
  }
}

/* ---------------- starting, finishing ---------------- */

async function startJob({ kind, threadId, payload, label }) {
  // A chat job's payload carries the whole prompt (history, page text, pictures). The runner gets all of it; the record kept in storage only needs what finishing the job uses.
  const kept = kind === 'chat'
    ? { preview: payload.preview, pdfEdit: !!payload.pdfEdit, essay: !!payload.essay, noSources: !!payload.noSources }
    : payload;
  const job = {
    id: `job_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    kind, threadId, payload: kept, label: label || '', status: 'running', startedAt: Date.now()
  };
  await putJob(job);
  await ensureOffscreen();
  const settings = await getSettings();
  // The runner may still be registering its listener right after it was created.
  for (let attempt = 0; ; attempt++) {
    try {
      await chrome.runtime.sendMessage({ target: 'offscreen', type: 'run', id: job.id, kind, payload, settings });
      break;
    } catch (err) {
      if (attempt >= 4) {
        await finish(job, 'failed', { message: 'The background runner did not start.' });
        throw err;
      }
      await new Promise((r) => setTimeout(r, 200));
    }
  }
  return job.id;
}

async function appendToThread(threadId, message) {
  const t = (await getThreads()).find((x) => x.id === threadId);
  if (!t) return false; // the conversation was deleted while the job ran
  if (t.messages.some((m) => m.jobId === message.jobId)) return true;
  t.messages.push(message);
  await saveThread(t);
  return true;
}

async function notify(job, ok, errMessage) {
  const settings = await getSettings();
  if (settings.prefs.notifyDone === false) return;
  const { title, message } = notificationFor(job, ok, errMessage);
  chrome.notifications.create(`viora-job-${job.id}`, {
    type: 'basic', iconUrl: chrome.runtime.getURL('icons/icon128.png'), title, message, priority: 1
  });
}

async function bumpUnseen() {
  const { unseen = 0 } = await chrome.storage.session.get('unseen');
  await chrome.storage.session.set({ unseen: unseen + 1 });
  await chrome.action.setBadgeBackgroundColor({ color: '#7c5cff' });
  await chrome.action.setBadgeText({ text: String(unseen + 1) });
}
async function clearUnseen() {
  await chrome.storage.session.set({ unseen: 0 });
  await chrome.action.setBadgeText({ text: '' });
}

async function finish(job, status, { out, message } = {}) {
  const watching = isWatched(job.id); // a panel that started it is still waiting for it and will show the outcome itself
  const ended = { ...job, status, endedAt: Date.now() };
  if (status === 'failed') ended.error = message || 'Something went wrong.';
  delete ended.payload?.seedUrls;
  await putJob(ended);

  if (status === 'done') {
    if (job.kind === 'chat' && job.payload?.pdfEdit) {
      // Editing a PDF needs the file itself, which only the open panel has.
      if (!watching) {
        await appendToThread(job.threadId, {
          role: 'assistant', jobId: job.id, error: true,
          content: 'I worked out the PDF edit, but applying it needs Viora open with the file. Send the request again and keep the panel open until it finishes.'
        });
      }
    } else {
      await appendToThread(job.threadId, messageForJob(job, out));
      digestThread(job.threadId).catch(() => {});
    }
  } else if (status === 'failed' && !watching) {
    // Nobody is watching, so the conversation has to say what happened.
    await appendToThread(job.threadId, {
      role: 'assistant', jobId: job.id, error: true,
      content: `I couldn't finish that ${JOB_NOUN[job.kind] || 'job'}: ${ended.error} Send it again and I'll retry.`
    });
  }
  if (status !== 'cancelled' && !watching) {
    await notify(job, status === 'done', ended.error);
    await bumpUnseen();
  }
  await chrome.storage.session.remove(`jobp_${job.id}`);
  setTimeout(() => closeOffscreenIfIdle(), 1500);
}

/* ---------------- messages from the panel and the runner ---------------- */

let lastProgressWrite = new Map();

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === 'viora:job-start') {
    startJob(msg).then((id) => reply({ id }), (err) => reply({ error: err?.message || String(err) }));
    return true;
  }
  if (msg?.type === 'viora:job-cancel' || msg?.type === 'viora:job-finish') {
    chrome.runtime.sendMessage({ target: 'offscreen', type: msg.type === 'viora:job-cancel' ? 'cancel' : 'finish', id: msg.id }).catch(() => {});
    reply({ ok: true });
    return false;
  }
  if (msg?.type === 'viora:jobs') {
    reapOrphans().then(async () => {
      const jobs = await getJobs();
      const prog = await chrome.storage.session.get(jobs.filter((j) => j.status === 'running').map((j) => `jobp_${j.id}`));
      reply({ jobs: jobs.map((j) => ({ ...j, progress: prog[`jobp_${j.id}`] || {} })) });
    });
    return true;
  }
  if (msg?.type === 'viora:job-event') {
    handleEvent(msg);
    return false;
  }
  return false;
});

async function handleEvent(msg) {
  // A reply streams in many times a second: those events never need the job record.
  if (msg.event === 'delta' || msg.event === 'web') return;
  if (msg.event === 'model') {
    if (msg.choice && msg.modelId) rememberModel(msg.choice, msg.modelId).catch(() => {});
    return;
  }
  const job = await getJob(msg.id);
  if (!job || job.status !== 'running') return;
  if (msg.event === 'progress' || msg.event === 'section') {
    // Keep the latest progress where a reopened panel can read it (throttled: it fires a lot).
    const now = Date.now();
    if (now - (lastProgressWrite.get(job.id) || 0) < 1500 && msg.event === 'progress') return;
    lastProgressWrite.set(job.id, now);
    const key = `jobp_${job.id}`;
    const prev = (await chrome.storage.session.get(key))[key] || {};
    const next = { ...prev };
    if (msg.status) next.status = msg.status;
    if (msg.sources) next.sources = msg.sources;
    if (msg.tally !== undefined) next.tally = msg.tally;
    if (msg.section) next.sections = [...(prev.sections || []), msg.section];
    await chrome.storage.session.set({ [key]: next });
  } else if (msg.event === 'result') {
    await finish(job, 'done', { out: msg.out });
  } else if (msg.event === 'error') {
    await finish(job, 'failed', { message: msg.message });
  } else if (msg.event === 'cancelled') {
    await finish(job, 'cancelled');
  }
}

/* ---------------- the panel being open or closed ---------------- */

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'viora-panel') return;
  panelPorts.add(port);
  watched.set(port, new Set());
  port.onMessage.addListener((m) => { if (m?.watch) watched.get(port)?.add(m.watch); });
  clearUnseen();
  chrome.notifications.getAll((all) => Object.keys(all || {}).filter((id) => id.startsWith('viora-job-')).forEach((id) => chrome.notifications.clear(id)));
  port.onDisconnect.addListener(() => {
    panelPorts.delete(port);
    watched.delete(port);
  });
});

chrome.notifications.onClicked.addListener(async (nid) => {
  const job = await getJob(nid.replace(/^viora-job-/, ''));
  chrome.notifications.clear(nid);
  if (job) await chrome.storage.local.set({ openThread: { id: job.threadId, at: Date.now() } });
  try {
    const win = await chrome.windows.getLastFocused();
    await chrome.sidePanel.open({ windowId: win.id });
  } catch {
    // Chrome only lets the panel open from a user gesture; the badge on the toolbar icon stays as the cue.
  }
});
