/**
 * Viora — offscreen job runner.
 *
 * The side panel dies the moment it is closed, and so does everything it was
 * awaiting. Long jobs (pictures, research reports) run here instead: an
 * offscreen document has a DOM (the web readers and the image resizer need
 * one) and stays alive until the service worker closes it. It only has the
 * chrome.runtime API, so it never touches storage — the service worker hands
 * it everything it needs and records what comes back.
 */

import { generateImage, ImageError } from '../lib/imagegen.js';
import { runResearch, RESEARCH } from '../lib/research.js';
import { searchWeb, readPage } from '../lib/web.js';
import { completeChat } from '../lib/providers.js';
import { configForChoice } from '../lib/storage.js';
import { chainFor } from '../lib/models.js';
import { finalizeReport } from '../lib/jobs.js';
import { humanizeLoop } from '../lib/humanizer.js';
import { checkAiScore } from '../lib/detector.js';
import { streamChat } from '../lib/providers.js';
import { runChatTurn } from '../lib/chatjob.js';

const running = new Map(); // id -> { controller, finish }

const dropThink = (raw) => String(raw || '').replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/<think>[\s\S]*$/i, '');
const emit = (id, event, data = {}) => chrome.runtime.sendMessage({ type: 'viora:job-event', id, event, ...data }).catch(() => {});

async function runImageJob(id, payload, { signal }) {
  const dataUrl = await generateImage({
    prompt: payload.prompt,
    signal,
    onProgress: (polls) => emit(id, 'progress', { status: `Painting your picture… (${polls})` })
  });
  return { dataUrl };
}

async function runReportJob(id, payload, settings, { signal, state }) {
  const began = Date.now();
  const ask = async (messages, o) => {
    const out = await completeChat({
      config: configForChoice(settings, 'search'),
      models: chainFor('search', { overrides: settings.modelOverrides, resolved: settings.resolvedModels }),
      messages,
      temperature: o.temperature,
      maxTokens: o.maxTokens,
      quick: o.quick,
      signal,
      onRetry: (ms) => emit(id, 'progress', { status: `Rate limited, waiting ${ms < 1500 ? 'a moment' : `~${Math.ceil(ms / 1000)}s`}` })
    });
    return dropThink(out.content);
  };

  const result = await runResearch({
    topic: payload.topic,
    steps: payload.steps,
    ask,
    signal,
    search: (q) => searchWeb(q, { signal, limit: 8 }),
    read: (url) => readPage(url, { signal, maxChars: RESEARCH.pageChars }),
    seedUrls: payload.seedUrls || [],
    shouldFinish: () => state.finish,
    onStatus: (status) => emit(id, 'progress', { status }),
    onSources: (list) => emit(id, 'progress', { sources: list.slice(0, 6) }),
    onProgress: (p) => emit(id, 'progress', { tally: p.phase === 'done' ? null : p }),
    onSection: (sec) => emit(id, 'section', { section: sec })
  });
  return finalizeReport({ topic: payload.topic, result, elapsedMs: Date.now() - began });
}

async function runHumanizeJob(id, payload, settings, { signal }) {
  const rewrite = async (msgs, temperature) => {
    const result = await streamChat({
      config: configForChoice(settings, 'humanize'),
      models: chainFor('humanize', { overrides: settings.modelOverrides, resolved: settings.resolvedModels }),
      messages: msgs,
      temperature,
      maxTokens: payload.maxTokens,
      quick: true,
      signal,
      onRetry: (ms) => emit(id, 'progress', { status: `Rate limited — waiting ${ms < 1500 ? 'a moment' : `~${Math.ceil(ms / 1000)}s`}` })
    });
    return dropThink(result.content).trim();
  };
  const out = await humanizeLoop({
    source: payload.source,
    messages: payload.messages,
    rewrite,
    check: payload.zeroOn ? (t) => checkAiScore(t, { apiKey: payload.zeroKey, signal }) : null,
    baseTemperature: payload.temperature,
    target: payload.target,
    maxRetries: payload.maxRetries,
    // Two drafts side by side, and retries that start again from the source (then passage by passage)
    // instead of re-editing a draft whose skeleton the detector already recognised.
    drafts: payload.drafts ?? 2,
    escalate: payload.escalate !== false,
    targeted: payload.targeted !== false,
    onStatus: (status) => emit(id, 'progress', { status })
  });
  return out;
}

/**
 * An ordinary chat reply (Flash, Deep Search, Math & Code): the internet pass,
 * the prompt, the model. The reply so far is sent as whole-text snapshots, a
 * few times a second, so the panel (if it is open) can show it growing.
 */
async function runChatJob(id, payload, settings, { signal }) {
  let last = 0;
  const ctx = { ...payload, settings };
  return runChatTurn(ctx, {
    signal,
    onStatus: (status) => emit(id, 'progress', { status }),
    onSources: (list) => emit(id, 'progress', { sources: list.slice(0, 6) }),
    onWeb: (web) => emit(id, 'web', { sources: web.sources }),
    onModel: (modelId) => emit(id, 'model', { choice: payload.modelKey, modelId }),
    onRetry: (ms) => emit(id, 'progress', { status: `Rate limited — waiting ${ms < 1500 ? 'a moment' : `~${Math.ceil(ms / 1000)}s`}` }),
    onSnapshot: ({ content, reasoning }) => {
      const now = Date.now();
      if (now - last < 90) return;
      last = now;
      emit(id, 'delta', { content, reasoning });
    }
  });
}

async function run({ id, kind, payload, settings }) {
  const controller = new AbortController();
  const state = { controller, finish: false };
  running.set(id, state);
  try {
    const out = kind === 'image'
      ? await runImageJob(id, payload, { signal: controller.signal })
      : kind === 'humanize'
        ? await runHumanizeJob(id, payload, settings, { signal: controller.signal })
        : kind === 'chat'
          ? await runChatJob(id, payload, settings, { signal: controller.signal })
          : await runReportJob(id, payload, settings, { signal: controller.signal, state });
    await emit(id, 'result', { out });
  } catch (err) {
    if (err?.name === 'AbortError') await emit(id, 'cancelled');
    else await emit(id, 'error', { message: err?.message || 'Something went wrong.', code: err?.code || '', hint: err?.hint || '', detail: err instanceof ImageError ? '' : err?.detail || '' });
  } finally {
    running.delete(id);
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.target !== 'offscreen') return false;
  if (msg.type === 'run') {
    run(msg);
    reply({ ok: true });
  } else if (msg.type === 'cancel') {
    running.get(msg.id)?.controller.abort();
    reply({ ok: true });
  } else if (msg.type === 'finish') {
    const s = running.get(msg.id);
    if (s) s.finish = true;
    reply({ ok: true });
  } else if (msg.type === 'ping') {
    reply({ ok: true, running: [...running.keys()] });
  }
  return false;
});
