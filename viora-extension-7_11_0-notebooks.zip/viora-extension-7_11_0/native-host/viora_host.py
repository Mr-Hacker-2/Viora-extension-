#!/usr/bin/env python3
"""
Viora Linux bridge: a Chrome Native Messaging host.

Chrome extensions can't run programs. This tiny host is the one thing that can: the
extension sends it a JSON message, the host runs it in a real Linux shell and sends the
result back. On Linux and macOS that shell is your own bash. On Windows it is your WSL
distro (install one with `wsl --install`).

It has no network listener. Chrome starts it only when the Viora extension asks, and only
extensions listed in the host manifest's "allowed_origins" can ask (install.ps1 / install.sh
write that list). Whatever the AI is allowed to run, runs as YOU, with your files.

Messages (one JSON object in, one JSON object out, Chrome's 4-byte length framing):
  {"op":"ping"}
  {"op":"run",   "command":"ls -la", "cwd":"~/proj", "timeout":120, "distro":"", "root":false}
  {"op":"write", "path":"~/a.txt", "content":"text", "distro":"", "root":false}
  {"op":"read",  "path":"~/a.txt", "maxBytes":200000, "distro":"", "root":false}
  {"op":"reset"}                          # forget the remembered working folder
The working folder is remembered between commands (cd carries over), like a terminal tab.
"""
import base64
import json
import os
import shlex
import shutil
import signal
import struct
import subprocess
import sys
import time

HOST_VERSION = '1.0.0'
IS_WIN = os.name == 'nt'
STATE_DIR = os.path.join(os.path.expanduser('~'), '.viora')
STATE_FILE = os.path.join(STATE_DIR, 'state.json')
DEFAULT_CWD = '~/viora-workspace'
MARK = '__VIORA_CWD__'
MAX_TIMEOUT = 3600
KEEP_HEAD, KEEP_TAIL = 20000, 40000      # characters of each stream sent back
MAX_ARG = 24000                           # Windows command lines top out near 32k


# ---------------------------------------------------------------- framing

def _binary_stdio():
    if IS_WIN:
        import msvcrt
        msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
        msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)


def read_message():
    head = sys.stdin.buffer.read(4)
    if len(head) < 4:
        return None
    (size,) = struct.unpack('=I', head)
    body = sys.stdin.buffer.read(size)
    return json.loads(body.decode('utf-8'))


def send_message(obj):
    data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
    sys.stdout.buffer.write(struct.pack('=I', len(data)))
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()


# ---------------------------------------------------------------- helpers

def decode(raw):
    """Linux output is UTF-8; wsl.exe's own messages are UTF-16LE."""
    if not raw:
        return ''
    if raw.count(b'\x00') > len(raw) // 4:
        return raw.decode('utf-16-le', 'replace')
    return raw.decode('utf-8', 'replace')


def clip(text):
    if len(text) <= KEEP_HEAD + KEEP_TAIL:
        return text, False
    cut = len(text) - KEEP_HEAD - KEEP_TAIL
    return f'{text[:KEEP_HEAD]}\n…[{cut} characters cut from the middle]…\n{text[-KEEP_TAIL:]}', True


def load_state():
    try:
        with open(STATE_FILE, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(state):
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(STATE_FILE, 'w', encoding='utf-8') as f:
            json.dump(state, f)
    except Exception:
        pass


def linux_argv(wrapper, distro='', root=False):
    """The argv that runs `bash -lc <wrapper>` inside Linux."""
    if IS_WIN:
        wsl = shutil.which('wsl.exe') or shutil.which('wsl')
        if not wsl:
            raise RuntimeError('WSL is not installed. In an admin terminal run: wsl --install')
        argv = [wsl]
        if distro:
            argv += ['-d', distro]
        if root:
            argv += ['-u', 'root']
        return argv + ['-e', 'bash', '-lc', wrapper]
    bash = shutil.which('bash')
    if not bash:
        raise RuntimeError('bash was not found on this machine.')
    if root and os.geteuid() != 0:
        sudo = shutil.which('sudo')
        if not sudo:
            raise RuntimeError('Running as root needs sudo, which was not found.')
        return [sudo, '-n', bash, '-lc', wrapper]
    return [bash, '-lc', wrapper]


def wrap(script, timeout=None, stdin_free=True):
    """
    Put a script into a temp file inside Linux (base64, so no quoting can break it), run it, clean up.
    The wrapper has no double quotes, because wsl.exe re-parses the command line.
    """
    b64 = base64.b64encode(script.encode('utf-8')).decode('ascii')
    run = f'timeout -k 5 {int(timeout)} bash $f' if timeout else 'bash $f'
    if stdin_free:
        run += ' </dev/null'
    return f'f=$(mktemp); echo {b64} | base64 -d > $f; {run}; rc=$?; rm -f $f; exit $rc'


def cd_prelude(cwd):
    q = shlex.quote(cwd)
    return (
        f'd={q}; case $d in "~"|"~/"*) d="$HOME${{d#\\~}}";; esac\n'
        'mkdir -p -- "$d" 2>/dev/null; cd -- "$d" 2>/dev/null || cd "$HOME"\n'
    )


def run_process(argv, stdin_bytes=None, timeout=120):
    kwargs = {}
    if IS_WIN:
        kwargs['creationflags'] = 0x08000000  # CREATE_NO_WINDOW
    else:
        kwargs['start_new_session'] = True
    proc = subprocess.Popen(
        argv,
        stdin=subprocess.PIPE if stdin_bytes is not None else subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        **kwargs,
    )
    try:
        out, err = proc.communicate(stdin_bytes, timeout=timeout)
        return proc.returncode, out, err, False
    except subprocess.TimeoutExpired:
        try:
            if IS_WIN:
                proc.kill()
            else:
                os.killpg(proc.pid, signal.SIGKILL)
        except Exception:
            pass
        out, err = proc.communicate()
        return 124, out or b'', err or b'', True


# ---------------------------------------------------------------- operations

def op_run(req):
    command = str(req.get('command', ''))
    if not command.strip():
        return {'ok': False, 'error': 'No command given.'}
    timeout = max(1, min(int(req.get('timeout') or 120), MAX_TIMEOUT))
    state = load_state()
    cwd = str(req.get('cwd') or state.get('cwd') or DEFAULT_CWD)
    script = (
        cd_prelude(cwd)
        + f"trap 'printf \"\\n{MARK}%s\\n\" \"$PWD\"' EXIT\n"
        + command
        + '\n'
    )
    wrapper = wrap(script, timeout=timeout)
    if IS_WIN and len(wrapper) > MAX_ARG:
        return {'ok': False, 'error': 'That command is too long for Windows. Save it as a script with the write op, then run the file.'}
    began = time.time()
    code, out, err, timed_out = run_process(linux_argv(wrapper, req.get('distro', ''), bool(req.get('root'))), timeout=timeout + 15)
    text, text_err = decode(out), decode(err)
    new_cwd = cwd
    if MARK in text:
        head, _, tail = text.rpartition(MARK)
        text = head.rstrip('\n')
        new_cwd = tail.strip().splitlines()[0] if tail.strip() else cwd
        state['cwd'] = new_cwd
        save_state(state)
    if code == 124:
        timed_out = True
    stdout, cut1 = clip(text)
    stderr, cut2 = clip(text_err)
    return {
        'ok': True,
        'exitCode': code,
        'stdout': stdout,
        'stderr': stderr,
        'cwd': new_cwd,
        'timedOut': timed_out,
        'truncated': cut1 or cut2,
        'ms': int((time.time() - began) * 1000),
    }


def op_write(req):
    path = str(req.get('path', ''))
    if not path:
        return {'ok': False, 'error': 'No path given.'}
    content = req.get('content', '')
    data = base64.b64decode(req['b64']) if req.get('b64') else str(content).encode('utf-8')
    state = load_state()
    cwd = str(state.get('cwd') or DEFAULT_CWD)
    q = shlex.quote(path)
    script = (
        cd_prelude(cwd)
        + f'p={q}; case $p in "~"|"~/"*) p="$HOME${{p#\\~}}";; esac\n'
        + 'mkdir -p -- "$(dirname -- "$p")" && cat > "$p" && printf "wrote %s bytes to %s\\n" "$(wc -c < "$p")" "$p"\n'
    )
    code, out, err, _ = run_process(linux_argv(wrap(script, stdin_free=False), req.get('distro', ''), bool(req.get('root'))), stdin_bytes=data, timeout=60)
    if code != 0:
        return {'ok': False, 'error': (decode(err) or decode(out) or f'write failed ({code})').strip()[:2000]}
    return {'ok': True, 'message': decode(out).strip()}


def op_read(req):
    path = str(req.get('path', ''))
    if not path:
        return {'ok': False, 'error': 'No path given.'}
    limit = max(1, min(int(req.get('maxBytes') or 200000), 600000))
    state = load_state()
    cwd = str(state.get('cwd') or DEFAULT_CWD)
    q = shlex.quote(path)
    script = cd_prelude(cwd) + f'p={q}; case $p in "~"|"~/"*) p="$HOME${{p#\\~}}";; esac\nhead -c {limit} -- "$p"\n'
    code, out, err, _ = run_process(linux_argv(wrap(script), req.get('distro', ''), bool(req.get('root'))), timeout=60)
    if code != 0:
        return {'ok': False, 'error': (decode(err) or f'read failed ({code})').strip()[:2000]}
    return {'ok': True, 'content': out.decode('utf-8', 'replace')}


def distros():
    if not IS_WIN:
        return []
    wsl = shutil.which('wsl.exe') or shutil.which('wsl')
    if not wsl:
        return []
    try:
        code, out, _, _ = run_process([wsl, '-l', '-q'], timeout=15)
        return [line.strip().strip('\x00') for line in decode(out).splitlines() if line.strip()]
    except Exception:
        return []


def op_ping(req):
    info = {'ok': True, 'host': HOST_VERSION, 'platform': sys.platform, 'wsl': IS_WIN, 'distros': distros()}
    try:
        script = 'echo "$(whoami)@$(uname -sr)"; echo "${BASH_VERSION%%(*}"; (sudo -n true 2>/dev/null && echo yes) || echo no\n'
        code, out, err, _ = run_process(linux_argv(wrap(script), req.get('distro', ''), False), timeout=30)
        lines = decode(out).strip().splitlines()
        if code != 0 or not lines:
            return {**info, 'ok': False, 'error': (decode(err) or 'Linux did not answer.').strip()[:500]}
        info.update(who=lines[0], bash=lines[1] if len(lines) > 1 else '', sudo=(lines[2] == 'yes') if len(lines) > 2 else False)
    except Exception as exc:
        return {**info, 'ok': False, 'error': str(exc)}
    return info


def op_reset(req):
    save_state({})
    return {'ok': True}


OPS = {'ping': op_ping, 'run': op_run, 'write': op_write, 'read': op_read, 'reset': op_reset}


def handle(req):
    try:
        fn = OPS.get(req.get('op'))
        if not fn:
            return {'ok': False, 'error': f'Unknown op: {req.get("op")!r}'}
        return fn(req)
    except Exception as exc:  # never let one bad request kill the host
        return {'ok': False, 'error': f'{type(exc).__name__}: {exc}'}


def main():
    _binary_stdio()
    while True:
        try:
            req = read_message()
        except Exception:
            break
        if req is None:
            break
        send_message(handle(req))


if __name__ == '__main__':
    main()
