#!/usr/bin/env bash
# Registers the Viora Linux bridge with Chrome / Chromium / Edge / Brave (Linux and macOS).
#   ./install.sh <extension-id>        install (or update) for that extension
#   ./install.sh --uninstall           remove it
# The extension id is shown in Viora > Settings > Linux, and on chrome://extensions.
set -euo pipefail

NAME="com.viora.linux"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="${XDG_DATA_HOME:-$HOME/.local/share}/viora/native-host"

case "$(uname -s)" in
  Darwin)
    DIRS=("$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
          "$HOME/Library/Application Support/Chromium/NativeMessagingHosts"
          "$HOME/Library/Application Support/Microsoft Edge/NativeMessagingHosts"
          "$HOME/Library/Application Support/BraveSoftware/Brave-Browser/NativeMessagingHosts") ;;
  *)
    DIRS=("$HOME/.config/google-chrome/NativeMessagingHosts"
          "$HOME/.config/chromium/NativeMessagingHosts"
          "$HOME/.config/microsoft-edge/NativeMessagingHosts"
          "$HOME/.config/BraveSoftware/Brave-Browser/NativeMessagingHosts") ;;
esac

if [[ "${1:-}" == "--uninstall" ]]; then
  for d in "${DIRS[@]}"; do rm -f "$d/$NAME.json"; done
  rm -rf "$DEST"
  echo "Removed the Viora Linux bridge."
  exit 0
fi

ID="${1:-}"
if [[ -z "$ID" ]]; then read -r -p "Viora extension ID (Viora > Settings > Linux): " ID; fi
IFS=',' read -r -a IDS <<< "$ID"
ORIGINS=""
for i in "${IDS[@]}"; do
  i="$(echo "$i" | tr -d '[:space:]')"
  [[ "$i" =~ ^[a-p]{32}$ ]] || { echo "That doesn't look like an extension ID (32 letters a-p): $i" >&2; exit 1; }
  ORIGINS+="${ORIGINS:+, }\"chrome-extension://$i/\""
done

command -v python3 >/dev/null || { echo "python3 is required (the bridge is one Python file)." >&2; exit 1; }
mkdir -p "$DEST"
cp "$HERE/viora_host.py" "$DEST/viora_host.py"
chmod +x "$DEST/viora_host.py"
sed -i.bak '1s|.*|#!/usr/bin/env python3|' "$DEST/viora_host.py" && rm -f "$DEST/viora_host.py.bak"

for d in "${DIRS[@]}"; do
  mkdir -p "$d"
  cat > "$d/$NAME.json" <<JSON
{
  "name": "$NAME",
  "description": "Viora Linux bridge: runs commands for the Viora extension",
  "path": "$DEST/viora_host.py",
  "type": "stdio",
  "allowed_origins": [ $ORIGINS ]
}
JSON
done
echo "Installed. Restart the browser, then Viora > Settings > Linux > Test connection."
