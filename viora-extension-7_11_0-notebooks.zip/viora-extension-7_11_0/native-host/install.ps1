<#
 Registers the Viora Linux bridge with Chrome / Edge / Brave on Windows.
 Commands run inside WSL (install it once with:  wsl --install ).

   powershell -ExecutionPolicy Bypass -File .\install.ps1 -ExtensionId <id>
   powershell -ExecutionPolicy Bypass -File .\install.ps1 -Uninstall

 The extension id is shown in Viora > Settings > Linux, and on chrome://extensions.
 No admin rights needed: everything goes under your own user profile.
#>
param(
  [string]$ExtensionId = '',
  [switch]$Uninstall
)
$ErrorActionPreference = 'Stop'
$name = 'com.viora.linux'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:LOCALAPPDATA 'Viora\native-host'
$keys = @(
  'HKCU:\Software\Google\Chrome\NativeMessagingHosts',
  'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts',
  'HKCU:\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts',
  'HKCU:\Software\Chromium\NativeMessagingHosts'
)

if ($Uninstall) {
  foreach ($k in $keys) { Remove-Item -Path "$k\$name" -Force -ErrorAction SilentlyContinue }
  Remove-Item -Path $dest -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host 'Removed the Viora Linux bridge.'
  exit 0
}

if (-not $ExtensionId) { $ExtensionId = Read-Host 'Viora extension ID (Viora > Settings > Linux)' }
$origins = @()
foreach ($id in ($ExtensionId -split ',')) {
  $id = $id.Trim()
  if ($id -notmatch '^[a-p]{32}$') { throw "That doesn't look like an extension ID (32 letters a-p): $id" }
  $origins += "chrome-extension://$id/"
}

# Find a real Python. The Microsoft Store 'python.exe' alias is only a stub, so test it for real.
$python = $null
$candidates = @(
  @{ cmd = 'py';      pre = @('-3') },
  @{ cmd = 'python';  pre = @() },
  @{ cmd = 'python3'; pre = @() }
)
foreach ($c in $candidates) {
  $found = Get-Command $c.cmd -ErrorAction SilentlyContinue
  if (-not $found) { continue }
  try {
    $out = & $found.Source @($c.pre) '-c' 'import sys; print(sys.version_info[0])' 2>$null
    if ("$out".Trim() -eq '3') { $python = $c; $pythonPath = $found.Source; break }
  } catch { }
}
if (-not $python) { throw 'Python 3 was not found. Install it from python.org (or: winget install Python.Python.3.12) and run this again.' }

New-Item -ItemType Directory -Path $dest -Force | Out-Null
Copy-Item (Join-Path $here 'viora_host.py') (Join-Path $dest 'viora_host.py') -Force
$pre = ($python.pre -join ' ')
$bat = "@echo off`r`n`"$pythonPath`" $pre `"%~dp0viora_host.py`" %*`r`n"
Set-Content -Path (Join-Path $dest 'host.bat') -Value $bat -Encoding ASCII

$manifest = [ordered]@{
  name            = $name
  description     = 'Viora Linux bridge: runs commands for the Viora extension'
  path            = (Join-Path $dest 'host.bat')
  type            = 'stdio'
  allowed_origins = $origins
}
$manifestPath = Join-Path $dest "$name.json"
$manifest | ConvertTo-Json | Set-Content -Path $manifestPath -Encoding ASCII
foreach ($k in $keys) {
  New-Item -Path "$k\$name" -Force | Out-Null
  Set-ItemProperty -Path "$k\$name" -Name '(default)' -Value $manifestPath
}

Write-Host "Installed to $dest"
$distros = (& wsl.exe -l -q 2>$null) -join ' ' -replace "`0", ''
if (-not $distros.Trim()) { Write-Warning 'No WSL distro found. In an admin terminal run:  wsl --install   (then restart).' }
else { Write-Host "WSL distros: $($distros.Trim())" }
Write-Host 'Restart the browser, then Viora > Settings > Linux > Test connection.'
