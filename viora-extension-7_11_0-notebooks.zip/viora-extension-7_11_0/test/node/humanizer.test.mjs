import {profileOf,profileNote,locateSentences,parseRepairs,repairFlagged,humanizeLoop,analyzeText} from '../../src/lib/humanizer.js';
import {systemFor} from '../../src/lib/prompts.js';
let pass=0,fail=0;const ok=(c,m)=>{c?pass++:fail++;console.log(c?'ok  ':'FAIL',m)};
const sample=`I never planned on writing this. Honestly, I just needed to get it down. The first week was a mess, and I mean a real mess, with boxes everywhere and no clue where the kettle was. We found it on day four. Behind the sofa? Don't ask. Then things settled, slowly, the way they do when you stop fighting them. My sister came round and laughed at the state of the kitchen. She wasn't wrong. By the end of the month I could find my keys again, which felt like winning something. It's funny how small the wins get. But they count. And I'll take them. Looking back, I'd do it all the same, except maybe the sofa bit. The neighbours were kind, mostly. One brought round a lasagne and a spare lamp, which we still use. I keep meaning to return the dish. It's been months, and that's a bit embarrassing, but she hasn't asked. Maybe I'll bake something instead. Nothing fancy. Just something warm.`;
const p=profileOf(sample);ok(p&&p.mean>3&&p.shortPct>0&&p.contractions>0,'profileOf measures a real sample: '+JSON.stringify(p));
ok(profileOf('too short')===null,'tiny sample ignored');
ok(/Sentences average/.test(profileNote(p))&&/never the sample/.test(profileNote(p)),'note tells model to copy habits not sentences');
// prompt wiring
const sys=systemFor('humanize',{}, {settings:{prefs:{writingSample:sample},humanizer:{style:[]}}});
ok(sys.includes('Measured from this person'),'writing sample reaches the humanize system prompt');
ok(!systemFor('humanize',{}, {settings:{prefs:{},humanizer:{style:[]}}}).includes('Measured from'),'no sample, no block');
// locate / parse
const text='One thing is clear. Furthermore, it is important to note that results vary widely. We tested 42 devices in 2024.';
ok(locateSentences(text,['Furthermore,  it is important to note that results vary widely.']).length===1,'locates flagged sentence despite whitespace diff');
ok(parseRepairs('```json\n["a b","c d"]\n```',2)?.length===2&&parseRepairs('["a"]',2)===null&&parseRepairs('nope',1)===null,'parseRepairs strict on count/shape');
// repairFlagged: fixes flagged, protects facts, leaves others
const msgs=[{role:'system',content:'S'},{role:'user',content:'u'}];
let r=await repairFlagged({text,flagged:['Furthermore, it is important to note that results vary widely.'],messages:msgs,rewrite:async()=>'["Results swing a lot."]'});
ok(r&&r.includes('Results swing a lot.')&&r.includes('One thing is clear.')&&r.includes('42 devices'),'only the flagged sentence changed');
r=await repairFlagged({text,flagged:['We tested 42 devices in 2024.'],messages:msgs,rewrite:async()=>'["We tried a bunch of devices."]'});
ok(r===null,'replacement that drops "42"/"2024" is rejected');
r=await repairFlagged({text,flagged:['One thing is clear.'],messages:msgs,rewrite:async()=>'garbage'});ok(r===null,'unusable model reply -> null (falls back)');
// loop: targeted repair is used, then detector rescored
const src='The framework is robust. Furthermore, it is crucial to understand that outcomes may vary. In conclusion, the approach is effective and scalable for many teams today. We shipped 3 releases.';
let calls=[];const rewrite=async(m)=>{const u=m.at(-1).content;calls.push(u.startsWith('Rewrite each numbered')?'repair':'full');if(u.startsWith('Rewrite each numbered'))return JSON.stringify(['Honestly it holds up fine.','Results swing, so test it first.'].slice(0,(u.match(/^\d+\. /gm)||[]).length));return 'The framework holds up. Furthermore, it is crucial to understand that outcomes may vary. It scales for plenty of teams. We shipped 3 releases.';return 'The framework holds up. Results swing, so test it first. It scales for plenty of teams. We shipped 3 releases.'};
let n=0;const check=async(t)=>({percent:n++===0?80:5,flagged:[t.split(/(?<=[.!?])\s+/)[1]]});
const out=await humanizeLoop({source:src,messages:msgs,rewrite,check,targeted:true,escalate:false,maxRetries:3,target:10});
ok(calls.includes('repair'),'loop attempted targeted repair after detector flagged sentences ('+calls.join(',')+')');
ok(out.detector?.percent<=10||out.passed,'final result passes after repair');
// regression: targeted=false behaves as before (no repair prompts)
calls=[];n=0;await humanizeLoop({source:src,messages:msgs,rewrite,check,targeted:false,escalate:false,maxRetries:2,target:10});
ok(!calls.includes('repair'),'targeted off -> old behaviour');
console.log(pass+' passed, '+fail+' failed');process.exit(fail?1:0)
