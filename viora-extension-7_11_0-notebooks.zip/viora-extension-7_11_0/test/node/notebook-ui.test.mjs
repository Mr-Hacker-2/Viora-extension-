// End-to-end smoke test of the Notebooks page with a stub DOM and a fake model server.
let pass=0,fail=0;const ok=(c,m)=>{c?pass++:fail++;console.log(c?'ok  ':'FAIL',m)};
const store={};
globalThis.chrome={storage:{local:{get:async k=>({[k]:store[k]}),set:async o=>Object.assign(store,o)}}};
const L={click:[],input:[],change:[],keydown:[]},els={};
const el=(id,o={})=>(els[id]={id,tagName:'DIV',value:'',innerHTML:'',textContent:'',scrollTop:0,selectionStart:0,selectionEnd:0,dataset:{},...o});
globalThis.document={addEventListener:(t,f)=>L[t].push(f),querySelector:s=>els[s.replace(/^#/,'')]||(/^\[data-n=/.test(s)?{click(){},scrollIntoView(){}}:null),createElement:()=>({click(){},getContext:()=>({measureText:s=>({width:String(s).length*6}),font:''})})};
globalThis.window={speechSynthesis:null};globalThis.confirm=()=>true;
let reqs=[];let reply='# Cells brief\n\nMitochondria make ATP [1].';
globalThis.fetch=async(url,init)=>{reqs.push({url:String(url),body:JSON.parse(init.body),auth:!!init.headers?.Authorization});
  const sse=`data: ${JSON.stringify({choices:[{delta:{content:reply}}]})}\n\ndata: [DONE]\n\n`;
  return new Response(new ReadableStream({start(c){c.enqueue(new TextEncoder().encode(sse));c.close()}}),{status:200,headers:{'content-type':'text/event-stream'}})};
const {createNotebooks,NB_CHOICE}=await import('../../src/workspace/notebook.js');
const S={tasks:[],docs:[{id:'d1',t:'My doc',b:'Photosynthesis uses light.'}],st:['To do','Doing','Done'],nb:{list:[]}};
let html='',saves=0,n=0;
const H={S:()=>S,save:()=>{saves++},render:()=>{html=NB.view()},E:s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])),uid:()=>'id'+(++n)};
const NB=createNotebooks(H);
const click=async(data,extra={})=>{const t={dataset:data,checked:true,...extra};t.closest=s=>s==='[data-n]'?t:null;for(const f of L.click)await f({target:t,stopPropagation(){}});await new Promise(r=>setTimeout(r,30))};
ok(NB_CHOICE==='search','notebook uses the Deep Search key/choice');
html=NB.view();ok(/New notebook/.test(html)&&/Think with your own sources/.test(html),'empty home explains notebooks');
el('nbn').value='Biology <b>';await click({n:'new'});
ok(S.nb.list.length===1&&/Biology &lt;b&gt;/.test(html)&&/class="nbg tb-refs"/.test(html),'new notebook opens on References and escapes its name');
['nbr','nbp','nbc','nbm','nbb','nbs','nbq','nbi','nbt2','nbcu'].forEach(i=>el(i));
await click({n:'f',k:'paste'});ok(/id="nbt2"/.test(els.nbr.innerHTML),'paste form appears');
els.nbi.value='Cell notes';els.nbt2.value='Mitochondria make ATP. The nucleus holds DNA.';await click({n:'addpaste'});
ok(S.nb.list[0].refs.length===1&&S.nb.list[0].refs[0].name==='Cell notes'&&/Cell notes/.test(els.nbr.innerHTML),'pasted text becomes reference 1');
await click({n:'f',k:'ws'});els.nbi.value='d1';await click({n:'addws'});
ok(S.nb.list[0].refs.length===2&&S.nb.list[0].refs[1].name==='My doc','workspace doc added as reference 2');
await click({n:'f',k:'url'});els.nbi.value='javascript:alert(1)';await click({n:'addurl'});
ok(S.nb.list[0].refs.length===2&&/https:\/\//.test(els.nbr.innerHTML),'non-http link refused with a message');
await click({n:'rt',id:S.nb.list[0].refs[1].id},{checked:false});ok(S.nb.list[0].refs[1].on===0,'reference can be switched off');
await click({n:'rt',id:S.nb.list[0].refs[1].id},{checked:true});
// chat
reply='Mitochondria make ATP [1].';els.nbq.value='What makes ATP?';await click({n:'ask'});
const chat=S.nb.list[0].chat;
ok(chat.length===2&&chat[1].t.includes('ATP [1]'),'chat answer stored');
const r=reqs.at(-1);
ok(/nvidia/.test(r.url)&&r.auth,'chat goes to the Deep Search key host with an Authorization header');
ok(r.body.messages[0].content.includes('ONLY the references')&&r.body.messages.at(-1).content.includes('[1] Cell notes')&&r.body.messages.at(-1).content.includes('[2] My doc'),'request carries system rules and numbered references');
ok(/data-n="cite"/.test(els.nbc.innerHTML),'answer shows citation chips');
// page generation
reply='# Cell Basics\n\nMitochondria make ATP [1]. Light drives photosynthesis [2].';
await click({n:'gen',t:'brief'});
const pg=S.nb.list[0].pages;
ok(pg.length===1&&pg[0].t==='Cell Basics'&&/## Sources\n1\. Cell notes\n2\. My doc/.test(pg[0].b),'Viora wrote a page, titled it and added sources');
ok(/Cell Basics/.test(els.nbp.innerHTML),'page shown in the editor');
// edit with selection + undo
const before=pg[0].b;reply='Mitochondria produce ATP';els.nbb.tagName='TEXTAREA';els.nbb.selectionStart=before.indexOf('Mitochondria make ATP');els.nbb.selectionEnd=els.nbb.selectionStart+'Mitochondria make ATP'.length;
await click({n:'ed',k:'improve'});
ok(pg[0].b.includes('Mitochondria produce ATP [1]')&&pg[0].b.includes('# Cell Basics')&&pg[0].hist.length===1,'edit changed only the selection');
await click({n:'undo'});ok(pg[0].b===before,'undo restores the page');
// export / integrations
S.nb.list[0].pages[0].b='# Plan\n- [ ] Read chapter\n- Draft essay';await click({n:'p2t'});
ok(S.tasks.map(t=>t.t).join('|')==='Read chapter|Draft essay','list lines become workspace tasks');
await click({n:'p2d'});ok(S.docs.some(d=>d.t==='Cell Basics'),'page saved into Docs');
// failure path
globalThis.fetch=async()=>new Response(JSON.stringify({error:{message:'nope'}}),{status:401});
const cnt=S.nb.list[0].pages.length;await click({n:'gen',t:'faq'});
ok(S.nb.list[0].pages.length===cnt,'a failed generation leaves no empty page');
// delete + home
await click({n:'home'});ok(/Biology/.test(html)&&/nbcard/.test(html),'home lists the notebook');
await click({n:'del',id:S.nb.list[0].id});ok(S.nb.list.length===0,'notebook deleted');
console.log(pass+' passed, '+fail+' failed');process.exit(fail?1:0)
