/**
 * Viora — side panel controller.
 * One backend, four personalities. Owns the thread, runs the turn, renders it.
 */

import {
  getSettings, saveSettings, getThreads, saveThread, deleteThread, newThread,
  groqConfig, configForChoice, partnerConfig, rememberModel
} from '../lib/storage.js';
import { MODELS, MODEL_ORDER, VISION_CHAIN, getModel, chainFor, partnerChain } from '../lib/models.js';
import { streamChat, completeChat, listModels, ProviderError, transcribeAudio, synthesizeSpeech } from '../lib/providers.js';
import { renderMarkdown, renderInline, bindCodeCopy, escapeHtml } from '../lib/markdown.js';
import { sourceStrip, linkInlineMarkers, extractTrailingSources, mergeSources, withSourceList } from '../lib/citations.js';
import { systemFor, withPageContext, REVIEWER_SYSTEM } from '../lib/prompts.js';
import { checkAiScore, DetectorError } from '../lib/detector.js';
import { gatherWeb, formatWebContext } from '../lib/web.js';
import { readFile, readScreenshot, attachmentsToText, attachmentsToContent, LIMITS } from '../lib/files.js';
import { downloadPdfBlob, markdownToPdf, pdfFilename, pdfTitle } from '../lib/pdf.js';
import { icon, MODEL_ICON } from '../lib/icons.js';
import { STYLE_QUESTIONS, STYLE_ANSWER_MAX, STYLE_ANSWER_MIN, buildStyleProfile } from '../lib/style-questions.js';
import {
  activeTab, openTabs, snapshot, pageContext, parsePlan, parseReview, runPlan, describeAction,
  isRestrictedUrl, PageAccessError, MAX_TURNS, MAX_TOTAL_ACTIONS, screenshotSelect, extractJson
} from '../lib/automation.js';

const $ = (sel) => document.querySelector(sel);

// Safety net: an uncaught error anywhere (a click handler, a render pass,
// a rejected promise) used to fail silently — a button would just look
// dead, with nothing in the UI to say why. Surface it in the status line
// instead, and always to the console, so a real bug is diagnosable from
// screenshots/reports instead of "nothing happens".
window.addEventListener('error', (e) => {
  console.error('[Viora]', e.error || e.message);
  try { setStatus('Something went wrong — check the console (right-click → Inspect).'); } catch {}
});
window.addEventListener('unhandledrejection', (e) => {
  console.error('[Viora]', e.reason);
  try { setStatus('Something went wrong — check the console (right-click → Inspect).'); } catch {}
});

const el = {
  root: document.documentElement,
  thread: $('#thread'),
  welcome: $('#welcome'),
  welcomeIcon: $('#welcome-icon'),
  welcomeLine: $('#welcome-line'),
  suggestions: $('#suggestions'),
  form: $('#composer'),
  input: $('#input'),
  send: $('#send'),
  hint: $('#hint'),
  status: $('#status'),
  attach: $('#attach'),
  attachSheet: $('#attach-sheet'),
  attachUpload: $('#attach-upload'),
  attachUploadIcon: $('#attach-upload-icon'),
  attachScreenshot: $('#attach-screenshot'),
  attachScreenshotIcon: $('#attach-screenshot-icon'),
  tabsDivider: $('#tabs-divider'),
  tabList: $('#tab-list'),
  fileInput: $('#file-input'),
  attachTray: $('#attach-tray'),
  pageChip: $('#page-chip'),
  pageChipIcon: $('#page-chip-icon'),
  pageChipTitle: $('#page-chip-title'),
  pageChipRemove: $('#page-chip-remove'),
  mic: $('#mic'),
  micIcon: $('#mic-icon'),
  voice: $('#voice'),
  voiceIcon: $('#voice-icon'),
  modelBtn: $('#model-btn'),
  modelSheet: $('#model-sheet'),
  modelList: $('#model-list'),
  pillIcon: $('#pill-icon'),
  pillName: $('#pill-name'),
  drawer: $('#drawer'),
  threadList: $('#thread-list'),
  threadEmpty: $('#thread-empty'),
  restyle: $('#restyle'),
  onboard: $('#onboard'),
  obDots: $('#ob-dots'),
  obCount: $('#ob-count'),
  obTitle: $('#ob-q-title'),
  obPrompt: $('#ob-q-prompt'),
  obAnswer: $('#ob-answer'),
  obNeed: $('#ob-need'),
  obChars: $('#ob-chars'),
  obBack: $('#ob-back'),
  obNext: $('#ob-next'),
  obSkip: $('#ob-skip')
};

const OPENERS = {
  flash: 'What are we working on?',
  search: 'What should I go and find out?',
  math: 'Give me something to chew on.',
  automate: 'What should I do on this page?',
  humanize: 'Paste the text and I’ll make it sound like you wrote it.'
};

const SUGGESTIONS = {
  flash: ['Summarise what I am reading', 'Draft a reply to this email', 'Talk me through two options'],
  search: ['What changed in EU AI rules this year?', 'Compare this year’s flagship phone cameras', 'Is this library still maintained?'],
  math: ['Solve 3x² − 7x + 2 = 0 step by step', 'Why does this throw a null reference?', 'Write a debounce hook in TypeScript'],
  automate: ['Fill this form with my details', 'Read me the pricing table', 'Open the first search result'],
  humanize: ['Make this sound more casual: ', 'Humanize this, keep it under 150 words: ', 'Humanize this for a school essay: ']
};

let settings = await getSettings();
let config = groqConfig(settings);
let thread = newThread(settings.prefs.model);
let controller = null;
let busy = false;
let pendingAttachments = [];
/** The tab picked from the "+" menu, if any — its page is read on every turn until removed. */
let selectedPage = null;

/* ---------------- shell ---------------- */

function current() {
  return getModel(thread.model);
}

function chain(choice = thread.model) {
  return chainFor(choice, {
    overrides: settings.modelOverrides,
    resolved: settings.resolvedModels
  });
}

/** Remember which ID answered, so the dead ones aren't retried next turn. */
function noteModel(choice) {
  return async (modelId) => {
    if (settings.resolvedModels[choice] !== modelId) {
      settings = await rememberModel(choice, modelId);
    }
  };
}

function setModel(choice) {
  thread.model = choice;
  const model = current();
  el.root.dataset.model = choice;
  el.pillIcon.innerHTML = icon(MODEL_ICON[choice]);
  el.pillName.textContent = model.name;
  el.modelBtn.title = model.blurb;
  el.input.placeholder = model.placeholder;
  el.welcomeIcon.innerHTML = icon(MODEL_ICON[choice]);
  el.welcomeLine.textContent = OPENERS[choice] || OPENERS.flash;

  el.attach.hidden = !model.canAttach;
  if (!model.canAttach) {
    if (pendingAttachments.length) {
      pendingAttachments = [];
      renderTray();
    }
    if (selectedPage) {
      selectedPage = null;
      renderPageChip();
    }
  }

  renderSuggestions();
  renderModelList();
  el.restyle.hidden = choice !== 'humanize' || !humanizerReady();
  syncHumanizerGate();
  saveSettings({ prefs: { model: choice } });
}

function renderModelList() {
  el.modelList.replaceChildren();
  for (const id of MODEL_ORDER) {
    const model = MODELS[id];
    const li = document.createElement('li');

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'model-row';
    btn.dataset.model = id;
    btn.setAttribute('role', 'option');
    btn.setAttribute('aria-selected', String(id === thread.model));

    const rowIcon = document.createElement('span');
    rowIcon.className = 'row-icon';
    rowIcon.innerHTML = icon(MODEL_ICON[id]);

    const copy = document.createElement('span');
    copy.className = 'row-copy';
    const name = document.createElement('span');
    name.className = 'row-name';
    name.textContent = model.name;
    const blurb = document.createElement('span');
    blurb.className = 'row-blurb';
    blurb.textContent = model.blurb;
    copy.append(name, blurb);

    const tick = document.createElement('span');
    tick.className = 'row-tick';
    if (id === thread.model) tick.innerHTML = icon('check');

    btn.append(rowIcon, copy, tick);
    btn.addEventListener('click', () => {
      setModel(id);
      closeSheets();
      el.input.focus();
    });

    li.append(btn);
    el.modelList.append(li);
  }
}

function renderSuggestions() {
  el.suggestions.replaceChildren();
  for (const text of SUGGESTIONS[thread.model] || []) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'suggestion';
    b.textContent = text;
    b.addEventListener('click', () => {
      el.input.value = text;
      el.input.focus();
      autosize();
    });
    el.suggestions.append(b);
  }
}

function closeSheets() {
  el.modelSheet.hidden = true;
  el.drawer.hidden = true;
  el.attachSheet.hidden = true;
  el.modelBtn.setAttribute('aria-expanded', 'false');
  $('#history').setAttribute('aria-expanded', 'false');
  el.attach.setAttribute('aria-expanded', 'false');
}

/* ---------------- the "+" menu: upload a file, or read an open tab ---------------- */

/** Set an icon element's content to a tab's favicon, falling back to the generic tab glyph. */
function setFavicon(target, favIconUrl) {
  target.replaceChildren();
  if (!favIconUrl) {
    target.innerHTML = icon('tab');
    return;
  }
  const img = document.createElement('img');
  img.src = favIconUrl;
  img.alt = '';
  img.addEventListener('error', () => { target.innerHTML = icon('tab'); }, { once: true });
  target.append(img);
}

function renderPageChip() {
  if (!selectedPage) {
    el.pageChip.hidden = true;
    return;
  }
  el.pageChip.hidden = false;
  el.pageChipTitle.textContent = selectedPage.title;
  el.pageChipTitle.title = selectedPage.url;
  setFavicon(el.pageChipIcon, selectedPage.favIconUrl);
}

function pickPage(tab) {
  selectedPage = { id: tab.id, title: tab.title, url: tab.url, favIconUrl: tab.favIconUrl };
  renderPageChip();
  closeSheets();
  el.input.focus();
}

const tabsById = new Map();

async function renderTabList() {
  el.tabList.replaceChildren();
  el.tabsDivider.hidden = true;
  tabsById.clear();

  let tabs;
  try {
    tabs = await openTabs();
  } catch {
    return;
  }
  // The panel's own window still counts, but there's nothing useful to
  // hand back for a tab Viora structurally can't read — show it, but disabled.
  if (!tabs.length) return;

  el.tabsDivider.hidden = false;
  for (const tab of tabs) {
    const li = document.createElement('li');
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'sheet-action tab-row';
    row.disabled = tab.restricted;
    if (tab.restricted) row.title = "Viora can't read this page.";

    const favicon = document.createElement('span');
    favicon.className = 'sheet-action-icon';
    setFavicon(favicon, tab.favIconUrl);

    const copy = document.createElement('span');
    copy.className = 'tab-copy';
    const title = document.createElement('span');
    title.className = 'tab-title';
    title.textContent = tab.title;
    const host = document.createElement('span');
    host.className = 'tab-host';
    try {
      host.textContent = new URL(tab.url).hostname;
    } catch {
      host.textContent = tab.url;
    }
    copy.append(title, host);

    row.append(favicon, copy);
    if (!tab.restricted) row.dataset.tabId = String(tab.id);
    li.append(row);
    el.tabList.append(li);
    if (!tab.restricted) tabsById.set(tab.id, tab);
  }
}

// Delegated: the list is torn down and rebuilt every time the "+" sheet
// opens (renderTabList), so binding to the container instead of each row
// means a click always hits a live listener, however many times it's redrawn.
el.tabList.addEventListener('click', (e) => {
  const row = e.target.closest('.tab-row');
  if (!row || row.disabled) return;
  const tab = tabsById.get(Number(row.dataset.tabId));
  if (tab) pickPage(tab);
});

function setStatus(text) {
  el.status.textContent = text;
  el.status.hidden = !text;
}

function setBusy(state) {
  busy = state;
  el.send.classList.toggle('stop', state);
  el.send.setAttribute('aria-label', state ? 'Stop' : 'Send');
  el.hint.textContent = state ? 'Thinking' : '';
}

let scrollFrame = 0;
function scrollDown() {
  // Streaming calls this per token; one scroll per frame is plenty.
  if (scrollFrame) return;
  scrollFrame = requestAnimationFrame(() => {
    scrollFrame = 0;
    el.thread.scrollTop = el.thread.scrollHeight;
  });
}

function autosize() {
  el.input.style.height = 'auto';
  el.input.style.height = `${Math.min(el.input.scrollHeight, 168)}px`;
}

/* ---------------- rendering ---------------- */

function clearWelcome() {
  if (el.welcome.isConnected) el.welcome.remove();
}

function attachmentChip(a, onRemove) {
  const chip = document.createElement('span');
  chip.className = 'attach-chip' + (a.warning ? ' has-warning' : '');
  if (a.warning) chip.title = a.warning;

  if (a.kind === 'image' && a.dataUrl) {
    const img = document.createElement('img');
    img.src = a.dataUrl;
    img.alt = '';
    chip.append(img);
  } else {
    const icon = document.createElement('span');
    icon.className = 'attach-icon';
    icon.textContent = a.kind === 'pdf' ? 'PDF' : 'TXT';
    chip.append(icon);
  }

  const name = document.createElement('span');
  name.className = 'attach-name';
  name.textContent = a.name;
  chip.append(name);

  if (onRemove) {
    const x = document.createElement('button');
    x.type = 'button';
    x.className = 'attach-remove';
    x.textContent = '×';
    x.setAttribute('aria-label', `Remove ${a.name}`);
    chip.append(x);
  }
  return chip;
}

function addUser(text, attachments = []) {
  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg user';

  if (attachments.length) {
    const tray = document.createElement('div');
    tray.className = 'attach-chips';
    attachments.forEach((a) => tray.append(attachmentChip(a)));
    node.append(tray);
  }
  if (text) {
    const p = document.createElement('div');
    p.className = 'user-text';
    p.textContent = text;
    node.append(p);
  }

  el.thread.append(node);
  scrollDown();
}

function addAssistant() {
  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg assistant streaming';

  const badge = document.createElement('span');
  badge.className = 'who';
  badge.innerHTML = icon(MODEL_ICON[thread.model]);

  const trace = document.createElement('details');
  trace.className = 'reasoning';
  trace.hidden = true;
  const summary = document.createElement('summary');
  summary.textContent = 'Working it out';
  const pre = document.createElement('div');
  pre.className = 'trace';
  trace.append(summary, pre);

  const body = document.createElement('div');
  body.className = 'body';

  node.append(badge, trace, body);
  el.thread.append(node);
  scrollDown();

  let pendingMd = null;
  let mdFrame = 0;

  return {
    node,
    body,
    setReasoning(text) {
      if (!settings.prefs.showReasoning || !text) return;
      trace.hidden = false;
      pre.textContent = text;
    },
    // Re-rendering the whole markdown tree for every streamed token gets
    // slower the longer the reply is. Coalesce to one render per frame —
    // always the latest text, so nothing is lost — and flush on finish.
    setMarkdown(text) {
      pendingMd = text;
      if (mdFrame) return;
      mdFrame = requestAnimationFrame(() => {
        mdFrame = 0;
        if (pendingMd !== null) {
          body.innerHTML = renderMarkdown(pendingMd);
          pendingMd = null;
        }
      });
    },
    finish() {
      if (mdFrame) {
        cancelAnimationFrame(mdFrame);
        mdFrame = 0;
      }
      if (pendingMd !== null) {
        body.innerHTML = renderMarkdown(pendingMd);
        pendingMd = null;
      }
      node.classList.remove('streaming');
      bindCodeCopy(body);
    }
  };
}

function addError(err, retry, extra) {
  clearWelcome();
  const box = document.createElement('div');
  box.className = 'msg assistant';
  const inner = document.createElement('div');
  inner.className = 'error';
  inner.textContent = err.message || 'Something went wrong.';
  if (err.hint) {
    const fix = document.createElement('span');
    fix.className = 'fix';
    fix.textContent = err.hint;
    inner.append(fix);
  }
  if (retry) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'Try again';
    btn.addEventListener('click', () => {
      box.remove();
      retry();
    });
    inner.append(btn);
  }
  box.append(inner);
  if (extra) inner.append(extra);
  el.thread.append(box);
  scrollDown();
}

/**
 * When every model in a chain is gone, ask Groq what it does serve and let the
 * user pin one, rather than sending them hunting through settings.
 */
function modelPicker(choice, retryFn) {
  const wrap = document.createElement('div');
  wrap.className = 'model-fix';
  const providerConfig = configForChoice(settings, choice);
  const providerLabel = providerConfig.label || 'Groq';

  const load = document.createElement('button');
  load.type = 'button';
  load.textContent = `Show what ${providerLabel} is serving`;

  load.addEventListener('click', async () => {
    load.disabled = true;
    load.textContent = 'Loading';
    try {
      const models = await listModels({ config: providerConfig });
      load.remove();

      const note = document.createElement('p');
      note.className = 'fix';
      note.textContent = `${providerLabel} has ${models.length} models right now. Pick the one ${getModel(choice).name} should use.`;

      const list = document.createElement('div');
      list.className = 'id-list';

      for (const id of models) {
        const b = document.createElement('button');
        b.type = 'button';
        b.textContent = id;
        b.addEventListener('click', async () => {
          settings = await saveSettings({ modelOverrides: { [choice]: id } });
          retryFn?.();
        });
        list.append(b);
      }

      wrap.append(note, list);
    } catch (err) {
      load.disabled = false;
      load.textContent = `Show what ${providerLabel} is serving`;
      const fail = document.createElement('span');
      fail.className = 'fix';
      fail.textContent = err.message;
      wrap.append(fail);
    }
  });

  wrap.append(load);
  return wrap;
}

/* ---------------- history ---------------- */

async function refreshDrawer() {
  const threads = await getThreads();
  el.threadList.replaceChildren();
  el.threadEmpty.hidden = threads.length > 0;

  for (const t of threads) {
    const li = document.createElement('li');
    const row = document.createElement('div');
    row.className = 'thread-item';

    const open = document.createElement('button');
    open.type = 'button';
    open.className = 't-title';
    open.textContent = t.title;
    open.addEventListener('click', () => loadThread(t));

    const mark = document.createElement('span');
    mark.className = 't-mode';
    mark.innerHTML = icon(MODEL_ICON[t.model] || 'flash');
    mark.title = getModel(t.model).name;

    const del = document.createElement('button');
    del.type = 'button';
    del.className = 't-del';
    del.title = 'Delete';
    del.setAttribute('aria-label', `Delete ${t.title}`);
    del.textContent = '×';
    del.dataset.threadId = t.id;

    row.append(open, mark, del);
    li.append(row);
    el.threadList.append(li);
  }
}

// Delegated: the drawer's rows are rebuilt on every refreshDrawer() call, so a
// listener bound directly to a row is gone the moment the list re-renders.
// Binding once on the stable #thread-list container survives every re-render.
el.threadList.addEventListener('click', async (e) => {
  const del = e.target.closest('.t-del');
  if (!del) return;
  try {
    await deleteThread(del.dataset.threadId);
    refreshDrawer();
  } catch (err) {
    setStatus("Couldn't delete that conversation — try again.");
  }
});

function loadThread(saved) {
  thread = structuredClone(saved);
  closeSheets();
  el.thread.replaceChildren();
  setModel(thread.model || 'flash');

  for (const m of thread.messages) {
    if (m.role === 'user') {
      addUser(m.displayText ?? m.content, m.attachments || []);
    } else {
      const view = addAssistant();
      view.setReasoning(m.reasoning);
      view.setMarkdown(m.content);
      if (m.sources?.length && settings.prefs.citations) {
        linkInlineMarkers(view.body, m.sources);
        view.body.append(sourceStrip(m.sources));
      }
      view.finish();
      if (m.pdf && m.content?.trim()) attachPdfFile(view, withSourceList(m.content, m.sources || []));
    }
  }
  scrollDown();
}

async function persist(firstPrompt) {
  if (thread.title === 'New conversation' && firstPrompt) {
    thread.title = firstPrompt.replace(/\s+/g, ' ').slice(0, 52) + (firstPrompt.length > 52 ? '…' : '');
  }
  await saveThread(thread);
  refreshDrawer();
}

/* ---------------- the turn ---------------- */

async function collectPage() {
  if (!selectedPage) return null;
  try {
    return await pageContext(selectedPage.id);
  } catch (err) {
    setStatus(err.message || "Viora can't read that page.");
    return null;
  }
}

/**
 * Groq counts a request's prompt *plus its max_tokens* against the minute's
 * token bucket before it runs, and Viora's shared key has only 8,000 a minute.
 * So keep the reservation honest: image turns stay small, and Flash — the
 * quick, chatty one — doesn't hold back 2,048 tokens for answers that run a
 * few hundred. Essays and the slower modes keep the user's full setting.
 * (If the bucket is still too full, providers.js shrinks it further, live;
 * if the prompt alone is over the model's ceiling, runChat() trims the
 * context and asks again rather than surfacing the refusal.)
 */
const FLASH_REPLY_TOKENS = 1500;

function outputReserve({ hasImages, choice, essay }) {
  const wanted = settings.prefs.maxTokens;
  if (hasImages) return Math.min(wanted, 768);
  if (choice === 'flash' && !essay) return Math.min(wanted, FLASH_REPLY_TOKENS);
  return wanted;
}

/**
 * The live web and the conversation history share the same fixed allowance:
 * Groq's free tier meters the whole shared key, and prompt tokens count
 * against it whether they're a web page or last week's messages. So the web
 * block gets its own cap up front, and history gives up exactly what the
 * block took — a turn never grows just because it also went online.
 */
const WEB_BUDGET = 7000;
const WEB_BUDGET_IMAGES = 3200;
// Deep Search reads wider than the everyday modes: more pages and a bigger
// block. It is the one mode where a longer wait and a heavier turn is the
// point — but the shared free-tier key still meters tokens per minute, and
// the TRIMS ladder below shrinks the block automatically if a turn is refused.
const DEEP_BUDGET = 12000;
const DEEP_DOCS = 5;

/** Older turns are the first thing to go when a thread's history gets heavy. */
const HISTORY_CHARS = 14000;

function trimHistory(messages, maxChars) {
  const out = [...messages];
  const size = (ms) => ms.reduce((n, m) => n + String(m.content || '').length, 0);
  // Always keep the newest message; drop from the front until it fits, and
  // don't leave a reply dangling at the start with no question above it.
  while (out.length > 1 && size(out) > maxChars) out.shift();
  while (out.length > 1 && out[0].role !== 'user') out.shift();
  return out;
}

/** How much of the turn's budget the web block is using (0 when there is none). */
const webChars = (web) => (web?.block ? web.block.length : 0);

async function runChat() {
  const model = current();
  const page = await collectPage();
  const attachments = pendingTurnAttachments;
  const hasImages = attachments.some((a) => a.kind === 'image');

  // Images need a vision model whichever personality is selected. The vision
  // model only exists on Groq, so an image turn always uses Groq regardless
  // of whether the chosen personality normally runs on NVIDIA.
  const models = hasImages ? [...VISION_CHAIN, ...chain()] : chain();
  const turnConfig = hasImages ? groqConfig(settings) : configForChoice(settings, thread.model);

  // The internet pass comes before a single token is spent: search what the
  // person asked, open the links they pasted and the strongest results (a
  // linked .pdf arrives as its text), and fit the lot into this turn's
  // budget. Modes without canWeb — the Humanizer and Automate — are routed
  // to their own runners by send() and never reach this line.
  const lastMessage = thread.messages.at(-1);
  const askText = String(lastMessage?.displayText ?? lastMessage?.content ?? '');
  let web = null;
  const deep = thread.model === 'search';
  if (model.canWeb) {
    try {
      web = await gatherWeb({
        text: askText,
        signal: controller?.signal,
        budget: hasImages ? WEB_BUDGET_IMAGES : deep ? DEEP_BUDGET : WEB_BUDGET,
        maxDocs: hasImages ? 2 : deep ? DEEP_DOCS : 3,
        deep: deep && !hasImages,
        onStatus: setStatus
      });
    } catch (err) {
      if (err.name === 'AbortError') throw err;
      // A turn that can't reach the web still answers — it just says the
      // check didn't happen (prompts.js WEB_DOWN) instead of faking it.
      console.warn('[Viora] live web unavailable:', err);
      web = { ready: false, sources: [], block: '', searched: false, read: 0 };
    }
    setStatus('');
  }
  /**
   * Groq refuses a request whose prompt + reserved reply is over its
   * per-minute ceiling *before* running any of it, and research turns are
   * the big ones: web block, page context and history all ride along.
   * providers.js shrinks the reservation and re-sends when that is enough;
   * when the prompt itself is over the ceiling nothing inside the provider
   * can help, so the panel rebuilds the same turn with less and asks again —
   * page context first (a convenience, not the answer), then history, then
   * the web block's text (the numbered list survives, just shorter, so [1]
   * still lands on chip 1). A slightly thinner answer beats a failed turn.
   * Level 0 is the full-fat turn; the rest are only ever reached on refusal.
   */
  const TRIMS = [
    { page: true, history: null, web: null, newest: 0 },
    { page: false, history: 3500, web: 3500, newest: 0 },
    { page: false, history: 0, web: 1500, newest: 6000 }
  ];

  const buildMessages = (level) => {
    const t = TRIMS[level];
    const liveWeb =
      web && t.web && web.block.length > t.web
        ? { ...web, ready: true, block: formatWebContext(web.sources, t.web).block }
        : web;

    // The last 20 messages are plenty of context, and a shorter prompt means
    // a faster first token on long threads. An image turn goes to qwen (7k
    // input tokens/min on free tier), so its history is cut much harder —
    // and in both cases history gives up exactly the room the web block took.
    const baseHistory = hasImages ? 6000 : HISTORY_CHARS;
    const wanted = t.history ?? Math.max(baseHistory - webChars(liveWeb), hasImages ? 2000 : 6000);
    const history = trimHistory(thread.messages.slice(hasImages ? -6 : -20), wanted);
    const msgs = [
      {
        role: 'system',
        content: withPageContext(
          systemFor(model.prompt, settings.prefs, {
            canSearch: Boolean(liveWeb?.block),
            settings,
            web: liveWeb,
            // The message itself: if it names a way of writing, styles.js
            // lends that turn the matching techniques from its catalogue.
            ask: askText
          }),
          t.page ? page : null
        )
      },
      ...history.map(({ role, content }) => ({ role, content }))
    ];

    // The newest message is the question itself, plus any pasted file's text.
    // It is the one thing that must survive, so it is cut down rather than
    // dropped when the ceiling is really tight.
    if (t.newest && msgs.length > 1) {
      const last = msgs[msgs.length - 1];
      if (typeof last.content === 'string' && last.content.length > t.newest) {
        last.content = `${last.content.slice(0, t.newest)}\n\n[earlier context trimmed to fit this model's limit]`;
      }
    }

    if (hasImages) {
      const last = msgs[msgs.length - 1];
      last.content = attachmentsToContent(last.content, attachments);
    }
    return msgs;
  };

  const view = addAssistant();
  let content = '';
  let reasoning = '';

  // Some hosted reasoning models put their chain inline in <think> tags
  // instead of a separate field, so split it back out before rendering.
  const split = (raw) => {
    const open = raw.indexOf('<think>');
    if (open < 0) return { think: '', answer: raw };
    const close = raw.indexOf('</think>');
    return close < 0
      ? { think: raw.slice(open + 7), answer: '' }
      : { think: raw.slice(open + 7, close), answer: raw.slice(0, open) + raw.slice(close + 8) };
  };

  // Free-tier Groq caps qwen3.8-27b (the vision model) at 1000 output tokens
  // per minute and rejects a request that *expects* more before it runs, so
  // keep image turns modest no matter what the default maxTokens is.
  const maxTokens = outputReserve({ hasImages, choice: thread.model, essay: pendingEssayPdf });

  // A refusal that says the request is too large for the model's per-minute
  // ceiling is answered with a smaller version of the same turn, not with an
  // error the person has to untangle. Nothing has streamed at that point, so
  // the bubble is still empty and simply starts filling on the retry.
  let level = 0;
  let result;
  for (;;) {
    try {
      result = await streamChat({
        config: turnConfig,
        models,
        messages: buildMessages(level),
        temperature: model.temperature,
        maxTokens,
        // Flash is the "quick, chatty" Viora — ask gpt-oss to keep its thinking
        // short so the first word lands sooner. Search/Math keep full reasoning.
        quick: thread.model === 'flash',
        signal: controller.signal,
        onModel: noteModel(hasImages ? 'vision' : thread.model),
        // Surface the (usually sub-second) rate-limit wait instead of leaving
        // the panel silent over it.
        onRetry: (ms) => setStatus(`Rate limited — waiting ${ms < 1500 ? 'a moment' : `~${Math.ceil(ms / 1000)}s`}`),
        onDelta: (d) => {
          if (d.reasoning) {
            reasoning += d.reasoning;
            view.setReasoning(reasoning);
          }
          if (d.content) {
            setStatus('');
            content += d.content;
            const { think, answer } = split(content);
            if (think) view.setReasoning(reasoning + think);
            view.setMarkdown(answer);
          }
          scrollDown();
        }
      });
      break;
    } catch (err) {
      if (err.code !== 'too_large' || level >= TRIMS.length - 1) throw err;
      level++;
      content = '';
      reasoning = '';
      setStatus("That's a lot of context — trimming it to fit and asking again.");
    }
  }

  setStatus('');
  const { think, answer } = split(result.content);
  const cleaned = answer.trim();
  // The model's own trailing "Sources:" block is pulled out of the text (it
  // becomes chips instead) and folded into the list the web pass produced,
  // so what's rendered is one list in the order the numbers refer to it.
  const { text: displayAnswer, sources: cited } = extractTrailingSources(cleaned);
  const sources = mergeSources(web?.sources || [], cited);

  view.setMarkdown(displayAnswer);
  if (sources.length && settings.prefs.citations) {
    linkInlineMarkers(view.body, sources);
    view.body.append(sourceStrip(sources));
  }
  view.finish();

  thread.messages.push({
    role: 'assistant',
    content: displayAnswer,
    reasoning: (result.reasoning || think).trim(),
    sources
  });

  if (pendingEssayPdf) {
    pendingEssayPdf = false;
    if (displayAnswer.trim()) {
      // The on-screen reply shows chips; the file has to carry its own list,
      // so an exported essay still cites whatever the web pass found.
      attachPdfFile(view, withSourceList(displayAnswer, sources));
      // Remember it belongs to this message so a reloaded conversation
      // rebuilds the file chip from the stored markdown.
      const pushed = thread.messages.at(-1);
      if (pushed?.role === 'assistant') pushed.pdf = true;
    }
  }
}

/**
 * Viora Automate's eyes. Screenshots the tab, has the vision model describe it
 * in plain text, and hands that back as the step's result (which lands in the
 * planner's "Done so far"). Chrome can only capture the tab that's in front,
 * so a background tab is brought forward first.
 */
async function lookAtTab(tabId, action) {
  const tab = await chrome.tabs.get(tabId);
  if (isRestrictedUrl(tab.url)) throw new PageAccessError(tab.url);
  if (!tab.active) {
    await chrome.tabs.update(tabId, { active: true });
    await new Promise((r) => setTimeout(r, 300)); // let it paint
  }

  const shot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 70 });
  // Whole viewport, downscaled the same way uploaded images are.
  const image = await readScreenshot(shot, { x: 0, y: 0, width: 100000, height: 100000 }, 1);

  const focus = (action.value || '').trim();
  const ask =
    'You are the eyes of a browser assistant. Describe what is on this screenshot of a web page in plain text: ' +
    'the main sections and their layout, visible text that matters, buttons, fields and their state (filled, empty, disabled, error), ' +
    'images or charts and what they show, popups or banners in the way, and anything that looks loading or broken. ' +
    (focus ? `Pay special attention to: ${focus}. ` : '') +
    'Be specific and concise, under 180 words, no preamble.';

  const { content } = await completeChat({
    config: groqConfig(settings),
    models: VISION_CHAIN,
    messages: [{ role: 'user', content: attachmentsToContent(ask, [image]) }],
    temperature: 0.2,
    // Free-tier Groq caps the vision model's output per minute; stay modest.
    maxTokens: 400,
    timeoutMs: 20000,
    signal: controller?.signal
  });
  const seen = content.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
  if (!seen) return { ok: false, detail: 'The vision model came back empty.' };
  return { ok: true, detail: `Saw: ${seen.slice(0, 900)}` };
}

/* ---------------- Humanizer onboarding: ten question cards ---------------- */

/**
 * The Humanizer rewrites in *the person's* voice, so before first use it asks
 * ten long-form questions (style-questions.js), one card at a time. Until
 * they're all answered the thread and composer are replaced by the cards
 * (body.gated); the header stays, so any other Viora is one tap away.
 * Progress is saved as they go, so closing the panel mid-way loses nothing.
 */
function humanizerReady() {
  const h = settings.humanizer;
  // `onboarded` alone is enough — a skipped run has no style answers at all,
  // a finished one has some, and prompts.js is already fine with an empty list.
  return Boolean(h?.onboarded);
}

const onboarding = {
  open: false,
  step: 0,
  answers: [],
  saveTimer: 0
};

/**
 * saveSettings is read-modify-write, so two overlapping calls can undo each
 * other — a draft save still in flight when Finish lands would flip
 * `onboarded` back to false. Run every onboarding write one after another.
 */
let onboardingSaves = Promise.resolve();
function queueSettingsSave(patch) {
  const run = onboardingSaves.then(() => saveSettings(patch));
  onboardingSaves = run.catch(() => {});
  return run;
}

function syncHumanizerGate() {
  const needed = thread.model === 'humanize' && !humanizerReady();
  if (needed && !onboarding.open) openOnboarding();
  else if (!needed && onboarding.open) closeOnboarding();
}

function openOnboarding({ fresh = false } = {}) {
  const draft = settings.humanizer?.draft;
  // Coming back to a half-finished run, or retaking with the old answers
  // filled in — never a blank start when there's something to keep.
  const saved = fresh ? [] : Array.isArray(draft?.answers) ? draft.answers : [];
  onboarding.answers = STYLE_QUESTIONS.map((_, i) => String(saved[i] || ''));
  onboarding.step = fresh ? 0 : Math.min(Math.max(Number(draft?.step) || 0, 0), STYLE_QUESTIONS.length - 1);
  onboarding.open = true;
  document.body.classList.add('gated');
  el.onboard.hidden = false;
  closeSheets();
  renderOnboarding();
  el.obAnswer.focus();
}

function closeOnboarding() {
  clearTimeout(onboarding.saveTimer);
  onboarding.open = false;
  document.body.classList.remove('gated');
  el.onboard.hidden = true;
}

const obDone = (i) => onboarding.answers[i].trim().length >= STYLE_ANSWER_MIN;

function renderOnboarding() {
  const { step } = onboarding;
  const total = STYLE_QUESTIONS.length;
  const q = STYLE_QUESTIONS[step];

  el.obDots.replaceChildren();
  STYLE_QUESTIONS.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.className = `ob-dot${i === step ? ' now' : obDone(i) && i < step ? ' done' : ''}`;
    dot.setAttribute('role', 'tab');
    dot.setAttribute('aria-selected', String(i === step));
    dot.setAttribute('aria-label', `Question ${i + 1}`);
    // Go back to a finished card; not ahead past one that isn't answered.
    dot.disabled = i > step;
    dot.addEventListener('click', () => goToStep(i));
    el.obDots.append(dot);
  });

  el.obCount.textContent = `Question ${step + 1} of ${total} — ${q.title}`;
  el.obTitle.textContent = q.title;
  el.obPrompt.textContent = q.prompt;
  el.obAnswer.placeholder = q.placeholder;
  el.obAnswer.maxLength = STYLE_ANSWER_MAX;
  el.obAnswer.value = onboarding.answers[step];
  el.obBack.hidden = step === 0;
  el.obNext.textContent = step === total - 1 ? 'Finish' : 'Next';
  updateOnboardingMeta();

  // Re-trigger the little entrance animation for each new card.
  const card = $('#ob-card');
  card.style.animation = 'none';
  void card.offsetWidth;
  card.style.animation = '';
  el.onboard.scrollTop = 0;
}

function updateOnboardingMeta() {
  const len = onboarding.answers[onboarding.step].trim().length;
  const ok = len >= STYLE_ANSWER_MIN;
  el.obNeed.className = `ob-need${ok ? ' ok' : ''}`;
  el.obNeed.textContent = ok ? 'Looks good' : `A few more words — ${STYLE_ANSWER_MIN - len} characters to go`;
  const raw = onboarding.answers[onboarding.step].length;
  el.obChars.textContent = `${raw} / ${STYLE_ANSWER_MAX}`;
  el.obChars.classList.toggle('near', raw > STYLE_ANSWER_MAX * 0.9);
  el.obNext.disabled = !ok;
}

function saveOnboardingDraft() {
  clearTimeout(onboarding.saveTimer);
  onboarding.saveTimer = setTimeout(() => {
    queueSettingsSave({ humanizer: { draft: { step: onboarding.step, answers: [...onboarding.answers] } } });
  }, 400);
}

function goToStep(i) {
  onboarding.step = i;
  saveOnboardingDraft();
  renderOnboarding();
  el.obAnswer.focus();
}

async function finishOnboarding() {
  clearTimeout(onboarding.saveTimer);
  const style = buildStyleProfile(onboarding.answers);
  settings = await queueSettingsSave({ humanizer: { onboarded: true, style, draft: { step: 0, answers: [] } } });
  closeOnboarding();
  el.restyle.hidden = thread.model !== 'humanize';
  setStatus('Got it — I’ll write like you now');
  setTimeout(() => setStatus(''), 2500);
  el.input.focus();
}

/**
 * Skip the cards outright. Whatever's been answered so far (maybe nothing)
 * is kept as a partial style profile, and the gate lifts anyway — the
 * Humanizer still rewrites without a voice to match, it just won't sound as
 * much like the person until they answer some cards later (Settings, or the
 * "Retake" link that appears once they're in).
 */
async function skipOnboarding() {
  clearTimeout(onboarding.saveTimer);
  const style = buildStyleProfile(onboarding.answers);
  settings = await queueSettingsSave({ humanizer: { onboarded: true, style, draft: { step: 0, answers: [] } } });
  closeOnboarding();
  el.restyle.hidden = thread.model !== 'humanize';
  setStatus('Skipped — you can answer these later from Settings');
  setTimeout(() => setStatus(''), 2500);
  el.input.focus();
}

el.obAnswer.addEventListener('input', () => {
  onboarding.answers[onboarding.step] = el.obAnswer.value;
  updateOnboardingMeta();
  saveOnboardingDraft();
});

el.obAnswer.addEventListener('keydown', (e) => {
  // Ctrl/Cmd+Enter moves on, like a send button; plain Enter stays a newline.
  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey) && !el.obNext.disabled) {
    e.preventDefault();
    el.obNext.click();
  }
});

el.obBack.addEventListener('click', () => {
  if (onboarding.step > 0) goToStep(onboarding.step - 1);
});

el.obNext.addEventListener('click', () => {
  if (!obDone(onboarding.step)) return;
  if (onboarding.step < STYLE_QUESTIONS.length - 1) goToStep(onboarding.step + 1);
  else finishOnboarding();
});

el.obSkip.addEventListener('click', () => skipOnboarding());

el.restyle.addEventListener('click', async () => {
  // Retake with the old answers filled in, so a tweak isn't a rewrite.
  const prior = STYLE_QUESTIONS.map((q) => settings.humanizer?.style?.find((s) => s.label === q.label)?.a || '');
  settings = await queueSettingsSave({ humanizer: { onboarded: false, draft: { step: 0, answers: prior } } });
  el.restyle.hidden = true;
  syncHumanizerGate();
});

/**
 * The Humanizer: paste AI-sounding text, get it back sounding human. One
 * streamed Groq call — no page, no tools — so it starts printing right away.
 */
// Sized to the shared key's 8,000-tokens-a-minute bucket: the rewrite request
// carries the system prompt + the person's style profile (~1.7k tokens) + the
// text (~chars/4) + room for the reply (~chars/3). 9,000 characters keeps that
// comfortably under the limit; 15,000 could never fit, however long it waited.
const HUMANIZE_MAX_CHARS = 9000;

/** How many extra rewrites the ZeroGPT check may ask for before it settles for the best one. */
const HUMANIZE_MAX_RETRIES = 3;

/** Set once ZeroGPT can't be reached, so later rewrites skip the check instead of stalling. */
let zeroGptDown = false;

async function runHumanize() {
  const model = current();
  const lastUser = thread.messages.at(-1)?.content || '';
  if (lastUser.length > HUMANIZE_MAX_CHARS) {
    throw new ProviderError('That’s too much text for one go.', {
      hint: 'Paste about 1,500 words at a time and I’ll do it in pieces.'
    });
  }

  // Only the last few turns: enough for "shorter" or "warmer" to mean the
  // previous rewrite, short enough that the first word appears quickly.
  const recent = thread.messages.slice(-5).map(({ role, content }) => ({ role, content }));
  while (recent.length && recent[0].role !== 'user') recent.shift();

  const messages = [{ role: 'system', content: systemFor(model.prompt, settings.prefs, { settings }) }, ...recent];
  const view = addAssistant();
  setStatus('Rewriting');

  // Drop any <think> block a reasoning model leaves inline.
  const stripThink = (raw) =>
    raw.replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/<think>[\s\S]*$/i, '');

  const words = (t) => (t.trim() ? t.trim().split(/\s+/).length : 0);
  const target = Math.min(50, Math.max(0, Number(settings.prefs.zerogptTarget ?? 10)));
  // ZeroGPT needs a real chunk of text to score; below this it just guesses.
  const checkOn = settings.prefs.zerogptCheck !== false && !zeroGptDown && words(lastUser) >= 30;

  /** One rewrite. With the check on, nothing is shown until it passes — no flicker of drafts. */
  const rewrite = async (msgs, temperature) => {
    let streamed = '';
    const result = await streamChat({
      config: configForChoice(settings, 'humanize'),
      models: chain('humanize'),
      messages: msgs,
      temperature,
      // A rewrite is about as long as the original; leave headroom, not a cap
      // that clips it.
      maxTokens: Math.min(4096, Math.max(600, Math.ceil(lastUser.length / 3))),
      quick: true,
      signal: controller.signal,
      onModel: noteModel('humanize'),
      onRetry: (ms) => setStatus(`Rate limited — waiting ${ms < 1500 ? 'a moment' : `~${Math.ceil(ms / 1000)}s`}`),
      onDelta: (d) => {
        if (!d.content || checkOn) return;
        setStatus('');
        streamed += d.content;
        view.setMarkdown(stripThink(streamed));
        scrollDown();
      }
    });
    return stripThink(result.content).trim();
  };

  let text = await rewrite(messages, model.temperature);
  let score = null; // last ZeroGPT AI % for the text we end up with
  let tries = 1;

  if (checkOn) {
    let best = null; // lowest-scoring rewrite so far
    for (let attempt = 0; ; attempt++) {
      setStatus(attempt ? `Checking again with ZeroGPT (${attempt}/${HUMANIZE_MAX_RETRIES})` : 'Checking with ZeroGPT');
      let res;
      try {
        res = await checkAiScore(text, { apiKey: settings.prefs.zerogptKey, signal: controller.signal });
      } catch (err) {
        if (err.name === 'AbortError') throw err;
        if (err instanceof DetectorError) {
          zeroGptDown = true; // don't pay for the same failure on every rewrite
          break;
        }
        throw err;
      }
      if (!best || res.percent < best.percent) best = { text, percent: res.percent, tries: attempt + 1 };
      if (res.percent <= target || attempt >= HUMANIZE_MAX_RETRIES) break;

      setStatus(`ZeroGPT says ${Math.round(res.percent)}% AI — rewriting again (${attempt + 1}/${HUMANIZE_MAX_RETRIES})`);
      const flagged = res.flagged.slice(0, 6).map((f) => `- ${f.slice(0, 220)}`).join('\n');
      try {
        text = await rewrite(
          [
            ...messages,
            { role: 'assistant', content: text },
            {
              role: 'user',
              content:
                `An AI detector scored that rewrite ${Math.round(res.percent)}% AI-written; the goal is under ${target}%.` +
                (flagged ? `\nThese sentences were flagged most:\n${flagged}` : '') +
                '\nRewrite the whole text again so it reads as genuinely human: keep every fact and the meaning, but break the even rhythm, use plainer and more specific wording, loosen any tidy structure, and change the flagged sentences most. Output ONLY the rewritten text.'
            }
          ],
          Math.min(1, model.temperature + 0.12 * (attempt + 1))
        );
      } catch (err) {
        if (err.name === 'AbortError') throw err;
        break; // keep the best one we have
      }
    }
    if (best) {
      text = best.text;
      score = best.percent;
      tries = best.tries;
    }
  }

  setStatus('');
  view.setMarkdown(text);
  view.finish();

  const bar = document.createElement('div');
  bar.className = 'humanize-bar';
  const count = document.createElement('span');
  count.textContent = `${words(lastUser)} → ${words(text)} words`;
  if (score !== null) {
    count.textContent += ` · ZeroGPT: ${Math.round(score)}% AI${score > target ? ` (best of ${HUMANIZE_MAX_RETRIES + 1} tries)` : ''}`;
  }
  const copy = document.createElement('button');
  copy.type = 'button';
  copy.className = 'copy-btn';
  copy.textContent = 'Copy';
  copy.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(text);
      copy.textContent = 'Copied';
    } catch {
      copy.textContent = 'Couldn’t copy';
    }
    setTimeout(() => { copy.textContent = 'Copy'; }, 1500);
  });
  bar.append(count, copy);
  view.node.append(bar);

  thread.messages.push({ role: 'assistant', content: text, reasoning: '' });
}

/**
 * Works a task across as many planning turns as it needs, re-snapshotting the
 * page after each batch so the model always plans against what's on screen now.
 */
async function runAutomation(prompt) {
  const tab = await activeTab();
  if (!tab?.id) throw new ProviderError('No active tab to work with.');
  if (isRestrictedUrl(tab.url)) {
    throw new ProviderError("I can't act on this tab — it's a browser page, not a website.", {
      hint: 'Switch to a normal website tab and ask me again.'
    });
  }

  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg assistant';
  el.thread.append(node);
  scrollDown();

  let currentTabId = tab.id;
  const history = [];
  let lastThought = '';
  let totalActions = 0;
  let turn = 0;
  let finished = false;
  let failStreak = 0;
  let stopNote = '';
  const reasoningLog = [];

  /** A collapsible "Working it out" box for one planning turn (respects the showReasoning pref). */
  function makeTrace() {
    const root = document.createElement('details');
    root.className = 'reasoning';
    root.hidden = true;
    const summary = document.createElement('summary');
    summary.textContent = turn > 1 ? `Working it out (step ${turn})` : 'Working it out';
    const pre = document.createElement('div');
    pre.className = 'trace';
    root.append(summary, pre);
    return {
      root,
      set(text) {
        if (!settings.prefs.showReasoning || !text) return;
        root.hidden = false;
        pre.textContent = text;
        pre.scrollTop = pre.scrollHeight;
      }
    };
  }

  /**
   * The planner ⇄ reviewer conversation for one turn, shown as a chat: name
   * tag, bubble, and a "…" bubble while the other AI is thinking. `say` can
   * carry the proposed steps as a small muted line under the message so the
   * reviewer's "ref 5 is wrong" is something the person can follow.
   */
  function makeDuo() {
    const root = document.createElement('div');
    root.className = 'duo';
    const lines = [];
    let typingRow = null;
    const clearTyping = () => {
      typingRow?.remove();
      typingRow = null;
    };
    const say = (who, text, tone, steps) => {
      clearTyping();
      const row = document.createElement('div');
      row.className = 'duo-row';
      row.dataset.who = who;
      if (tone) row.dataset.tone = tone;
      const tag = document.createElement('span');
      tag.className = 'duo-who';
      tag.textContent = who === 'planner' ? 'Planner' : 'Reviewer';
      const bubble = document.createElement('div');
      bubble.className = 'duo-text';
      bubble.textContent = text;
      if (steps?.length) {
        const st = document.createElement('div');
        st.className = 'duo-steps';
        st.textContent = steps.map((a, i) => `${i + 1}. ${describeAction(a)}`).join('  ·  ');
        bubble.append(st);
      }
      row.append(tag, bubble);
      root.append(row);
      lines.push(`${tag.textContent}: ${text}${steps?.length ? `\n   ${steps.map((a, i) => `${i + 1}. ${describeAction(a)}`).join('\n   ')}` : ''}`);
      scrollDown();
    };
    const typing = (who) => {
      clearTyping();
      const row = document.createElement('div');
      row.className = 'duo-row duo-typing';
      row.dataset.who = who;
      const tag = document.createElement('span');
      tag.className = 'duo-who';
      tag.textContent = who === 'planner' ? 'Planner' : 'Reviewer';
      const bubble = document.createElement('div');
      bubble.className = 'duo-text';
      bubble.innerHTML = '<i></i><i></i><i></i>';
      row.append(tag, bubble);
      root.append(row);
      typingRow = row;
      scrollDown();
    };
    const note = (text, cls = 'duo-note') => {
      clearTyping();
      const p = document.createElement('div');
      p.className = cls;
      p.textContent = text;
      root.append(p);
      lines.push(text);
      scrollDown();
    };
    return {
      root,
      say,
      typing,
      note,
      agreed: (text = 'Both agree — here is the plan.') => note(text, 'duo-note duo-agreed'),
      transcript: () => lines.join('\n')
    };
  }

  while (!finished && turn < MAX_TURNS && totalActions < MAX_TOTAL_ACTIONS) {
    turn++;

    setStatus('Reading the page');
    let snap;
    try {
      snap = await snapshot(currentTabId);
    } catch (err) {
      stopNote = err instanceof PageAccessError ? err.message : 'Lost track of the tab.';
      break;
    }
    const elements = snap.elements
      .map((e) => `${e.ref}. <${e.tag}${e.type ? ` ${e.type}` : ''}> ${e.label}`)
      .join('\n');

    const trace = makeTrace();
    node.append(trace.root);
    // Two AIs, one plan: the NVIDIA planner drafts, a Groq reviewer checks it
    // against the same snapshot, and they trade notes until they agree (or the
    // round cap is hit). Nothing touches the page before that.
    const duo = settings.prefs.duoAutomate ? makeDuo() : null;
    if (duo) node.append(duo.root);

    const context = `Overall task: ${prompt}\n\n${
      history.length ? `Done so far:\n${history.join('\n')}\n\n` : ''
    }Current page: ${snap.title}\n${snap.url}\n\nElements:\n${elements}`;

    const convo = [
      { role: 'system', content: systemFor('automate', settings.prefs, { settings }) },
      { role: 'user', content: context }
    ];

    // Streamed, not one blocking call: the planner's own reasoning (when it
    // exposes any) shows up live in the "Working it out" box while it plans.
    const draftPlan = async (messages) => {
      const ask = async (msgs) => {
        let native = '';
        const res = await streamChat({
          config: configForChoice(settings, 'automate'),
          models: chain('automate'),
          messages: msgs,
          temperature: getModel('automate').temperature,
          // Headroom for a reasoning model's chain plus the JSON plan — max_tokens
          // counts both, and a plan cut off mid-JSON is a wasted turn.
          maxTokens: 1600,
          signal: controller.signal,
          onModel: noteModel('automate'),
          onRetry: (ms) => setStatus(`Rate limited — waiting ${ms < 1500 ? 'a moment' : `~${Math.ceil(ms / 1000)}s`}`),
          onDelta: (d) => {
            if (d.reasoning) {
              native += d.reasoning;
              trace.set(native);
              scrollDown();
            }
          }
        });
        return { res, native };
      };

      let { res, native } = await ask(messages);
      let plan;
      try {
        plan = parsePlan(res.content);
      } catch (firstErr) {
        if (firstErr.name === 'AbortError') throw firstErr;
        // One corrective retry: quote the malformed reply back and ask for
        // clean JSON. Plans usually come back valid on the second pass.
        setStatus('Fixing the plan format');
        const retryMessages = [
          ...messages,
          { role: 'assistant', content: res.content },
          {
            role: 'user',
            content:
              `That reply was not valid JSON (${firstErr.message}). Reply with ONLY the corrected plan as JSON — no prose, no code fences — in exactly this shape:\n` +
              '{"thought":"…","reasoning":"…","actions":[{"type":"click","ref":1,"summary":"…"}]}'
          }
        ];
        const second = await ask(retryMessages);
        res = second.res;
        native = second.native;
        plan = parsePlan(res.content);
      }
      return { raw: res.content, native: res.reasoning || native, plan };
    };

    const reviewPlan = async (plan, earlier = []) => {
      const { content } = await completeChat({
        config: partnerConfig(settings),
        // The reviewer only says "agree" or "here's what's wrong", so it gets
        // two tries at most, a few seconds each, and low reasoning effort —
        // a slow reviewer is skipped rather than waited for.
        models: partnerChain({ overrides: settings.modelOverrides, resolved: settings.resolvedModels }).slice(0, 2),
        messages: [
          { role: 'system', content: REVIEWER_SYSTEM },
          {
            role: 'user',
            content: `${context}\n\n${
              earlier.length ? `Earlier in this chat (your own comments, oldest first):\n${earlier.map((c) => `- ${c}`).join('\n')}\n\n` : ''
            }Proposed plan:\n${JSON.stringify({
              thought: plan.thought,
              reasoning: plan.reasoning,
              actions: plan.actions
            })}`
          }
        ],
        temperature: 0.1,
        maxTokens: 300,
        quick: true,
        timeoutMs: 6000,
        timeoutAll: true,
        signal: controller.signal,
        onModel: noteModel('automatePartner')
      });
      return parseReview(content);
    };

    let drafted;
    let plan;
    let nativeReasoning = '';
    let settled = true; // did the reviewer sign off on the plan that runs?

    // What the planner "says" in the chat: its one-line intent, then why.
    const plannerSays = (p) => [p.thought, p.reasoning].filter(Boolean).join(' ') || 'Here is my plan.';

    if (!duo) {
      setStatus('Planning');
      drafted = await draftPlan(convo);
      plan = drafted.plan;
      nativeReasoning = drafted.native;
    } else {
      // A real exchange, one message at a time, that the person can read:
      // the planner proposes, the reviewer answers, and if the reviewer
      // objects the planner replies with a fix — up to MAX_ROUNDS reviews.
      // Nothing touches the page until the chat is over.
      const MAX_ROUNDS = 3;
      const heard = [];

      duo.typing('planner');
      setStatus('Planner is drafting');
      drafted = await draftPlan(convo);
      plan = drafted.plan;
      nativeReasoning = drafted.native;
      duo.say('planner', plannerSays(plan), null, plan.actions);

      for (let round = 1; round <= MAX_ROUNDS; round++) {
        duo.typing('reviewer');
        setStatus('Reviewer is checking');
        let review;
        try {
          review = await reviewPlan(plan, heard);
        } catch (err) {
          if (err.name === 'AbortError') throw err;
          // A slow or unreachable reviewer never blocks the planner.
          settled = false;
          duo.note("The reviewer didn't answer in time — going with the planner's plan.");
          break;
        }

        if (review.verdict === 'agree') {
          duo.say('reviewer', review.comment || 'Looks right to me.', 'agree');
          duo.agreed();
          break;
        }

        duo.say('reviewer', review.comment || 'I have a doubt about this plan.', 'revise');
        heard.push(review.comment || 'Had a doubt.');
        if (round === MAX_ROUNDS) {
          settled = false;
          duo.note("They couldn't fully agree — running the planner's final call.");
          break;
        }

        duo.typing('planner');
        setStatus('Planner is replying');
        try {
          const revised = await draftPlan([
            ...convo,
            { role: 'assistant', content: drafted.raw },
            {
              role: 'user',
              content:
                `The reviewer replied to your plan: "${review.comment}"\n\n` +
                'Answer them. If they are right, fix the plan and start "thought" with "Fixed:". If you are sure the original is correct, keep it and start "thought" with "Keeping it:", ' +
                'then in "reasoning" say why. Check every ref against the Elements list. JSON only, same format as before.'
            }
          ]);
          drafted = revised;
          plan = revised.plan;
          nativeReasoning = [nativeReasoning, revised.native].filter(Boolean).join('\n\n');
          duo.say('planner', plannerSays(plan), null, plan.actions);
        } catch (err) {
          if (err.name === 'AbortError') throw err;
          settled = false;
          duo.note("Couldn't rework the plan — running the planner's last version.");
          break;
        }
      }
    }

    lastThought = plan.thought || lastThought;

    // Final trace = the planner's native chain (if it has one) + the short
    // "why these steps" it wrote into the plan itself.
    const traceText = [nativeReasoning.trim(), plan.reasoning].filter(Boolean).join('\n\n');
    trace.set(traceText);
    const logged = [traceText, duo?.transcript()].filter(Boolean).join('\n\n');
    if (logged) reasoningLog.push(`Turn ${turn}:\n${logged}`);

    if (plan.thought && !duo) {
      const body = document.createElement('div');
      body.className = 'body';
      body.innerHTML = `<p>${escapeHtml(plan.thought)}</p>`;
      node.append(body);
    }

    if (duo) {
      const banner = document.createElement('div');
      banner.className = 'agreed-banner';
      banner.dataset.settled = settled ? 'yes' : 'no';
      banner.textContent = `${settled ? 'The plan they agreed on' : 'Final plan'} · ${plan.actions.length} step${plan.actions.length === 1 ? '' : 's'}`;
      node.append(banner);
    }
    const list = document.createElement('div');
    list.className = 'plan';
    node.append(list);

    const rows = plan.actions.map((action) => {
      const row = document.createElement('div');
      row.className = 'step';
      row.dataset.state = 'idle';
      const dot = document.createElement('span');
      dot.className = 'dot';
      const label = document.createElement('span');
      label.textContent = describeAction(action);
      const detail = document.createElement('span');
      detail.className = 'detail';
      row.append(dot, label, detail);
      list.append(row);
      return { row, detail };
    });
    scrollDown();

    setStatus('Running');
    let i = 0;
    const { results, finalTabId } = await runPlan(currentTabId, plan, (step) => {
      const ui = rows[i++];
      if (!ui) return;
      ui.row.dataset.state = step.ok ? 'ok' : 'fail';
      ui.detail.textContent = (step.detail || '').slice(0, 120);
      scrollDown();
    }, { look: lookAtTab });
    setStatus('');

    currentTabId = finalTabId;
    totalActions += plan.actions.length;
    for (const r of results) {
      history.push(`- ${describeAction(r.action)}: ${r.ok ? r.detail || 'ok' : `failed — ${r.detail}`}`);
    }

    // A look ends its batch early, so a "done" queued behind it never ran.
    finished = results.some((r) => r.action.type === 'done');
    failStreak = results.some((r) => r.ok) ? 0 : failStreak + 1;
    if (failStreak >= 2) {
      stopNote = "Stopping — the last two batches didn't get anywhere. Try rephrasing, or check the page is what you expect.";
      break;
    }
  }

  if (!finished) {
    if (!stopNote) {
      stopNote = `Paused after ${totalActions} steps across ${turn} turn${turn === 1 ? '' : 's'} — say "continue" and I'll pick it up.`;
    }
    const note = document.createElement('div');
    note.className = 'body';
    note.innerHTML = `<p>${escapeHtml(stopNote)}</p>`;
    node.append(note);
  }

  thread.messages.push({
    role: 'assistant',
    content: `${lastThought}\n\n${history.join('\n')}${finished ? '' : `\n\n${stopNote}`}`,
    reasoning: reasoningLog.join('\n\n')
  });
}

/* ---------------- quiz ("test me on ...") ---------------- */

/** "test me on X", "quiz me on X", "test me about X" — X becomes the topic, verbatim. */
const QUIZ_RE = /^(?:test|quiz)\s+me\s+(?:on|about|in)\s+(.+?)[\s.!?]*$/i;

function detectQuizTopic(text) {
  const m = QUIZ_RE.exec(text.trim());
  return m ? m[1].trim() : null;
}

/**
 * Essay requests come back as a downloadable .pdf instead of only on-screen
 * text. Matches "write me an essay about X", "draft a paper on Y" and friends
 * — phrased as an ask to *produce* the piece, not a question that merely
 * mentions essays ("what's an essay?" must not trigger a file download).
 * Can be turned off in Settings (prefs.essayPdf).
 */
const ESSAY_RE =
  /\b(?:write|create|draft|compose|make|produce|generate|give me|help me (?:write|with))\b[^.!?\n]{0,70}\b(?:essay|paper|composition|report)\b|\b(?:essay|paper)\s+(?:for|about|on|called|titled)\b/i;

/** Set per turn in send(); consumed once by runChat() when the answer lands. */
let pendingEssayPdf = false;

function detectEssayRequest(text) {
  if (settings.prefs.essayPdf === false) return false;
  return ESSAY_RE.test(text);
}

/**
 * Offer the finished answer as an attached .pdf file — a real file chip on
 * the reply (PDF icon + filename), the way an attachment should look. The
 * PDF is built locally (no service, no key) once and kept in memory; one
 * click on the chip saves it. Marking the message with `pdf: true` lets a
 * reloaded conversation rebuild the chip from the stored markdown.
 */
function attachPdfFile(view, markdown) {
  let blob = null;
  try {
    blob = markdownToPdf(markdown);
  } catch {
    /* handled below: the chip still works by rebuilding on click */
  }
  const name = pdfFilename(pdfTitle(markdown));

  const chip = document.createElement('button');
  chip.type = 'button';
  chip.className = 'attach-chip file-chip';
  chip.title = `Download ${name}`;

  const icon = document.createElement('span');
  icon.className = 'attach-icon';
  icon.textContent = 'PDF';

  const label = document.createElement('span');
  label.className = 'attach-name';
  label.textContent = name;

  const size = document.createElement('span');
  size.className = 'attach-size';
  size.textContent = blob ? `${Math.max(1, Math.round(blob.size / 1024))} KB` : 'Save';

  chip.append(icon, label, size);

  chip.addEventListener('click', () => {
    try {
      const file = blob || markdownToPdf(markdown);
      downloadPdfBlob(file, name);
      chip.classList.add('saved');
      size.textContent = 'Saved ✓';
      setTimeout(() => {
        chip.classList.remove('saved');
        size.textContent = file ? `${Math.max(1, Math.round(file.size / 1024))} KB` : 'Save';
      }, 2200);
    } catch {
      size.textContent = 'Failed';
      setTimeout(() => { size.textContent = 'Save'; }, 2200);
    }
  });

  const tray = document.createElement('div');
  tray.className = 'attach-chips';
  tray.append(chip);
  view.node.append(tray);
  scrollDown();
}

/** Ask the math model for one multiple-choice question, strictly as JSON. */
async function fetchQuizQuestion(topic, avoid = []) {
  const avoidLine = avoid.length
    ? `\n\nAlready asked on this topic — write a different question, don't repeat or reword these:\n- ${avoid.join('\n- ')}`
    : '';
  const { content: raw } = await completeChat({
    config: configForChoice(settings, 'math'),
    models: chain('math'),
    messages: [
      { role: 'system', content: systemFor('quiz', settings.prefs, { settings }) },
      { role: 'user', content: `Test me on: ${topic}${avoidLine}` }
    ],
    temperature: 0.6,
    maxTokens: 500,
    quick: true,
    // A stalled quiz question shouldn't hang the round — give up and retry.
    timeoutMs: 20000,
    signal: controller.signal,
    onModel: noteModel('math'),
    onRetry: (ms) => setStatus(`Rate limited — waiting ${ms < 1500 ? 'a moment' : `~${Math.ceil(ms / 1000)}s`}`)
  });
  return parseQuiz(raw);
}

/** Pull the JSON object out of the reply and check its shape before trusting it. */
function parseQuiz(raw) {
  const data = extractJson(String(raw).replace(/<think>[\s\S]*?<\/think>/gi, ''));
  const { question, choices, correctIndex, explanation } = data || {};
  if (
    typeof question !== 'string' || !question.trim() ||
    !Array.isArray(choices) || choices.length < 2 ||
    !choices.every((c) => typeof c === 'string' && c.trim()) ||
    !Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex >= choices.length
  ) {
    throw new ProviderError("That question came back malformed — try again, or rephrase the topic.");
  }
  return { question, choices, correctIndex, explanation: typeof explanation === 'string' ? explanation : '' };
}

function addQuizCard() {
  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg assistant';

  const badge = document.createElement('span');
  badge.className = 'who';
  badge.innerHTML = icon(MODEL_ICON.math);

  const card = document.createElement('div');
  card.className = 'quiz-card';
  card.textContent = 'Putting a question together…';

  node.append(badge, card);
  el.thread.append(node);
  scrollDown();
  return card;
}

/** Render one question into the card as tappable choices, flashcard style. */
function renderQuizQuestion(card, topic, q, asked, score) {
  card.dataset.state = 'unanswered';
  card.replaceChildren();

  const head = document.createElement('div');
  head.className = 'quiz-head';
  const topicEl = document.createElement('span');
  topicEl.className = 'quiz-topic';
  topicEl.textContent = topic;
  const scoreEl = document.createElement('span');
  scoreEl.className = 'quiz-score';
  scoreEl.textContent = `${score.right}/${score.total}`;
  head.append(topicEl, scoreEl);

  const qEl = document.createElement('div');
  qEl.className = 'quiz-question';
  qEl.innerHTML = renderInline(q.question);

  const choicesEl = document.createElement('div');
  choicesEl.className = 'quiz-choices';
  const buttons = q.choices.map((choiceText, i) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'quiz-choice';
    btn.innerHTML = renderInline(choiceText);
    btn.addEventListener('click', () => answer(i));
    choicesEl.append(btn);
    return btn;
  });

  card.append(head, qEl, choicesEl);
  scrollDown();

  function answer(i) {
    if (card.dataset.state !== 'unanswered') return;
    card.dataset.state = 'answered';
    const correct = i === q.correctIndex;
    score.total++;
    if (correct) score.right++;
    scoreEl.textContent = `${score.right}/${score.total}`;

    buttons.forEach((btn, idx) => {
      btn.disabled = true;
      if (idx === q.correctIndex) btn.classList.add('correct');
      else if (idx === i) btn.classList.add('wrong');
    });

    if (q.explanation) {
      const exp = document.createElement('div');
      exp.className = 'quiz-explain';
      exp.innerHTML = renderMarkdown(q.explanation);
      card.append(exp);
    }

    const next = document.createElement('button');
    next.type = 'button';
    next.className = 'quiz-next';
    next.textContent = correct ? 'Nice — next question' : 'Next question';
    next.addEventListener('click', async () => {
      next.disabled = true;
      next.textContent = 'Loading…';
      try {
        const nextQ = await fetchQuizQuestion(topic, asked);
        asked.push(nextQ.question);
        if (asked.length > 12) asked.shift();
        renderQuizQuestion(card, topic, nextQ, asked, score);
      } catch (err) {
        next.disabled = false;
        next.textContent = 'Try again';
        setStatus(err.message || "Couldn't get the next question.");
      }
    });
    card.append(next);
    scrollDown();
  }
}

async function runQuiz(topic) {
  const card = addQuizCard();
  const score = { right: 0, total: 0 };
  const asked = [];
  let q;
  try {
    q = await fetchQuizQuestion(topic, asked);
  } catch (err) {
    card.closest('.msg')?.remove();
    throw err;
  }
  asked.push(q.question);
  renderQuizQuestion(card, topic, q, asked, score);

  thread.messages.push({
    role: 'assistant',
    content: `Quiz on **${topic}** — tap an answer above to keep going.`
  });
}

/* ---------------- send ---------------- */

function renderTray() {
  el.attachTray.replaceChildren();
  el.attachTray.hidden = pendingAttachments.length === 0;
  pendingAttachments.forEach((a) => {
    el.attachTray.append(attachmentChip(a, true));
  });
}

// Delegated for the same reason as the drawer's delete button: renderTray()
// rebuilds every chip from scratch, so the container is the only listener
// target guaranteed to stick around.
el.attachTray.addEventListener('click', (e) => {
  const x = e.target.closest('.attach-remove');
  if (!x) return;
  const chip = x.closest('.attach-chip');
  const i = [...el.attachTray.children].indexOf(chip);
  if (i < 0) return;
  pendingAttachments.splice(i, 1);
  renderTray();
});

/** Trim what a saved attachment carries — images keep their data URL, the rest just a name. */
function attachmentMeta(a) {
  return a.kind === 'image'
    ? { kind: 'image', name: a.name, dataUrl: a.dataUrl }
    : { kind: a.kind, name: a.name };
}

let pendingTurnAttachments = [];

async function send(prompt, attachments = []) {
  const text = prompt.trim();
  if (busy || (!text && !attachments.length)) return;

  // The Humanizer can't rewrite in a voice it hasn't met. If something got
  // past the hidden composer (a right-click "Humanize", say), keep the text
  // for after the cards instead of dropping it.
  if (thread.model === 'humanize' && !humanizerReady()) {
    el.input.value = prompt;
    syncHumanizerGate();
    return;
  }

  const quizTopic = !attachments.length ? detectQuizTopic(text) : null;

  // Essays become a file (see detectEssayRequest); chat modes only — the
  // Humanizer must return bare text and Automate must return its JSON plan.
  pendingEssayPdf = !quizTopic &&
    thread.model !== 'humanize' && thread.model !== 'automate' &&
    !attachments.length && detectEssayRequest(text);

  pendingTurnAttachments = attachments;
  const folded = attachmentsToText(attachments);
  const fullText = [text, folded].filter(Boolean).join('\n\n') || 'Tell me about the attached file.';

  addUser(text, attachments);
  thread.messages.push({
    role: 'user',
    content: fullText,
    displayText: text,
    attachments: attachments.map(attachmentMeta)
  });
  el.input.value = '';
  autosize();

  controller = new AbortController();
  setBusy(true);

  try {
    if (quizTopic) await runQuiz(quizTopic);
    else if (thread.model === 'automate') await runAutomation(prompt);
    else if (thread.model === 'humanize') await runHumanize();
    else await runChat();
    await persist(text || attachments[0]?.name || 'Shared a file');
  } catch (err) {
    // A turn that failed before saying anything leaves an empty bubble behind — clear it.
    const dead = document.querySelector('.msg.assistant.streaming');
    if (dead && !dead.querySelector('.body')?.textContent.trim()) dead.remove();
    else dead?.classList.remove('streaming');
    setStatus('');

    // "Try again" must not stack a second copy of the same question: take the
    // failed turn's user message back out (thread + screen) before re-sending.
    const retryTurn = () => {
      document.querySelectorAll('.msg.assistant .error').forEach((n) => n.closest('.msg')?.remove());
      if (thread.messages.at(-1)?.role === 'user') thread.messages.pop();
      [...el.thread.querySelectorAll('.msg.user')].at(-1)?.remove();
      send(prompt, attachments);
    };

    if (err.name === 'AbortError') {
      setStatus('Stopped');
    } else if (err.code === 'model_retired') {
      addError(err, null, modelPicker(thread.model, retryTurn));
    } else {
      if (err.detail) console.warn('[Viora] provider said:', err.detail);
      addError(err, retryTurn);
    }
  } finally {
    setBusy(false);
    controller = null;
  }
}

/* ---------------- events ---------------- */

el.form.addEventListener('submit', (e) => {
  e.preventDefault();
  if (busy) {
    controller?.abort();
    return;
  }
  const attachments = pendingAttachments;
  pendingAttachments = [];
  renderTray();
  send(el.input.value, attachments);
});

el.attach.addEventListener('click', () => {
  const open = el.attachSheet.hidden;
  closeSheets();
  el.attachSheet.hidden = !open;
  el.attach.setAttribute('aria-expanded', String(open));
  if (open) renderTabList();
});

el.attachUpload.addEventListener('click', () => {
  closeSheets();
  el.fileInput.click();
});

el.attachScreenshot.addEventListener('click', async () => {
  closeSheets();

  const tab = await activeTab();
  if (!tab?.id) {
    setStatus("Can't find the tab to screenshot.");
    return;
  }
  if (isRestrictedUrl(tab.url)) {
    setStatus("Viora can't screenshot a browser or extension page — switch to a regular website tab.");
    return;
  }
  if (pendingAttachments.length >= LIMITS.maxFiles) {
    setStatus(`I can take up to ${LIMITS.maxFiles} files at a time.`);
    return;
  }

  setStatus('Drag to select an area on the page…');
  let selection;
  try {
    selection = await screenshotSelect(tab.id);
  } catch (err) {
    setStatus(err.message || "Couldn't start the screenshot tool on this page.");
    return;
  }
  if (!selection?.ok) {
    setStatus('');
    return; // cancelled — Esc, or too small a drag
  }

  try {
    const captureDataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
    const result = await readScreenshot(captureDataUrl, selection.rect, selection.dpr);
    pendingAttachments.push(result);
    renderTray();
    setStatus('');
  } catch (err) {
    setStatus("Couldn't capture that screenshot — try again.");
  }
});

el.pageChipRemove.addEventListener('click', () => {
  selectedPage = null;
  renderPageChip();
});

el.fileInput.addEventListener('change', async () => {
  const files = [...el.fileInput.files];
  el.fileInput.value = '';

  for (const file of files) {
    if (pendingAttachments.length >= LIMITS.maxFiles) {
      setStatus(`I can take up to ${LIMITS.maxFiles} files at a time.`);
      break;
    }
    try {
      const result = await readFile(file);
      pendingAttachments.push(result);
      if (result.warning) setStatus(result.warning);
    } catch (err) {
      setStatus(err.message);
    }
  }
  renderTray();
});

el.input.addEventListener('input', autosize);

el.input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    el.form.requestSubmit();
  }
});

el.modelBtn.addEventListener('click', () => {
  const open = el.modelSheet.hidden;
  closeSheets();
  el.modelSheet.hidden = !open;
  el.modelBtn.setAttribute('aria-expanded', String(open));
});

$('#new-thread').addEventListener('click', () => {
  controller?.abort();
  const keep = thread.model;
  thread = newThread(keep);
  el.thread.replaceChildren(el.welcome);
  setModel(keep);
  closeSheets();
  el.input.focus();
});

$('#history').addEventListener('click', (e) => {
  const open = el.drawer.hidden;
  closeSheets();
  el.drawer.hidden = !open;
  e.currentTarget.setAttribute('aria-expanded', String(open));
  if (open) refreshDrawer();
});

/**
 * The gear opens Viora's settings page. The tiny Viora mark next to it opens
 * the panel itself in a normal browser tab — same chat, history, voice and
 * settings, except screenshots and Automation can't run there because both
 * need a *different* tab to act on, and a chrome-extension:// page can't be
 * scripted or captured by Chrome at all.
 */
$('#open-settings').addEventListener('click', () => chrome.runtime.openOptionsPage());

$('#open-viora').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('src/sidepanel/index.html') });
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeSheets();
});

document.addEventListener('click', (e) => {
  if (el.modelSheet.hidden && el.drawer.hidden && el.attachSheet.hidden) return;
  if (e.target.closest('#model-sheet, #drawer, #attach-sheet, #model-btn, #history, #attach')) return;
  closeSheets();
});

chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area === 'local' && changes.settings) {
    settings = await getSettings();
    config = groqConfig(settings);
    // Settings can reset or clear the style profile while the panel is open.
    el.restyle.hidden = thread.model !== 'humanize' || !humanizerReady();
    syncHumanizerGate();
  }
});

/* ---------------- voice input ---------------- */

// Viora transcribes speech with Groq's whisper-large-v3. It uses its own key
// (GROQ_STT_KEY), so the shared chat key's budget stays untouched; a personal
// key from settings still wins for both. The mic records locally
// (MediaRecorder) and the audio is transcribed once you tap stop. If the
// microphone can't be captured it falls back to Chrome's built-in recognizer,
// and if neither exists the mic button stays hidden.
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

const canCapture =
  typeof MediaRecorder !== 'undefined' &&
  Boolean(navigator.mediaDevices?.getUserMedia);

if (!canCapture && !SpeechRecognition) {
  el.mic.hidden = true;
} else {
  /** 'idle' | 'requesting' | 'capturing' | 'transcribing' */
  let state = 'idle';
  let audioStream = null; // live mic, released as soon as recording stops
  let recorder = null;    // active MediaRecorder, if any
  let recognizer = null;  // active Chrome recognizer, if any

  const setMicState = (next) => {
    state = next;
    el.mic.classList.toggle('recording', next === 'capturing');
    el.mic.disabled = next === 'requesting' || next === 'transcribing';
    el.mic.setAttribute(
      'aria-label',
      next === 'capturing' ? 'Stop listening'
        : next === 'requesting' ? 'Starting mic'
        : next === 'transcribing' ? 'Transcribing'
        : 'Voice input'
    );
  };

  const releaseMic = () => {
    audioStream?.getTracks().forEach((t) => t.stop());
    audioStream = null;
  };

  const withTimeout = (promise, ms) =>
    Promise.race([
      promise,
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), ms))
    ]);

  /**
   * Make sure the extension may use the mic. Chrome won't show the permission
   * prompt inside a docked side panel (a known limitation), so when permission
   * isn't already granted this opens the mic-permission page in a small popup
   * window where the prompt CAN be shown. A "blocked" state opens the site
   * settings so the user can flip it to Allow. Returns false when the user
   * shouldn't proceed (and has been told why in the status line).
   */
  async function ensureMicPermission() {
    try {
      const status = await navigator.permissions.query({ name: 'microphone' });
      if (status.state === 'granted') return true;
      if (status.state === 'denied') {
        chrome.tabs.create({
          url: `chrome://settings/content/siteDetails?site=chrome-extension%3A%2F%2F${chrome.runtime.id}%2F`
        });
        setStatus('Microphone is blocked — set it to Allow in the settings tab that opened, then tap the mic again.');
        return false;
      }
    } catch {
      // Permission query unsupported — fall through to a direct request.
    }

    // Try a direct request first; Chrome may show the prompt here normally.
    let direct = null;
    try {
      direct = navigator.mediaDevices.getUserMedia({ audio: true });
      const stream = await withTimeout(direct, 4000);
      direct = null;
      stream.getTracks().forEach((t) => t.stop());
      return true;
    } catch {
      direct?.then((s) => s.getTracks().forEach((t) => t.stop())).catch(() => {});
      /* expected — side panels suppress the prompt */
    }

    // Open the permission bridge in a popup window and wait for it to close.
    setStatus('Allow the microphone in the popup that just opened.');
    try {
      const win = await chrome.windows.create({
        url: chrome.runtime.getURL('src/mic/mic-permission.html'),
        type: 'popup',
        width: 440,
        height: 340,
        focused: true
      });
      if (!win?.id) return false;
      await new Promise((resolve) => {
        const onClose = (windowId) => {
          if (windowId !== win.id) return;
          chrome.windows.onRemoved.removeListener(onClose);
          setTimeout(resolve, 350);
        };
        chrome.windows.onRemoved.addListener(onClose);
      });
      return true;
    } catch {
      return false;
    }
  }

  /** Record until stopped, then POST the audio to Groq's whisper model. */
  async function transcribeWithWhisper() {
    setMicState('requesting');
    setStatus('Requesting microphone…');

    if (!(await ensureMicPermission())) {
      if (!el.status.textContent) setStatus("Couldn't get microphone access — try again.");
      setMicState('idle');
      return;
    }

    let stream;
    let pending = null;
    try {
      pending = navigator.mediaDevices.getUserMedia({ audio: true });
      stream = await withTimeout(pending, 6000);
      pending = null;
    } catch {
      // The prompt was denied or never answered. If a stream now shows up
      // late, drop it so the mic light doesn't stay on. Fall back to Chrome's
      // recognizer when there is one, else say what happened.
      pending?.then((s) => s.getTracks().forEach((t) => t.stop())).catch(() => {});
      if (SpeechRecognition) { captureLocally(); return; }
      setMicState('idle');
      setStatus('Microphone access was blocked.');
      return;
    }
    audioStream = stream;

    let rec;
    try {
      rec = new MediaRecorder(stream);
    } catch {
      releaseMic();
      if (SpeechRecognition) { captureLocally(); return; }
      setMicState('idle');
      setStatus('Audio recording is not supported here.');
      return;
    }
    recorder = rec;

    const chunks = [];
    rec.addEventListener('dataavailable', (e) => {
      if (e.data.size) chunks.push(e.data);
    });

    setMicState('capturing');
    setStatus('Recording — tap again when done');
    rec.start();

    await new Promise((resolve) => {
      rec.addEventListener('stop', resolve, { once: true });
      rec.addEventListener('error', resolve, { once: true });
    });
    releaseMic();
    recorder = null;

    if (!chunks.length) {
      setMicState('idle');
      return;
    }

    setMicState('transcribing');
    setStatus('Transcribing');
    let text = '';
    try {
      const blob = new Blob(chunks, { type: rec.mimeType || 'audio/webm' });
      text = await transcribeAudio({ config, blob });
    } catch (err) {
      setMicState('idle');
      setStatus(err.hint || 'Transcription failed — try again.');
      el.input.focus();
      return;
    }

    setMicState('idle');
    if (text) {
      el.input.value = el.input.value.trim() ? `${el.input.value.trim()} ${text}` : text;
      autosize();
      setStatus('');
    } else {
      setStatus("Didn't catch that — try again.");
    }
    el.input.focus();
  }

  /** Chrome's built-in recognizer — the fallback when the mic can't be captured. */
  function captureLocally() {
    recognizer = new SpeechRecognition();
    recognizer.lang = navigator.language || 'en-US';
    recognizer.interimResults = true;
    recognizer.continuous = false;

    recognizer.addEventListener('start', () => {
      setMicState('capturing');
      setStatus('Listening');
    });

    recognizer.addEventListener('result', (e) => {
      let transcript = '';
      for (const r of e.results) transcript += r[0].transcript;
      el.input.value = transcript;
      autosize();
    });

    recognizer.addEventListener('error', (e) => {
      setStatus(
        e.error === 'not-allowed' || e.error === 'service-not-allowed'
          ? 'Microphone access was blocked.'
          : e.error === 'no-speech'
            ? ''
            : "Didn't catch that — try again."
      );
    });

    recognizer.addEventListener('end', () => {
      recognizer = null;
      setMicState('idle');
      setStatus('');
      el.input.focus();
    });

    try {
      recognizer.start();
    } catch {
      recognizer = null;
      setMicState('idle');
    }
  }

  el.mic.addEventListener('click', () => {
    if (state === 'requesting' || state === 'transcribing') return;
    if (state === 'capturing') {
      recorder?.stop();
      recognizer?.stop();
      return;
    }
    if (canCapture) transcribeWithWhisper();
    else captureLocally();
  });

  /* -------- voice mode: "talk to Viora" -------- */
  // Tap the voice button once: Viora listens, transcribes with whisper,
  // sends the message, speaks the reply back with Groq's Orpheus TTS, then
  // starts listening again automatically — a hands-free back-and-forth,
  // like tapping a voice button in a chat app. Tap again at any point to
  // stop and hand control back to typing.
  if (el.voice) {
    if (!canCapture) {
      el.voice.hidden = true;
    } else {
      let voiceActive = false;
      let voiceRecorder = null;
      let voiceStream = null;
      let currentAudio = null;
      /** The in-flight browser-synthesis utterance, when Orpheus is unavailable. */
      let currentBrowserUtterance = null;

      const setVoiceState = (next) => {
        el.voice.classList.remove('listening', 'thinking', 'speaking');
        if (next !== 'off') el.voice.classList.add(next);
        el.voice.setAttribute(
          'aria-label',
          next === 'listening' ? 'Listening — tap to send'
            : next === 'thinking' ? 'Thinking'
            : next === 'speaking' ? 'Speaking — tap to stop'
            : 'Talk to Viora'
        );
      };

      const stripForSpeech = (text) =>
        text
          .replace(/```[\s\S]*?```/g, ' ')
          .replace(/`([^`]+)`/g, '$1')
          .replace(/!\[[^\]]*]\([^)]*\)/g, ' ')
          .replace(/\[([^\]]+)]\([^)]*\)/g, '$1')
          .replace(/[*_#>~]/g, '')
          .trim()
          .slice(0, 4000);

      async function speakReply(text) {
        const clean = stripForSpeech(text);
        if (!clean) return;
        setVoiceState('speaking');
        setStatus('Speaking — tap to stop');
        try {
          const blob = await synthesizeSpeech({ config, text: clean });
          if (!voiceActive) return;
          const url = URL.createObjectURL(blob);
          currentAudio = new Audio(url);
          await new Promise((resolve) => {
            currentAudio.addEventListener('ended', resolve, { once: true });
            currentAudio.addEventListener('error', resolve, { once: true });
            currentAudio.play().catch(resolve);
          });
          URL.revokeObjectURL(url);
        } catch (err) {
          if (!voiceActive) return;
          // Groq's Orpheus voice currently 400s until the org accepts its
          // terms on console.groq.com. Rather than dead-ending the whole
          // conversation on that, fall back to Chrome's own speech synthesis
          // so Viora still talks back — a plainer voice, but the loop works.
          if (typeof speechSynthesis !== 'undefined' && typeof SpeechSynthesisUtterance !== 'undefined') {
            await speakWithBrowser(clean);
          } else {
            setStatus(err.hint || 'Could not read that reply out loud.');
          }
        }
        currentAudio = null;
      }

      /** Read the reply with the browser's built-in voice (Orpheus fallback). */
      function speakWithBrowser(text) {
        return new Promise((resolve) => {
          const utter = new SpeechSynthesisUtterance(text.slice(0, 1500));
          utter.lang = navigator.language || 'en-US';
          utter.rate = 1.02;
          utter.addEventListener('end', resolve, { once: true });
          utter.addEventListener('error', resolve, { once: true });
          speechSynthesis.cancel();
          speechSynthesis.speak(utter);
          // Keep the tap-to-stop affordance working: stopVoiceMode cancels
          // both the Audio element and this synthesis.
          currentBrowserUtterance = utter;
        });
      }

      async function voiceListenTurn() {
        setVoiceState('listening');
        setStatus('Listening — tap to send');

        if (!(await ensureMicPermission())) {
          if (!el.status.textContent) setStatus("Couldn't get microphone access.");
          voiceActive = false;
          setVoiceState('off');
          return;
        }
        if (!voiceActive) return;

        let stream;
        try {
          stream = await withTimeout(navigator.mediaDevices.getUserMedia({ audio: true }), 6000);
        } catch {
          setStatus('Microphone access was blocked.');
          voiceActive = false;
          setVoiceState('off');
          return;
        }
        if (!voiceActive) { stream.getTracks().forEach((t) => t.stop()); return; }
        voiceStream = stream;

        let rec;
        try {
          rec = new MediaRecorder(stream);
        } catch {
          stream.getTracks().forEach((t) => t.stop());
          voiceStream = null;
          setStatus('Audio recording is not supported here.');
          voiceActive = false;
          setVoiceState('off');
          return;
        }
        voiceRecorder = rec;

        const chunks = [];
        rec.addEventListener('dataavailable', (e) => { if (e.data.size) chunks.push(e.data); });
        rec.start();

        await new Promise((resolve) => {
          rec.addEventListener('stop', resolve, { once: true });
          rec.addEventListener('error', resolve, { once: true });
        });
        voiceStream?.getTracks().forEach((t) => t.stop());
        voiceStream = null;
        voiceRecorder = null;

        if (!voiceActive) return; // stopped mid-turn

        if (!chunks.length) { setVoiceState('off'); voiceActive = false; setStatus(''); return; }

        setVoiceState('thinking');
        setStatus('Transcribing');
        let text = '';
        try {
          const blob = new Blob(chunks, { type: rec.mimeType || 'audio/webm' });
          text = await transcribeAudio({ config, blob });
        } catch (err) {
          if (!voiceActive) return;
          setStatus(err.hint || 'Transcription failed — listening again.');
          voiceListenTurn();
          return;
        }
        if (!voiceActive) return;

        if (!text) {
          setStatus("Didn't catch that — listening again.");
          voiceListenTurn();
          return;
        }

        setStatus('');
        await send(text);
        if (!voiceActive) return;

        const reply = thread.messages.filter((m) => m.role === 'assistant').at(-1);
        if (reply?.content) await speakReply(reply.content);
        if (voiceActive) voiceListenTurn();
        else setStatus('');
      }

      function stopVoiceMode() {
        voiceActive = false;
        try { voiceRecorder?.stop(); } catch {}
        voiceStream?.getTracks().forEach((t) => t.stop());
        voiceStream = null;
        currentAudio?.pause();
        currentAudio = null;
        // Cancel an in-flight browser-synthesis reply too (Orpheus fallback).
        try { speechSynthesis?.cancel(); } catch {}
        currentBrowserUtterance = null;
        setVoiceState('off');
        setStatus('');
      }

      el.voice.addEventListener('click', () => {
        if (!voiceActive) {
          voiceActive = true;
          voiceListenTurn();
        } else if (voiceRecorder && voiceRecorder.state === 'recording') {
          voiceRecorder.stop(); // done talking — transcribe and send
        } else {
          stopVoiceMode(); // mid-thinking or mid-speaking — cancel entirely
        }
      });
    }
  }
}

/* ---------------- boot ---------------- */

el.attachUploadIcon.innerHTML = icon('upload');
el.attachScreenshotIcon.innerHTML = icon('camera');
el.micIcon.innerHTML = icon('mic');
el.voiceIcon.innerHTML = icon('voice');

setModel(settings.prefs.model || 'flash');
refreshDrawer();
el.input.focus();

// Pick up anything queued from a context-menu click.
const task = await chrome.runtime.sendMessage({ type: 'viora:get-task' }).catch(() => null);
if (task?.prompt) {
  setModel(task.model || 'flash');
  if (task.usePage && task.tabId != null) {
    try {
      pickPage(await chrome.tabs.get(task.tabId));
    } catch {
      // The tab closed before the panel opened — nothing to attach.
    }
  }
  send(task.prompt);
}
