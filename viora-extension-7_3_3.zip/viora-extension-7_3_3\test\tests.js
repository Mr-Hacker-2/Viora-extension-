/**
 * Viora — test harness for the live-web pass.
 *
 * Runs in a plain browser page (no bundler, no test framework on this
 * project) against the real modules. Network tests go through the local
 * server's /proxy route, which reproduces the one thing an extension page
 * has and a web page doesn't: the <all_urls> host permission that makes
 * cross-origin fetches work without CORS.
 */

import {
  WEB_LIMITS, gatherWeb, searchWeb, fetchDocument, htmlToReadable,
  parseDuckHtml, parseDuckLite, parseBingRss, extractUrls, searchQueryFrom, formatWebContext
} from '../src/lib/web.js';
import { mergeSources, withSourceList, extractTrailingSources, linkInlineMarkers, sourceStrip, faviconUrl } from '../src/lib/citations.js';
import { renderMarkdown } from '../src/lib/markdown.js';
import { systemFor } from '../src/lib/prompts.js';
import { STYLE_TECHNIQUES, matchStyles, styleBlock } from '../src/lib/styles.js';
import { extractPdfText } from '../src/lib/files.js';
import { readError, tpmCeiling } from '../src/lib/providers.js';
import { localScore, detectAiScore } from '../src/lib/detector.js';
import { detectImageRequest } from '../src/lib/image-request.js';
import { parseImageResponse, ImageError, toJpegDataUrl, imageMime, generateImage } from '../src/lib/imagegen.js';

/* ---------------- tiny test runner ---------------- */

const results = [];
let current = '';

function record(ok, message, detail = '') {
  results.push({ suite: current, ok, message, detail });
}

function test(name, fn) {
  current = name;
  try {
    fn();
  } catch (err) {
    record(false, `threw: ${err.message}`, err.stack || '');
  }
}

async function testAsync(name, fn) {
  current = name;
  try {
    await fn();
  } catch (err) {
    record(false, `threw: ${err.message}`, err.stack || '');
  }
}

function ok(cond, message) {
  record(Boolean(cond), message, cond ? '' : 'expected truthy');
}

function eq(actual, expected, message) {
  // Arrays/objects are compared structurally — `===` on two equal arrays
  // would fail every time and bury the real failures.
  const same = actual === expected
    || JSON.stringify(actual) === JSON.stringify(expected);
  record(same, message, same ? '' : `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
}

function includes(haystack, needle, message) {
  const pass = String(haystack ?? '').includes(needle);
  record(pass, message, pass ? '' : `missing ${JSON.stringify(needle)}`);
}

async function fixture(name) {
  const res = await fetch(`/test/fixtures/${name}`);
  return res.text();
}

/* ---------------- bridge the extension gets for free ---------------- */

const realFetch = window.fetch.bind(window);
window.fetch = (input, init) => {
  const url = typeof input === 'string' ? input : input.url;
  if (/^https?:\/\//.test(url) && !url.startsWith(location.origin)) {
    return realFetch(`/proxy?url=${encodeURIComponent(url)}`, init);
  }
  return realFetch(input, init);
};

/* ---------------- the suite ---------------- */

async function run() {
  /* --- URLs the person typed --- */
  test('extractUrls', () => {
    eq(
      extractUrls('metr.org/hugging-face-incident-report-aug-2026.pdf'),
      ['https://metr.org/hugging-face-incident-report-aug-2026.pdf'],
      'a typed link with no scheme is still a link'
    );
    eq(
      extractUrls('read example.com now'),
      ['https://example.com/'],
      'a bare domain counts too (URL() canonically adds the root slash)'
    );
    eq(
      extractUrls('report.pdf and version 2.0 and e.g. stay as words'),
      [],
      'file names, versions and abbreviations never become links'
    );
    eq(
      extractUrls('see https://example.com/a. and also http://two.test/x.'),
      ['https://example.com/a', 'http://two.test/x'],
      'strips trailing sentence punctuation'
    );
    eq(
      extractUrls('read [the paper](https://example.com/p) now'),
      ['https://example.com/p'],
      'reads a markdown link and drops its closing paren'
    );
    eq(
      extractUrls('https://en.wikipedia.org/wiki/Foo_(bar) next'),
      ['https://en.wikipedia.org/wiki/Foo_(bar)'],
      'keeps a balanced paren inside the path'
    );
    eq(extractUrls('https://a.test/1 https://a.test/1/'), ['https://a.test/1'], 'dedupes by normalised url');
    eq(extractUrls('no links here, try ftp://a.test/x or javascript:alert(1)'), [], 'ignores non-http schemes');
    eq(
      extractUrls(Array.from({ length: 14 }, (_, i) => `https://s${i}.test/`).join(' ')).length,
      WEB_LIMITS.maxSources,
      'caps how many links one message can carry'
    );
  });

  test('searchQueryFrom', () => {
    eq(
      searchQueryFrom('What is the boiling point of water? See https://example.com/data for the chart'),
      'What is the boiling point of water? See for the chart',
      'drops the URLs out of the query'
    );
    eq(
      searchQueryFrom('is metr.org/hugging-face-incident-report-aug-2026.pdf real?'),
      'is real?',
      'drops a scheme-less link too, instead of searching the filename'
    );
    eq(searchQueryFrom('https://only-a-link.example/doc'), '', 'a link with no words is not a query');
    eq(searchQueryFrom('metr.org/report.pdf'), '', 'neither is a message that is only a typed link');
    const long = 'Explain something long. '.repeat(20);
    ok(searchQueryFrom(long).length <= WEB_LIMITS.queryChars, 'query is capped');
    ok(/[.!?]$/.test(searchQueryFrom(long)), 'capped query stops at a sentence boundary');
  });

  /* --- search result parsing --- */
  const htmlFixture = await fixture('ddg-html.html');
  test('parseDuckHtml', () => {
    const parsed = parseDuckHtml(htmlFixture);
    eq(parsed.length, 3, 'finds every result');
    eq(parsed[0].url, 'https://orbital-mechanics.space/the-orbit-equation/orbital-nomenclature.html', 'unwraps the uddg redirect into the real url');
    eq(parsed[1].url, 'https://en.wikipedia.org/wiki/Argument_of_periapsis', 'second result is absolute http(s)');
    eq(parsed[1].title, 'Argument of periapsis - Wikipedia', 'keeps the title text');
    includes(parsed[1].snippet, 'symbolized as ω', 'picks up the snippet next to its own result');
    includes(parsed[2].snippet, 'orbit period', 'snippet follows the result it belongs to, not index drift');
  });

  const liteFixture = await fixture('ddg-lite.html');
  test('parseDuckLite', () => {
    const parsed = parseDuckLite(liteFixture);
    eq(parsed.length, 2, 'finds every lite result');
    eq(parsed[0].url, 'https://en.wikipedia.org/wiki/Argument_of_periapsis', 'unwraps the lite redirect');
    includes(parsed[0].snippet, 'orbital elements', 'attaches the snippet row to the link above it');
    includes(parsed[1].snippet, 'orbit period', 'second snippet lands on the second result');
    ok(!/<b>/.test(parsed[0].snippet), 'snippet is plain text, tags stripped');
  });

  const challengeFixture = await fixture('ddg-challenge.html');

  const bingFixture = await fixture('bing-rss.xml');
  test('parseBingRss', () => {
    const parsed = parseBingRss(bingFixture);
    eq(parsed.length, 10, 'reads every item');
    eq(parsed[0].url, 'https://sciencenotes.org/boiling-point-of-water-what-temperature-does-water-boil/', 'link comes through untouched');
    includes(parsed[3].title, 'Britannica', 'and &amp; entities are decoded in the title');
    includes(parsed[3].title, '&', 'the decoded ampersand is a real ampersand');
    ok(parsed.some((r) => r.snippet.length > 50), 'descriptions survive as snippets');
    ok(parsed.every((r) => /^https?:\/\//.test(r.url)), 'every item is an absolute url');
  });
  test('bot challenge is not read as "no results"', () => {
    eq(parseDuckHtml(challengeFixture).length, 0, 'a challenge page yields no results, so the next endpoint is tried');
  });

  /* --- reading a page --- */
  const pageFixture = await fixture('page.html');
  test('htmlToReadable', () => {
    const { title, text } = htmlToReadable(pageFixture);
    eq(title, 'Orbital Nomenclature — Orbital Mechanics', 'returns the document title');
    includes(text, 'conical sections', 'keeps the article prose');
    includes(text, 'Periapsis — closest', 'keeps list items');
    includes(text, 'nearest point', 'keeps table cells');
    ok(!text.includes('this must never reach the model'), 'drops <script> contents');
    ok(!text.includes('BUY ROCKET FUEL'), 'drops <aside>');
    ok(!text.includes('all rights reserved'), 'drops <footer>');
    ok(!text.includes('Home Topics') && !text.includes('/privacy'), 'drops <nav>');
    ok(!text.includes('newsletter'), 'drops forms');
    ok(!text.includes('<p>'), 'no raw tags survive');
    ok(text.split('\n').filter((l) => l.trim()).length >= 4, 'paragraphs arrive on separate lines');
    const capped = htmlToReadable(pageFixture, 40);
    ok(capped.text.length <= 40, 'respects the character cap');
  });

  /* --- laying the block out --- */
  const sampleSources = [
    { url: 'https://a.test/one', title: 'First source', snippet: 'A snippet about the thing.', linked: true,
      doc: { kind: 'html', text: 'Body of the first page.\nSecond line of it.', note: '' } },
    { url: 'https://b.test/two', title: 'Second source', snippet: 'Another snippet.', linked: true },
    { url: 'https://c.test/three', title: 'Third source', snippet: 'Third snippet.', linked: false,
      doc: { kind: 'error', text: '', note: 'the server answered 403' } }
  ];

  test('formatWebContext', () => {
    const { block, sources } = formatWebContext(sampleSources, WEB_LIMITS.budgetChars);
    includes(block, '[1] First source', 'numbers start at 1');
    includes(block, '[2] Second source', 'second entry numbered 2');
    includes(block, '[3] Third source', 'third entry numbered 3');
    includes(block, 'https://a.test/one', 'entry carries its url');
    includes(block, 'Body of the first page.', 'opened page text is inlined');
    includes(block, '(could not read it: the server answered 403)', 'a page that refused to read says so');
    includes(block, '(linked by the person, but not opened this turn)', 'a link past the doc cap is marked unread');
    eq(sources.length, 3, 'every kept source is returned for rendering');
    const numbers = [...block.matchAll(/\[(\d+)\]/g)].map((m) => Number(m[1]));
    eq(Math.max(...numbers), sources.length, 'the highest number matches the source count, so no chip can dangle');
  });

  test('formatWebContext stays inside the budget', () => {
    const many = Array.from({ length: 8 }, (_, i) => ({
      url: `https://s${i}.test/`,
      title: `Source ${i}`,
      snippet: 'sn '.repeat(40),
      doc: { kind: 'html', text: 'words '.repeat(2000), note: '' }
    }));
    const { block, sources } = formatWebContext(many, 2000);
    ok(block.length <= 2000, `block is ${block.length} chars, within the 2000 budget`);
    ok(sources.length >= 1, 'the first source survives even a tight budget');
    eq(sources.length, [...block.matchAll(/\[(\d+)\]/g)].length, 'kept sources and printed numbers still agree');
  });

  /* --- merging what the model cited --- */
  test('mergeSources', () => {
    const provided = [{ url: 'https://a.test/one', title: 'One' }, { url: 'https://b.test/two', title: 'Two' }];
    const cited = [{ url: 'https://b.test/two/', title: 'Two' }, { url: 'https://c.test/three', title: '' }];
    const merged = mergeSources(provided, cited);
    eq(merged.length, 3, 'dedupes across the two lists (www, slash and hash ignored)');
    eq(merged[0].url, 'https://a.test/one', 'keeps the provided order, so [1] still means chip 1');
    eq(merged[1].url, 'https://b.test/two', 'the provided copy wins over the cited one');
    eq(merged[2].title, 'c.test', 'an extra url the model cited anyway is appended, with a host as its title');
    eq(mergeSources([], []).length, 0, 'empty in, empty out');
  });

  test('withSourceList', () => {
    const md = withSourceList('# Essay\n\nBody.', [{ url: 'https://a.test/1' }, { url: 'https://b.test/2' }]);
    includes(md, '**Sources**', 'exports carry a sources section');
    includes(md, '- https://a.test/1', 'one url per line');
    eq(withSourceList('# Essay', []), '# Essay', 'unchanged when there is nothing to cite');
  });

  /* --- the answer → chips pipeline --- */
  test('citations render as favicon chips', () => {
    // [7] is deliberately past the end of the list: the model citing a
    // number that has no source behind it must leave plain text, not a chip
    // that links nowhere.
    const raw = 'The closest approach is the periapsis [1], while [7] is unbacked.\n\nSources:\nhttps://en.wikipedia.org/wiki/Argument_of_periapsis';
    const { text, sources } = extractTrailingSources(raw);
    ok(!/^Sources:/m.test(text), 'the trailing block is stripped out of the reply');
    eq(sources.length, 1, 'one source pulled out of the block');

    const provided = [{ url: 'https://example.com/live', title: 'Live source' }];
    const merged = mergeSources(provided, sources);
    eq(merged.length, 2, 'provided list first, model-added url appended');
    eq(merged[0].url, 'https://example.com/live', 'chip 1 is entry 1 of the list the model was given');

    const body = document.createElement('div');
    body.innerHTML = renderMarkdown(text);
    linkInlineMarkers(body, merged);
    body.append(sourceStrip(merged));

    const marker = body.querySelector('.marker');
    ok(marker, 'the [1] marker became a clickable marker');
    eq(marker?.getAttribute('href'), 'https://example.com/live', 'marker 1 links the first source');
    const markerImg = marker?.querySelector('img');
    ok(markerImg, 'the marker carries a favicon image');
    ok(markerImg?.src.includes('s2/favicons'), 'favicon comes from the s2 lookup');
    ok(markerImg?.src.includes('domain=example.com'), 'favicon asks for the bare hostname only');
    includes(body.textContent, '[7]', 'a marker with no source behind it is left as plain text, not a broken chip');

    const chips = body.querySelectorAll('.sources .chip');
    eq(chips.length, 2, 'both sources get a chip');
    eq(body.querySelector('.chip-num')?.textContent, '1', 'chip numbering matches the inline markers');
    ok(body.querySelector('.chip-icon')?.src.includes('s2/favicons'), 'chips show favicons too');
    eq(body.querySelector('.sources-head')?.textContent, '2 sources', 'the strip has a count');
    eq(faviconUrl('https://www.example.com/x'), 'https://www.google.com/s2/favicons?domain=example.com&sz=32', 'favicon url never carries more than the hostname');
  });

  /* --- prompts --- */
  test('prompts carry the web rules and the block', () => {
    const web = { ready: true, block: '[1] Live source\n     https://example.com/live' };
    const chat = systemFor('chat', {}, { web, settings: null });    includes(chat, 'Live web context, gathered moments ago', 'chat prompt announces the context');
    includes(chat, '[1] Live source', 'the numbered block is in the prompt');
    includes(chat, 'exactly "Sources:"', 'chat is told to end with a Sources block');
    includes(chat, 'Never say you\'re searching', 'chat is told not to narrate a search it did not run');
    includes(chat, 'untrusted data from the internet', 'page text is flagged as data, not instructions');

    const math = systemFor('math', {}, { web, settings: null });
    includes(math, 'Live web context, gathered moments ago', 'Math & Code gets the web too');

    const research = systemFor('research', {}, { web, settings: null });
    includes(research, 'This is research, not a chat answer', 'Deep Search switches to the live research prompt when sources exist');
    includes(research, 'Grade your findings', 'and keeps its findings-grading');

    const researchDown = systemFor('research', { prefs: {} }, { web: { ready: false, block: '' }, settings: null });
    includes(researchDown, 'you don\'t have a working live web search tool', 'a failed lookup falls back to the honest no-web research prompt');
    includes(researchDown, 'no fresh sources were gathered', 'and says plainly the check did not happen');

    const chatDown = systemFor('chat', {}, { web: { ready: false, block: '' }, settings: null });
    includes(chatDown, 'The live web lookup failed this turn', 'chat admits a failed lookup too');
    ok(!chatDown.includes('[1]'), 'no sources are promised when none were gathered');

    const noWeb = systemFor('humanize', {}, { settings: null });
    ok(!noWeb.includes('Live web context'), 'the Humanizer never sees web text');
    const automate = systemFor('automate', {}, { settings: null });
    ok(!automate.includes('Live web context'), 'Automate never sees web text either');
    const quiz = systemFor('quiz', {}, { settings: null });
    ok(!quiz.includes('Live web context'), 'quiz cards stay clean');
  });

  test('every mode gets the check; only the citing modes cite', () => {
    const web = { ready: true, block: '[1] A checked fact\n     https://example.com/checked' };

    const humanize = systemFor('humanize', {}, { web, settings: null });
    includes(humanize, 'Reference only', 'the Humanizer gets the lookup as reference only');
    includes(humanize, '[1] A checked fact', 'with the numbered block riding along');
    includes(humanize, 'do not add a "Sources:" list', 'and is told never to write a source into the rewrite');
    includes(humanize, 'Rewrite it so it reads like a real person wrote it', 'the rewrite rules themselves are untouched');
    includes(humanize, 'Output ONLY the rewritten text', 'so is the rule that keeps the reply bare');

    const automate = systemFor('automate', {}, { web, settings: null });
    includes(automate, 'Reference only', 'Automate gets the check as well');
    includes(automate, 'Reply with a single JSON object and nothing else', 'and still has to answer with its one JSON object');
    includes(automate, '[1] A checked fact', 'carrying the same block');

    const quiz = systemFor('quiz', {}, { web, settings: null });
    includes(quiz, 'Reference only', 'quiz rounds are checked against the web too');
    includes(quiz, 'Reply with a single JSON object and nothing else', 'while staying a single JSON object');

    // A failed lookup still reaches these modes — they just aren't allowed
    // to say so out loud, because their output format is fixed.
    const down = systemFor('humanize', {}, { web: { ready: false, block: '' }, settings: null });
    includes(down, 'nothing fresh to check against', 'a failed lookup is reported to a fixed-output mode');
    ok(!down.includes('say plainly that'), 'without the "tell the person" wording that mode cannot use');
    ok(!down.includes('[1]'), 'and with no sources promised');

    // No lookup, no web text — passing `web` is what opts a mode in.
    ok(!systemFor('automate', {}, { settings: null }).includes('Reference only'), 'Automate without a lookup is clean');
    ok(!systemFor('quiz', {}, { settings: null }).includes('Reference only'), 'quiz without a lookup is clean');
  });

  /* --- on-demand writing techniques (styles.js) --- */
  test('the writing catalogue', () => {
    ok(STYLE_TECHNIQUES.length > 100, `the catalogue holds over 100 ways to write (${STYLE_TECHNIQUES.length})`);
    const names = new Set(STYLE_TECHNIQUES.map((t) => t.name));
    eq(names.size, STYLE_TECHNIQUES.length, 'no two techniques share a name');
    ok(
      STYLE_TECHNIQUES.every((t) => t.name && Array.isArray(t.keys) && t.keys.length && t.how),
      'every technique has a name, trigger words and an instruction'
    );
    ok(
      STYLE_TECHNIQUES.every((t) => t.how.length <= 160),
      'instructions stay one line — they are paid for per token'
    );
  });

  test('techniques fire only for a writing request', () => {
    const hits = matchStyles('write this as a bulleted list, formal tone please');
    const names = hits.map((h) => h.name);
    ok(names.includes('Bulleted list'), 'a list request finds the list technique');
    ok(names.includes('Formal'), 'and the tone alongside it');
    ok(hits.length <= 4, 'at most four techniques per turn, to protect the token budget');

    eq(matchStyles('who is the smartest person on earth'), [], 'an ordinary question loads nothing');
    eq(matchStyles('did you get my email earlier?'), [], 'a stray mention of a technique word loads nothing');
    eq(matchStyles(''), [], 'an empty message loads nothing');
    ok(matchStyles('be formal').length > 0, 'an imperative style command counts on its own');

    const block = styleBlock('draft a cover letter, make it casual and short');
    includes(block, 'How this reply should be written', 'the block tells the model what it is');
    includes(block, '- Cover letter:', 'and carries the matched technique');
    ok(block.length <= 900, `the block is capped for the 8k/min budget (${block.length} chars)`);
    eq(styleBlock('what is the capital of burundi'), '', 'no block at all when nothing was asked for');
  });

  test('techniques ride along only when asked', () => {
    const ask = 'write this as a numbered list in a formal tone';
    includes(systemFor('chat', {}, { ask, settings: null }), 'How this reply should be written', 'chat receives the techniques for that turn');
    includes(systemFor('math', {}, { ask, settings: null }), '- Numbered list:', 'Math & Code receives them too');
    ok(!systemFor('chat', {}, { ask: 'who won the world cup', settings: null }).includes('How this reply should be written'), 'an ordinary turn pays nothing');
    ok(!systemFor('humanize', {}, { ask, settings: null }).includes('How this reply should be written'), 'the Humanizer must emit only the rewritten text');
    ok(!systemFor('automate', {}, { ask, settings: null }).includes('How this reply should be written'), 'Automate must emit only its JSON');
    ok(!systemFor('quiz', {}, { ask, settings: null }).includes('How this reply should be written'), 'quiz cards stay clean');
    includes(
      systemFor('chat', {}, { ask, web: { ready: true, block: '[1] https://example.com/x' }, settings: null }),
      'Live web context, gathered moments ago',
      'techniques and the web block coexist in one prompt'
    );
  });

  // Regression: gatherWeb()'s real return value must switch prompts on by
  // itself. The block below is shaped exactly as web.js produces it (no
  // `ready` field at the time of the bug) — passing a hand-built object
  // instead is precisely how the shipped code came to drop every block. The
  // pasted link points at a fixture the local server always serves, so this
  // tests the *wiring* rather than the live network, which has its own tests.
  await testAsync('the real gatherWeb output reaches the prompt untouched', async () => {
    const web = await gatherWeb({
      text: `Read ${location.origin}/test/fixtures/page.html for me — what does it say about periapsis?`
    });
    ok(web.block.length > 0, `gatherWeb produced a block (${web.block.length} chars)`);
    eq(web.ready, true, 'gatherWeb reports itself ready when it has a block');

    const chat = systemFor('chat', {}, { web, settings: null });
    includes(chat, 'Live web context, gathered moments ago', 'chat gets the block, not the failure note');
    includes(chat, '[1] ', 'with its numbered sources');
    ok(!chat.includes('The live web lookup failed this turn'), 'chat does not claim the lookup failed');

    const research = systemFor('research', {}, { web, settings: null });
    includes(research, 'This is research, not a chat answer', 'Deep Search switches to the live prompt');

    // …and an explicitly failed lookup must still be honest.
    const down = systemFor('chat', {}, { web: { ready: false, sources: [], block: '', searched: false, read: 0 }, settings: null });
    includes(down, 'The live web lookup failed this turn', 'ready:false keeps the honest note');
  });

  /* --- live network, through the proxy --- */
  await testAsync('searchWeb against a live engine', async () => {
    const results2 = await searchWeb('what is the boiling point of water at sea level');
    ok(results2.length >= 3, `got ${results2.length} live results`);
    ok(results2.every((r) => /^https?:\/\//.test(r.url)), 'every result is an absolute http(s) url');
    ok(results2.every((r) => r.title && r.title.length > 2), 'every result has a title');
    ok(results2.some((r) => r.snippet.length > 20 || r.title.length > 15), 'at least one result carries a snippet');
    ok(results2.every((r) => !/duckduckgo\.com|bing\.com/.test(r.url)), 'the engine never cites itself');
  });

  /* --- engines race instead of queueing --- */

  const engine = (name, path, parse) => ({ name, url: () => `${location.origin}${path}`, parse });

  await testAsync('a working engine wins even when another is unreachable', async () => {
    // The old sequential order tried DuckDuckGo's black-holed endpoints
    // first and burned both timeouts before asking the engine that answers —
    // twenty seconds of nothing, then no sources. Racing them, the fixture
    // engine answers immediately while the hanging one is still waiting.
    const started = Date.now();
    const results2 = await searchWeb('anything at all', {
      engines: [engine('dead', '/hang?ms=8000', parseDuckHtml), engine('fixture', '/test/fixtures/bing-rss.xml', parseBingRss)]
    });
    ok(results2.length >= 3, `the reachable engine's results came through: ${results2.length}`);
    ok(Date.now() - started < 4000, 'without waiting out the unreachable one first');
  });

  await testAsync('an engine that answers with nothing loses the race quietly', async () => {
    const results2 = await searchWeb('anything at all', {
      engines: [engine('challenge', '/test/fixtures/ddg-challenge.html', parseDuckHtml), engine('fixture', '/test/fixtures/bing-rss.xml', parseBingRss)]
    });
    ok(results2.length >= 3, 'the challenge page is not mistaken for the answer');
  });

  await testAsync('every engine failing means no sources, not an exception', async () => {
    const results2 = await searchWeb('anything at all', {
      engines: [engine('gone1', '/test/fixtures/definitely-missing.html', parseDuckHtml), engine('gone2', '/also-missing', parseDuckLite)]
    });
    eq(results2.length, 0, 'quietly empty');
  });

  await testAsync('Stop still aborts a search in flight', async () => {
    const ctl = new AbortController();
    ctl.abort();
    let threw = null;
    try {
      await searchWeb('anything at all', { signal: ctl.signal, engines: [engine('dead', '/hang?ms=8000', parseDuckHtml)] });
    } catch (err) {
      threw = err;
    }
    eq(threw?.name, 'AbortError', 'an already-aborted caller gets the Stop signal, not silence');
  });

  await testAsync('fetchDocument reads a live HTML page', async () => {
    const doc = await fetchDocument('https://example.com/');
    eq(doc.kind, 'html', 'example.com is read as html');
    includes(doc.text, 'Example Domain', 'got the page text');
    eq(doc.title, 'Example Domain', 'got the title');
    ok(!doc.text.includes('<h1'), 'no tags in the extracted text');
  });

  await testAsync('fetchDocument reads a live PDF', async () => {
    const doc = await fetchDocument('https://pdfobject.com/pdf/sample.pdf');
    eq(doc.kind, 'pdf', 'detected as a pdf from the content type');
    ok(doc.text.replace(/\s/g, '').length > 10, `pulled text out of it: ${JSON.stringify(doc.text.slice(0, 60))}`);
    ok(doc.text.split(/\s+/).filter(Boolean).length > 3, 'the PDF words actually came through');
  });

  await testAsync('extractPdfText on the same bytes', async () => {
    const res = await fetch('https://pdfobject.com/pdf/sample.pdf');
    const bytes = new Uint8Array(await res.arrayBuffer());
    const { text, sparse } = await extractPdfText(bytes);
    ok(text.replace(/\s/g, '').length > 10, 'shared extractor works for uploads too');
    eq(sparse, false, 'not flagged as a scanned/empty PDF');
  });

  await testAsync('a live page that cannot be read reports why, never throws', async () => {
    const missing = await fetchDocument('https://example.com/definitely-not-here-404');
    eq(missing.kind, 'error', 'a 404 is an error entry');
    includes(missing.note, '404', 'and names the status');
    const bad = await fetchDocument('https://example.com/');
    ok(bad.kind === 'html', 'the good path still works afterwards');
  });

  await testAsync('gatherWeb end to end', async () => {
    const statuses = [];
    const web = await gatherWeb({
      text: 'Read https://pdfobject.com/pdf/sample.pdf for me — what is the boiling point of water at sea level?',
      onStatus: (s) => statuses.push(s)
    });

    eq(web.sources[0]?.url, 'https://pdfobject.com/pdf/sample.pdf', 'the pasted link is source 1');
    eq(web.searched, true, 'a search ran alongside the pasted link');
    ok(web.read >= 1, `opened ${web.read} page(s)`);
    includes(web.block, '[1] ', 'the block is numbered from 1');
    includes(web.block, 'The page itself (a .pdf, read as text)', 'the linked PDF was read as text into the block');
    ok(web.block.length <= WEB_LIMITS.budgetChars, `block is ${web.block.length} chars, within budget`);
    ok(statuses.includes('Searching the web'), 'reported the search phase');
    ok(statuses.some((s) => /Reading/.test(s)), 'reported the reading phase');
    eq(statuses.at(-1), '', 'status clears itself when done');

    const numbering = [...web.block.matchAll(/\[(\d+)\]/g)].map((m) => Number(m[1]));
    eq(Math.max(...numbering, 0), web.sources.length, 'the model sees exactly the sources that will render');
  });

  await testAsync('gatherWeb survives a message with no links', async () => {
    const web = await gatherWeb({ text: 'who wrote the foundation series' });
    ok(web.sources.length > 0, 'still finds sources from the search alone');
    includes(web.block, '[1] ', 'and numbers them');
  });

  await testAsync('gatherWeb gives up quietly when nothing works', async () => {
    const ctl = new AbortController();
    ctl.abort();
    let threw = null;
    try {
      await gatherWeb({ text: 'anything at all', signal: ctl.signal });
    } catch (err) {
      threw = err;
    }
    eq(threw?.name, 'AbortError', 'Stop during the web pass aborts the turn instead of failing it');
  });

  /* --- the panel module itself --- */
  await testAsync('sidepanel.js parses and imports cleanly', async () => {
    // Loaded on a plain page it will fail at the first chrome.* call or
    // missing element — that is expected outside the extension. What must
    // never happen is a SyntaxError or a bad import path, which would leave
    // the whole panel dead.
    let err = null;
    try {
      await import('../src/sidepanel/sidepanel.js');
    } catch (e) {
      err = e;
    }
    if (err) {
      ok(err.name !== 'SyntaxError', `module failed to parse: ${err.message}`);
      ok(!/Failed to fetch|404|mime/i.test(String(err.message)), `an import could not be resolved: ${err.message}`);
    } else {
      ok(true, 'module imported with no error at all');
    }
  });

  /* --- "request too large": the refusal must become something fixable --- */

  // Verbatim from Groq: no "Used" between Limit and Requested, and a 400
  // rather than a 429. Matching only the older three-number spelling let this
  // exact error reach the person raw, with nothing shrunk and nothing retried.
  const TOO_LARGE_DETAIL =
    'Request too large for model `openai/gpt-oss-120b` in organization `org_01m37g49fkeb0v85wwfrr8bfgy` ' +
    'service tier `on_demand` on tokens per minute (TPM): Limit 8000, Requested 11173, please reduce your ' +
    'message size and try again. Need more tokens? Upgrade to Dev Tier today at https://console.groq.com/settings/billing';

  await testAsync('readError parses the no-"Used" TPM refusal', async () => {
    const res = new Response(JSON.stringify({ error: { message: TOO_LARGE_DETAIL } }), {
      status: 400,
      statusText: 'Bad Request'
    });
    const err = await readError(res, 'Groq');
    ok(err instanceof Error, 'still an Error');
    eq(err.status, 400, 'status preserved — a400 must not be mistaken for success');
    eq(err.code, 'too_large', 'flagged as shrinkable, whatever the status');
    eq(err.tpm?.limit, 8000, 'the ceiling is read out of the message');
    eq(err.tpm?.used, 0, 'no Used group means no known usage, not a parse failure');
    eq(err.tpm?.requested, 11173, 'what the request asked for');
    includes(err.hint, 'trims the context', 'the hint promises the recovery it will actually attempt');
    ok(!/org_01m37|console\.groq/.test(err.message), 'org ids and billing pitches stay out of the shown message');
    includes(err.detail, TOO_LARGE_DETAIL.slice(0, 40), 'the raw wording is kept for the console only');
  });

  await testAsync('readError still parses the older Used-spelling bucket', async () => {
    const res = new Response(
      JSON.stringify({ error: { message: 'Rate limit reached for request. Limit 8000, Used 7900, Requested 9400, please try again in 12s.' } }),
      { status: 429, statusText: 'Too Many Requests' }
    );
    const err = await readError(res, 'Groq');
    eq(err.code, 'too_large', 'over the ceiling by 1400 — flagged, not just queued');
    eq(err.tpm?.used, 7900, 'usage read when present');
    eq(err.message, 'That’s more than Viora can take in at once.', 'a shrunk retry is promised to the person');
    eq(err.retryAfterMs, 12000, 'and the named wait is still available as the fallback');
  });

  await testAsync('readError leaves an ordinary failure alone', async () => {
    const res = new Response(JSON.stringify({ error: { message: 'Invalid request' } }), { status: 400, statusText: 'Bad Request' });
    const err = await readError(res, 'Groq');
    eq(err.code, undefined, 'not mislabelled as too_large');
    eq(err.tpm, null, 'no token numbers invented');
    eq(tpmCeiling('never-seen/Model'), 0, 'a ceiling is only ever learnt from a real refusal');
  });

  await testAsync('a slow page times out as a failure, never as a Stop', async () => {
    // The distinction matters: fetch rejects a timeout with AbortError, which
    // every caller reads as "the person pressed Stop" — one sluggish page
    // would abort the whole turn instead of being reported as unreadable.
    const doc = await fetchDocument(`${location.origin}/hang?ms=3000`, { ms: 600 });
    eq(doc.kind, 'error', 'a page that never answers is an error entry');
    includes(doc.note, 'took too long', 'and says why, in words');
    const okDoc = await fetchDocument('https://example.com/');
    eq(okDoc.kind, 'html', 'the good path still works afterwards');
  });

  await testAsync('a search that times out returns, never throws an abort', async () => {
    // searchWeb's own timeout surfaces from fetch as AbortError — if that
    // leaked, it would look exactly like Stop and kill the turn. Shrinking
    // the search deadline forces the timeout path for real.
    const before = WEB_LIMITS.searchMs;
    WEB_LIMITS.searchMs = 1;
    let web = null;
    let threw = null;
    try {
      web = await gatherWeb({ text: 'anything at all' });
    } catch (err) {
      threw = err;
    } finally {
      WEB_LIMITS.searchMs = before;
    }
    eq(threw, null, 'a timed-out search is not an exception');
    ok(web && Array.isArray(web.sources), 'and still returns a well-formed result to render');
    eq(web.searched, false, 'reporting honestly that no search completed');
  });

  render();
}

/* ---------------- reporting ---------------- */

test('a bare "Create an image" is an image request with nothing yet to draw', () => {
  const bare = detectImageRequest('Create an image');
  ok(bare && bare.subject === '', `expected an empty subject, got ${JSON.stringify(bare)}`);
});

test('"create an image" pulls the subject out of the sentence', () => {
  const cases = [
    ['Create an image of a red bicycle', 'a red bicycle'],
    ['create a picture of a fox in the snow', 'a fox in the snow'],
    ['Draw me a picture of a cat in the rain', 'a cat in the rain'],
    ['Can you make a logo for my bakery', 'my bakery'],
    ["I'd like an illustration of a fox", 'a fox'],
    ['Generate an image of a castle at dawn', 'a castle at dawn'],
    ['please make me a photo of my dog, please', 'my dog'],
    ['Design a poster for my band', 'my band']
  ];
  const bad = cases
    .map(([input, want]) => ({ input, got: detectImageRequest(input)?.subject }))
    .filter((r) => r.got !== cases.find(([i]) => i === r.input)[1]);
  ok(bad.length === 0, `subjects parsed wrong: ${JSON.stringify(bad)}`);
});

test('mentions of an existing image are not mistaken for requests to make one', () => {
  const notRequests = [
    'What does the image of the chart show?',
    'please explain the image of the chart',
    'describe the picture they attached',
    'Draw me a diagram of the cycle',
    'Summarise what I am reading',
    'Humanize this text: it sounds robotic',
    ''
  ];
  const wrong = notRequests.filter((t) => detectImageRequest(t) !== null);
  ok(wrong.length === 0, `these must not trigger a render: ${JSON.stringify(wrong)}`);
});

test('the image service answer is read from artifacts, and refusals are not silent', () => {
  eq(parseImageResponse({ artifacts: [{ base64: 'AAA' }] }), 'AAA', 'a plain answer reads straight through');
  eq(
    parseImageResponse({ artifacts: [{ base64: 'BBB', finishReason: 'SUCCESS' }] }),
    'BBB',
    'SUCCESS is not an error'
  );

  const refused = [
    { detail: [{ msg: 'Input should be 768' }] },
    { detail: 'Please make a purchase' },
    { artifacts: [] },
    { artifacts: [{ base64: '' }] },
    { artifacts: [{ base64: 'X', finishReason: 'CONTENT_FILTERED' }] },
    {}
  ];
  const silent = refused.filter((body) => {
    try {
      parseImageResponse(body);
      return true;
    } catch (err) {
      return !(err instanceof ImageError) || !err.message;
    }
  });
  ok(silent.length === 0, `every failure shape must throw a readable ImageError: ${JSON.stringify(silent)}`);
  ok(
    /768/.test((() => { try { parseImageResponse(refused[0]); return ''; } catch (e) { return e.message; } })()),
    'the service\'s own wording is surfaced, not replaced'
  );
});

testAsync('a render is re-encoded to JPEG before it is saved', async () => {
  const src = document.createElement('canvas');
  src.width = 300;
  src.height = 200;
  const ctx = src.getContext('2d');
  ctx.fillStyle = '#c33';
  ctx.fillRect(0, 0, 300, 200);

  const out = await toJpegDataUrl(src.toDataURL('image/png'), { maxEdge: 150 });
  ok(out.startsWith('data:image/jpeg'), `expected a JPEG data URL, got ${out.slice(0, 24)}`);
  ok(out.length < src.toDataURL('image/png').length, 'the JPEG must be smaller than the PNG it came from');

  const back = await new Promise((resolve) => {
    const i = new Image();
    i.onload = () => resolve(i);
    i.src = out;
  });
  ok(back.naturalWidth === 150 && back.naturalHeight === 100, `scaled to ${back.naturalWidth}×${back.naturalHeight}, expected 150×100`);
});

test('the format is sniffed from the bytes, since the docs promise PNG and the service sends JPEG', () => {
  eq(imageMime('/9j/4AAQSkZJRgABAQAAAQABAAD'), 'image/jpeg', 'JPEG magic');
  eq(imageMime('iVBORw0KGgoAAAANSUhEUg'), 'image/png', 'PNG magic');
  eq(imageMime('UklGRhoAAABXRUJQVlA4'), 'image/webp', 'WebP magic');
  eq(imageMime('nonsense'), 'image/jpeg', 'an unknown prefix falls back to JPEG rather than asserting PNG');
});

testAsync('a filtered render is retried once on a fresh seed, then reported as a refusal', async () => {
  const filtered = JSON.stringify({ artifacts: [{ base64: 'AAA', finishReason: 'CONTENT_FILTERED' }] });
  const good = JSON.stringify({ artifacts: [{ base64: '/9j/4AAQBBQU=', finishReason: 'SUCCESS' }] });

  const bodies = [];
  const fake = async (_url, opts) => {
    bodies.push(JSON.parse(opts.body));
    const body = bodies.length === 1 ? filtered : good;
    return { ok: true, status: 200, json: async () => JSON.parse(body) };
  };

  const url = await generateImage({ prompt: 'a fox', fetchImpl: fake, attempts: 2 });
  eq(url, 'data:image/jpeg;base64,/9j/4AAQBBQU=', 'the second attempt wins and carries the sniffed mime');
  eq(bodies.length, 2, 'exactly one retry');
  ok(bodies[0].seed !== bodies[1].seed, 'the retry must use a different seed — that is the whole point of it');

  let thrown = null;
  const always = async () => ({ ok: true, status: 200, json: async () => JSON.parse(filtered) });
  try {
    await generateImage({ prompt: 'a fox', fetchImpl: always, attempts: 2 });
  } catch (err) { thrown = err; }
  ok(thrown instanceof ImageError, 'a persistently filtered prompt throws');
  ok(/safety filter/.test(thrown.message), `the refusal is named, not swallowed: ${thrown.message}`);

  let calls = 0;
  const rejected = async () => {
    calls++;
    return { ok: false, status: 422, text: async () => '{"detail":[{"msg":"bad"}]}' };
  };
  let statusErr = null;
  try {
    await generateImage({ prompt: 'a fox', fetchImpl: rejected, attempts: 2 });
  } catch (err) { statusErr = err; }
  ok(statusErr instanceof ImageError, 'a 422 throws');
  eq(calls, 1, 'only a content filter is worth retrying — a 422 will fail identically');
  ok(/bad/.test(statusErr.message), `the service's own wording is surfaced: ${statusErr.message}`);

  let empty = null;
  try { await generateImage({ prompt: '   ', fetchImpl: always }); } catch (err) { empty = err; }
  ok(empty instanceof ImageError && /nothing to draw/.test(empty.message), 'a blank prompt never reaches the network');
});

/* ---------------- local detector: calibration corpus ---------------- */

const CALIBRATION = [
  ['ai', 'The implementation of this feature demonstrates a comprehensive approach to software development. It is important to note that the system leverages cutting-edge methodologies to facilitate seamless integration across multiple platforms and diverse stakeholder groups. Furthermore, this methodology enables stakeholders to synergize their efforts in a robust and scalable manner across the entire organization. In today’s rapidly evolving digital landscape, organizations must prioritize innovation and agility in order to remain competitive. By leveraging the power of advanced analytics and machine learning, businesses can unlock new opportunities for growth and drive meaningful change. Moreover, the adoption of cloud-native architectures empowers teams to iterate quickly, reduce time to market, and deliver exceptional value to their customers while fostering a culture of collaboration and continuous improvement.'],
  ['ai', 'In recent years, the relationship between technology and education has undergone a profound transformation. It is important to note that digital tools have fundamentally reshaped the way students access information and engage with course material. Furthermore, educators are increasingly leveraging these platforms to create more personalised learning experiences. However, it is worth noting that the rapid adoption of such tools also raises important questions about equity and access. Ultimately, a holistic approach is required in order to ensure that the benefits of these innovations are shared by all learners. In conclusion, while challenges remain, the potential of technology to enhance education is undeniable.'],
  ['ai', 'Our platform empowers teams to streamline their workflow and unlock new opportunities for growth. With a robust suite of features and a seamless user experience, you can navigate the complexities of modern project management with ease. From real-time analytics to comprehensive reporting, every tool you need is built into one powerful dashboard. Moreover, our cutting-edge architecture ensures that your data is always secure and instantly available. Whether you are a startup or an enterprise, we deliver the scalability and performance your business demands.'],
  ['ai', 'First and foremost, it is essential to understand the underlying principles that govern this process. In addition, practitioners must take into account a myriad of factors that influence the final outcome. Secondly, careful attention should be paid to the quality of the inputs, as these ultimately determine the reliability of the results. Thirdly, continuous monitoring plays a pivotal role in maintaining standards over time. Finally, stakeholders should be prepared to adapt their strategies as new information becomes available.'],
  ['ai', 'The device features a comprehensive set of sensors that continuously monitor environmental conditions and transmit data to the cloud for analysis. Users can access detailed insights through the companion application, which provides actionable recommendations based on machine learning models. Installation is straightforward and requires no professional assistance, allowing customers to begin collecting valuable information within minutes of unboxing the product.'],
  ['human', 'so i ended up not going last night lol. mike rang about half 6 saying his car had died on the A34 and he’d need a lift, so obviously i said fine. we got there and the place was shut. SHUT. i could have cried honestly. anyway we ended up at that pub on the corner, which was actually alright. home by 11. you up for doing it properly this weekend?'],
  ['human', 'ok so has anyone else had this problem? i’ve been on hold for 40 minutes now, twice, and every time it cuts me off right before i get through to someone. the automated thing keeps saying my query is important to us which, yeah, cool, but i’d rather it was important enough to actually answer the phone. i’m not angry, just baffled really. is there a trick to getting through?'],
  ['human', 'I didn’t think it would be that hard, honestly. We’d been planning the trip since March and I’d booked the cottage the day it went on the market. Of course, the week we’re due to go, it’s forecast to absolutely chuck it down. My mum says we’ll make the best of it and she’s probably right — we always do. There’s a fire, there’s a pub down the road, and I’ve brought three books. Can’t say it sounds terrible to me.'],
  ['human', 'The dog had been at the door for an hour. Scratching. Whining. That particular low grumble he does when he knows you’re up but you haven’t moved yet. I’d already been awake since five — no idea why, just was — so it wasn’t as if he’d woken me. But he didn’t know that, and frankly he didn’t care. By six I gave in. It was freezing. The field was wet through within about ten seconds of us getting there, and he absolutely loved it, which made the whole thing worth it, I suppose.'],
  ['human', 'Hi Rachel, thanks for sending that over — I’ve had a look and it’s mostly fine. Couple of things: the second paragraph repeats what the first one says, and the figures in the table don’t match the ones in the appendix. Could you take another pass? No rush, end of week is fine. Also, I’m out Thursday so if you need me just ring my mobile rather than emailing. Cheers, Tom'],
  // Harder: formal, contraction-free human writing. A humaniser that works
  // well on an essay lands here, so this is the case that decides whether the
  // target is reachable at all.
  ['human', 'Reading the novel for the first time, I was struck by how little actually happens. A man walks to a station, waits, and goes home again. Yet the whole thing aches. I read it again on the train and found it sadder still, though I could not have told you why. My supervisor thinks I am reading too much into it. She may be right, but I do not think so.'],
  ['human', 'We shipped this in March and it has been stable since, which frankly surprised us. Our first attempt failed because we had assumed the queue would drain in order; it does not. Under load the workers pick up whatever is free, so two of them can end up writing the same record. We added a version column and now reject the stale write. It is not elegant, but it has not lost a row since.'],
  ['human', 'Technology has changed education quite a lot, and not always in the ways people expected. Digital tools have made it far easier for students to find material, and teachers have been quick to use them — some more eagerly than others. The trickier question is who actually gets to benefit. Not everyone has the same kit at home, and a school down the road might be working with ten-year-old laptops. So while the potential is real, it needs a bit of care to make sure it does not just widen the gap it was supposed to close.']
];

test('local detector calibration', () => {
  const rows = CALIBRATION.map(([expect, text]) => ({
    expect,
    score: localScore(text).percent,
    flagged: localScore(text).flagged.length
  }));
  // Scores ride along in `detail`; they show up in test/_result.json for
  // tuning even while the assertion itself passes.
  record(true, `local detector scores: ${rows.map((r) => `${r.expect}=${r.score}`).join(' ')}`, JSON.stringify(rows));
  ok(rows.length === CALIBRATION.length, 'every calibration passage was scored');
});

test('local detector separates machine prose from human prose', () => {
  const ai = CALIBRATION.filter(([e]) => e === 'ai').map(([, t]) => localScore(t).percent);
  const human = CALIBRATION.filter(([e]) => e === 'human').map(([, t]) => localScore(t).percent);
  ok(Math.min(...ai) > Math.max(...human), `no AI passage (${Math.min(...ai)}) may score at or below the worst human one (${Math.max(...human)})`);
});

test('the humaniser target is reachable — formal human prose lands at or under 10%', () => {
  const formal = CALIBRATION.slice(-3).map(([, t]) => localScore(t).percent);
  ok(Math.max(...formal) <= 10, `formal human passages must pass the default target, worst scored ${Math.max(...formal)}%`);
});

testAsync('detectAiScore falls back to the built-in check with no key', async () => {
  const res = await detectAiScore('Honestly this one is fine, I wrote it myself and you can tell — it wanders a bit, goes off on tangents, and that is kind of the point, right?');
  eq(res.source, 'Viora', 'a rewrite with no ZeroGPT key is scored by the built-in check');
  ok(typeof res.percent === 'number', 'the built-in check returns a number, always');
});

/**
 * Hand the results to the local server as well as the page. Headless Chrome
 * with --dump-dom exits at `load`, which is long before the network tests
 * finish, and --virtual-time-budget fast-forwards setTimeout so every fetch
 * timeout fires mid-download and corrupts exactly the tests under scrutiny.
 * The runner therefore opens this page, lets it run in real time, and waits
 * for this POST to land in test/_result.json.
 */
function report() {
  const payload = {
    title: document.title,
    results
  };
  fetch('/test/result', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  }).catch(() => { /* the server is gone; the page still shows the verdict */ });
}

function render() {
  const passed = results.filter((r) => r.ok).length;
  const failed = results.filter((r) => !r.ok);
  const suites = [...new Set(results.map((r) => r.suite))];

  document.title = `${failed.length ? 'FAIL' : 'PASS'} ${passed}/${results.length}`;

  const summary = document.createElement('p');
  summary.className = failed.length ? 'fail' : 'pass';
  summary.textContent = failed.length
    ? `FAILED ${failed.length} of ${results.length} checks across ${suites.length} suites`
    : `ALL ${passed} CHECKS PASSED across ${suites.length} suites`;
  document.body.prepend(summary);

  const list = document.createElement('ul');
  for (const r of results) {
    const li = document.createElement('li');
    li.className = r.ok ? 'ok' : 'bad';
    li.textContent = `${r.ok ? '✓' : '✗'} [${r.suite}] ${r.message}${r.ok || !r.detail ? '' : ` — ${r.detail}`}`;
    list.append(li);
  }
  document.body.append(list);
  window.__done = true;
  report();
}

run().catch((err) => {
  document.title = 'HARNESS ERROR';
  const p = document.createElement('p');
  p.className = 'fail';
  p.textContent = `Harness error: ${err.message}\n${err.stack}`;
  document.body.prepend(p);
  window.__done = true;
  report();
});
