/**
 * Viora — content script.
 * Builds the numbered element snapshot the planner reads, performs the
 * actions it returns, and briefly outlines whatever it touches so the user
 * can see what happened.
 */

(() => {
  if (window.__vioraContentReady) return;
  window.__vioraContentReady = true;

  const INTERACTIVE = 'a[href], button, input, select, textarea, [role="button"], [role="link"], [role="tab"], [contenteditable="true"]';
  let refs = new Map();

  const visible = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity) > 0.05;
  };

  const label = (el) => {
    const text =
      el.getAttribute('aria-label') ||
      el.getAttribute('placeholder') ||
      el.getAttribute('title') ||
      el.value ||
      el.innerText ||
      el.getAttribute('name') ||
      '';
    return text.replace(/\s+/g, ' ').trim().slice(0, 80);
  };

  function buildSnapshot() {
    refs = new Map();
    const items = [];
    let ref = 1;
    for (const el of document.querySelectorAll(INTERACTIVE)) {
      if (!visible(el) || el.disabled) continue;
      refs.set(ref, el);
      items.push({
        ref,
        tag: el.tagName.toLowerCase(),
        type: el.getAttribute('type') || el.getAttribute('role') || '',
        label: label(el)
      });
      ref++;
      if (ref > 120) break;
    }
    return { url: location.href, title: document.title, elements: items };
  }

  function readableText() {
    const clone = document.body.cloneNode(true);
    clone.querySelectorAll('script, style, noscript, svg, nav, footer, aside').forEach((n) => n.remove());
    return clone.innerText.replace(/\n{3,}/g, '\n\n').trim();
  }

  /**
   * Raw markup of the page, for tasks that need actual tags/attributes
   * (structure, data-* attributes, hrefs, form field names) rather than
   * just the rendered text. Scripts, styles, comments and inline event
   * handlers are stripped — they're irrelevant to reading the page and
   * scripts in particular are the one part of "the page's HTML" that
   * should never be replayed back through a prompt.
   */
  function rawHtml() {
    const clone = document.body.cloneNode(true);
    clone.querySelectorAll('script, style, noscript, template').forEach((n) => n.remove());
    clone.querySelectorAll('*').forEach((el) => {
      for (const attr of [...el.attributes]) {
        if (/^on/i.test(attr.name)) el.removeAttribute(attr.name);
      }
    });
    const html = clone.innerHTML
      .replace(/<!--[\s\S]*?-->/g, '')
      .replace(/[ \t]{2,}/g, ' ')
      .replace(/\n{2,}/g, '\n')
      .trim();
    return html;
  }

  function flash(el) {
    el.classList.add('viora-touch');
    setTimeout(() => el.classList.remove('viora-touch'), 900);
  }

  async function act(action) {
    const el = action.ref != null ? refs.get(action.ref) : null;
    if (action.type !== 'scroll' && !el) {
      return { ok: false, detail: `No element with ref ${action.ref}. Take a fresh snapshot.` };
    }

    switch (action.type) {
      case 'click':
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        flash(el);
        // Menus and custom buttons often listen for the pointer events that
        // come before a click, not the click itself, so send those first.
        for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) {
          const Ctor = type.startsWith('pointer') && window.PointerEvent ? PointerEvent : MouseEvent;
          el.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, view: window }));
        }
        el.click();
        return { ok: true, detail: `Clicked "${label(el) || el.tagName.toLowerCase()}"` };

      case 'fill': {
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        flash(el);
        el.focus();
        if (el.isContentEditable) {
          // Rich editors (chat boxes, Notion-style editors, comment fields)
          // keep their own model of the text, so writing straight into the DOM
          // gets ignored or wiped. execCommand goes through the same path as
          // real typing, which they do listen to; the plain assignment is only
          // the fallback for pages where that isn't available.
          const text = action.value ?? '';
          const range = document.createRange();
          range.selectNodeContents(el);
          const sel = window.getSelection();
          sel.removeAllRanges();
          sel.addRange(range);
          const typed = document.execCommand && (text ? document.execCommand('insertText', false, text) : document.execCommand('delete'));
          if (!typed) el.textContent = text;
        } else {
          const setter = Object.getOwnPropertyDescriptor(
            el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype,
            'value'
          )?.set;
          setter ? setter.call(el, action.value ?? '') : (el.value = action.value ?? '');
        }
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return { ok: true, detail: `Filled "${label(el) || 'field'}"` };
      }

      case 'scroll':
        window.scrollTo({
          top: action.to === 'top' ? 0 : document.body.scrollHeight,
          behavior: 'smooth'
        });
        return { ok: true, detail: `Scrolled to ${action.to || 'bottom'}` };

      case 'extract':
        flash(el);
        return { ok: true, detail: (el.innerText || el.value || '').trim().slice(0, 1500) };

      case 'set_file': {
        if (el.tagName !== 'INPUT' || el.type !== 'file') {
          return { ok: false, detail: 'That element is not a file picker (input type="file").' };
        }
        try {
          const res = await fetch(action.url);
          if (!res.ok) return { ok: false, detail: `Could not fetch the file (HTTP ${res.status}).` };
          const blob = await res.blob();
          const name = action.url.split('/').pop()?.split('?')[0] || 'file';
          const file = new File([blob], name, { type: blob.type || 'application/octet-stream' });
          const dt = new DataTransfer();
          dt.items.add(file);
          el.files = dt.files;
          flash(el);
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          return { ok: true, detail: `Added "${name}" to "${label(el) || 'file input'}"` };
        } catch (err) {
          return { ok: false, detail: `Could not load that file: ${err.message}` };
        }
      }

      default:
        return { ok: false, detail: `Unknown action: ${action.type}` };
    }
  }

  /**
   * Screenshot area picker. Dims the page, lets the user drag a rectangle,
   * and resolves with viewport-space coordinates — capturing the pixels
   * themselves happens on the extension side (a content script has no API
   * for that), so this just answers "which rectangle".
   */
  function pickScreenshotArea() {
    return new Promise((resolve) => {
      const veil = document.createElement('div');
      veil.className = 'viora-shot-veil';
      const hint = document.createElement('div');
      hint.className = 'viora-shot-hint';
      hint.textContent = 'Drag to select an area · Esc to cancel';
      let box = null;
      let start = null;
      let done = false;

      function cleanup() {
        veil.remove();
        hint.remove();
        box?.remove();
        document.removeEventListener('keydown', onKey, true);
      }

      function finish(result) {
        if (done) return;
        done = true;
        cleanup();
        resolve(result);
      }

      function onKey(e) {
        if (e.key === 'Escape') {
          e.preventDefault();
          finish({ ok: false, cancelled: true });
        }
      }

      veil.addEventListener('mousedown', (e) => {
        if (e.button !== 0) return;
        start = { x: e.clientX, y: e.clientY };
        box = document.createElement('div');
        box.className = 'viora-shot-box';
        box.style.left = `${start.x}px`;
        box.style.top = `${start.y}px`;
        document.body.append(box);
      });

      veil.addEventListener('mousemove', (e) => {
        if (!start || !box) return;
        const x = Math.min(start.x, e.clientX);
        const y = Math.min(start.y, e.clientY);
        const w = Math.abs(e.clientX - start.x);
        const h = Math.abs(e.clientY - start.y);
        box.style.left = `${x}px`;
        box.style.top = `${y}px`;
        box.style.width = `${w}px`;
        box.style.height = `${h}px`;
      });

      veil.addEventListener('mouseup', (e) => {
        if (!start) return;
        const x = Math.min(start.x, e.clientX);
        const y = Math.min(start.y, e.clientY);
        const width = Math.abs(e.clientX - start.x);
        const height = Math.abs(e.clientY - start.y);
        if (width < 6 || height < 6) {
          finish({ ok: false, cancelled: true });
          return;
        }
        finish({
          ok: true,
          rect: { x, y, width, height },
          dpr: window.devicePixelRatio || 1
        });
      });

      document.addEventListener('keydown', onKey, true);
      document.body.append(veil, hint);
    });
  }

  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    switch (msg?.type) {
      case 'viora:ping':
        reply({ ok: true });
        return true;
      case 'viora:snapshot':
        reply(buildSnapshot());
        return true;
      case 'viora:page-context':
        reply({
          url: location.href,
          title: document.title,
          text: readableText().slice(0, 12000),
          html: rawHtml().slice(0, 20000)
        });
        return true;
      case 'viora:selection':
        reply({ text: String(getSelection() || '').trim() });
        return true;
      case 'viora:act':
        act(msg.action).then(reply);
        return true;
      case 'viora:screenshot-select':
        pickScreenshotArea().then(reply);
        return true;
      default:
        return false;
    }
  });
})();
