/**
 * Why did the live search come back empty this run? Ask each endpoint the
 * exact way web.js does (same URL builder, same proxy path, same headers a
 * page may set) and report status, size and how many results the markup
 * carries — then call searchWeb() itself. The verdict goes to the server
 * like the test suite's does.
 */

import { searchWeb, parseDuckHtml, parseDuckLite, parseBingRss } from '../src/lib/web.js';

const realFetch = window.fetch.bind(window);
window.fetch = (input, init) => {
  const url = typeof input === 'string' ? input : input.url;
  if (/^https?:\/\//.test(url) && !url.startsWith(location.origin)) {
    return realFetch(`/proxy?url=${encodeURIComponent(url)}`, init);
  }
  return realFetch(input, init);
};

const query = 'what is the boiling point of water at sea level';
const endpoints = [
  { name: 'ddg-html', url: `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`, parse: parseDuckHtml },
  { name: 'ddg-lite', url: `https://lite.duckduckgo.com/lite/?q=${encodeURIComponent(query)}`, parse: parseDuckLite },
  { name: 'bing-rss', url: `https://www.bing.com/search?q=${encodeURIComponent(query)}&format=rss`, parse: parseBingRss }
];

const report = [];
const t0 = Date.now();

for (const e of endpoints) {
  const row = { name: e.name, ms: 0 };
  const started = Date.now();
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 12000);
    const res = await fetch(e.url, {
      redirect: 'follow',
      credentials: 'omit',
      signal: ctl.signal,
      headers: { Accept: 'text/html,application/xhtml+xml,application/pdf,text/plain,*/*' }
    });
    clearTimeout(timer);
    row.status = res.status;
    row.type = res.headers.get('content-type');
    const text = await res.text();
    row.chars = text.length;
    row.parsed = e.parse(text).length;
    row.snippet = text.slice(0, 160).replace(/\s+/g, ' ');
  } catch (err) {
    row.error = `${err.name}: ${err.message}`;
  }
  row.ms = Date.now() - started;
  report.push(row);
}

let search = { ms: 0 };
const s0 = Date.now();
try {
  const results = await searchWeb(query);
  search.count = results.length;
  search.first = results[0]?.url || '';
} catch (err) {
  search.error = `${err.name}: ${err.message}`;
}
search.ms = Date.now() - s0;

fetch('/test/result', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ title: 'DEBUG search endpoints', results: report.map((r) => ({
    suite: 'endpoint',
    ok: Boolean(r.parsed),
    message: `${r.name}: status=${r.status ?? '-'} chars=${r.chars ?? '-'} parsed=${r.parsed ?? '-'} ms=${r.ms}${r.error ? ` error=${r.error}` : ''}`,
    detail: r.snippet || r.error || ''
  })).concat([{
    suite: 'searchWeb',
    ok: search.count > 0,
    message: `searchWeb: count=${search.count ?? '-'} ms=${search.ms}${search.error ? ` error=${search.error}` : ''}`,
    detail: search.first
  }]) })
}).catch(() => {});

document.title = 'DEBUG done';
