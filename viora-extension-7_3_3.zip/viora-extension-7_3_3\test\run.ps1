# Viora - run the test suite in headless Chrome and print the verdict.
#
# Why not --dump-dom: it fires at `load`, before any async test finishes.
# Why not --virtual-time-budget: it fast-forwards setTimeout, so web.js's
# 15s fetch timeout fires while a download is still streaming and every
# network test dies with "BodyStreamBuffer was aborted" - the failures would
# be the harness's own doing. Instead the page POSTs its results to the
# server (tests.js report()), and this script waits for that file in real
# time.
#
# Prerequisite: test\server.ps1 running on 127.0.0.1:8764.

$ErrorActionPreference = 'Stop'
$resultFile = Join-Path $PSScriptRoot '_result.json'
$page = 'http://127.0.0.1:8764/test/index.html'
$chrome = "$env:ProgramFiles\Google\Chrome\Application\chrome.exe"
if (-not (Test-Path $chrome)) { $chrome = "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe" }
if (-not (Test-Path $chrome)) { throw 'Chrome not found.' }

if (Test-Path $resultFile) { Remove-Item $resultFile -Force }

# A throwaway profile so the run never touches (or is blocked by) the
# person's real Chrome session.
$profile = Join-Path $env:TEMP 'viora-test-profile'
$proc = Start-Process -FilePath $chrome -PassThru -WindowStyle Hidden -ArgumentList @(
  '--headless=new', '--disable-gpu', '--no-sandbox',
  "--user-data-dir=`"$profile`"",
  '--no-first-run', '--no-default-browser-check',
  $page
)

try {
  $deadline = (Get-Date).AddSeconds(180)
  while ((Get-Date) -lt $deadline -and -not (Test-Path $resultFile)) {
    Start-Sleep -Milliseconds 500
  }
} finally {
  if ($proc -and -not $proc.HasExited) { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
  Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" |
    Where-Object { $_.CommandLine -like "*viora-test-profile*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

if (-not (Test-Path $resultFile)) {
  Write-Output 'NO RESULT - the page never reported back within 180s.'
  exit 1
}

$json = Get-Content $resultFile -Raw | ConvertFrom-Json
$all = $json.results
$bad = @($all | Where-Object { -not $_.ok })
Write-Output ("{0} - {1} of {2} checks failed, across {3} suites." -f $json.title, $bad.Count, $all.Count, (@($all | Select-Object -ExpandProperty suite -Unique)).Count)
foreach ($b in $bad) {
  Write-Output ("  FAIL [{0}] {1} {2}" -f $b.suite, $b.message, $b.detail)
}
if ($bad.Count -eq 0) { exit 0 } else { exit 1 }
