/**
 * Viora — microphone permission bridge.
 *
 * Chrome suppresses the mic-permission prompt inside a docked side panel, so
 * the panel opens this page in a small popup window where the prompt CAN be
 * shown. One grant here covers the whole extension origin, and the side panel
 * can then record normally.
 */

const btn = document.getElementById('grant');
const state = document.getElementById('state');

const say = (text, err = false) => {
  state.textContent = text;
  state.classList.toggle('err', err);
};

btn.addEventListener('click', async () => {
  btn.disabled = true;
  say('Requesting microphone…');

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((t) => t.stop());
    say('Granted — you can close this window.');
    setTimeout(() => window.close(), 700);
  } catch (err) {
    btn.disabled = false;
    say(err?.name === 'NotAllowedError' ? 'Denied — click again to retry.' : 'Could not get the microphone — try again.', true);
  }
});