import { getSettings, saveSettings, groqConfig, configForChoice, DEFAULTS } from '../lib/storage.js';
import { MODELS, MODEL_ORDER, chainFor } from '../lib/models.js';
import { listModels } from '../lib/providers.js';
import { icon, MODEL_ICON } from '../lib/icons.js';
import { STYLE_QUESTIONS } from '../lib/style-questions.js';

const result = document.getElementById('result');
const read = (obj, path) => path.split('.').reduce((o, k) => o?.[k], obj);

function write(obj, path, value) {
  const keys = path.split('.');
  const last = keys.pop();
  const target = keys.reduce((o, k) => (o[k] ??= {}), obj);
  target[last] = value;
}

const say = (text) => { result.textContent = text; };

/* ---- the default-model radio group ---- */

function buildDefaultModel(settings) {
  const host = document.getElementById('default-model');
  host.replaceChildren();
  for (const id of MODEL_ORDER) {
    const model = MODELS[id];
    const label = document.createElement('label');
    label.className = 'choice';

    const radio = document.createElement('input');
    radio.type = 'radio';
    radio.name = 'default-model';
    radio.value = id;
    radio.checked = settings.prefs.model === id;

    const rowIcon = document.createElement('span');
    rowIcon.className = 'choice-icon';
    rowIcon.innerHTML = icon(MODEL_ICON[id]);

    const copy = document.createElement('span');
    copy.className = 'choice-copy';
    const name = document.createElement('strong');
    name.textContent = model.name;
    const blurb = document.createElement('span');
    blurb.textContent = model.blurb;
    copy.append(name, blurb);

    label.append(radio, rowIcon, copy);
    host.append(label);
  }
}

/* ---- per-model ID overrides ---- */

function buildOverrides(settings) {
  const host = document.getElementById('overrides');
  host.replaceChildren();
  for (const id of MODEL_ORDER) {
    const model = MODELS[id];
    const label = document.createElement('label');
    label.className = 'override-label';

    const labelIcon = document.createElement('span');
    labelIcon.className = 'choice-icon choice-icon-sm';
    labelIcon.innerHTML = icon(MODEL_ICON[id]);
    const labelText = document.createElement('span');
    labelText.textContent = model.name;
    label.append(labelIcon, labelText);

    const input = document.createElement('input');
    input.type = 'text';
    input.setAttribute('list', 'groq-models');
    input.dataset.override = id;
    input.value = settings.modelOverrides?.[id] ?? '';
    input.placeholder = chainFor(id, { resolved: settings.resolvedModels })[0];

    label.append(input);
    host.append(label);
  }
}

/* ---- memory: the list of things Viora is told to remember ---- */

// Kept as a plain array in module state while the page is open; collected
// wholesale on save (chrome.storage merges arrays by replacement, which is
// what we want — removing an entry should actually remove it).
let memoryItems = [];

function buildMemory() {
  const host = document.getElementById('memory-list');
  const empty = document.getElementById('memory-empty');
  host.replaceChildren();

  memoryItems.forEach((item, i) => {
    const li = document.createElement('li');
    const text = document.createElement('span');
    text.textContent = item;
    const del = document.createElement('button');
    del.type = 'button';
    del.textContent = 'Forget';
    del.setAttribute('aria-label', `Stop remembering: ${item}`);
    del.addEventListener('click', () => {
      memoryItems.splice(i, 1);
      buildMemory();
    });
    li.append(text, del);
    host.append(li);
  });

  if (empty) empty.hidden = memoryItems.length > 0;
}

function wireMemory() {
  const input = document.getElementById('memory-input');
  const add = document.getElementById('memory-add-btn');

  const addCurrent = () => {
    const value = input.value.trim();
    if (!value) return;
    if (memoryItems.includes(value)) {
      input.value = '';
      return;
    }
    memoryItems.push(value);
    input.value = '';
    buildMemory();
    input.focus();
  };

  add.addEventListener('click', addCurrent);
  // Enter adds (there's no form here — the save button is page-wide).
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addCurrent();
    }
  });
}

function fill(settings) {
  for (const field of document.querySelectorAll('[data-path]')) {
    const path = field.dataset.path;
    if (field.type === 'checkbox') field.checked = Boolean(read(settings, path));
    else field.value = read(settings, path) ?? '';
  }
  memoryItems = Array.isArray(settings.memory) ? settings.memory.filter((m) => String(m).trim()) : [];
  buildMemory();
  buildDefaultModel(settings);
  buildOverrides(settings);
  showStyleStatus(settings);
}

/* ---- Humanizer writing style: retake or clear the ten-card profile ---- */

function showStyleStatus(settings) {
  const note = document.getElementById('style-status');
  const h = settings.humanizer;
  const ready = Boolean(h?.onboarded && h.style?.length);
  const partial = !ready && (h?.draft?.answers || []).some((a) => String(a).trim());
  note.textContent = ready
    ? `Set up — the Humanizer is matching ${h.style.length} answers about how you write.`
    : partial
      ? 'Half-finished — open the Humanizer in the panel to pick up where you left off.'
      : 'Not set up yet — the Humanizer asks you ten short question cards the first time you open it.';
  document.getElementById('style-retake').disabled = !ready;
  document.getElementById('style-clear').disabled = !ready && !partial;
}

document.getElementById('style-retake').addEventListener('click', async () => {
  const settings = await getSettings();
  // Keep their old answers on the cards so tweaking one isn't rewriting ten.
  const prior = STYLE_QUESTIONS.map((q) => settings.humanizer?.style?.find((s) => s.label === q.label)?.a || '');
  const next = await saveSettings({ humanizer: { onboarded: false, draft: { step: 0, answers: prior } } });
  showStyleStatus(next);
  say('Open the Humanizer in the panel to retake the questions.');
});

document.getElementById('style-clear').addEventListener('click', async () => {
  const next = await saveSettings({ humanizer: { onboarded: false, style: [], draft: { step: 0, answers: [] } } });
  showStyleStatus(next);
  say('Style profile cleared.');
});

function collect() {
  const patch = { modelOverrides: {}, memory: memoryItems.map((m) => m.trim()).filter(Boolean) };
  for (const field of document.querySelectorAll('[data-path]')) {
    const value =
      field.type === 'checkbox' ? field.checked
      : field.type === 'number' ? Number(field.value)
      : field.value.trim();
    write(patch, field.dataset.path, value);
  }
  for (const input of document.querySelectorAll('[data-override]')) {
    patch.modelOverrides[input.dataset.override] = input.value.trim();
  }
  const picked = document.querySelector('input[name="default-model"]:checked');
  if (picked) write(patch, 'prefs.model', picked.value);
  return patch;
}

document.getElementById('save').addEventListener('click', async () => {
  await saveSettings(collect());
  say('Saved.');
  setTimeout(() => say(''), 2200);
});

document.getElementById('reset').addEventListener('click', async () => {
  await chrome.storage.local.set({ settings: DEFAULTS });
  fill(DEFAULTS);
  say('Back to defaults.');
});

document.getElementById('test').addEventListener('click', async () => {
  await saveSettings(collect());
  const settings = await getSettings();
  const groq = groqConfig(settings);
  say('Testing…');

  const lines = [groq.usingPersonalKey ? 'Using your Groq key' : 'Using the built-in Groq key'];
  for (const id of MODEL_ORDER) {
    const config = configForChoice(settings, id);
    const model = chainFor(id, {
      overrides: settings.modelOverrides,
      resolved: settings.resolvedModels
    })[0];
    try {
      const res = await fetch(`${config.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${config.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model, messages: [{ role: 'user', content: 'ping' }], max_tokens: 1 })
      });
      const label = MODELS[id].name.replace('Viora ', '');
      lines.push(`${label} (${config.label}): ${res.ok ? 'ready' : `failed (${res.status})`}`);
    } catch {
      lines.push(`${MODELS[id].name.replace('Viora ', '')} (${config.label}): unreachable`);
    }
  }
  say(lines.join(' · '));
});

document.getElementById('load-models').addEventListener('click', async (e) => {
  const btn = e.currentTarget;
  btn.disabled = true;
  btn.textContent = 'Loading';
  try {
    await saveSettings(collect());
    const settings = await getSettings();
    const models = await listModels({ config: groqConfig(settings) });
    const list = document.getElementById('groq-models');
    list.replaceChildren();
    for (const id of models) {
      const opt = document.createElement('option');
      opt.value = id;
      list.append(opt);
    }
    btn.textContent = `${models.length} models loaded`;
    say('Click any model field above to pick from the live list.');
  } catch (err) {
    btn.textContent = 'Load what Groq is serving now';
    say(err.message);
  } finally {
    btn.disabled = false;
  }
});

fill(await getSettings());
wireMemory();
